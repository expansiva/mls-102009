/// <mls fileReference="_102009_/l1/petshop/layer_2_controllers/router.ts" enhancement="_blank" />
import type { BffHandler } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import {
  petshopGetTopProductsHandler,
  petshopHomeLoadHandler,
  petshopListCatalogHandler,
  petshopSeedMockDataHandler,
} from '/_102009_/l1/petshop/layer_2_controllers/catalogo.js';
import {
  petshopUpdateProductHandler,
} from '/_102009_/l1/petshop/layer_2_controllers/editProducts.js';

export function createPetshopRouter(): Map<string, BffHandler> {
  return new Map<string, BffHandler>([
    ['petshop.home.load', petshopHomeLoadHandler],
    ['petshop.listCatalog', petshopListCatalogHandler],
    ['petshop.getTopProducts', petshopGetTopProductsHandler],
    ['petshop.seedMockData', petshopSeedMockDataHandler],
    ['petshop.updateProduct', petshopUpdateProductHandler],
  ]);
}
