/// <mls fileReference="_102009_/l1/pizzaria/layer_2_controllers/router.ts" enhancement="_blank" />
import type { BffHandler } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import {
  pizzariaGetTopItemsHandler,
  pizzariaHomeLoadHandler,
  pizzariaListMenuHandler,
  pizzariaSeedMockDataHandler,
} from '/_102009_/l1/pizzaria/layer_2_controllers/cardapio.js';
import {
  pizzariaUpdateItemHandler,
} from '/_102009_/l1/pizzaria/layer_2_controllers/editItems.js';
import {
  areaPublicaCheckoutGetResumoCheckoutPublicoHandler,
  areaPublicaCheckoutListarItensPedidoHandler,
  areaPublicaCheckoutListarCombosAtivosHandler,
  areaPublicaCheckoutListarPoliticasCancelamentoAtivasHandler,
} from '/_102009_/l1/pizzaria/layer_2_controllers/areaPublicaCheckout.js';

export function createPizzariaRouter(): Map<string, BffHandler> {
  return new Map<string, BffHandler>([
    ['pizzaria.home.load', pizzariaHomeLoadHandler],
    ['pizzaria.listMenu', pizzariaListMenuHandler],
    ['pizzaria.getTopItems', pizzariaGetTopItemsHandler],
    ['pizzaria.seedMockData', pizzariaSeedMockDataHandler],
    ['pizzaria.updateItem', pizzariaUpdateItemHandler],
    ['pizzaria.getResumoCheckoutPublico', areaPublicaCheckoutGetResumoCheckoutPublicoHandler],
    ['pizzaria.listarItensPedido', areaPublicaCheckoutListarItensPedidoHandler],
    ['pizzaria.listarCombosAtivos', areaPublicaCheckoutListarCombosAtivosHandler],
    ['pizzaria.listarPoliticasCancelamentoAtivas', areaPublicaCheckoutListarPoliticasCancelamentoAtivasHandler],]);
}
