/// <mls shortName="adminDashboard" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';

@customElement('travelagency--admin-dashboard-102009')
export class PageAdminDashboard extends CollabPageElement {
    initPage() {

    }
}