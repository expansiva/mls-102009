/// <mls shortName="organismAddRelationship" project="102009" folder="crm" groupName="crm" enhancement="_blank" />

    // Do not change – automatically generated code.

    export const defs: mls.l4.BaseDefs = {
    "meta": {
        "projectId": 102009,
        "folder": "crm",
        "shortName": "organismAddRelationship",
        "type": "organism",
        "devFidelity": "scaffold",
        "group": "crm",
        "tags": [
        "lit",
        "organism"
        ]
    },
    "references": {
        "widgets": [],
        "plugins": [],
        "statesRO": [],
        "statesRW": [],
        "statesWO": [],
        "imports": []
    },
    "planning": {
        "generalDescription": "",
        "goal": "",
        "userStories": [],
        "userRequestsEnhancements": [],
        "constraints": []
    }
}