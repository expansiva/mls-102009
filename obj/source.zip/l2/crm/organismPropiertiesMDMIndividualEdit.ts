/// <mls shortName="organismPropiertiesMDMIndividualEdit" project="102009" folder="crm" enhancement="_100554_enhancementLit" groupName="crm" />

    import { html } from 'lit';
    import { customElement } from 'lit/decorators.js';
    import { IcaOrganismBase } from '_100554_/l2/icaOrganismBase';

    @customElement('crm--organism-propierties-m-d-m-individual-edit-102009')
    export class organismPropiertiesMDMIndividualEdit extends IcaOrganismBase {
        render(){
            return html`<h3>In developed</h3>`
        }

    }