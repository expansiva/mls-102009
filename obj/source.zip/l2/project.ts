/// <mls shortName="project" project="102009" enhancement="_100554_enhancementLit" groupName="other" folder="" />

export const modules = [
  {
    name: 'petshop'
  }
];