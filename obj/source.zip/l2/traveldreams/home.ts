/// <mls shortName="home" project="102009" folder="traveldreams" enhancement="_100554_enhancementLit" groupName="traveldreams" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';

@customElement('traveldreams--home-102009')
export class PageHome extends CollabPageElement {
    initPage() {

    }
}