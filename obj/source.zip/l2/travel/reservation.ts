/// <mls shortName="reservation" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';

@customElement('travel--reservation-102009')
export class PageReservation extends CollabPageElement {
    initPage() {

    }
}