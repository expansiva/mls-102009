/// <mls shortName="userProfile" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';

@customElement('travel--user-profile-102009')
export class PageUserProfile extends CollabPageElement {
    initPage() {

    }
}