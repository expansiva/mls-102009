/// <mls shortName="organismNav" project="102009" enhancement="_blank" folder="travel" />

 import { ICANTest, ICANIntegration, ICANSchema  } from './_100554_tsTestAST';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];