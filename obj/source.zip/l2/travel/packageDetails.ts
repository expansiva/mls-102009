/// <mls shortName="packageDetails" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';

@customElement('travel--package-details-102009')
export class PagePackageDetails extends CollabPageElement {
    initPage() {

    }
}