/// <mls shortName="login" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';

@customElement('login-102009')
export class _102009_login extends CollabPageElement {
    initPage() {

    }
}