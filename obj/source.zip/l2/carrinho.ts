/// <mls shortName="carrinho" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';

@customElement('carrinho-102009')
export class _102009_carrinho extends CollabPageElement {
    initPage() {

    }
}