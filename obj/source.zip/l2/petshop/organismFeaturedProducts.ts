/// <mls shortName="organismFeaturedProducts" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />

import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { exec } from "./_102019_layer1Exec";
import { MdmRecord, RegistrationDataProduct, MdmType, AttachmentType, RequestMDMGetListByType } from "./_102019_commonGlobal";

@customElement('petshop--organism-featured-products-102009')
export class organismFeaturedProducts extends IcaOrganismBase {

  @state() mdmProducts: MdmRecord[] = [];

  //---------------------------

  async firstUpdated() {
    this.init();
  }

  render() {
    return html`
    <div class="products-container">
      <h2>Produtos em destaque</h2>
      <div class="products-list" id="petshop--featured-products-102009-3">
        ${this.mdmProducts.map((prod, index) => this.renderItem(prod, index))}
      </div>
    </div>
      `
  }

  renderItem(prod: MdmRecord, index: number) {
    if (index > 3) return html``;
    const reg = (prod.details.registrationData as RegistrationDataProduct);
    let img = 'https://images.unsplash.com/photo-1583860332956-0cd934c28cec?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBiZWQlMjBjb21mb3J0YWJsZSUyMGJsdWUlMjBncmVlbnxlbnwwfHx8fDE3NTQ0MTEzMTZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080';

    if (prod.details.attachments && prod.details.attachments.length > 0) {
      prod.details.attachments.forEach((i) => {
        if (i.type === AttachmentType.MEDIA_PROFILE_PIC) img = i.url;
      });
    }

    return html`
      <div class="product-card">
        <div class="product-image">
          <img src="${img}" alt="Caminha confortável para pets">
        </div>
        <div class="product-title">${reg.name}</div>
        <div class="product-price">R$ 50,00</div>
        <div class="product-action">
          <a href="/pageProduct">Comprar</a>
        </div>
      </div>
    `;
  }

  //--------------------------

  private init() {
    this.loadProd();
  }

  private async loadProd() {
    const req: RequestMDMGetListByType = {
      action: 'MDMGetListByType',
      inDeveloped: true,
      version: '1',
      params: { type: MdmType.Produto },
    };

    const response = await exec(req);
    if (response.ok) {
      this.mdmProducts = response.data.map((item: MdmRecord) => {
        const item2: MdmRecord = item;
        return item2;
      });
    }
  }

}