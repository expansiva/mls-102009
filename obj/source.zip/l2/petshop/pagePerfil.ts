/// <mls shortName="pagePerfil" project="102009" enhancement="_100554_enhancementLit" folder="petshop" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';

@customElement('petshop--page-perfil-102009')
export class PagePerfil extends CollabPageElement {
    initPage() {

    }
}