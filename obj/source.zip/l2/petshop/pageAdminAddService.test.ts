/// <mls shortName="pageAdminAddService" project="102009" enhancement="_blank" folder="petshop" />

 import { ICANTest, ICANIntegration, ICANSchema  } from './_100554_tsTestAST';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];