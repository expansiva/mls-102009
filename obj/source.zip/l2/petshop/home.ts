/// <mls shortName="home" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';

@customElement('petshop--home-102009')
export class PageHome extends CollabPageElement {
    initPage() {

    }
}
