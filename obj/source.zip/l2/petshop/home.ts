/// <mls shortName="home" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';
//import { PageAdminPanel } from './_102009_petshop/adminPanel';
//import { PageAdminPanel } from './l2/petshop/adminPanel';

@customElement('petshop--home-102009')
export class PageHome extends CollabPageElement {
    initPage() {

    }
}
