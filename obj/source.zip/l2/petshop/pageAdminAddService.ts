/// <mls shortName="pageAdminAddService" project="102009" enhancement="_100554_enhancementLit" groupName="page" folder="petshop" />

import { CollabPageElement } from '_100554_/l2/collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from '_100554_/l2/collabState';

@customElement('petshop--page-admin-add-service-102009')
export class PageAdminAddService102009 extends CollabPageElement {
    initPage() {
    }
}

