/// <mls shortName="pageContact" project="102009" enhancement="_100554_enhancementLit" folder="petshop" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';

@customElement('petshop--page-contact-102009')
export class PageContact extends CollabPageElement {
    initPage() {

    }
}