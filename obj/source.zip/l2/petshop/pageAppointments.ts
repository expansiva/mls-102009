/// <mls shortName="pageAppointments" project="102009" enhancement="_100554_enhancementLit" folder="petshop" />

import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';

@customElement('petshop--page-appointments-102009')
export class PageAppointments extends CollabPageElement {
    initPage() {

    }
}