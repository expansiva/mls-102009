/// <mls shortName="organismAddToCart" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAddToCart = class _102009_organismAddToCart extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-add-to-cart-102009 .add-to-cart-container{max-width:1200px;margin:var(--spacing-xl) auto 0;padding:0 var(--spacing-md);background-color:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-lg);box-shadow:var(--shadow-sm)}organism-add-to-cart-102009 .quantity-selector{margin-bottom:var(--spacing-lg)}organism-add-to-cart-102009 .quantity-selector label{display:block;font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-xs);color:var(--color-text-normal)}organism-add-to-cart-102009 .quantity-selector .quantity-controls{display:flex;align-items:center;gap:var(--spacing-xs)}organism-add-to-cart-102009 .quantity-selector .quantity-controls .quantity-btn{width:40px;height:40px;border:1px solid var(--color-border);background-color:var(--color-background);color:var(--color-text-normal);border-radius:var(--border-radius-xs);font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-fast)}organism-add-to-cart-102009 .quantity-selector .quantity-controls .quantity-btn:hover{background-color:var(--color-primary);color:white;border-color:var(--color-primary)}organism-add-to-cart-102009 .quantity-selector .quantity-controls .quantity-input{width:80px;height:40px;text-align:center;border:1px solid var(--color-border);border-radius:var(--border-radius-xs);font-size:var(--font-size-md);font-weight:var(--font-weight-bold)}organism-add-to-cart-102009 .quantity-selector .quantity-controls .quantity-input:focus{outline:none;border-color:var(--color-primary)}organism-add-to-cart-102009 .cart-actions{display:flex;gap:var(--spacing-md);margin-bottom:var(--spacing-lg)}@media (max-width:480px){organism-add-to-cart-102009 .cart-actions{flex-direction:column}}organism-add-to-cart-102009 .cart-actions .btn-add-cart{flex:2;background-color:var(--color-primary);color:white;border:none;padding:var(--spacing-md) var(--spacing-lg);border-radius:var(--border-radius-sm);font-size:var(--font-size-md);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-fast);display:flex;align-items:center;justify-content:center;gap:var(--spacing-xs)}organism-add-to-cart-102009 .cart-actions .btn-add-cart:hover{background-color:#1671a0;transform:translateY(-2px);box-shadow:var(--shadow-md)}organism-add-to-cart-102009 .cart-actions .btn-add-cart .cart-icon{font-size:var(--font-size-lg)}organism-add-to-cart-102009 .cart-actions .btn-buy-now{flex:1;background-color:var(--color-accent);color:white;border:none;padding:var(--spacing-md) var(--spacing-lg);border-radius:var(--border-radius-sm);font-size:var(--font-size-md);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-fast)}organism-add-to-cart-102009 .cart-actions .btn-buy-now:hover{background-color:#ed5f07;transform:translateY(-2px);box-shadow:var(--shadow-md)}organism-add-to-cart-102009 .shipping-info{margin-bottom:var(--spacing-lg)}organism-add-to-cart-102009 .shipping-info .shipping-calculator{margin-bottom:var(--spacing-md)}organism-add-to-cart-102009 .shipping-info .shipping-calculator label{display:block;font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-xs);color:var(--color-text-normal)}organism-add-to-cart-102009 .shipping-info .shipping-calculator .cep-input-group{display:flex;gap:var(--spacing-xs)}organism-add-to-cart-102009 .shipping-info .shipping-calculator .cep-input-group .cep-input{flex:1;padding:var(--spacing-sm);border:1px solid var(--color-border);border-radius:var(--border-radius-xs);font-size:var(--font-size-md)}organism-add-to-cart-102009 .shipping-info .shipping-calculator .cep-input-group .cep-input:focus{outline:none;border-color:var(--color-primary)}organism-add-to-cart-102009 .shipping-info .shipping-calculator .cep-input-group .btn-calculate-shipping{background-color:var(--color-secondary);color:white;border:none;padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--border-radius-xs);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-fast)}organism-add-to-cart-102009 .shipping-info .shipping-calculator .cep-input-group .btn-calculate-shipping:hover{background-color:#f29e07}organism-add-to-cart-102009 .shipping-info .shipping-options .shipping-option{display:flex;justify-content:space-between;align-items:center;padding:var(--spacing-sm);background-color:var(--color-background);border:1px solid var(--color-border);border-radius:var(--border-radius-xs);margin-bottom:var(--spacing-xs)}organism-add-to-cart-102009 .shipping-info .shipping-options .shipping-option .shipping-type{font-weight:var(--font-weight-bold);color:var(--color-text-normal)}organism-add-to-cart-102009 .shipping-info .shipping-options .shipping-option .shipping-time{color:var(--color-text-secondary);font-size:var(--font-size-sm)}organism-add-to-cart-102009 .shipping-info .shipping-options .shipping-option .shipping-price{font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-add-to-cart-102009 .product-guarantees{display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:var(--spacing-sm)}organism-add-to-cart-102009 .product-guarantees .guarantee-item{display:flex;align-items:center;gap:var(--spacing-xs);padding:var(--spacing-sm);background-color:var(--color-background);border-radius:var(--border-radius-xs);border:1px solid var(--color-border)}organism-add-to-cart-102009 .product-guarantees .guarantee-item .guarantee-icon{font-size:var(--font-size-lg)}organism-add-to-cart-102009 .product-guarantees .guarantee-item .guarantee-text{font-size:var(--font-size-sm);color:var(--color-text-secondary);font-weight:var(--font-weight-bold)}`);
    }
    render() {
        return html `
    <div class="add-to-cart-container" id="add-to-cart-1">
  <div class="quantity-selector" id="add-to-cart-2">
    <label for="quantity" id="add-to-cart-3">Quantidade:</label>
    <div class="quantity-controls" id="add-to-cart-4">
      <button type="button" class="quantity-btn decrease" onclick="decreaseQuantity()" id="add-to-cart-5">-</button>
      <input type="number" id="quantity" name="quantity" value="1" min="1" max="12" class="quantity-input" />
      <button type="button" class="quantity-btn increase" onclick="increaseQuantity()" id="add-to-cart-6">+</button>
    </div>
  </div>
  <div class="cart-actions" id="add-to-cart-7">
    <button type="button" class="btn-add-cart primary" id="add-to-cart-8">
      <span class="cart-icon" id="add-to-cart-9">🛒</span>
      Adicionar ao Carrinho
    </button>
    <button type="button" class="btn-buy-now secondary" id="add-to-cart-10">
      Comprar Agora
    </button>
  </div>
  <div class="shipping-info" id="add-to-cart-11">
    <div class="shipping-calculator" id="add-to-cart-12">
      <label for="cep" id="add-to-cart-13">Calcular frete:</label>
      <div class="cep-input-group" id="add-to-cart-14">
        <input type="text" id="cep" name="cep" placeholder="00000-000" class="cep-input" />
        <button type="button" class="btn-calculate-shipping" id="add-to-cart-15">Calcular</button>
      </div>
    </div>
    <div class="shipping-options" style="display: none;" id="add-to-cart-16">
      <div class="shipping-option" id="add-to-cart-17">
        <span class="shipping-type" id="add-to-cart-18">Entrega Padrão</span>
        <span class="shipping-time" id="add-to-cart-19">5-7 dias úteis</span>
        <span class="shipping-price" id="add-to-cart-20">R$ 15,90</span>
      </div>
      <div class="shipping-option" id="add-to-cart-21">
        <span class="shipping-type" id="add-to-cart-22">Entrega Expressa</span>
        <span class="shipping-time" id="add-to-cart-23">2-3 dias úteis</span>
        <span class="shipping-price" id="add-to-cart-24">R$ 25,90</span>
      </div>
    </div>
  </div>
  <div class="product-guarantees" id="add-to-cart-25">
    <div class="guarantee-item" id="add-to-cart-26">
      <span class="guarantee-icon" id="add-to-cart-27">🔒</span>
      <span class="guarantee-text" id="add-to-cart-28">Compra 100% segura</span>
    </div>
    <div class="guarantee-item" id="add-to-cart-29">
      <span class="guarantee-icon" id="add-to-cart-30">↩️</span>
      <span class="guarantee-text" id="add-to-cart-31">7 dias para troca</span>
    </div>
    <div class="guarantee-item" id="add-to-cart-32">
      <span class="guarantee-icon" id="add-to-cart-33">🚚</span>
      <span class="guarantee-text" id="add-to-cart-34">Frete grátis acima de R$ 99</span>
    </div>
  </div>
</div>

    `;
    }
};
_102009_organismAddToCart = __decorate([
    customElement('organism-add-to-cart-102009')
], _102009_organismAddToCart);
export { _102009_organismAddToCart };
