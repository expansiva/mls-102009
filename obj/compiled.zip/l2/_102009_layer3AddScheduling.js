/// <mls shortName="layer3AddScheduling" project="102009" enhancement="_blank" />
export async function addScheduling(ctx, data) {
    data.id = Date.now().toString();
    return await ctx.io.scheduling.add(data);
}
