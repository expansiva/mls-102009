/// <mls shortName="layer3AddScheduling" project="102009" enhancement="_blank" />
export async function addScheduling(ctx, data) {
    return await ctx.io.scheduling.add(data);
}
