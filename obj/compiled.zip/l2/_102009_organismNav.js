/// <mls shortName="organismNav" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismNav = class _102009_organismNav extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-nav-102009 .navbar{background-color:white;box-shadow:var(--shadow-sm);position:sticky;top:0;z-index:var(--z-index-dropdown)}organism-nav-102009 .nav-container{max-width:1200px;margin:0 auto;padding:0 var(--spacing-md);display:flex;justify-content:space-between;align-items:center;height:70px}organism-nav-102009 .nav-brand{display:flex;align-items:center;gap:var(--spacing-sm)}organism-nav-102009 .nav-brand .logo{height:40px;width:auto}organism-nav-102009 .nav-brand .brand-name{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-nav-102009 .nav-menu{display:flex;list-style:none;margin:0;padding:0;gap:var(--spacing-lg)}organism-nav-102009 .nav-menu .nav-link{text-decoration:none;color:var(--color-text-normal);font-weight:var(--font-weight-normal);transition:var(--transition-base);padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs)}organism-nav-102009 .nav-menu .nav-link:hover,organism-nav-102009 .nav-menu .nav-link.active{color:var(--color-primary);background-color:var(--color-overlay)}organism-nav-102009 .nav-menu .nav-link.login-btn{background-color:var(--color-primary);color:white}organism-nav-102009 .nav-menu .nav-link.login-btn:hover{background-color:var(--color-link-visited)}organism-nav-102009 .nav-toggle{display:none;flex-direction:column;cursor:pointer}organism-nav-102009 .nav-toggle .bar{width:25px;height:3px;background-color:var(--color-primary);margin:3px 0;transition:var(--transition-fast)}@media (max-width:768px){organism-nav-102009 .nav-menu{display:none}organism-nav-102009 .nav-toggle{display:flex}}`);
    }
    render() {
        return html `
      <nav class="navbar">
        <div class="nav-container">
          <div class="nav-brand">
            <img src="https://images.unsplash.com/photo-1704657198645-6dd792478814?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBzaG9wJTIwbG9nbyUyMHBhdyUyMHByaW50fGVufDB8fHx8MTc1MzM2NTA1OHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="PetShop Logo" class="logo">
            <span class="brand-name">PetShop</span>
          </div>
          <ul class="nav-menu">
            <li class="nav-item"><a href="#" class="nav-link active">Home</a></li>
            <li class="nav-item"><a href="#" class="nav-link">Serviços</a></li>
            <li class="nav-item"><a href="#" class="nav-link">Loja</a></li>
            <li class="nav-item"><a href="#" class="nav-link">Agendamento</a></li>
            <li class="nav-item"><a href="#" class="nav-link">Perfil</a></li>
            <li class="nav-item"><a href="#" class="nav-link login-btn">Login</a></li>
          </ul>
          <div class="nav-toggle">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
          </div>
        </div>
      </nav>
    `;
    }
};
_102009_organismNav = __decorate([
    customElement('organism-nav-102009')
], _102009_organismNav);
export { _102009_organismNav };
