/// <mls shortName="organismPaymentMethods" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismPaymentMethods = class _102009_organismPaymentMethods extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-payment-methods-102009 .payment-methods-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-lg);box-shadow:var(--shadow-sm)}organism-payment-methods-102009 .payment-methods-container h2{color:var(--color-primary);font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-lg);text-align:center}organism-payment-methods-102009 .payment-methods-container .payment-options{margin-bottom:var(--spacing-lg)}organism-payment-methods-102009 .payment-methods-container .payment-option{margin-bottom:var(--spacing-md)}organism-payment-methods-102009 .payment-methods-container .payment-option input[type="radio"]{display:none}organism-payment-methods-102009 .payment-methods-container .payment-option input[type="radio"]:checked+.payment-label{border-color:var(--color-primary);background-color:var(--color-overlay)}organism-payment-methods-102009 .payment-methods-container .payment-option .payment-label{display:flex;align-items:center;padding:var(--spacing-md);border:2px solid var(--color-border);border-radius:var(--border-radius-sm);cursor:pointer;transition:var(--transition-base)}organism-payment-methods-102009 .payment-methods-container .payment-option .payment-label:hover{border-color:var(--color-primary)}organism-payment-methods-102009 .payment-methods-container .payment-option .payment-label .payment-icon{width:48px;height:48px;margin-right:var(--spacing-md)}organism-payment-methods-102009 .payment-methods-container .payment-option .payment-label .payment-icon img{width:100%;height:100%;object-fit:contain}organism-payment-methods-102009 .payment-methods-container .payment-option .payment-label .payment-info h3{color:var(--color-text-normal);font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-xs)}organism-payment-methods-102009 .payment-methods-container .payment-option .payment-label .payment-info p{color:var(--color-text-secondary);font-size:var(--font-size-sm);margin:0}organism-payment-methods-102009 .payment-methods-container .payment-details{padding:var(--spacing-lg);background:var(--color-background);border-radius:var(--border-radius-sm);border:1px solid var(--color-border)}organism-payment-methods-102009 .payment-methods-container .payment-details h3{color:var(--color-text-normal);font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-md)}organism-payment-methods-102009 .payment-methods-container .payment-details .form-row{display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-md);margin-bottom:var(--spacing-md)}organism-payment-methods-102009 .payment-methods-container .payment-details .form-row:first-child,organism-payment-methods-102009 .payment-methods-container .payment-details .form-row:nth-child(2){grid-template-columns:1fr}@media (max-width:480px){organism-payment-methods-102009 .payment-methods-container .payment-details .form-row{grid-template-columns:1fr}}organism-payment-methods-102009 .payment-methods-container .payment-details .form-group{display:flex;flex-direction:column}organism-payment-methods-102009 .payment-methods-container .payment-details .form-group label{color:var(--color-text-normal);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-xs);font-size:var(--font-size-sm)}organism-payment-methods-102009 .payment-methods-container .payment-details .form-group input{padding:var(--spacing-sm);border:2px solid var(--color-border);border-radius:var(--border-radius-sm);font-size:var(--font-size-md);transition:var(--transition-base)}organism-payment-methods-102009 .payment-methods-container .payment-details .form-group input:focus{outline:none;border-color:var(--color-primary);box-shadow:0 0 0 3px rgba(28,145,205,0.1)}`);
    }
    render() {
        return html `
      <div class="payment-methods-container" id="payment-methods-1">
  <h2 id="payment-methods-2">Forma de Pagamento</h2>
  <div class="payment-options" id="payment-methods-3">
    <div class="payment-option" id="payment-methods-4">
      <input type="radio" id="payment-methods-5" name="payment" value="credit-card" checked="">
      <label for="payment-methods-5" class="payment-label" id="payment-methods-6">
        <div class="payment-icon" id="payment-methods-7">
          <img src="https://images.unsplash.com/photo-1600693616179-fa8eb243ce48?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxjcmVkaXQlMjBjYXJkJTIwaWNvbiUyMHBheW1lbnQlMjBtZXRob2R8ZW58MHx8fHwxNzUzMzY1NzU3fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Cartão de Crédito" id="payment-methods-8">
        </div>
        <div class="payment-info" id="payment-methods-9">
          <h3 id="payment-methods-10">Cartão de Crédito</h3>
          <p id="payment-methods-11">Visa, Mastercard, Elo</p>
        </div>
      </label>
    </div>

    <div class="payment-option" id="payment-methods-12">
      <input type="radio" id="payment-methods-13" name="payment" value="pix">
      <label for="payment-methods-13" class="payment-label" id="payment-methods-14">
        <div class="payment-icon" id="payment-methods-15">
          <img src="https://images.unsplash.com/photo-1643455464171-aaaaa1042fc8?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwaXglMjBwYXltZW50JTIwaWNvbiUyMGJyYXppbHxlbnwwfHx8fDE3NTMzMDEyNTh8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="PIX" id="payment-methods-16">
        </div>
        <div class="payment-info" id="payment-methods-17">
          <h3 id="payment-methods-18">PIX</h3>
          <p id="payment-methods-19">Pagamento instantâneo</p>
        </div>
      </label>
    </div>

    <div class="payment-option" id="payment-methods-20">
      <input type="radio" id="payment-methods-21" name="payment" value="boleto">
      <label for="payment-methods-21" class="payment-label" id="payment-methods-22">
        <div class="payment-icon" id="payment-methods-23">
          <img src="https://images.unsplash.com/photo-1689673476137-048bb19d7c20?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxiYW5rJTIwc2xpcCUyMGJvbGV0byUyMGljb24lMjBicmF6aWx8ZW58MHx8fHwxNzUzMzY1NzU4fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Boleto" id="payment-methods-24">
        </div>
        <div class="payment-info" id="payment-methods-25">
          <h3 id="payment-methods-26">Boleto Bancário</h3>
          <p id="payment-methods-27">Vencimento em 3 dias úteis</p>
        </div>
      </label>
    </div>
  </div>

  <div class="payment-details" id="payment-methods-28">
    <h3 id="payment-methods-29">Dados do Cartão</h3>
    <div class="form-row" id="payment-methods-30">
      <div class="form-group" id="payment-methods-31">
        <label for="card-number" id="payment-methods-32">Número do Cartão *</label>
        <input type="text" id="payment-methods-33" name="card-number" placeholder="0000 0000 0000 0000">
      </div>
    </div>
    <div class="form-row" id="payment-methods-34">
      <div class="form-group" id="payment-methods-35">
        <label for="card-name" id="payment-methods-36">Nome no Cartão *</label>
        <input type="text" id="payment-methods-37" name="card-name">
      </div>
    </div>
    <div class="form-row" id="payment-methods-38">
      <div class="form-group" id="payment-methods-39">
        <label for="card-expiry" id="payment-methods-40">Validade *</label>
        <input type="text" id="payment-methods-41" name="card-expiry" placeholder="MM/AA">
      </div>
      <div class="form-group" id="payment-methods-42">
        <label for="card-cvv" id="payment-methods-43">CVV *</label>
        <input type="text" id="payment-methods-44" name="card-cvv" placeholder="123">
      </div>
    </div>
  </div>
</div>

    `;
    }
};
_102009_organismPaymentMethods = __decorate([
    customElement('organism-payment-methods-102009')
], _102009_organismPaymentMethods);
export { _102009_organismPaymentMethods };
