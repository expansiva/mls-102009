/// <mls shortName="layer3DelScheduling" project="102009" enhancement="_blank" />
export async function delScheduling(ctx, id) {
    return await ctx.io.scheduling.del(id);
}
