/// <mls shortName="layer3GetByClientScheduling" project="102009" enhancement="_blank" />
export async function getByClientScheduling(ctx, clientId) {
    return await ctx.io.scheduling.listByClient(clientId);
}
