/// <mls shortName="organismAdminProducts" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAdminProducts = class _102009_organismAdminProducts extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-admin-products-102009 .admin-section{background-color:var(--color-background);border-radius:var(--border-radius-md);padding:var(--spacing-lg);margin-bottom:var(--spacing-lg);box-shadow:var(--shadow-sm)}organism-admin-products-102009 .admin-section .section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-lg)}organism-admin-products-102009 .admin-section .section-header h2{color:var(--color-text-normal);font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);margin:0}organism-admin-products-102009 .admin-section .section-header .add-product-btn{background-color:var(--color-primary);color:white;border:none;padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--border-radius-sm);cursor:pointer;font-weight:var(--font-weight-bold);transition:var(--transition-base)}organism-admin-products-102009 .admin-section .section-header .add-product-btn:hover{background-color:var(--color-link-hover)}organism-admin-products-102009 .admin-section .products-table{overflow-x:auto}organism-admin-products-102009 .admin-section .products-table table{width:100%;border-collapse:collapse}organism-admin-products-102009 .admin-section .products-table table th,organism-admin-products-102009 .admin-section .products-table table td{padding:var(--spacing-sm) var(--spacing-md);text-align:left;border-bottom:1px solid var(--color-border)}organism-admin-products-102009 .admin-section .products-table table th{background-color:var(--color-surface);font-weight:var(--font-weight-bold);color:var(--color-text-normal)}organism-admin-products-102009 .admin-section .products-table table .product-thumb{width:50px;height:50px;object-fit:cover;border-radius:var(--border-radius-xs)}organism-admin-products-102009 .admin-section .products-table table .stock-low{color:var(--color-warning);font-weight:var(--font-weight-bold)}organism-admin-products-102009 .admin-section .products-table table .stock-ok{color:var(--color-success);font-weight:var(--font-weight-bold)}organism-admin-products-102009 .admin-section .products-table table .stock-out{color:var(--color-error);font-weight:var(--font-weight-bold)}organism-admin-products-102009 .admin-section .products-table table .status-active{background-color:var(--color-success);color:white;padding:var(--spacing-xxs) var(--spacing-xs);border-radius:var(--border-radius-xs);font-size:var(--font-size-xs)}organism-admin-products-102009 .admin-section .products-table table .status-inactive{background-color:var(--color-error);color:white;padding:var(--spacing-xxs) var(--spacing-xs);border-radius:var(--border-radius-xs);font-size:var(--font-size-xs)}organism-admin-products-102009 .admin-section .products-table table .btn-edit,organism-admin-products-102009 .admin-section .products-table table .btn-delete{padding:var(--spacing-xxs) var(--spacing-xs);border:none;border-radius:var(--border-radius-xs);cursor:pointer;font-size:var(--font-size-xs);margin-right:var(--spacing-xxs);transition:var(--transition-base)}organism-admin-products-102009 .admin-section .products-table table .btn-edit{background-color:var(--color-secondary);color:white}organism-admin-products-102009 .admin-section .products-table table .btn-edit:hover{opacity:.9}organism-admin-products-102009 .admin-section .products-table table .btn-delete{background-color:var(--color-error);color:white}organism-admin-products-102009 .admin-section .products-table table .btn-delete:hover{opacity:.9}`);
    }
    render() {
        return html `
      <section class="admin-section">
        <div class="section-header">
          <h2>Gerenciar Produtos</h2>
          <button class="btn-primary add-product-btn">+ Adicionar Produto</button>
        </div>
        
        <div class="products-table">
          <table>
            <thead>
              <tr>
                <th>Imagem</th>
                <th>Nome</th>
                <th>Categoria</th>
                <th>Preço</th>
                <th>Estoque</th>
                <th>Status</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><img src="https://images.unsplash.com/photo-1708746333832-9a8cde4a0cfa?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwZG9nJTIwZm9vZCUyMGJhZyUyMGtpYmJsZXxlbnwwfHx8fDE3NTMyOTIxMjB8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Ração Premium" class="product-thumb"></td>
                <td>Ração Premium Cães Adultos</td>
                <td>Ração</td>
                <td>R$ 89,90</td>
                <td class="stock-low">5</td>
                <td><span class="status-active">Ativo</span></td>
                <td>
                  <button class="btn-edit">Editar</button>
                  <button class="btn-delete">Excluir</button>
                </td>
              </tr>
              <tr>
                <td><img src="https://images.unsplash.com/photo-1659692679040-5356d677d897?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjByb3BlJTIwdG95JTIwY29sb3JmdWwlMjBwbGF5fGVufDB8fHx8MTc1MzM2NTk5M3ww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Brinquedo" class="product-thumb"></td>
                <td>Brinquedo Corda</td>
                <td>Brinquedos</td>
                <td>R$ 24,90</td>
                <td class="stock-ok">25</td>
                <td><span class="status-active">Ativo</span></td>
                <td>
                  <button class="btn-edit">Editar</button>
                  <button class="btn-delete">Excluir</button>
                </td>
              </tr>
              <tr>
                <td><img src="https://images.unsplash.com/photo-1587291086390-69a3af40cf0b?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBzaGFtcG9vJTIwYm90dGxlJTIwbmV1dHJhbCUyMGh5Z2llbmV8ZW58MHx8fHwxNzUzMzY1OTkzfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Shampoo" class="product-thumb"></td>
                <td>Shampoo Neutro</td>
                <td>Higiene</td>
                <td>R$ 32,50</td>
                <td class="stock-out">0</td>
                <td><span class="status-inactive">Inativo</span></td>
                <td>
                  <button class="btn-edit">Editar</button>
                  <button class="btn-delete">Excluir</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    `;
    }
};
_102009_organismAdminProducts = __decorate([
    customElement('organism-admin-products-102009')
], _102009_organismAdminProducts);
export { _102009_organismAdminProducts };
