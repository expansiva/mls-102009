/// <mls shortName="layer3GetByIdServiceOrder" project="102009" enhancement="_blank" />
export async function getByIdServiceOrder(ctx, id) {
    const record = await ctx.io.petshopDB.serviceOrder.getById(id);
    if (record.data) {
    }
    return record;
}
