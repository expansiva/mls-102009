/// <mls shortName="layer3GetByIdServiceOrder" project="102009" enhancement="_blank" />
export async function getByIdServiceOrder(ctx, id) {
    return await ctx.io.serviceOrder.getById(id);
}
