/// <mls shortName="organismReservationForm" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismReservationForm = class organismReservationForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-reservation-form-102009{display:block;width:100%;max-width:520px;margin:0 auto;background:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 8px rgba(211,211,211,0.1);padding:var(--space-32) var(--space-24);margin-bottom:var(--space-32)}travel--organism-reservation-form-102009 .reservation-form-section{width:100%}travel--organism-reservation-form-102009 .form-title{font-family:var(--font-family-primary);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color-darker);margin-bottom:var(--space-24);line-height:var(--line-height-large)}travel--organism-reservation-form-102009 form.reservation-form{display:flex;flex-direction:column;gap:var(--space-24)}travel--organism-reservation-form-102009 fieldset{border:none;padding:0;margin:0 0 var(--space-16) 0}travel--organism-reservation-form-102009 .section-legend{font-size:var(--font-size-16);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-8)}travel--organism-reservation-form-102009 .form-group{display:flex;flex-direction:column;margin-bottom:var(--space-16)}travel--organism-reservation-form-102009 .form-group label{font-size:var(--font-size-16);color:var(--text-primary-color-darker);margin-bottom:var(--space-8)}travel--organism-reservation-form-102009 .form-group input,travel--organism-reservation-form-102009 .form-group select{font-family:var(--font-family-primary);font-size:var(--font-size-16);padding:var(--space-8) var(--space-16);border:1px solid var(--grey-color-dark);border-radius:4px;background:var(--bg-primary-color-lighter);color:var(--text-primary-color-darker);transition:border-color var(--transition-slow)}travel--organism-reservation-form-102009 .form-group input:focus,travel--organism-reservation-form-102009 .form-group select:focus{border-color:var(--text-primary-color);outline:none}travel--organism-reservation-form-102009 .form-actions{display:flex;justify-content:flex-end;margin-top:var(--space-16)}travel--organism-reservation-form-102009 .form-actions .pay-btn{display:flex;align-items:center;gap:var(--space-8);background:var(--bg-secondary-color);color:var(--bg-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);border:none;border-radius:4px;padding:var(--space-8) var(--space-24);cursor:pointer;transition:background var(--transition-slow)}travel--organism-reservation-form-102009 .form-actions .pay-btn .mp-logo{height:24px;width:24px}travel--organism-reservation-form-102009 .form-actions .pay-btn:hover,travel--organism-reservation-form-102009 .form-actions .pay-btn:focus{background:var(--bg-secondary-color-hover)}travel--organism-reservation-form-102009 .form-actions .pay-btn:active{background:var(--bg-secondary-color-focus)}travel--organism-reservation-form-102009 .form-actions .pay-btn:disabled{background:var(--bg-secondary-color-disabled);cursor:not-allowed}@media (max-width:544px){travel--organism-reservation-form-102009{padding:var(--space-16) var(--space-8)}travel--organism-reservation-form-102009 .form-title{font-size:var(--font-size-20)}}`);
    }
    render() {
        return html `<section class="reservation-form-section" aria-labelledby="reservation-form-title" id="travel--reservation-form-102009-1">
        <h1 id="reservation-form-title" class="form-title">Reserve seu pacote</h1>
        <form class="reservation-form" autocomplete="off" id="travel--reservation-form-102009-2">
          <fieldset class="personal-info" id="travel--reservation-form-102009-3">
            <legend class="section-legend" id="travel--reservation-form-102009-4">Dados pessoais</legend>
            <div class="form-group" id="travel--reservation-form-102009-5">
              <label for="reservation-name" id="travel--reservation-form-102009-6">Nome completo</label>
              <input type="text" id="reservation-name" name="name" required="" placeholder="Seu nome" autocomplete="name">
            </div>
            <div class="form-group" id="travel--reservation-form-102009-7">
              <label for="reservation-email" id="travel--reservation-form-102009-8">E-mail</label>
              <input type="email" id="reservation-email" name="email" required="" placeholder="seu@email.com" autocomplete="email">
            </div>
            <div class="form-group" id="travel--reservation-form-102009-9">
              <label for="reservation-phone" id="travel--reservation-form-102009-10">Telefone</label>
              <input type="tel" id="reservation-phone" name="phone" required="" placeholder="(99) 99999-9999" autocomplete="tel">
            </div>
          </fieldset>
          <fieldset class="package-info" id="travel--reservation-form-102009-11">
            <legend class="section-legend" id="travel--reservation-form-102009-12">Detalhes da reserva</legend>
            <div class="form-group" id="travel--reservation-form-102009-13">
              <label for="reservation-package" id="travel--reservation-form-102009-14">Pacote</label>
              <select id="reservation-package" name="package" required="">
                <option value="" id="travel--reservation-form-102009-15">Selecione um pacote</option>
                <option value="1" id="travel--reservation-form-102009-16">Praias do Nordeste</option>
                <option value="2" id="travel--reservation-form-102009-17">Aventura na Amazônia</option>
                <option value="3" id="travel--reservation-form-102009-18">Cultura em Minas Gerais</option>
              </select>
            </div>
            <div class="form-group" id="travel--reservation-form-102009-19">
              <label for="reservation-date" id="travel--reservation-form-102009-20">Data de início</label>
              <input type="date" id="reservation-date" name="start_date" required="">
            </div>
            <div class="form-group" id="travel--reservation-form-102009-21">
              <label for="reservation-people" id="travel--reservation-form-102009-22">Quantidade de pessoas</label>
              <input type="number" id="reservation-people" name="people" min="1" max="20" value="1" required="">
            </div>
          </fieldset>
          <div class="form-actions" id="travel--reservation-form-102009-23">
            <button type="submit" class="pay-btn" aria-label="Pagar com Mercado Pago" id="travel--reservation-form-102009-24">
              <img src="https://images.unsplash.com/photo-1637489981573-e45e9297cb21?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxNZXJjYWRvJTIwUGFnbyUyMGxvZ298ZW58MHx8fHwxNzU1MDMxNTcwfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Mercado Pago" class="mp-logo" id="travel--reservation-form-102009-25">
              Pagar com Mercado Pago
            </button>
          </div>
        </form>
      </section>
    `;
    }
};
organismReservationForm = __decorate([
    customElement('travel--organism-reservation-form-102009')
], organismReservationForm);
export { organismReservationForm };
