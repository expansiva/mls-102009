/// <mls shortName="organismFooterInfo" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismFooterInfo = class organismFooterInfo extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-footer-info-102009 .footer-info{background:var(--bg-primary-color-darker);color:var(--text-primary-color-darker);padding:var(--space-32) 0 var(--space-16) 0;font-family:var(--font-family-primary);border-top:1px solid var(--grey-color);margin-top:var(--space-32)}travel--organism-footer-info-102009 .footer-info__main{display:flex;align-items:flex-start;justify-content:space-between;gap:var(--space-32);max-width:1200px;margin:0 auto var(--space-16) auto;flex-wrap:wrap}@media (max-width:768px){travel--organism-footer-info-102009 .footer-info__main{flex-direction:column;gap:var(--space-16);align-items:flex-start}}travel--organism-footer-info-102009 .footer-info__brand{display:flex;flex-direction:column;align-items:flex-start;gap:var(--space-8)}travel--organism-footer-info-102009 .footer-info__logo{height:36px;width:auto;margin-bottom:var(--space-8)}travel--organism-footer-info-102009 .footer-info__slogan{font-size:var(--font-size-16);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold)}travel--organism-footer-info-102009 .footer-info__contacts{display:flex;flex-direction:column;gap:var(--space-8);font-size:var(--font-size-16)}travel--organism-footer-info-102009 .footer-info__contact{color:var(--text-primary-color-darker)}travel--organism-footer-info-102009 .footer-info__social{display:flex;gap:var(--space-16);margin-top:var(--space-8)}travel--organism-footer-info-102009 .footer-info__social-link{display:inline-block}travel--organism-footer-info-102009 .footer-info__social-link img{width:28px;height:28px;filter:grayscale(.2);transition:filter var(--transition-normal)}travel--organism-footer-info-102009 .footer-info__social-link:hover img,travel--organism-footer-info-102009 .footer-info__social-link:focus img{filter:grayscale(0) brightness(1.2);outline:none}travel--organism-footer-info-102009 .footer-info__links{display:flex;gap:var(--space-24);justify-content:center;margin:var(--space-16) 0}travel--organism-footer-info-102009 .footer-info__links a{color:var(--text-primary-color);text-decoration:none;font-size:var(--font-size-16)}travel--organism-footer-info-102009 .footer-info__links a:hover,travel--organism-footer-info-102009 .footer-info__links a:focus{color:var(--text-primary-color-hover);text-decoration:underline;outline:none}travel--organism-footer-info-102009 .footer-info__copyright{text-align:center;color:var(--grey-color-darker);font-size:var(--font-size-12);margin-top:var(--space-8)}`);
    }
    render() {
        return html `<footer class="footer-info" aria-label="Informações do rodapé" id="travel--footer-info-102009-1">
        <div class="footer-info__main" id="travel--footer-info-102009-2">
          <div class="footer-info__brand" id="travel--footer-info-102009-3">
            <img src="https://images.unsplash.com/photo-1504542982118-59308b40fe0c?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxsb2dvJTIwYWclQzMlQUFuY2lhJTIwZGUlMjB2aWFnZW5zJTIwdHJhdmVsfGVufDB8fHx8MTc1NTAyODI3MHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Logo Travel" class="footer-info__logo" id="travel--footer-info-102009-4">
            <span class="footer-info__slogan" id="travel--footer-info-102009-5">Sua viagem, nosso compromisso.</span>
          </div>
          <div class="footer-info__contacts" id="travel--footer-info-102009-6">
            <span class="footer-info__contact" id="travel--footer-info-102009-7"><strong id="travel--footer-info-102009-8">Telefone:</strong> (11) 99999-9999</span>
            <span class="footer-info__contact" id="travel--footer-info-102009-9"><strong id="travel--footer-info-102009-10">E-mail:</strong> contato@travel.com.br</span>
          </div>
          <div class="footer-info__social" id="travel--footer-info-102009-11">
            <a href="#" class="footer-info__social-link" aria-label="Instagram Travel" id="travel--footer-info-102009-12">
              <img src="https://images.unsplash.com/photo-1496076977604-c07450d07690?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHwlQzMlQURjb25lJTIwaW5zdGFncmFtfGVufDB8fHx8MTc1NTAyNTE0N3ww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Instagram" id="travel--footer-info-102009-13">
            </a>
            <a href="#" class="footer-info__social-link" aria-label="Facebook Travel" id="travel--footer-info-102009-14">
              <img src="https://images.unsplash.com/photo-1553379027-34913cb52c1a?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHwlQzMlQURjb25lJTIwZmFjZWJvb2t8ZW58MHx8fHwxNzU1MDI1MTQ3fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Facebook" id="travel--footer-info-102009-15">
            </a>
            <a href="#" class="footer-info__social-link" aria-label="WhatsApp Travel" id="travel--footer-info-102009-16">
              <img src="https://images.unsplash.com/photo-1604228852344-461c83473c89?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHwlQzMlQURjb25lJTIwd2hhdHNhcHB8ZW58MHx8fHwxNzU1MDI4Mjc5fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="WhatsApp" id="travel--footer-info-102009-17">
            </a>
          </div>
        </div>
        <div class="footer-info__links" id="travel--footer-info-102009-18">
          <a href="/politica-privacidade" class="footer-info__link" id="travel--footer-info-102009-19">Política de Privacidade</a>
          <a href="/termos-uso" class="footer-info__link" id="travel--footer-info-102009-20">Termos de Uso</a>
        </div>
        <div class="footer-info__copyright" id="travel--footer-info-102009-21">
          © 2025 Travel Agência de Viagens. Todos os direitos reservados.
        </div>
      </footer>
    `;
    }
};
organismFooterInfo = __decorate([
    customElement('travel--organism-footer-info-102009')
], organismFooterInfo);
export { organismFooterInfo };
