/// <mls shortName="userProfile" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageUserProfile = class PageUserProfile extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--user-profile-102009{display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color-lighter)}travel--user-profile-102009 header{width:100%;background:var(--bg-primary-color);box-shadow:0 2px 8px rgba(211,211,211,0.08);z-index:10}travel--user-profile-102009 main.layout{flex:1;display:flex;flex-direction:column;align-items:center;gap:var(--space-40);padding:var(--space-40) 0}@media (max-width:768px){travel--user-profile-102009 main.layout{padding:var(--space-24) 0;gap:var(--space-24)}}travel--user-profile-102009 footer{width:100%;background:var(--bg-primary-color);margin-top:auto}`);
    }
    initPage() {
    }
};
PageUserProfile = __decorate([
    customElement('travel--user-profile-102009')
], PageUserProfile);
export { PageUserProfile };
