/// <mls shortName="organismFilterPanel" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismFilterPanel = class organismFilterPanel extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-filter-panel-102009{display:block;background:var(--bg-primary-color-lighter);padding:var(--space-24);border-radius:var(--space-16);box-shadow:0 2px 8px rgba(230,230,230,0.2);min-width:220px;max-width:320px}travel--organism-filter-panel-102009 .filter-form{display:flex;flex-direction:column;gap:var(--space-24)}travel--organism-filter-panel-102009 .filter-group{border:none;margin:0;padding:0;display:flex;flex-direction:column;gap:var(--space-8)}travel--organism-filter-panel-102009 .filter-title{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);color:var(--text-primary-color-darker);margin-bottom:var(--space-8)}travel--organism-filter-panel-102009 .filter-range{display:flex;gap:var(--space-8);align-items:center}travel--organism-filter-panel-102009 .filter-range label{font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}travel--organism-filter-panel-102009 .filter-range input[type=number]{width:80px;padding:var(--space-8);border:1px solid var(--grey-color-dark);border-radius:var(--space-8);font-size:var(--font-size-16);background:var(--bg-primary-color);color:var(--text-primary-color-darker);transition:border-color var(--transition-normal)}travel--organism-filter-panel-102009 .filter-range input[type=number]:focus{border-color:var(--text-primary-color);outline:none}travel--organism-filter-panel-102009 select{padding:var(--space-8);border-radius:var(--space-8);border:1px solid var(--grey-color-dark);font-size:var(--font-size-16);background:var(--bg-primary-color);color:var(--text-primary-color-darker);transition:border-color var(--transition-normal)}travel--organism-filter-panel-102009 select:focus{border-color:var(--text-primary-color);outline:none}travel--organism-filter-panel-102009 .filter-checkboxes{display:flex;flex-direction:column;gap:var(--space-8)}travel--organism-filter-panel-102009 .filter-checkboxes label{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);cursor:pointer}travel--organism-filter-panel-102009 .filter-checkboxes label input[type=checkbox]{margin-right:var(--space-8)}travel--organism-filter-panel-102009 .filter-submit{margin-top:var(--space-16);padding:var(--space-8) var(--space-24);background:var(--bg-secondary-color);color:var(--bg-primary-color);border:none;border-radius:var(--space-8);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-normal)}travel--organism-filter-panel-102009 .filter-submit:hover,travel--organism-filter-panel-102009 .filter-submit:focus{background:var(--bg-secondary-color-hover);outline:none}@media (max-width:768px){organism-filter-panel{padding:var(--space-16);min-width:0;max-width:100%}}`);
    }
    render() {
        return html `<form class="filter-form" aria-label="Filtrar pacotes de viagem" id="travel--filter-panel-102009-1">
          <fieldset class="filter-group" id="travel--filter-panel-102009-2">
            <legend class="filter-title" id="travel--filter-panel-102009-3">Preço</legend>
            <div class="filter-range" id="travel--filter-panel-102009-4">
              <label for="preco-min" id="travel--filter-panel-102009-5">Mínimo</label>
              <input type="number" id="preco-min" name="preco-min" min="0" placeholder="R$ 0">
              <label for="preco-max" id="travel--filter-panel-102009-6">Máximo</label>
              <input type="number" id="preco-max" name="preco-max" min="0" placeholder="R$ 10.000">
            </div>
          </fieldset>
          <fieldset class="filter-group" id="travel--filter-panel-102009-7">
            <legend class="filter-title" id="travel--filter-panel-102009-8">Destino</legend>
            <select name="destino" id="destino">
              <option value="" id="travel--filter-panel-102009-9">Todos</option>
              <option value="rio" id="travel--filter-panel-102009-10">Rio de Janeiro</option>
              <option value="salvador" id="travel--filter-panel-102009-11">Salvador</option>
              <option value="gramado" id="travel--filter-panel-102009-12">Gramado</option>
              <option value="florianopolis" id="travel--filter-panel-102009-13">Florianópolis</option>
            </select>
          </fieldset>
          <fieldset class="filter-group" id="travel--filter-panel-102009-14">
            <legend class="filter-title" id="travel--filter-panel-102009-15">Duração</legend>
            <select name="duracao" id="duracao">
              <option value="" id="travel--filter-panel-102009-16">Todas</option>
              <option value="1-3" id="travel--filter-panel-102009-17">1-3 dias</option>
              <option value="4-7" id="travel--filter-panel-102009-18">4-7 dias</option>
              <option value="8-14" id="travel--filter-panel-102009-19">8-14 dias</option>
              <option value="15+" id="travel--filter-panel-102009-20">15+ dias</option>
            </select>
          </fieldset>
          <fieldset class="filter-group" id="travel--filter-panel-102009-21">
            <legend class="filter-title" id="travel--filter-panel-102009-22">Tipo de pacote</legend>
            <div class="filter-checkboxes" id="travel--filter-panel-102009-23">
              <label id="travel--filter-panel-102009-24"><input type="checkbox" name="tipo" value="familia" id="travel--filter-panel-102009-25"> Família</label>
              <label id="travel--filter-panel-102009-26"><input type="checkbox" name="tipo" value="romantico" id="travel--filter-panel-102009-27"> Romântico</label>
              <label id="travel--filter-panel-102009-28"><input type="checkbox" name="tipo" value="aventura" id="travel--filter-panel-102009-29"> Aventura</label>
              <label id="travel--filter-panel-102009-30"><input type="checkbox" name="tipo" value="cultural" id="travel--filter-panel-102009-31"> Cultural</label>
            </div>
          </fieldset>
          <button type="submit" class="filter-submit" id="travel--filter-panel-102009-32">Aplicar filtros</button>
        </form>
      `;
    }
};
organismFilterPanel = __decorate([
    customElement('travel--organism-filter-panel-102009')
], organismFilterPanel);
export { organismFilterPanel };
