/// <mls shortName="organismHeroBanner" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismHeroBanner = class organismHeroBanner extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-hero-banner-102009 .hero-banner{display:flex;align-items:center;justify-content:space-between;background:var(--bg-primary-color-lighter);padding:var(--space-40) var(--space-32);gap:var(--space-32);min-height:340px}@media (max-width:768px){travel--organism-hero-banner-102009 .hero-banner{flex-direction:column-reverse;padding:var(--space-24) var(--space-8);gap:var(--space-16)}}travel--organism-hero-banner-102009 .hero-banner__content{flex:1 1 0;display:flex;flex-direction:column;gap:var(--space-16);max-width:500px}travel--organism-hero-banner-102009 .hero-banner__title{font-size:var(--font-size-40);font-weight:var(--font-weight-bold);color:var(--text-primary-color-darker);margin:0;line-height:var(--line-height-large)}travel--organism-hero-banner-102009 .hero-banner__subtitle{font-size:var(--font-size-20);color:var(--text-primary-color);margin:0;line-height:var(--line-height-medium)}travel--organism-hero-banner-102009 .hero-banner__cta{display:inline-block;background:var(--bg-secondary-color);color:var(--bg-primary-color);font-weight:var(--font-weight-bold);font-size:var(--font-size-16);padding:var(--space-8) var(--space-24);border-radius:4px;text-decoration:none;margin-top:var(--space-8);transition:background var(--transition-normal),color var(--transition-normal)}travel--organism-hero-banner-102009 .hero-banner__cta:hover,travel--organism-hero-banner-102009 .hero-banner__cta:focus{background:var(--bg-secondary-color-hover);color:var(--bg-primary-color);outline:none}travel--organism-hero-banner-102009 .hero-banner__image{flex:1 1 0;display:flex;align-items:center;justify-content:center;min-width:220px}travel--organism-hero-banner-102009 .hero-banner__image img{max-width:380px;width:100%;height:auto;border-radius:12px;box-shadow:0 4px 24px var(--grey-color-light)}@media (max-width:768px){travel--organism-hero-banner-102009 .hero-banner__image img{max-width:100%}travel--organism-hero-banner-102009 .hero-banner__content{max-width:100%}}`);
    }
    render() {
        return html `<section class="hero-banner" id="travel--hero-banner-102009-1">
        <div class="hero-banner__content" id="travel--hero-banner-102009-2">
          <h1 class="hero-banner__title" id="travel--hero-banner-102009-3">Descubra o mundo com a Travel</h1>
          <p class="hero-banner__subtitle" id="travel--hero-banner-102009-4">Pacotes exclusivos, experiências inesquecíveis. Sua próxima viagem começa aqui!</p>
          <a href="#busca" class="hero-banner__cta" id="travel--hero-banner-102009-5">Buscar Pacotes</a>
        </div>
        <div class="hero-banner__image" id="travel--hero-banner-102009-6">
          <img src="https://images.unsplash.com/photo-1565429559511-3bfbb436d148?crop=entropy&amp;cs=srgb&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwYWlzYWdlbSUyMGluc3BpcmFkb3JhJTIwdmlhZ2VtJTIwcHJhaWElMjBtb250YW5oYXxlbnwwfHx8fDE3NTUwMzE0MDB8MA&amp;ixlib=rb-4.1.0&amp;q=85" alt="Paisagem inspiradora de viagem" id="travel--hero-banner-102009-7">
        </div>
      </section>
    `;
    }
};
organismHeroBanner = __decorate([
    customElement('travel--organism-hero-banner-102009')
], organismHeroBanner);
export { organismHeroBanner };
