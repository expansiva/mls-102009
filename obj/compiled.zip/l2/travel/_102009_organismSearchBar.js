/// <mls shortName="organismSearchBar" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismSearchBar = class organismSearchBar extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-search-bar-102009 .search-bar{background:var(--bg-primary-color);padding:var(--space-24) var(--space-32);border-radius:8px;margin:var(--space-32) auto;max-width:900px;box-shadow:0 2px 8px var(--grey-color-light)}@media (max-width:768px){travel--organism-search-bar-102009 .search-bar{padding:var(--space-16) var(--space-8);margin:var(--space-16) auto}}travel--organism-search-bar-102009 .search-bar__form{display:flex;align-items:flex-end;gap:var(--space-16);flex-wrap:wrap}@media (max-width:768px){travel--organism-search-bar-102009 .search-bar__form{flex-direction:column;align-items:stretch;gap:var(--space-8)}}travel--organism-search-bar-102009 .search-bar__label{font-size:var(--font-size-16);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);margin-bottom:4px;display:block}travel--organism-search-bar-102009 .search-bar__input{font-size:var(--font-size-16);padding:var(--space-8);border:1px solid var(--grey-color-dark);border-radius:4px;background:var(--bg-primary-color-lighter);color:var(--text-primary-color);width:180px}@media (max-width:768px){travel--organism-search-bar-102009 .search-bar__input{width:100%}}travel--organism-search-bar-102009 .search-bar__input:focus{border-color:var(--text-primary-color);outline:none}travel--organism-search-bar-102009 .search-bar__button{background:var(--bg-secondary-color);color:var(--bg-primary-color);font-weight:var(--font-weight-bold);font-size:var(--font-size-16);padding:var(--space-8) var(--space-24);border:none;border-radius:4px;cursor:pointer;transition:background var(--transition-normal),color var(--transition-normal)}travel--organism-search-bar-102009 .search-bar__button:hover,travel--organism-search-bar-102009 .search-bar__button:focus{background:var(--bg-secondary-color-hover);color:var(--bg-primary-color);outline:none}`);
    }
    render() {
        return html `<section class="search-bar" id="busca" aria-label="Busca de pacotes">
        <form class="search-bar__form" role="search" aria-label="Buscar pacotes" id="travel--search-bar-102009-1">
          <label for="destino" class="search-bar__label" id="travel--search-bar-102009-2">Destino</label>
          <input type="text" id="destino" name="destino" class="search-bar__input" placeholder="Para onde você quer ir?" autocomplete="off">
          <label for="data" class="search-bar__label" id="travel--search-bar-102009-3">Data</label>
          <input type="date" id="data" name="data" class="search-bar__input">
          <button type="submit" class="search-bar__button" id="travel--search-bar-102009-4">Buscar</button>
        </form>
      </section>
    `;
    }
};
organismSearchBar = __decorate([
    customElement('travel--organism-search-bar-102009')
], organismSearchBar);
export { organismSearchBar };
