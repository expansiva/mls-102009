/// <mls shortName="organismPackageList" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPackageList = class organismPackageList extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-package-list-102009{display:block}travel--organism-package-list-102009 .package-list{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(2, 1fr);gap:var(--space-32)}travel--organism-package-list-102009 .package-item{display:flex}travel--organism-package-list-102009 .package-card{display:flex;flex-direction:row;background:var(--bg-primary-color);border-radius:var(--space-16);box-shadow:0 2px 8px rgba(230,230,230,0.2);overflow:hidden;width:100%;min-height:180px;transition:box-shadow var(--transition-normal)}travel--organism-package-list-102009 .package-card:hover,travel--organism-package-list-102009 .package-card:focus-within{box-shadow:0 4px 16px rgba(28,145,205,0.15)}travel--organism-package-list-102009 .package-image{flex:0 0 140px;height:140px;overflow:hidden}travel--organism-package-list-102009 .package-image img{width:100%;height:100%;object-fit:cover;display:block}travel--organism-package-list-102009 .package-info{flex:1 1 auto;padding:var(--space-16) var(--space-24);display:flex;flex-direction:column;justify-content:space-between;min-width:0}travel--organism-package-list-102009 .package-title{font-family:var(--font-family-primary);font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-primary-color-darker);margin:0 0 var(--space-8) 0;line-height:var(--line-height-medium);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}travel--organism-package-list-102009 .package-summary{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);margin:0 0 var(--space-8) 0;line-height:var(--line-height-large);flex:0 0 auto}travel--organism-package-list-102009 .package-meta{display:flex;gap:var(--space-16);font-size:var(--font-size-12);color:var(--text-primary-color-lighter);margin-bottom:var(--space-8)}travel--organism-package-list-102009 .package-meta .package-destino:before{content:'\1F30D ';margin-right:var(--space-8)}travel--organism-package-list-102009 .package-meta .package-duracao:before{content:'\23F1 ';margin-right:var(--space-8)}travel--organism-package-list-102009 .package-bottom{display:flex;align-items:center;justify-content:space-between;margin-top:var(--space-8)}travel--organism-package-list-102009 .package-bottom .package-preco{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-secondary-color-darker)}travel--organism-package-list-102009 .package-bottom .package-reservar{background:var(--bg-secondary-color);color:var(--bg-primary-color);border-radius:var(--space-8);padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);text-decoration:none;transition:background var(--transition-normal)}travel--organism-package-list-102009 .package-bottom .package-reservar:hover,travel--organism-package-list-102009 .package-bottom .package-reservar:focus{background:var(--bg-secondary-color-hover);outline:none}@media (max-width:1012px){organism-package-list .package-list{grid-template-columns:1fr}organism-package-list .package-card{flex-direction:column}organism-package-list .package-card .package-image{width:100%;height:180px}}@media (max-width:768px){organism-package-list .package-list{gap:var(--space-16)}organism-package-list .package-info{padding:var(--space-8) var(--space-8)}}@media (max-width:544px){organism-package-list .package-list{gap:var(--space-8)}organism-package-list .package-card{min-height:120px}organism-package-list .package-info{padding:var(--space-8) var(--space-8)}organism-package-list .package-title{font-size:var(--font-size-16)}organism-package-list .package-preco{font-size:var(--font-size-16)}}`);
    }
    render() {
        return html `<ul class="package-list" aria-label="Resultados da busca de pacotes" id="travel--package-list-102009-1">
          <li class="package-item" id="travel--package-list-102009-2">
            <div class="package-card" id="travel--package-list-102009-3">
              <div class="package-image" id="travel--package-list-102009-4">
                <img src="https://images.unsplash.com/photo-1698320856830-246e897b8e9b?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxQcmFpYSUyMGRlJTIwQ29wYWNhYmFuYSUyMFJpbyUyMGRlJTIwSmFuZWlyb3xlbnwwfHx8fDE3NTUwMzE0NjZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Praia de Copacabana, Rio de Janeiro" id="travel--package-list-102009-5">
              </div>
              <div class="package-info" id="travel--package-list-102009-6">
                <h2 class="package-title" id="travel--package-list-102009-7">Rio de Janeiro Inesquecível</h2>
                <p class="package-summary" id="travel--package-list-102009-8">4 dias, hotel 4 estrelas, city tour, café da manhã incluso.</p>
                <div class="package-meta" id="travel--package-list-102009-9">
                  <span class="package-destino" id="travel--package-list-102009-10">Rio de Janeiro</span>
                  <span class="package-duracao" id="travel--package-list-102009-11">4 dias</span>
                </div>
                <div class="package-bottom" id="travel--package-list-102009-12">
                  <span class="package-preco" id="travel--package-list-102009-13">R$ 1.200</span>
                  <a href="#" class="package-reservar" aria-label="Reservar pacote Rio de Janeiro Inesquecível" id="travel--package-list-102009-14">Reservar</a>
                </div>
              </div>
            </div>
          </li>
          <li class="package-item" id="travel--package-list-102009-15">
            <div class="package-card" id="travel--package-list-102009-16">
              <div class="package-image" id="travel--package-list-102009-17">
                <img src="https://images.unsplash.com/photo-1614963885169-8df21f8d2209?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxQZWxvdXJpbmhvJTIwU2FsdmFkb3IlMjBCYWhpYXxlbnwwfHx8fDE3NTUwMzE0NjZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Pelourinho, Salvador" id="travel--package-list-102009-18">
              </div>
              <div class="package-info" id="travel--package-list-102009-19">
                <h2 class="package-title" id="travel--package-list-102009-20">Salvador Cultural</h2>
                <p class="package-summary" id="travel--package-list-102009-21">5 dias, hotel 3 estrelas, passeio histórico, traslados.</p>
                <div class="package-meta" id="travel--package-list-102009-22">
                  <span class="package-destino" id="travel--package-list-102009-23">Salvador</span>
                  <span class="package-duracao" id="travel--package-list-102009-24">5 dias</span>
                </div>
                <div class="package-bottom" id="travel--package-list-102009-25">
                  <span class="package-preco" id="travel--package-list-102009-26">R$ 1.450</span>
                  <a href="#" class="package-reservar" aria-label="Reservar pacote Salvador Cultural" id="travel--package-list-102009-27">Reservar</a>
                </div>
              </div>
            </div>
          </li>
          <li class="package-item" id="travel--package-list-102009-28">
            <div class="package-card" id="travel--package-list-102009-29">
              <div class="package-image" id="travel--package-list-102009-30">
                <img src="https://images.unsplash.com/photo-1549365811-8f4bb8d22c49?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxDZW50cm8lMjBkZSUyMEdyYW1hZG8lMjBSaW8lMjBHcmFuZGUlMjBkbyUyMFN1bHxlbnwwfHx8fDE3NTUwMzE0Njd8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Centro de Gramado" id="travel--package-list-102009-31">
              </div>
              <div class="package-info" id="travel--package-list-102009-32">
                <h2 class="package-title" id="travel--package-list-102009-33">Gramado Romântico</h2>
                <p class="package-summary" id="travel--package-list-102009-34">3 dias, pousada charmosa, jantar especial, passeio de pedalinho.</p>
                <div class="package-meta" id="travel--package-list-102009-35">
                  <span class="package-destino" id="travel--package-list-102009-36">Gramado</span>
                  <span class="package-duracao" id="travel--package-list-102009-37">3 dias</span>
                </div>
                <div class="package-bottom" id="travel--package-list-102009-38">
                  <span class="package-preco" id="travel--package-list-102009-39">R$ 1.800</span>
                  <a href="#" class="package-reservar" aria-label="Reservar pacote Gramado Romântico" id="travel--package-list-102009-40">Reservar</a>
                </div>
              </div>
            </div>
          </li>
          <li class="package-item" id="travel--package-list-102009-41">
            <div class="package-card" id="travel--package-list-102009-42">
              <div class="package-image" id="travel--package-list-102009-43">
                <img src="https://images.unsplash.com/photo-1742614098758-ff24f78a33c7?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxQcmFpYSUyMEZsb3JpYW4lQzMlQjNwb2xpcyUyMFNhbnRhJTIwQ2F0YXJpbmF8ZW58MHx8fHwxNzU1MDMxNDY4fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Praia em Florianópolis" id="travel--package-list-102009-44">
              </div>
              <div class="package-info" id="travel--package-list-102009-45">
                <h2 class="package-title" id="travel--package-list-102009-46">Aventura em Florianópolis</h2>
                <p class="package-summary" id="travel--package-list-102009-47">7 dias, hostel, trilhas, surf e passeios ecológicos.</p>
                <div class="package-meta" id="travel--package-list-102009-48">
                  <span class="package-destino" id="travel--package-list-102009-49">Florianópolis</span>
                  <span class="package-duracao" id="travel--package-list-102009-50">7 dias</span>
                </div>
                <div class="package-bottom" id="travel--package-list-102009-51">
                  <span class="package-preco" id="travel--package-list-102009-52">R$ 2.100</span>
                  <a href="#" class="package-reservar" aria-label="Reservar pacote Aventura em Florianópolis" id="travel--package-list-102009-53">Reservar</a>
                </div>
              </div>
            </div>
          </li>
        </ul>
      `;
    }
};
organismPackageList = __decorate([
    customElement('travel--organism-package-list-102009')
], organismPackageList);
export { organismPackageList };
