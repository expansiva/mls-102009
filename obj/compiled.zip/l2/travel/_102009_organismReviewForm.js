/// <mls shortName="organismReviewForm" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismReviewForm = class organismReviewForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-review-form-102009{display:block;background:var(--bg-primary-color);padding:var(--space-32) 0}travel--organism-review-form-102009 .review-form__container{max-width:700px;margin:0 auto;padding:0 var(--space-16)}travel--organism-review-form-102009 .review-form__form{background:var(--bg-primary-color-lighter);border-radius:var(--space-16);box-shadow:0 1px 4px rgba(230,230,230,0.15);padding:var(--space-24);margin-bottom:var(--space-16)}travel--organism-review-form-102009 .review-form__fieldset{border:none;padding:0;margin:0;display:flex;flex-direction:column;gap:var(--space-16)}travel--organism-review-form-102009 .review-form__legend{font-size:var(--font-size-20);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);margin-bottom:var(--space-8)}travel--organism-review-form-102009 .review-form__label{font-size:var(--font-size-16);color:var(--text-primary-color);margin-bottom:var(--space-8);display:block}travel--organism-review-form-102009 .review-form__select,travel--organism-review-form-102009 .review-form__textarea{width:100%;font-size:var(--font-size-16);padding:var(--space-8);border-radius:var(--space-8);border:1px solid var(--grey-color);background:var(--bg-primary-color);color:var(--text-primary-color-lighter);transition:border-color var(--transition-slow)}travel--organism-review-form-102009 .review-form__select:focus,travel--organism-review-form-102009 .review-form__textarea:focus{border-color:var(--text-primary-color);outline:none}travel--organism-review-form-102009 .review-form__submit{background:var(--text-secondary-color);color:var(--bg-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);border:none;border-radius:var(--space-8);padding:var(--space-8) var(--space-24);cursor:pointer;transition:background var(--transition-slow)}travel--organism-review-form-102009 .review-form__submit:hover,travel--organism-review-form-102009 .review-form__submit:focus{background:var(--text-secondary-color-hover)}travel--organism-review-form-102009 .review-form__login-message{background:var(--bg-secondary-color-lighter);color:var(--text-primary-color-darker);border-radius:var(--space-8);padding:var(--space-16);text-align:center;font-size:var(--font-size-16)}travel--organism-review-form-102009 .review-form__login-message a.review-form__login-link{color:var(--link-color);text-decoration:underline}travel--organism-review-form-102009 .review-form__login-message a.review-form__login-link:hover,travel--organism-review-form-102009 .review-form__login-message a.review-form__login-link:focus{color:var(--link-color-hover)}`);
    }
    render() {
        return html `<section class="review-form__container" aria-label="Enviar avaliação" id="travel--review-form-102009-1">
        <form class="review-form__form" autocomplete="off" id="travel--review-form-102009-2">
          <fieldset class="review-form__fieldset" id="travel--review-form-102009-3">
            <legend class="review-form__legend" id="travel--review-form-102009-4">Deixe sua avaliação</legend>
            <div class="review-form__rating-group" id="travel--review-form-102009-5">
              <label for="review-rating" class="review-form__label" id="travel--review-form-102009-6">Nota:</label>
              <select id="review-rating" name="rating" class="review-form__select" required="">
                <option value="" id="travel--review-form-102009-7">Selecione</option>
                <option value="5" id="travel--review-form-102009-8">5 - Excelente</option>
                <option value="4" id="travel--review-form-102009-9">4 - Muito bom</option>
                <option value="3" id="travel--review-form-102009-10">3 - Bom</option>
                <option value="2" id="travel--review-form-102009-11">2 - Regular</option>
                <option value="1" id="travel--review-form-102009-12">1 - Ruim</option>
              </select>
            </div>
            <div class="review-form__comment-group" id="travel--review-form-102009-13">
              <label for="review-comment" class="review-form__label" id="travel--review-form-102009-14">Comentário:</label>
              <textarea id="review-comment" name="comment" class="review-form__textarea" rows="4" maxlength="500" required="" placeholder="Compartilhe sua experiência..."></textarea>
            </div>
            <button type="submit" class="review-form__submit" id="travel--review-form-102009-15">Enviar avaliação</button>
          </fieldset>
        </form>
        <div class="review-form__login-message" aria-live="polite" style="display:none;" id="travel--review-form-102009-16">
          <p id="travel--review-form-102009-17">Para enviar uma avaliação, faça <a href="#login" class="review-form__login-link" id="travel--review-form-102009-18">login</a> na sua conta.</p>
        </div>
      </section>
    `;
    }
};
organismReviewForm = __decorate([
    customElement('travel--organism-review-form-102009')
], organismReviewForm);
export { organismReviewForm };
