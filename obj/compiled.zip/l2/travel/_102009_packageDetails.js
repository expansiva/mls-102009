/// <mls shortName="packageDetails" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PagePackageDetails = class PagePackageDetails extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--package-details-102009{display:block;min-height:100vh;background:var(--bg-primary-color-lighter)}travel--package-details-102009 header{background:var(--bg-primary-color);box-shadow:0 2px 8px rgba(230,230,230,0.1)}travel--package-details-102009 main.main-content{display:flex;flex-direction:column;gap:var(--space-32);padding-bottom:var(--space-32)}travel--package-details-102009 footer{background:var(--bg-primary-color);margin-top:var(--space-32)}@media (max-width:768px){travel--package-details-102009 main.main-content{gap:var(--space-24)}}`);
    }
    initPage() {
    }
};
PagePackageDetails = __decorate([
    customElement('travel--package-details-102009')
], PagePackageDetails);
export { PagePackageDetails };
