/// <mls shortName="organismPackageDetails" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPackageDetails = class organismPackageDetails extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-package-details-102009{display:block;background:var(--bg-primary-color);padding:var(--space-32) 0}travel--organism-package-details-102009 .package-details__container{display:flex;flex-wrap:wrap;gap:var(--space-40);max-width:1012px;margin:0 auto;align-items:flex-start}travel--organism-package-details-102009 .package-details__gallery{flex:1 1 340px;min-width:320px;max-width:420px}travel--organism-package-details-102009 .package-details__gallery .package-details__main-img{width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:var(--space-16);box-shadow:0 2px 8px rgba(230,230,230,0.3);margin-bottom:var(--space-16)}travel--organism-package-details-102009 .package-details__gallery .package-details__thumbnails{display:flex;gap:var(--space-8)}travel--organism-package-details-102009 .package-details__gallery .package-details__thumbnails .package-details__thumb{width:72px;height:54px;object-fit:cover;border-radius:var(--space-8);border:2px solid var(--grey-color-light);transition:border-color var(--transition-slow);cursor:pointer}travel--organism-package-details-102009 .package-details__gallery .package-details__thumbnails .package-details__thumb:hover,travel--organism-package-details-102009 .package-details__gallery .package-details__thumbnails .package-details__thumb:focus{border-color:var(--text-primary-color)}travel--organism-package-details-102009 .package-details__info{flex:2 1 400px;min-width:320px}travel--organism-package-details-102009 .package-details__info .package-details__title{font-family:var(--font-family-primary);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color-darker);margin-bottom:var(--space-16)}travel--organism-package-details-102009 .package-details__info .package-details__meta{display:flex;gap:var(--space-24);font-size:var(--font-size-16);color:var(--text-primary-color);margin-bottom:var(--space-16)}travel--organism-package-details-102009 .package-details__info .package-details__meta span{display:flex;align-items:center}travel--organism-package-details-102009 .package-details__info .package-details__description{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);margin-bottom:var(--space-24);line-height:var(--line-height-large)}travel--organism-package-details-102009 .package-details__info .package-details__itinerary h2{font-size:var(--font-size-20);color:var(--text-primary-color-darker);margin-bottom:var(--space-8)}travel--organism-package-details-102009 .package-details__info .package-details__itinerary ul{padding-left:var(--space-24);margin:0}travel--organism-package-details-102009 .package-details__info .package-details__itinerary ul li{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);margin-bottom:var(--space-8);list-style:disc}@media (max-width:768px){travel--organism-package-details-102009 .package-details__container{flex-direction:column;gap:var(--space-24);padding:0 var(--space-16)}travel--organism-package-details-102009 .package-details__gallery,travel--organism-package-details-102009 .package-details__info{min-width:0;max-width:100%}}`);
    }
    render() {
        return html `<div class="package-details__container" id="travel--package-details-102009-1">
        <div class="package-details__gallery" id="travel--package-details-102009-2">
          <img src="https://images.unsplash.com/photo-1614723268053-f32f936f13f9?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxGZXJuYW5kbyUyMGRlJTIwTm9yb25oYSUyMHByYWlhJTIwcGFpc2FnZW18ZW58MHx8fHwxNzU1MDMxNTIyfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Foto principal do pacote" class="package-details__main-img" id="travel--package-details-102009-3">
          <div class="package-details__thumbnails" id="travel--package-details-102009-4">
            <img src="https://images.unsplash.com/photo-1593193391560-76ce8e2b313c?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxQcmFpYSUyMGRvJTIwU2FuY2hvJTIwTm9yb25oYXxlbnwwfHx8fDE3NTUwMzE1MjN8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Foto do destino 1" class="package-details__thumb" id="travel--package-details-102009-5">
            <img src="https://images.unsplash.com/photo-1456440532435-1c8f42495a53?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxUcmlsaGElMjBlY29sJUMzJUIzZ2ljYSUyME5vcm9uaGF8ZW58MHx8fHwxNzU1MDMxNTIzfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Foto do destino 2" class="package-details__thumb" id="travel--package-details-102009-6">
            <img src="https://images.unsplash.com/photo-1586731023793-871d4799d0ed?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxNZXJndWxobyUyMEZlcm5hbmRvJTIwZGUlMjBOb3JvbmhhfGVufDB8fHx8MTc1NTAzMTUyNHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Foto do destino 3" class="package-details__thumb" id="travel--package-details-102009-7">
          </div>
        </div>
        <div class="package-details__info" id="travel--package-details-102009-8">
          <h1 class="package-details__title" id="travel--package-details-102009-9">Pacote: Roteiro dos Sonhos - Fernando de Noronha</h1>
          <div class="package-details__meta" id="travel--package-details-102009-10">
            <span class="package-details__date" id="travel--package-details-102009-11"><strong id="travel--package-details-102009-12">Datas:</strong> 10/09/2025 a 17/09/2025</span>
            <span class="package-details__price" id="travel--package-details-102009-13"><strong id="travel--package-details-102009-14">Preço:</strong> R$ 4.200,00</span>
          </div>
          <p class="package-details__description" id="travel--package-details-102009-15">
            Viva uma experiência inesquecível em Fernando de Noronha! Pacote completo com hospedagem, passeios guiados, traslados e café da manhã incluso. Aproveite praias paradisíacas, trilhas ecológicas e mergulhos incríveis.
          </p>
          <div class="package-details__itinerary" id="travel--package-details-102009-16">
            <h2 id="travel--package-details-102009-17">Itinerário</h2>
            <ul id="travel--package-details-102009-18">
              <li id="travel--package-details-102009-19">Dia 1: Chegada e traslado ao hotel</li>
              <li id="travel--package-details-102009-20">Dia 2: Passeio de barco pelas praias</li>
              <li id="travel--package-details-102009-21">Dia 3: Trilha ecológica e visita ao Projeto Tamar</li>
              <li id="travel--package-details-102009-22">Dia 4: Mergulho com cilindro (opcional)</li>
              <li id="travel--package-details-102009-23">Dia 5: Dia livre para explorar</li>
              <li id="travel--package-details-102009-24">Dia 6: City tour histórico</li>
              <li id="travel--package-details-102009-25">Dia 7: Retorno</li>
            </ul>
          </div>
        </div>
      </div>
    `;
    }
};
organismPackageDetails = __decorate([
    customElement('travel--organism-package-details-102009')
], organismPackageDetails);
export { organismPackageDetails };
