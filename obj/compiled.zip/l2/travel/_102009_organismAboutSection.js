/// <mls shortName="organismAboutSection" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAboutSection = class organismAboutSection extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-about-section-102009 .about-section{display:flex;align-items:center;justify-content:space-between;background:var(--bg-primary-color);padding:var(--space-40) var(--space-32);gap:var(--space-32);max-width:1200px;margin:var(--space-32) auto;border-radius:12px;box-shadow:0 2px 8px var(--grey-color-light)}@media (max-width:768px){travel--organism-about-section-102009 .about-section{flex-direction:column;padding:var(--space-16) var(--space-8);gap:var(--space-16)}}travel--organism-about-section-102009 .about-section__content{flex:2 1 0;display:flex;flex-direction:column;gap:var(--space-16)}travel--organism-about-section-102009 .about-section__title{font-size:var(--font-size-24);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);margin:0}travel--organism-about-section-102009 .about-section__text{font-size:var(--font-size-16);color:var(--text-primary-color);margin:0;line-height:var(--line-height-medium)}travel--organism-about-section-102009 .about-section__differentials{list-style:disc inside;color:var(--text-primary-color-lighter);font-size:var(--font-size-16);margin:0;padding-left:var(--space-16)}travel--organism-about-section-102009 .about-section__differentials li{margin-bottom:var(--space-8)}travel--organism-about-section-102009 .about-section__image{flex:1 1 0;display:flex;align-items:center;justify-content:center;min-width:180px}travel--organism-about-section-102009 .about-section__image img{max-width:260px;width:100%;height:auto;border-radius:8px;box-shadow:0 2px 8px var(--grey-color-light)}@media (max-width:768px){travel--organism-about-section-102009 .about-section__image img{max-width:100%}}`);
    }
    render() {
        return html `<section class="about-section" aria-label="Sobre a agência" id="travel--about-section-102009-1">
        <div class="about-section__content" id="travel--about-section-102009-2">
          <h2 class="about-section__title" id="travel--about-section-102009-3">Sobre a Travel</h2>
          <p class="about-section__text" id="travel--about-section-102009-4">
            Somos apaixonados por viagens e experiências únicas. Há mais de 10 anos, conectamos pessoas aos melhores destinos do Brasil e do mundo, com atendimento personalizado e condições exclusivas.
          </p>
          <ul class="about-section__differentials" id="travel--about-section-102009-5">
            <li id="travel--about-section-102009-6">Atendimento 100% personalizado</li>
            <li id="travel--about-section-102009-7">Parcelamento facilitado e seguro</li>
            <li id="travel--about-section-102009-8">Equipe especializada em roteiros exclusivos</li>
            <li id="travel--about-section-102009-9">Suporte 24h durante sua viagem</li>
          </ul>
        </div>
        <div class="about-section__image" id="travel--about-section-102009-10">
          <img src="https://images.unsplash.com/photo-1572504743618-6fd46e2724f7?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxlcXVpcGUlMjBhZyVDMyVBQW5jaWElMjBkZSUyMHZpYWdlbnMlMjBzb3JyaW5kb3xlbnwwfHx8fDE3NTUwMzE0MDJ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Equipe da agência Travel sorrindo" id="travel--about-section-102009-11">
        </div>
      </section>
    `;
    }
};
organismAboutSection = __decorate([
    customElement('travel--organism-about-section-102009')
], organismAboutSection);
export { organismAboutSection };
