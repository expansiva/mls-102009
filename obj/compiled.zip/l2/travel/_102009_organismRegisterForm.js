/// <mls shortName="organismRegisterForm" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismRegisterForm = class organismRegisterForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-register-form-102009{display:block;margin-bottom:var(--space-32)}travel--organism-register-form-102009 .register-form{background:var(--bg-primary-color-lighter);border-radius:8px;box-shadow:0 2px 8px rgba(230,230,230,0.2);padding:var(--space-32) var(--space-24);max-width:360px;margin:0 auto var(--space-24) auto;font-family:var(--font-family-primary)}travel--organism-register-form-102009 .register-form .form-title{font-size:var(--font-size-24);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);margin-bottom:var(--space-24);text-align:center}travel--organism-register-form-102009 .register-form .form-group{margin-bottom:var(--space-16)}travel--organism-register-form-102009 .register-form .form-group label{display:block;font-size:var(--font-size-16);color:var(--text-primary-color);margin-bottom:var(--space-8)}travel--organism-register-form-102009 .register-form .form-group input{width:100%;padding:var(--space-8);border:1px solid var(--grey-color-dark);border-radius:4px;font-size:var(--font-size-16);background:var(--bg-primary-color);color:var(--text-primary-color-darker);transition:border-color var(--transition-slow)}travel--organism-register-form-102009 .register-form .form-group input:focus{border-color:var(--text-primary-color);outline:none}travel--organism-register-form-102009 .register-form .form-actions{display:flex;justify-content:flex-end;margin-top:var(--space-16)}travel--organism-register-form-102009 .register-form .form-actions .btn-register{background:#fff;color:var(--bg-primary-color);border:none;border-radius:4px;padding:var(--space-8) var(--space-24);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-slow)}travel--organism-register-form-102009 .register-form .form-actions .btn-register:hover,travel--organism-register-form-102009 .register-form .form-actions .btn-register:focus{background:#fff}@media (max-width:544px){travel--organism-register-form-102009 .register-form{padding:var(--space-16) var(--space-8);max-width:100%}}`);
    }
    render() {
        return html `<form class="register-form" aria-label="Formulário de Registro" autocomplete="off" id="travel--register-form-102009-1">
          <h2 class="form-title" id="travel--register-form-102009-2">Criar nova conta</h2>
          <div class="form-group" id="travel--register-form-102009-3">
            <label for="register-name" id="travel--register-form-102009-4">Nome completo</label>
            <input type="text" id="register-name" name="name" placeholder="Seu nome" required="" autocomplete="name">
          </div>
          <div class="form-group" id="travel--register-form-102009-5">
            <label for="register-email" id="travel--register-form-102009-6">E-mail</label>
            <input type="email" id="register-email" name="email" placeholder="seu@email.com" required="" autocomplete="username">
          </div>
          <div class="form-group" id="travel--register-form-102009-7">
            <label for="register-password" id="travel--register-form-102009-8">Senha</label>
            <input type="password" id="register-password" name="password" placeholder="Crie uma senha" required="" autocomplete="new-password">
          </div>
          <div class="form-actions" id="travel--register-form-102009-9">
            <button type="submit" class="btn-register" id="travel--register-form-102009-10">Cadastrar</button>
          </div>
        </form>
      `;
    }
};
organismRegisterForm = __decorate([
    customElement('travel--organism-register-form-102009')
], organismRegisterForm);
export { organismRegisterForm };
