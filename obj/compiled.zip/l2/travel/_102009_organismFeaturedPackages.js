/// <mls shortName="organismFeaturedPackages" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismFeaturedPackages = class organismFeaturedPackages extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-featured-packages-102009 .featured-packages{background:var(--bg-primary-color-lighter);padding:var(--space-32) 0;margin:0 auto;max-width:1200px}@media (max-width:768px){travel--organism-featured-packages-102009 .featured-packages{padding:var(--space-16) 0}}travel--organism-featured-packages-102009 .featured-packages__title{font-size:var(--font-size-24);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);margin:0 0 var(--space-24) var(--space-32)}@media (max-width:768px){travel--organism-featured-packages-102009 .featured-packages__title{margin:0 0 var(--space-16) var(--space-8)}}travel--organism-featured-packages-102009 .featured-packages__list{display:flex;gap:var(--space-32);justify-content:center;flex-wrap:wrap}@media (max-width:768px){travel--organism-featured-packages-102009 .featured-packages__list{gap:var(--space-16)}}travel--organism-featured-packages-102009 .featured-packages__item{background:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 8px var(--grey-color-light);overflow:hidden;width:320px;display:flex;flex-direction:column;transition:box-shadow var(--transition-normal)}travel--organism-featured-packages-102009 .featured-packages__item:hover,travel--organism-featured-packages-102009 .featured-packages__item:focus-within{box-shadow:0 4px 16px var(--grey-color-dark)}@media (max-width:768px){travel--organism-featured-packages-102009 .featured-packages__item{width:100%;max-width:340px}}travel--organism-featured-packages-102009 .featured-packages__img{width:100%;height:180px;object-fit:cover;display:block}travel--organism-featured-packages-102009 .featured-packages__info{padding:var(--space-16);display:flex;flex-direction:column;gap:var(--space-8)}travel--organism-featured-packages-102009 .featured-packages__name{font-size:var(--font-size-20);color:var(--text-primary-color);font-weight:var(--font-weight-bold);margin:0}travel--organism-featured-packages-102009 .featured-packages__price{font-size:var(--font-size-16);color:var(--text-secondary-color-darker);margin:0}travel--organism-featured-packages-102009 .featured-packages__details{align-self:flex-start;background:var(--bg-secondary-color);color:var(--bg-primary-color);font-weight:var(--font-weight-bold);font-size:var(--font-size-16);padding:var(--space-8) var(--space-16);border-radius:4px;text-decoration:none;transition:background var(--transition-normal),color var(--transition-normal)}travel--organism-featured-packages-102009 .featured-packages__details:hover,travel--organism-featured-packages-102009 .featured-packages__details:focus{background:var(--bg-secondary-color-hover);color:var(--bg-primary-color);outline:none}`);
    }
    render() {
        return html `<section class="featured-packages" aria-label="Pacotes em destaque" id="travel--featured-packages-102009-1">
        <h2 class="featured-packages__title" id="travel--featured-packages-102009-2">Pacotes em Destaque</h2>
        <div class="featured-packages__list" id="travel--featured-packages-102009-3">
          <div class="featured-packages__item" id="travel--featured-packages-102009-4">
            <img src="https://images.unsplash.com/photo-1517053083425-2f61fe08a342?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcmFpYSUyMHBhcmFkaXMlQzMlQURhY2ElMjBGZXJuYW5kbyUyMGRlJTIwTm9yb25oYXxlbnwwfHx8fDE3NTUwMzE0MDF8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Praia paradisíaca em Fernando de Noronha" class="featured-packages__img" id="travel--featured-packages-102009-5">
            <div class="featured-packages__info" id="travel--featured-packages-102009-6">
              <h3 class="featured-packages__name" id="travel--featured-packages-102009-7">Fernando de Noronha</h3>
              <p class="featured-packages__price" id="travel--featured-packages-102009-8">A partir de <strong id="travel--featured-packages-102009-9">R$ 2.500</strong></p>
              <a href="/pacotes/fernando-de-noronha" class="featured-packages__details" id="travel--featured-packages-102009-10">Ver detalhes</a>
            </div>
          </div>
          <div class="featured-packages__item" id="travel--featured-packages-102009-11">
            <img src="https://images.unsplash.com/photo-1500413702358-48b1daad8ddc?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxHcmFtYWRvJTIwaW52ZXJubyUyMG5ldmV8ZW58MHx8fHwxNzU1MDMxNDAxfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Vista aérea de Gramado no inverno" class="featured-packages__img" id="travel--featured-packages-102009-12">
            <div class="featured-packages__info" id="travel--featured-packages-102009-13">
              <h3 class="featured-packages__name" id="travel--featured-packages-102009-14">Gramado Inverno</h3>
              <p class="featured-packages__price" id="travel--featured-packages-102009-15">A partir de <strong id="travel--featured-packages-102009-16">R$ 1.800</strong></p>
              <a href="/pacotes/gramado-inverno" class="featured-packages__details" id="travel--featured-packages-102009-17">Ver detalhes</a>
            </div>
          </div>
          <div class="featured-packages__item" id="travel--featured-packages-102009-18">
            <img src="https://images.unsplash.com/photo-1482951486181-13a752dbbd52?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxDYXRhcmF0YXMlMjBkbyUyMElndWElQzMlQTd1fGVufDB8fHx8MTc1NTAzMTQwMnww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Cataratas do Iguaçu" class="featured-packages__img" id="travel--featured-packages-102009-19">
            <div class="featured-packages__info" id="travel--featured-packages-102009-20">
              <h3 class="featured-packages__name" id="travel--featured-packages-102009-21">Cataratas do Iguaçu</h3>
              <p class="featured-packages__price" id="travel--featured-packages-102009-22">A partir de <strong id="travel--featured-packages-102009-23">R$ 1.200</strong></p>
              <a href="/pacotes/cataratas-iguacu" class="featured-packages__details" id="travel--featured-packages-102009-24">Ver detalhes</a>
            </div>
          </div>
        </div>
      </section>
    `;
    }
};
organismFeaturedPackages = __decorate([
    customElement('travel--organism-featured-packages-102009')
], organismFeaturedPackages);
export { organismFeaturedPackages };
