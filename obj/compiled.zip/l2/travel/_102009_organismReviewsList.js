/// <mls shortName="organismReviewsList" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismReviewsList = class organismReviewsList extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-reviews-list-102009{display:block;background:var(--bg-primary-color-lighter);padding:var(--space-32) 0}travel--organism-reviews-list-102009 .reviews-list__container{max-width:700px;margin:0 auto;padding:0 var(--space-16)}travel--organism-reviews-list-102009 .reviews-list__title{font-size:var(--font-size-20);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}travel--organism-reviews-list-102009 .reviews-list__list{list-style:none;margin:0;padding:0}travel--organism-reviews-list-102009 .reviews-list__list .reviews-list__item{background:var(--bg-primary-color);border-radius:var(--space-16);box-shadow:0 1px 4px rgba(230,230,230,0.2);padding:var(--space-16);margin-bottom:var(--space-16)}travel--organism-reviews-list-102009 .reviews-list__list .reviews-list__item .reviews-list__header{display:flex;align-items:center;gap:var(--space-16);margin-bottom:var(--space-8)}travel--organism-reviews-list-102009 .reviews-list__list .reviews-list__item .reviews-list__header .reviews-list__author{font-weight:var(--font-weight-bold);color:var(--text-primary-color)}travel--organism-reviews-list-102009 .reviews-list__list .reviews-list__item .reviews-list__header .reviews-list__rating{color:var(--warning-color);font-size:var(--font-size-16);letter-spacing:1px}travel--organism-reviews-list-102009 .reviews-list__list .reviews-list__item .reviews-list__comment{color:var(--text-primary-color-lighter);font-size:var(--font-size-16);line-height:var(--line-height-large)}`);
    }
    render() {
        return html `<section class="reviews-list__container" aria-label="Avaliações de clientes" id="travel--reviews-list-102009-1">
        <h2 class="reviews-list__title" id="travel--reviews-list-102009-2">Avaliações de clientes</h2>
        <ul class="reviews-list__list" id="travel--reviews-list-102009-3">
          <li class="reviews-list__item" id="travel--reviews-list-102009-4">
            <div class="reviews-list__header" id="travel--reviews-list-102009-5">
              <span class="reviews-list__author" id="travel--reviews-list-102009-6">Ana Paula</span>
              <span class="reviews-list__rating" aria-label="Nota 5 de 5" id="travel--reviews-list-102009-7">★★★★★</span>
            </div>
            <p class="reviews-list__comment" id="travel--reviews-list-102009-8">Viagem perfeita! Organização impecável e paisagens de tirar o fôlego. Recomendo muito!</p>
          </li>
          <li class="reviews-list__item" id="travel--reviews-list-102009-9">
            <div class="reviews-list__header" id="travel--reviews-list-102009-10">
              <span class="reviews-list__author" id="travel--reviews-list-102009-11">Carlos Eduardo</span>
              <span class="reviews-list__rating" aria-label="Nota 4 de 5" id="travel--reviews-list-102009-12">★★★★☆</span>
            </div>
            <p class="reviews-list__comment" id="travel--reviews-list-102009-13">Gostei bastante, só senti falta de mais opções de passeios noturnos. No geral, excelente!</p>
          </li>
          <li class="reviews-list__item" id="travel--reviews-list-102009-14">
            <div class="reviews-list__header" id="travel--reviews-list-102009-15">
              <span class="reviews-list__author" id="travel--reviews-list-102009-16">Juliana M.</span>
              <span class="reviews-list__rating" aria-label="Nota 5 de 5" id="travel--reviews-list-102009-17">★★★★★</span>
            </div>
            <p class="reviews-list__comment" id="travel--reviews-list-102009-18">Equipe atenciosa e roteiro bem planejado. Voltaria com certeza!</p>
          </li>
        </ul>
      </section>
    `;
    }
};
organismReviewsList = __decorate([
    customElement('travel--organism-reviews-list-102009')
], organismReviewsList);
export { organismReviewsList };
