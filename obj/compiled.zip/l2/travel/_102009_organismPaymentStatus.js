/// <mls shortName="organismPaymentStatus" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPaymentStatus = class organismPaymentStatus extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-payment-status-102009{display:block;width:100%;max-width:520px;margin:0 auto}travel--organism-payment-status-102009 .payment-status-section{margin-top:var(--space-24)}travel--organism-payment-status-102009 .payment-status{display:flex;align-items:flex-start;gap:var(--space-16);border-radius:6px;padding:var(--space-16) var(--space-16);margin-bottom:var(--space-16);box-shadow:0 1px 4px rgba(211,211,211,0.08);background:var(--bg-primary-color-lighter)}travel--organism-payment-status-102009 .payment-status--success{border-left:4px solid var(--success-color);background:rgba(82,196,26,0.08)}travel--organism-payment-status-102009 .payment-status--error{border-left:4px solid var(--error-color);background:rgba(255,77,79,0.08)}travel--organism-payment-status-102009 .payment-status .status-icon{width:36px;height:36px;margin-right:var(--space-8)}travel--organism-payment-status-102009 .payment-status .status-title{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-primary-color-darker);margin-bottom:var(--space-8)}travel--organism-payment-status-102009 .payment-status .status-message{font-size:var(--font-size-16);color:var(--text-primary-color);margin:0}@media (max-width:544px){travel--organism-payment-status-102009 .payment-status{flex-direction:column;align-items:flex-start}travel--organism-payment-status-102009 .payment-status .status-icon{margin-bottom:var(--space-8)}}`);
    }
    render() {
        return html `<section class="payment-status-section" aria-live="polite" id="travel--payment-status-102009-1">
        <!-- Exemplo de status de pagamento -->
        <div class="payment-status payment-status--success" role="status" id="travel--payment-status-102009-2">
          <img src="https://images.unsplash.com/photo-1681577997228-8c558352ffa7?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHwlQzMlQURjb25lJTIwZGUlMjBzdWNlc3NvJTJDJTIwY2hlY2slMjB2ZXJkZXxlbnwwfHx8fDE3NTUwMzE1NzB8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Sucesso" class="status-icon" id="travel--payment-status-102009-3">
          <div id="travel--payment-status-102009-4">
            <h2 class="status-title" id="travel--payment-status-102009-5">Pagamento aprovado!</h2>
            <p class="status-message" id="travel--payment-status-102009-6">Sua reserva foi confirmada. Você receberá um e-mail com os detalhes em instantes.</p>
          </div>
        </div>
        <!--
        <div class="payment-status payment-status--error" role="alert">
          <img src="https://images.unsplash.com/photo-1628322131627-312b59100847?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHwlQzMlQURjb25lJTIwZGUlMjBlcnJvJTJDJTIwWCUyMHZlcm1lbGhvfGVufDB8fHx8MTc1NTAzMTU3MXww&ixlib=rb-4.1.0&q=80&w=1080" alt="Erro" class="status-icon" />
          <div>
            <h2 class="status-title">Pagamento não aprovado</h2>
            <p class="status-message">Houve um problema ao processar seu pagamento. Tente novamente ou utilize outro método.</p>
          </div>
        </div>
        -->
      </section>
    `;
    }
};
organismPaymentStatus = __decorate([
    customElement('travel--organism-payment-status-102009')
], organismPaymentStatus);
export { organismPaymentStatus };
