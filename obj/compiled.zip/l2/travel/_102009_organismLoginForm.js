/// <mls shortName="organismLoginForm" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismLoginForm = class organismLoginForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-login-form-102009{display:block;margin-bottom:var(--space-32)}travel--organism-login-form-102009 .login-form{background:var(--bg-primary-color-lighter);border-radius:8px;box-shadow:0 2px 8px rgba(230,230,230,0.2);padding:var(--space-32) var(--space-24);max-width:360px;margin:0 auto var(--space-24) auto;font-family:var(--font-family-primary)}travel--organism-login-form-102009 .login-form .form-title{font-size:var(--font-size-24);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);margin-bottom:var(--space-24);text-align:center}travel--organism-login-form-102009 .login-form .form-group{margin-bottom:var(--space-16)}travel--organism-login-form-102009 .login-form .form-group label{display:block;font-size:var(--font-size-16);color:var(--text-primary-color);margin-bottom:var(--space-8)}travel--organism-login-form-102009 .login-form .form-group input{width:100%;padding:var(--space-8);border:1px solid var(--grey-color-dark);border-radius:4px;font-size:var(--font-size-16);background:var(--bg-primary-color);color:var(--text-primary-color-darker);transition:border-color var(--transition-slow)}travel--organism-login-form-102009 .login-form .form-group input:focus{border-color:var(--text-primary-color);outline:none}travel--organism-login-form-102009 .login-form .form-actions{display:flex;justify-content:space-between;align-items:center;margin-top:var(--space-16)}travel--organism-login-form-102009 .login-form .form-actions .btn-login{background:var(--active-color);color:var(--bg-primary-color);border:none;border-radius:4px;padding:var(--space-8) var(--space-24);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-slow)}travel--organism-login-form-102009 .login-form .form-actions .btn-login:hover,travel--organism-login-form-102009 .login-form .form-actions .btn-login:focus{background:var(--active-color-hover)}travel--organism-login-form-102009 .login-form .form-actions .link-password-recovery{color:var(--link-color);font-size:var(--font-size-12);text-decoration:underline;cursor:pointer}travel--organism-login-form-102009 .login-form .form-actions .link-password-recovery:hover,travel--organism-login-form-102009 .login-form .form-actions .link-password-recovery:focus{color:var(--link-color-hover)}@media (max-width:544px){travel--organism-login-form-102009 .login-form{padding:var(--space-16) var(--space-8);max-width:100%}}`);
    }
    render() {
        return html `<form class="login-form" aria-label="Formulário de Login" autocomplete="off" id="travel--login-form-102009-1">
          <h2 class="form-title" id="travel--login-form-102009-2">Entrar na sua conta</h2>
          <div class="form-group" id="travel--login-form-102009-3">
            <label for="login-email" id="travel--login-form-102009-4">E-mail</label>
            <input type="email" id="login-email" name="email" placeholder="seu@email.com" required="" autocomplete="username">
          </div>
          <div class="form-group" id="travel--login-form-102009-5">
            <label for="login-password" id="travel--login-form-102009-6">Senha</label>
            <input type="password" id="login-password" name="password" placeholder="Sua senha" required="" autocomplete="current-password">
          </div>
          <div class="form-actions" id="travel--login-form-102009-7">
            <button type="submit" class="btn-login" id="travel--login-form-102009-8">Entrar</button>
            <a href="#recuperar" class="link-password-recovery" aria-controls="password-recovery-form" id="travel--login-form-102009-9">Esqueceu a senha?</a>
          </div>
        </form>
      `;
    }
};
organismLoginForm = __decorate([
    customElement('travel--organism-login-form-102009')
], organismLoginForm);
export { organismLoginForm };
