/// <mls shortName="reservation" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageReservation = class PageReservation extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--reservation-102009{display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color-lighter)}travel--reservation-102009 header{width:100%;background:var(--bg-primary-color);box-shadow:0 1px 4px rgba(211,211,211,0.08)}travel--reservation-102009 .reservation-main{flex:1 1 auto;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding:var(--space-32) 0 var(--space-32) 0;background:var(--bg-primary-color-lighter);min-height:60vh}travel--reservation-102009 footer{width:100%;background:var(--grey-color-light);margin-top:auto}@media (max-width:544px){travel--reservation-102009 .reservation-main{padding:var(--space-16) 0 var(--space-16) 0}}`);
    }
    initPage() {
    }
};
PageReservation = __decorate([
    customElement('travel--reservation-102009')
], PageReservation);
export { PageReservation };
