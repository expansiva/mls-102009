/// <mls shortName="organismReservationCta" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismReservationCta = class organismReservationCta extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-reservation-cta-102009{display:block;background:var(--bg-secondary-color-lighter);padding:var(--space-32) 0}travel--organism-reservation-cta-102009 .reservation-cta__container{max-width:700px;margin:0 auto;padding:0 var(--space-16);display:flex;justify-content:flex-end}travel--organism-reservation-cta-102009 .reservation-cta__content{display:flex;align-items:center;gap:var(--space-24);background:var(--bg-primary-color);border-radius:var(--space-16);box-shadow:0 1px 4px rgba(230,230,230,0.15);padding:var(--space-16) var(--space-24)}travel--organism-reservation-cta-102009 .reservation-cta__price{font-size:var(--font-size-20);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold)}travel--organism-reservation-cta-102009 .reservation-cta__button{background:var(--text-secondary-color);color:var(--bg-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);border:none;border-radius:var(--space-8);padding:var(--space-8) var(--space-24);text-decoration:none;transition:background var(--transition-slow);box-shadow:0 1px 4px rgba(230,230,230,0.1)}travel--organism-reservation-cta-102009 .reservation-cta__button:hover,travel--organism-reservation-cta-102009 .reservation-cta__button:focus{background:var(--text-secondary-color-hover)}@media (max-width:768px){travel--organism-reservation-cta-102009 .reservation-cta__container{justify-content:center}travel--organism-reservation-cta-102009 .reservation-cta__content{flex-direction:column;gap:var(--space-16);width:100%;align-items:stretch}travel--organism-reservation-cta-102009 .reservation-cta__button{width:100%;text-align:center}}`);
    }
    render() {
        return html `<section class="reservation-cta__container" aria-label="Reservar pacote" id="travel--reservation-cta-102009-1">
        <div class="reservation-cta__content" id="travel--reservation-cta-102009-2">
          <span class="reservation-cta__price" id="travel--reservation-cta-102009-3">R$ 4.200,00</span>
          <a href="#reserva" class="reservation-cta__button" role="button" aria-label="Reservar agora" id="travel--reservation-cta-102009-4">Reservar agora</a>
        </div>
      </section>
    `;
    }
};
organismReservationCta = __decorate([
    customElement('travel--organism-reservation-cta-102009')
], organismReservationCta);
export { organismReservationCta };
