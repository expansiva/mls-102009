/// <mls shortName="organismNav" project="102009" folder="travel" enhancement="_100554_enhancementLit" groupName="travel" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismNav = class organismNav extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travel--organism-nav-102009 .nav{display:flex;align-items:center;justify-content:space-between;background:var(--bg-primary-color);padding:var(--space-16) var(--space-32);font-family:var(--font-family-primary);border-bottom:1px solid var(--grey-color);position:relative}@media (max-width:768px){travel--organism-nav-102009 .nav{flex-wrap:wrap;padding:var(--space-8) var(--space-16)}}travel--organism-nav-102009 .nav__logo-area{flex:0 0 auto}travel--organism-nav-102009 .nav__logo-img{height:40px;width:auto;display:block}travel--organism-nav-102009 .nav__toggle{display:none;background:none;border:none;cursor:pointer;flex-direction:column;gap:3px}@media (max-width:768px){travel--organism-nav-102009 .nav__toggle{display:flex}}travel--organism-nav-102009 .nav__toggle-bar{width:24px;height:3px;background:var(--text-primary-color);border-radius:2px;display:block;transition:background var(--transition-normal)}travel--organism-nav-102009 .nav__links{display:flex;gap:var(--space-24);list-style:none;margin:0;padding:0}@media (max-width:768px){travel--organism-nav-102009 .nav__links{flex-direction:column;position:absolute;top:100%;left:0;right:0;background:var(--bg-primary-color);border-top:1px solid var(--grey-color);display:none;z-index:10}}travel--organism-nav-102009 .nav__link{color:var(--text-primary-color);text-decoration:none;font-size:var(--font-size-16);font-weight:var(--font-weight-normal);padding:var(--space-8) var(--space-16);border-radius:4px;transition:background var(--transition-normal),color var(--transition-normal)}travel--organism-nav-102009 .nav__link:hover,travel--organism-nav-102009 .nav__link:focus{background:var(--bg-primary-color-lighter);color:var(--text-primary-color-hover);outline:none}travel--organism-nav-102009 .nav__link--active{color:var(--text-secondary-color);font-weight:var(--font-weight-bold)}travel--organism-nav-102009 .nav__link--auth{background:var(--bg-secondary-color);color:var(--bg-primary-color);font-weight:var(--font-weight-bold)}travel--organism-nav-102009 .nav__link--auth:hover,travel--organism-nav-102009 .nav__link--auth:focus{background:var(--bg-secondary-color-hover);color:var(--bg-primary-color)}@media (max-width:768px){travel--organism-nav-102009 .nav__links{display:none}travel--organism-nav-102009 .nav__toggle[aria-expanded="true"]+.nav__links{display:flex}}`);
    }
    render() {
        return html `<nav class="nav" aria-label="Navegação principal" id="travel--nav-102009-1">
        <div class="nav__logo-area" id="travel--nav-102009-2">
          <a href="/" class="nav__logo-link" aria-label="Página inicial" id="travel--nav-102009-3">
            <img src="https://images.unsplash.com/photo-1504542982118-59308b40fe0c?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxsb2dvJTIwYWclQzMlQUFuY2lhJTIwZGUlMjB2aWFnZW5zJTIwdHJhdmVsfGVufDB8fHx8MTc1NTAyODI3MHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Logo Travel" class="nav__logo-img" id="travel--nav-102009-4">
          </a>
        </div>
        <button class="nav__toggle" aria-label="Abrir menu" aria-controls="nav__links" aria-expanded="false" id="travel--nav-102009-5">
          <span class="nav__toggle-bar" id="travel--nav-102009-6"></span>
          <span class="nav__toggle-bar" id="travel--nav-102009-7"></span>
          <span class="nav__toggle-bar" id="travel--nav-102009-8"></span>
        </button>
        <ul class="nav__links" id="nav__links">
          <li id="travel--nav-102009-9"><a href="/" class="nav__link nav__link--active" id="travel--nav-102009-10">Home</a></li>
          <li id="travel--nav-102009-11"><a href="/pacotes" class="nav__link" id="travel--nav-102009-12">Pacotes</a></li>
          <li id="travel--nav-102009-13"><a href="/login" class="nav__link nav__link--auth" id="travel--nav-102009-14">Login</a></li>
        </ul>
      </nav>
    `;
    }
};
organismNav = __decorate([
    customElement('travel--organism-nav-102009')
], organismNav);
export { organismNav };
