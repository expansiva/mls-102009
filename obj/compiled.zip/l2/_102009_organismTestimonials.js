/// <mls shortName="organismTestimonials" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismTestimonials = class _102009_organismTestimonials extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-testimonials-102009 .testimonials-section{padding:var(--spacing-xxl) 0;background-color:var(--color-surface)}organism-testimonials-102009 .testimonials-carousel{display:grid;grid-template-columns:repeat(auto-fit, minmax(350px, 1fr));gap:var(--spacing-lg)}organism-testimonials-102009 .testimonial-card{background-color:white;padding:var(--spacing-xl);border-radius:var(--border-radius-md);box-shadow:var(--shadow-sm)}organism-testimonials-102009 .testimonial-card .testimonial-text{font-size:var(--font-size-lg);line-height:var(--line-height-lg);color:var(--color-text-normal);margin-bottom:var(--spacing-lg);font-style:italic}organism-testimonials-102009 .testimonial-card .testimonial-text::before{content:'"';font-size:2em;color:var(--color-primary);line-height:0}organism-testimonials-102009 .testimonial-card .testimonial-author{display:flex;align-items:center;gap:var(--spacing-md)}organism-testimonials-102009 .testimonial-card .testimonial-author .author-photo{width:60px;height:60px;border-radius:50%;object-fit:cover}organism-testimonials-102009 .testimonial-card .testimonial-author .author-info .author-name{font-weight:var(--font-weight-bold);color:var(--color-primary);margin-bottom:var(--spacing-xs)}organism-testimonials-102009 .testimonial-card .testimonial-author .author-info .author-pet{color:var(--color-text-secondary);font-size:var(--font-size-sm)}`);
    }
    render() {
        return html `
  <section class="testimonials-section" id="testimonials-1">
  <div class="container" id="testimonials-2">
    <h2 class="section-title" id="testimonials-3">O que nossos clientes dizem</h2>
    <div class="testimonials-carousel" id="testimonials-4">
      
      <div class="testimonial-card" id="testimonials-5">
        <div class="testimonial-content" id="testimonials-6">
          <p class="testimonial-text" id="testimonials-7">"Excelente atendimento! Minha cachorrinha sempre fica linda depois do banho e tosa. Equipe muito carinhosa."</p>
          <div class="testimonial-author" id="testimonials-8">
            <img src="https://images.unsplash.com/photo-1712571354493-a249035399e0?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxoYXBweSUyMHdvbWFuJTIwd2l0aCUyMGRvZyUyMHBvcnRyYWl0fGVufDB8fHx8MTc1MzM2NTA2M3ww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Foto da Maria Silva" class="author-photo" id="testimonials-9">
            <div class="author-info" id="testimonials-10">
              <h4 class="author-name" id="testimonials-11">Maria Silva</h4>
              <span class="author-pet" id="testimonials-12">Dona da Bella</span>
            </div>
          </div>
        </div>
      </div>
      
      <div class="testimonial-card" id="testimonials-13">
        <div class="testimonial-content" id="testimonials-14">
          <p class="testimonial-text" id="testimonials-15">"O veterinário é muito competente e atencioso. Meu gato se sente à vontade durante as consultas."</p>
          <div class="testimonial-author" id="testimonials-16">
            <img src="https://images.unsplash.com/photo-1745365491611-7eaac36bccc0?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxtYW4lMjBob2xkaW5nJTIwY2F0JTIwcG9ydHJhaXR8ZW58MHx8fHwxNzUzMzY1MDYzfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Foto do João Santos" class="author-photo" id="testimonials-17">
            <div class="author-info" id="testimonials-18">
              <h4 class="author-name" id="testimonials-19">João Santos</h4>
              <span class="author-pet" id="testimonials-20">Dono do Mimi</span>
            </div>
          </div>
        </div>
      </div>
      
      <div class="testimonial-card" id="testimonials-21">
        <div class="testimonial-content" id="testimonials-22">
          <p class="testimonial-text" id="testimonials-23">"Produtos de ótima qualidade e preços justos. A entrega é sempre rápida e os produtos chegam em perfeito estado."</p>
          <div class="testimonial-author" id="testimonials-24">
            <img src="https://images.unsplash.com/photo-1752306639329-02e07c8ec4cd?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHdpdGglMjBsYXJnZSUyMGRvZyUyMHBvcnRyYWl0fGVufDB8fHx8MTc1MzM2NTA2NHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Foto da Ana Costa" class="author-photo" id="testimonials-25">
            <div class="author-info" id="testimonials-26">
              <h4 class="author-name" id="testimonials-27">Ana Costa</h4>
              <span class="author-pet" id="testimonials-28">Dona do Rex</span>
            </div>
          </div>
        </div>
      </div>
      
    </div>
  </div>
</section>

    `;
    }
};
_102009_organismTestimonials = __decorate([
    customElement('organism-testimonials-102009')
], _102009_organismTestimonials);
export { _102009_organismTestimonials };
