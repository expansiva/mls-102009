/// <mls shortName="organismServicosDestaque" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
let _102009_organismServicosDestaque = class _102009_organismServicosDestaque extends IcaOrganismWireframeBase {
    constructor() {
        super(...arguments);
        this.generalDescription = 'Seção de serviços principais na home.';
        this.goal = 'Apresentar banho e tosa de forma clara e atrativa.';
    }
};
_102009_organismServicosDestaque = __decorate([
    customElement('organism-servicos-destaque-102009')
], _102009_organismServicosDestaque);
export { _102009_organismServicosDestaque };
