/// <mls shortName="layer3AddServiceOrder" project="102009" enhancement="_blank" />
export async function addServiceOrder(ctx, data) {
    return await ctx.io.petshopDB.serviceOrder.add(data);
}
