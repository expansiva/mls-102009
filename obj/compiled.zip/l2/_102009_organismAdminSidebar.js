/// <mls shortName="organismAdminSidebar" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAdminSidebar = class _102009_organismAdminSidebar extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-admin-sidebar-102009 .sidebar{height:100%;padding:var(--spacing-lg) 0}organism-admin-sidebar-102009 .sidebar .sidebar-menu{list-style:none;padding:0;margin:0}organism-admin-sidebar-102009 .sidebar .sidebar-menu .menu-item .menu-link{display:flex;align-items:center;gap:var(--spacing-sm);padding:var(--spacing-md) var(--spacing-lg);color:var(--color-text-normal);text-decoration:none;transition:var(--transition-base)}organism-admin-sidebar-102009 .sidebar .sidebar-menu .menu-item .menu-link .icon{font-size:var(--font-size-lg)}organism-admin-sidebar-102009 .sidebar .sidebar-menu .menu-item .menu-link .text{font-weight:var(--font-weight-normal)}organism-admin-sidebar-102009 .sidebar .sidebar-menu .menu-item .menu-link:hover{background-color:var(--color-overlay);color:var(--color-primary)}organism-admin-sidebar-102009 .sidebar .sidebar-menu .menu-item.active .menu-link{background-color:var(--color-primary);color:white}organism-admin-sidebar-102009 .sidebar .sidebar-menu .menu-item.active .menu-link:hover{background-color:var(--color-primary);color:white}`);
    }
    render() {
        return html `
      <div class="sidebar">
        <ul class="sidebar-menu">
          <li class="menu-item active">
            <a href="#services" class="menu-link">
              <span class="icon">🛁</span>
              <span class="text">Serviços</span>
            </a>
          </li>
          <li class="menu-item">
            <a href="#products" class="menu-link">
              <span class="icon">🛍️</span>
              <span class="text">Produtos</span>
            </a>
          </li>
          <li class="menu-item">
            <a href="#appointments" class="menu-link">
              <span class="icon">📅</span>
              <span class="text">Agendamentos</span>
            </a>
          </li>
          <li class="menu-item">
            <a href="#customers" class="menu-link">
              <span class="icon">👥</span>
              <span class="text">Clientes</span>
            </a>
          </li>
          <li class="menu-item">
            <a href="#reports" class="menu-link">
              <span class="icon">📊</span>
              <span class="text">Relatórios</span>
            </a>
          </li>
          <li class="menu-item">
            <a href="#settings" class="menu-link">
              <span class="icon">⚙️</span>
              <span class="text">Configurações</span>
            </a>
          </li>
        </ul>
      </div>
    `;
    }
};
_102009_organismAdminSidebar = __decorate([
    customElement('organism-admin-sidebar-102009')
], _102009_organismAdminSidebar);
export { _102009_organismAdminSidebar };
