/// <mls shortName="organismAdminCustomers" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAdminCustomers = class _102009_organismAdminCustomers extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-admin-customers-102009 .admin-section{background-color:var(--color-background);border-radius:var(--border-radius-md);padding:var(--spacing-lg);margin-bottom:var(--spacing-lg);box-shadow:var(--shadow-sm)}organism-admin-customers-102009 .admin-section .section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-lg)}organism-admin-customers-102009 .admin-section .section-header h2{color:var(--color-text-normal);font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);margin:0}organism-admin-customers-102009 .admin-section .section-header .search-controls{display:flex;gap:var(--spacing-xs)}organism-admin-customers-102009 .admin-section .section-header .search-controls .search-input{padding:var(--spacing-xs) var(--spacing-sm);border:1px solid var(--color-border);border-radius:var(--border-radius-xs);font-size:var(--font-size-sm);width:250px}organism-admin-customers-102009 .admin-section .section-header .search-controls .btn-search{background-color:var(--color-primary);color:white;border:none;padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);cursor:pointer;transition:var(--transition-base)}organism-admin-customers-102009 .admin-section .section-header .search-controls .btn-search:hover{background-color:var(--color-link-hover)}organism-admin-customers-102009 .admin-section .customers-grid{display:grid;grid-template-columns:repeat(auto-fill, minmax(400px, 1fr));gap:var(--spacing-md)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card{border:1px solid var(--color-border);border-radius:var(--border-radius-sm);padding:var(--spacing-md);transition:var(--transition-base)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card:hover{box-shadow:var(--shadow-md)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info{display:flex;gap:var(--spacing-md);margin-bottom:var(--spacing-md)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-avatar{width:60px;height:60px;border-radius:50%;object-fit:cover}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details{flex:1}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details h4{margin:0 0 var(--spacing-xs) 0;color:var(--color-text-normal);font-size:var(--font-size-md)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details p{margin:var(--spacing-xxs) 0;font-size:var(--font-size-sm)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details p.customer-email{color:var(--color-primary)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details p.customer-phone{color:var(--color-text-secondary)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details p.customer-since{color:var(--color-text-disabled);font-size:var(--font-size-xs)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info{margin-bottom:var(--spacing-md)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info h5{margin:0 0 var(--spacing-xs) 0;color:var(--color-text-normal);font-size:var(--font-size-sm);font-weight:var(--font-weight-bold)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info .pet-list .pet-item{display:flex;align-items:center;gap:var(--spacing-xs);margin-bottom:var(--spacing-xs)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info .pet-list .pet-item .pet-photo{width:40px;height:40px;border-radius:50%;object-fit:cover}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info .pet-list .pet-item .pet-details{display:flex;flex-direction:column}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info .pet-list .pet-item .pet-details .pet-name{font-weight:var(--font-weight-bold);color:var(--color-text-normal);font-size:var(--font-size-sm)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info .pet-list .pet-item .pet-details .pet-breed{color:var(--color-text-secondary);font-size:var(--font-size-xs)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions{display:flex;gap:var(--spacing-xs)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions button{padding:var(--spacing-xs) var(--spacing-sm);border:none;border-radius:var(--border-radius-xs);cursor:pointer;font-size:var(--font-size-sm);transition:var(--transition-base)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions .btn-view{background-color:var(--color-primary);color:white}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions .btn-view:hover{background-color:var(--color-link-hover)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions .btn-edit{background-color:var(--color-secondary);color:white}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions .btn-edit:hover{opacity:.9}`);
    }
    render() {
        return html `
  <section class="admin-section" id="admin-customers-1">
  <div class="section-header" id="admin-customers-2">
    <h2 id="admin-customers-3">Clientes e Pets</h2>
    <div class="search-controls" id="admin-customers-4">
      <input type="text" placeholder="Buscar cliente..." class="search-input" id="admin-customers-5">
      <button class="btn-search" id="admin-customers-6">🔍</button>
    </div>
  </div>
  
  <div class="customers-grid" id="admin-customers-7">
    <div class="customer-card" id="admin-customers-8">
      <div class="customer-info" id="admin-customers-9">
        <img src="https://images.unsplash.com/photo-1675186914580-94356f7c012c?..." alt="Maria Silva" class="customer-avatar" id="admin-customers-10">
        <div class="customer-details" id="admin-customers-11">
          <h4 id="admin-customers-12">Maria Silva</h4>
          <p class="customer-email" id="admin-customers-13">maria@email.com</p>
          <p class="customer-phone" id="admin-customers-14">(11) 99999-9999</p>
          <p class="customer-since" id="admin-customers-15">Cliente desde: Jan 2024</p>
        </div>
      </div>
      <div class="pets-info" id="admin-customers-16">
        <h5 id="admin-customers-17">Pets:</h5>
        <div class="pet-list" id="admin-customers-18">
          <div class="pet-item" id="admin-customers-19">
            <img src="https://images.unsplash.com/photo-1609348490161-a879e4327ae9?..." alt="Rex" class="pet-photo" id="admin-customers-20">
            <div class="pet-details" id="admin-customers-21">
              <span class="pet-name" id="admin-customers-22">Rex</span>
              <span class="pet-breed" id="admin-customers-23">Golden Retriever</span>
            </div>
          </div>
        </div>
      </div>
      <div class="customer-actions" id="admin-customers-24">
        <button class="btn-view" id="admin-customers-25">Ver Perfil</button>
        <button class="btn-edit" id="admin-customers-26">Editar</button>
      </div>
    </div>

    <div class="customer-card" id="admin-customers-27">
      <div class="customer-info" id="admin-customers-28">
        <img src="https://images.unsplash.com/photo-1664101606938-e664f5852fac?..." alt="João Santos" class="customer-avatar" id="admin-customers-29">
        <div class="customer-details" id="admin-customers-30">
          <h4 id="admin-customers-31">João Santos</h4>
          <p class="customer-email" id="admin-customers-32">joao@email.com</p>
          <p class="customer-phone" id="admin-customers-33">(11) 88888-8888</p>
          <p class="customer-since" id="admin-customers-34">Cliente desde: Mar 2024</p>
        </div>
      </div>
      <div class="pets-info" id="admin-customers-35">
        <h5 id="admin-customers-36">Pets:</h5>
        <div class="pet-list" id="admin-customers-37">
          <div class="pet-item" id="admin-customers-38">
            <img src="https://images.unsplash.com/photo-1675191855383-4b80d79a0628?..." alt="Mimi" class="pet-photo" id="admin-customers-39">
            <div class="pet-details" id="admin-customers-40">
              <span class="pet-name" id="admin-customers-41">Mimi</span>
              <span class="pet-breed" id="admin-customers-42">Gato Persa</span>
            </div>
          </div>
        </div>
      </div>
      <div class="customer-actions" id="admin-customers-43">
        <button class="btn-view" id="admin-customers-44">Ver Perfil</button>
        <button class="btn-edit" id="admin-customers-45">Editar</button>
      </div>
    </div>
  </div>
</section>

    `;
    }
};
_102009_organismAdminCustomers = __decorate([
    customElement('organism-admin-customers-102009')
], _102009_organismAdminCustomers);
export { _102009_organismAdminCustomers };
