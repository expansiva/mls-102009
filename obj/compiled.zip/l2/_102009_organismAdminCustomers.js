/// <mls shortName="organismAdminCustomers" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAdminCustomers = class _102009_organismAdminCustomers extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-admin-customers-102009 .admin-section{background-color:var(--color-background);border-radius:var(--border-radius-md);padding:var(--spacing-lg);margin-bottom:var(--spacing-lg);box-shadow:var(--shadow-sm)}organism-admin-customers-102009 .admin-section .section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-lg)}organism-admin-customers-102009 .admin-section .section-header h2{color:var(--color-text-normal);font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);margin:0}organism-admin-customers-102009 .admin-section .section-header .search-controls{display:flex;gap:var(--spacing-xs)}organism-admin-customers-102009 .admin-section .section-header .search-controls .search-input{padding:var(--spacing-xs) var(--spacing-sm);border:1px solid var(--color-border);border-radius:var(--border-radius-xs);font-size:var(--font-size-sm);width:250px}organism-admin-customers-102009 .admin-section .section-header .search-controls .btn-search{background-color:var(--color-primary);color:white;border:none;padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);cursor:pointer;transition:var(--transition-base)}organism-admin-customers-102009 .admin-section .section-header .search-controls .btn-search:hover{background-color:var(--color-link-hover)}organism-admin-customers-102009 .admin-section .customers-grid{display:grid;grid-template-columns:repeat(auto-fill, minmax(400px, 1fr));gap:var(--spacing-md)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card{border:1px solid var(--color-border);border-radius:var(--border-radius-sm);padding:var(--spacing-md);transition:var(--transition-base)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card:hover{box-shadow:var(--shadow-md)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info{display:flex;gap:var(--spacing-md);margin-bottom:var(--spacing-md)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-avatar{width:60px;height:60px;border-radius:50%;object-fit:cover}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details{flex:1}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details h4{margin:0 0 var(--spacing-xs) 0;color:var(--color-text-normal);font-size:var(--font-size-md)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details p{margin:var(--spacing-xxs) 0;font-size:var(--font-size-sm)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details p.customer-email{color:var(--color-primary)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details p.customer-phone{color:var(--color-text-secondary)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-info .customer-details p.customer-since{color:var(--color-text-disabled);font-size:var(--font-size-xs)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info{margin-bottom:var(--spacing-md)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info h5{margin:0 0 var(--spacing-xs) 0;color:var(--color-text-normal);font-size:var(--font-size-sm);font-weight:var(--font-weight-bold)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info .pet-list .pet-item{display:flex;align-items:center;gap:var(--spacing-xs);margin-bottom:var(--spacing-xs)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info .pet-list .pet-item .pet-photo{width:40px;height:40px;border-radius:50%;object-fit:cover}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info .pet-list .pet-item .pet-details{display:flex;flex-direction:column}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info .pet-list .pet-item .pet-details .pet-name{font-weight:var(--font-weight-bold);color:var(--color-text-normal);font-size:var(--font-size-sm)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .pets-info .pet-list .pet-item .pet-details .pet-breed{color:var(--color-text-secondary);font-size:var(--font-size-xs)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions{display:flex;gap:var(--spacing-xs)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions button{padding:var(--spacing-xs) var(--spacing-sm);border:none;border-radius:var(--border-radius-xs);cursor:pointer;font-size:var(--font-size-sm);transition:var(--transition-base)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions .btn-view{background-color:var(--color-primary);color:white}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions .btn-view:hover{background-color:var(--color-link-hover)}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions .btn-edit{background-color:var(--color-secondary);color:white}organism-admin-customers-102009 .admin-section .customers-grid .customer-card .customer-actions .btn-edit:hover{opacity:.9}`);
    }
    render() {
        return html `
      <section class="admin-section">
        <div class="section-header">
          <h2>Clientes e Pets</h2>
          <div class="search-controls">
            <input type="text" placeholder="Buscar cliente..." class="search-input">
            <button class="btn-search">🔍</button>
          </div>
        </div>
        
        <div class="customers-grid">
          <div class="customer-card">
            <div class="customer-info">
              <img src="https://images.unsplash.com/photo-1675186914580-94356f7c012c?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHNtaWxpbmclMjBwb3J0cmFpdCUyMHByb2Zlc3Npb25hbCUyMGF2YXRhcnxlbnwwfHx8fDE3NTMzNjU5OTR8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Maria Silva" class="customer-avatar">
              <div class="customer-details">
                <h4>Maria Silva</h4>
                <p class="customer-email">maria@email.com</p>
                <p class="customer-phone">(11) 99999-9999</p>
                <p class="customer-since">Cliente desde: Jan 2024</p>
              </div>
            </div>
            <div class="pets-info">
              <h5>Pets:</h5>
              <div class="pet-list">
                <div class="pet-item">
                  <img src="https://images.unsplash.com/photo-1609348490161-a879e4327ae9?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxnb2xkZW4lMjByZXRyaWV2ZXIlMjBkb2clMjBwb3J0cmFpdCUyMGhhcHB5fGVufDB8fHx8MTc1MzM2NTQzMXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Rex" class="pet-photo">
                  <div class="pet-details">
                    <span class="pet-name">Rex</span>
                    <span class="pet-breed">Golden Retriever</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="customer-actions">
              <button class="btn-view">Ver Perfil</button>
              <button class="btn-edit">Editar</button>
            </div>
          </div>
          
          <div class="customer-card">
            <div class="customer-info">
              <img src="https://images.unsplash.com/photo-1664101606938-e664f5852fac?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxtYW4lMjBzbWlsaW5nJTIwcG9ydHJhaXQlMjBwcm9mZXNzaW9uYWwlMjBhdmF0YXJ8ZW58MHx8fHwxNzUzMzY1OTk0fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="João Santos" class="customer-avatar">
              <div class="customer-details">
                <h4>João Santos</h4>
                <p class="customer-email">joao@email.com</p>
                <p class="customer-phone">(11) 88888-8888</p>
                <p class="customer-since">Cliente desde: Mar 2024</p>
              </div>
            </div>
            <div class="pets-info">
              <h5>Pets:</h5>
              <div class="pet-list">
                <div class="pet-item">
                  <img src="https://images.unsplash.com/photo-1675191855383-4b80d79a0628?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXJzaWFuJTIwY2F0JTIwcG9ydHJhaXQlMjBmbHVmZnklMjB3aGl0ZXxlbnwwfHx8fDE3NTMzNjU0MzF8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Mimi" class="pet-photo">
                  <div class="pet-details">
                    <span class="pet-name">Mimi</span>
                    <span class="pet-breed">Gato Persa</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="customer-actions">
              <button class="btn-view">Ver Perfil</button>
              <button class="btn-edit">Editar</button>
            </div>
          </div>
        </div>
      </section>
    `;
    }
};
_102009_organismAdminCustomers = __decorate([
    customElement('organism-admin-customers-102009')
], _102009_organismAdminCustomers);
export { _102009_organismAdminCustomers };
