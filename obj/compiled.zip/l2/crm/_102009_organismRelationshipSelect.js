var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismRelationshipSelect" project="102009" folder="crm" enhancement="_100554_enhancementLit" groupName="crm" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { property } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismRelationshipSelect = class organismRelationshipSelect extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`crm--organism-relationship-select-102009 .organism-relationship-select{padding:16px;background-color:var(--bg-primary-color);font-family:var(--font-family-primary)}crm--organism-relationship-select-102009 .organism-relationship-select__description{color:var(--text-primary-color-darker);font-size:var(--font-size-16);line-height:var(--line-height-medium);margin-bottom:16px}crm--organism-relationship-select-102009 .organism-relationship-select__options{display:flex;gap:16px}crm--organism-relationship-select-102009 .organism-relationship-select__option{display:flex;align-items:center;margin-bottom:0}crm--organism-relationship-select-102009 .organism-relationship-select-field{margin-top:var(--space-16)}crm--organism-relationship-select-102009 .organism-relationship-select__field-label{margin-left:16px;color:var(--text-primary-color);font-size:var(--font-size-16)}crm--organism-relationship-select-102009 .organism-relationship-select__input{margin-left:8px;padding:8px;border:1px solid var(--grey-color);border-radius:4px;font-size:var(--font-size-16)}crm--organism-relationship-select-102009 .organism-relationship-select__icon{margin-left:8px;color:var(--text-secondary-color)}crm--organism-relationship-select-102009 .organism-relationship-select__continue{margin-top:16px;background-color:var(--active-color);color:var(--bg-primary-color-lighter);border:none;padding:8px 16px;border-radius:4px;font-size:var(--font-size-16);cursor:pointer;display:flex;align-items:center}crm--organism-relationship-select-102009 .organism-relationship-select__arrow{margin-left:8px;color:var(--success-color)}`);
        // Property to track the selected relationship type
        this.selectedRelationship = 'new-relationship';
    }
    // Handler for radio button change events
    handleRelationshipChange(e) {
        const target = e.target;
        this.selectedRelationship = target.value;
    }
    render() {
        return html `
<div class="organism-relationship-select">
<p class="organism-relationship-select__description">Neste programa, é possível escolher o tipo de relacionamento a ser inserido:</p>
<div class="organism-relationship-select__options">
<div class="organism-relationship-select__option">
<input type="radio" id="new-contact" name="relationship-type" value="new-contact" @change=${this.handleRelationshipChange}>
<label for="new-contact">Incluir Novo Contato</label>
</div>
<div class="organism-relationship-select__option">
<input type="radio" id="new-relationship" name="relationship-type" value="new-relationship" checked @change=${this.handleRelationshipChange}>
<label for="new-relationship">Incluir Novo Relacionamento</label>
</div>
</div>
${this.selectedRelationship === 'new-relationship' ? html `
<div class="organism-relationship-select-field">
<span class="organism-relationship-select__field-label">Informe o código do Relacionamento:</span>
<input type="text" value="174289" class="organism-relationship-select__input">
<span class="organism-relationship-select__icon">🔍</span>
</div>
` : ''}
<button class="organism-relationship-select__continue">Continuar</button>
</div>
`;
    }
};
__decorate([
    property()
], organismRelationshipSelect.prototype, "selectedRelationship", void 0);
organismRelationshipSelect = __decorate([
    customElement('crm--organism-relationship-select-102009')
], organismRelationshipSelect);
export { organismRelationshipSelect };
