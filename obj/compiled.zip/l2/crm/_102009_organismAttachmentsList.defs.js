/// <mls shortName="organismAttachmentsList" project="102009" folder="crm" groupName="crm" enhancement="_blank" />
// Do not change – automatically generated code.
export const defs = {
    "meta": {
        "projectId": 102009,
        "folder": "crm",
        "shortName": "organismAttachmentsList",
        "type": "organism",
        "devFidelity": "scaffold",
        "group": "crm",
        "tags": [
            "lit",
            "organism"
        ]
    },
    "references": {
        "widgets": [],
        "plugins": [],
        "statesRO": [],
        "statesRW": [],
        "statesWO": [],
        "imports": []
    },
    "planning": {
        "generalDescription": "",
        "goal": "",
        "userStories": [],
        "userRequestsEnhancements": [],
        "constraints": []
    }
};
