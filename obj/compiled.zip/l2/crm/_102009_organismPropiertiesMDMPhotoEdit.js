var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismPropiertiesMDMPhotoEdit" project="102009" folder="crm" enhancement="_100554_enhancementLit" groupName="crm" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPropiertiesMDMPhotoEdit = class organismPropiertiesMDMPhotoEdit extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`crm--organism-propierties-m-d-m-photo-edit-102009{display:block;background-color:var(--bg-primary-color-lighter);padding:16px}crm--organism-propierties-m-d-m-photo-edit-102009 .container{border:1px solid var(--grey-color);font-family:var(--font-family-primary);padding:16px}crm--organism-propierties-m-d-m-photo-edit-102009 .container h1{font-size:var(--font-size-24);font-weight:var(--font-weight-normal);color:var(--text-primary-color);margin-bottom:var(--space-24);text-align:left}crm--organism-propierties-m-d-m-photo-edit-102009 .container .field{display:flex;align-items:center;margin-bottom:var(--space-16)}crm--organism-propierties-m-d-m-photo-edit-102009 .container .field label{font-size:var(--font-size-16);color:var(--text-primary-color);margin-right:var(--space-16);min-width:80px}crm--organism-propierties-m-d-m-photo-edit-102009 .container .field button{background-color:var(--bg-secondary-color);color:var(--text-primary-color);border:1px solid var(--grey-color);padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);cursor:pointer;margin-right:var(--space-16)}crm--organism-propierties-m-d-m-photo-edit-102009 .container .field button:hover{background-color:var(--bg-secondary-color-hover)}crm--organism-propierties-m-d-m-photo-edit-102009 .container .field span{font-size:var(--font-size-16);color:var(--text-primary-color-lighter)}crm--organism-propierties-m-d-m-photo-edit-102009 .container .field input[type="text"]{flex:1;padding:var(--space-8);border:1px solid var(--grey-color);font-size:var(--font-size-16);background-color:var(--bg-primary-color-lighter);color:var(--text-primary-color)}crm--organism-propierties-m-d-m-photo-edit-102009 .container .organism-actions{display:flex;justify-content:end;gap:var(--space-16);margin-top:var(--space-32)}crm--organism-propierties-m-d-m-photo-edit-102009 .container .organism-button{padding:var(--space-8) var(--space-16);border:none;border-radius:4px;font-size:var(--font-size-16);cursor:pointer;transition:background-color var(--transition-normal)}crm--organism-propierties-m-d-m-photo-edit-102009 .container .organism-button--primary{background-color:var(--active-color);color:var(--bg-primary-color)}crm--organism-propierties-m-d-m-photo-edit-102009 .container .organism-button--primary:hover{background-color:var(--active-color-hover)}crm--organism-propierties-m-d-m-photo-edit-102009 .container .organism-button--secondary{background-color:var(--bg-secondary-color);color:var(--text-primary-color)}crm--organism-propierties-m-d-m-photo-edit-102009 .container .organism-button--secondary:hover{background-color:var(--bg-secondary-color-hover)}`);
    }
    render() {
        return html `<div class="container" id="crm--organism-propierties-m-d-m-photo-edit-102009-1">
<h1 id="crm--organism-propierties-m-d-m-photo-edit-102009-2">Adicionar nova Foto:</h1>
<div class="field" id="crm--organism-propierties-m-d-m-photo-edit-102009-3">
<label id="crm--organism-propierties-m-d-m-photo-edit-102009-4">Foto:</label>
<button id="crm--organism-propierties-m-d-m-photo-edit-102009-5">Escolher arquivo</button>
<span id="crm--organism-propierties-m-d-m-photo-edit-102009-6">Nenhum arquivo escolhido</span>
</div>
<div class="field" id="crm--organism-propierties-m-d-m-photo-edit-102009-7">
<label id="crm--organism-propierties-m-d-m-photo-edit-102009-8">Descrição:</label>
<input type="text" id="crm--organism-propierties-m-d-m-photo-edit-102009-9">
</div>

<div class="organism-actions" id="crm--organism-propierties-m-d-m-photo-edit-102009-11">
<button class="organism-button organism-button--secondary" id="crm--organism-propierties-m-d-m-photo-edit-102009-12">Voltar</button>
<button class="organism-button organism-button--secondary" id="crm--organism-propierties-m-d-m-photo-edit-102009-13">Cancelar</button>
<button class="organism-button organism-button--primary" id="id="crm--organism-propierties-m-d-m-photo-edit-102009-14">Salvar</button>
</div>
</div>`;
    }
};
organismPropiertiesMDMPhotoEdit = __decorate([
    customElement('crm--organism-propierties-m-d-m-photo-edit-102009')
], organismPropiertiesMDMPhotoEdit);
export { organismPropiertiesMDMPhotoEdit };
