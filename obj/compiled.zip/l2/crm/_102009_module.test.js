/// <mls shortName="module" project="102009" enhancement="_blank" folder="crm" />
export const integrations = [];
export const tests = [];
