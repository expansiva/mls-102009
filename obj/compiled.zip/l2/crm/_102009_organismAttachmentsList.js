var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismAttachmentsList" project="102009" folder="crm" enhancement="_100554_enhancementLit" groupName="crm" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAttachmentsList = class organismAttachmentsList extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`crm--organism-attachments-list-102009 .attachments-list{background-color:white;font-family:Arial,sans-serif;padding:16px}crm--organism-attachments-list-102009 .attachments-list__new-btn{background-color:#f0f0f0;color:black;border:none;padding:8px 16px;font-size:16px;cursor:pointer;margin-bottom:16px}crm--organism-attachments-list-102009 .attachments-list__new-btn:hover{background-color:#e0e0e0}crm--organism-attachments-list-102009 .attachments-list__table{width:100%;border-collapse:collapse}crm--organism-attachments-list-102009 .attachments-list__table th,crm--organism-attachments-list-102009 .attachments-list__table td{padding:8px;text-align:left;border-bottom:1px solid #ccc}crm--organism-attachments-list-102009 .attachments-list__table th{background-color:#f9f9f9;font-weight:bold;color:black}crm--organism-attachments-list-102009 .attachments-list__table td{color:black}crm--organism-attachments-list-102009 .attachments-list__details-link{color:blue;text-decoration:none}crm--organism-attachments-list-102009 .attachments-list__details-link:hover{color:darkblue}crm--organism-attachments-list-102009 .attachments-list__pagination{margin-top:16px;display:flex;justify-content:center;gap:8px}crm--organism-attachments-list-102009 .attachments-list__pagination-btn{background-color:#f0f0f0;color:black;border:none;padding:8px 16px;font-size:16px;cursor:pointer}crm--organism-attachments-list-102009 .attachments-list__pagination-btn:hover{background-color:#e0e0e0}`);
        // Define a property for dynamic attachments data
        this.attachments = [
            { details: 'Detalhes', file: 'arquivo1.pdf', extranet: true },
            { details: 'Detalhes', file: 'arquivo2.docx', extranet: false },
            { details: 'Detalhes', file: 'arquivo3.xlsx', extranet: true },
            { details: 'Detalhes', file: 'arquivo4.txt', extranet: false },
        ];
    }
    render() {
        return html `<div class="attachments-list">
      <button class="attachments-list__new-btn">Novo</button>
      <table class="attachments-list__table">
        <thead>
          <tr>
            <th>Detalhes</th>
            <th>Arquivo</th>
            <th>(EXTRANET)</th>
          </tr>
        </thead>
        <tbody>
          ${this.attachments.map(attachment => html `
            <tr>
              <td><a href="#" class="attachments-list__details-link"> Detalhes </a></td>
              <td>${attachment.file}</td>
              <td><input type="checkbox" ?checked="${attachment.extranet}" disabled></td>
            </tr>
          `)}
        </tbody>
      </table>
    </div>`;
    }
};
organismAttachmentsList = __decorate([
    customElement('crm--organism-attachments-list-102009')
], organismAttachmentsList);
export { organismAttachmentsList };
