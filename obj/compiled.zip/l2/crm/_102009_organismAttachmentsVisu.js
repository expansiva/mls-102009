var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismAttachmentsVisu" project="102009" folder="crm" enhancement="_100554_enhancementLit" groupName="crm" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { collab_chevron_left, collab_file_pen, collab_xmark } from './_100554_collabIcons';
let organismAttachmentsVisu = class organismAttachmentsVisu extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`crm--organism-attachments-visu-102009 .attachment-detail{border:1px solid var(--grey-color);padding:var(--space-16);margin:var(--space-16);font-family:var(--font-family-primary)}crm--organism-attachments-visu-102009 .attachment-detail h2{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-16)}crm--organism-attachments-visu-102009 .attachment-detail .file-link{color:var(--link-color);text-decoration:underline;font-size:var(--font-size-16);font-weight:var(--font-weight-normal);margin-bottom:var(--space-8);display:block}crm--organism-attachments-visu-102009 .attachment-detail p{font-size:var(--font-size-16);color:var(--text-primary-color);line-height:var(--line-height-medium);margin-bottom:var(--space-8)}crm--organism-attachments-visu-102009 .attachment-actions{display:flex;gap:var(--space-8);margin-bottom:var(--space-16)}crm--organism-attachments-visu-102009 .action-button{display:flex;align-items:center;gap:var(--space-8);padding:var(--space-8) var(--space-16);background-color:var(--bg-secondary-color);border:1px solid var(--grey-color);color:var(--text-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);cursor:pointer;transition:background-color var(--transition-normal)}crm--organism-attachments-visu-102009 .action-button:hover{background-color:var(--bg-secondary-color-hover)}crm--organism-attachments-visu-102009 .action-button img{width:16px;height:16px}`);
    }
    render() {
        return html `<div class="attachment-detail">
<div class="attachment-actions">
<button class="action-button back-button" @click="${this.handleBack}">
${collab_chevron_left}
Voltar
</button>
<button class="action-button edit-button" @click="${this.handleEdit}">
${collab_file_pen}
Editar
</button>
<button class="action-button delete-button" @click="${this.handleDelete}">
${collab_xmark}
Deletar
</button>
</div>
<h2>Detalhe do Anexo</h2>
<a href="#" class="file-link">numeros_da_discadora_alarme.txt</a>
<p>Última alteração em 26/07/2016 10:31:49 por cleyton@expansiva.com.br</p>
<p>Descrição: números configurados na discadora do alarme.</p>
</div>`;
    }
    // New methods for button handlers
    handleBack() {
        // Handle back action
    }
    handleEdit() {
        // Handle edit action
    }
    handleDelete() {
        // Handle delete action
    }
};
organismAttachmentsVisu = __decorate([
    customElement('crm--organism-attachments-visu-102009')
], organismAttachmentsVisu);
export { organismAttachmentsVisu };
