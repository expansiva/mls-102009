var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismPropiertiesMDMJuridicalEdit" project="102009" folder="crm" enhancement="_100554_enhancementLit" groupName="crm" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPropiertiesMDMJuridicalEdit = class organismPropiertiesMDMJuridicalEdit extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`crm--organism-propierties-m-d-m-juridical-edit-102009 .organism-propierties-m-d-m-juridical-edit{padding:16px}crm--organism-propierties-m-d-m-juridical-edit-102009 .title{color:var(--text-primary-color);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}crm--organism-propierties-m-d-m-juridical-edit-102009 .warning{color:var(--warning-color);font-size:var(--font-size-16);margin-bottom:var(--space-24)}crm--organism-propierties-m-d-m-juridical-edit-102009 .panel{border:1px solid var(--bg-secondary-color-darker);padding:var(--space-16);background-color:var(--bg-primary-color)}crm--organism-propierties-m-d-m-juridical-edit-102009 .field{margin-bottom:var(--space-16);display:flex;flex-direction:column;align-items:flex-start}crm--organism-propierties-m-d-m-juridical-edit-102009 label{color:var(--text-primary-color);font-weight:var(--font-weight-normal);margin-bottom:var(--space-8)}crm--organism-propierties-m-d-m-juridical-edit-102009 input,crm--organism-propierties-m-d-m-juridical-edit-102009 select{flex:1;padding:var(--space-8);border:1px solid var(--grey-color);border-radius:4px;font-size:var(--font-size-16)}crm--organism-propierties-m-d-m-juridical-edit-102009 .attention{color:var(--error-color);font-weight:var(--font-weight-bold)}crm--organism-propierties-m-d-m-juridical-edit-102009 .save-button{background-color:var(--success-color);color:var(--bg-primary-color);border:none;padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;margin-top:var(--space-16)}crm--organism-propierties-m-d-m-juridical-edit-102009 .save-button:hover{background-color:var(--success-color-hover)}`);
    }
    render() {
        return html `<div class="organism-propierties-m-d-m-juridical-edit">
<h1 class="title">Edição do Nome da Empresa e CPF/CNPJ</h1>
<p class="warning">[Não utilize esta ferramenta para renomear identidades. Pois poderão causar falhas em relatórios futuros.]</p>
<div class="panel">
<div class="field">
<label>Nome Fantasia:</label>
<input type="text" value="Empresa ABC Teste">
</div>
<div class="field">
<label>Nome:</label>
<input type="text" value="Minha empresa ABC LTDA">
</div>
<div class="field">
<label>CPF/CNPJ:</label>
<input type="text" value="61.297.630/0001-64">
</div>
<div class="field">
<label>Código Alternativo:</label>
<input type="text" value="174291">
</div>
<div class="field">
<label>Tipo Alternativo:</label>
<select readonly>
<option>Pessoa Jurídica</option>
</select>
<span class="attention">*Atenção, este campo não é para ser alterado.</span>
</div>
<button class="save-button">Salvar</button>
</div>
</div>`;
    }
};
organismPropiertiesMDMJuridicalEdit = __decorate([
    customElement('crm--organism-propierties-m-d-m-juridical-edit-102009')
], organismPropiertiesMDMJuridicalEdit);
export { organismPropiertiesMDMJuridicalEdit };
