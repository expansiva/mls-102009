/// <mls shortName="organismAttachmentsAdd" project="102009" enhancement="_100554_enhancementLit" folder="crm" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAttachmentsEdit = class organismAttachmentsEdit extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`crm--organism-attachments-add-102009{background-color:var(--bg-primary-color);color:var(--text-primary-color);font-family:var(--font-family-primary);font-size:var(--font-size-16);line-height:var(--line-height-medium);padding:var(--space-24)}crm--organism-attachments-add-102009 .organism-attachments-add{max-width:600px;margin:0 auto}crm--organism-attachments-add-102009 h1{font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:var(--space-24);color:var(--text-primary-color-darker)}crm--organism-attachments-add-102009 .form-group{margin-bottom:var(--space-16)}crm--organism-attachments-add-102009 .form-group label{display:block;margin-bottom:var(--space-8);font-weight:var(--font-weight-normal);color:var(--text-primary-color)}crm--organism-attachments-add-102009 .form-group input[type="text"],crm--organism-attachments-add-102009 .form-group input[type="file"],crm--organism-attachments-add-102009 .form-group select,crm--organism-attachments-add-102009 .form-group textarea{width:100%;padding:var(--space-8);border:1px solid var(--grey-color);border-radius:4px;background-color:var(--bg-primary-color-lighter);color:var(--text-primary-color);font-size:var(--font-size-16)}crm--organism-attachments-add-102009 .form-group input[readonly]{background-color:var(--bg-secondary-color);color:var(--text-primary-color-disabled)}crm--organism-attachments-add-102009 .form-group span{display:block;margin-top:var(--space-8);font-size:var(--font-size-12);color:var(--text-secondary-color)}crm--organism-attachments-add-102009 .form-group p{margin-top:var(--space-8);font-size:var(--font-size-12);color:var(--warning-color)}crm--organism-attachments-add-102009 .form-group input[type="checkbox"]{width:auto;margin-right:var(--space-8)}crm--organism-attachments-add-102009 .checkbox-inline label{display:flex;align-items:center;margin-bottom:0}crm--organism-attachments-add-102009 .checkbox-inline input[type="checkbox"]{order:-1;margin-right:var(--space-8);margin-left:0}@media (max-width:544px){crm--organism-attachments-add-102009 .checkbox-inline label{flex-direction:column;align-items:flex-start}crm--organism-attachments-add-102009 .checkbox-inline input[type="checkbox"]{margin-bottom:var(--space-8);margin-right:0}}crm--organism-attachments-add-102009 .checkbox-inline{display:flex}crm--organism-attachments-add-102009 .form-actions{margin-top:var(--space-24);text-align:right}crm--organism-attachments-add-102009 .form-actions button{padding:var(--space-8) var(--space-16);border:none;border-radius:4px;font-size:var(--font-size-16);cursor:pointer;margin-left:var(--space-8);transition:background-color var(--transition-normal)}crm--organism-attachments-add-102009 .form-actions button:first-child{background-color:var(--grey-color);color:var(--text-primary-color)}crm--organism-attachments-add-102009 .form-actions button:first-child:hover{background-color:var(--grey-color-dark)}crm--organism-attachments-add-102009 .form-actions button:last-child{background-color:var(--active-color);color:var(--bg-primary-color-lighter)}crm--organism-attachments-add-102009 .form-actions button:last-child:hover{background-color:var(--active-color-hover)}`);
    }
    render() {
        return html `<form class="organism-attachments-add" id="crm--organism-attachments-add-102009-1">
<h1 id="crm--organism-attachments-add-102009-2">Adicionar Anexo</h1>
<div class="form-group" id="crm--organism-attachments-add-102009-3">

<div class="form-group" id="crm--organism-attachments-add-102009-6">
<label for="file-upload" id="crm--organism-attachments-add-102009-7">Escolher arquivo</label>
<input type="file" id="file-upload" id="crm--organism-attachments-add-102009-8">

<div class="form-group" id="crm--organism-attachments-add-102009-11">
<label for="team-select" id="crm--organism-attachments-add-102009-12">Editando Equipe</label>
<select id="team-select" id="crm--organism-attachments-add-102009-13">
<option value="financeiro" id="crm--organism-attachments-add-102009-14">Financeiro</option>
<option value="ti" id="crm--organism-attachments-add-102009-15">TI</option>
<option value="operacoes" id="crm--organism-attachments-add-102009-16">Operações</option>
</select>
</div>
<div class="form-group" id="crm--organism-attachments-add-102009-17">
<label for="description" id="crm--organism-attachments-add-102009-18">Editando Descrição</label>
<textarea id="description" placeholder="Descrição do anexo" id="crm--organism-attachments-add-102009-19"></textarea>
</div>
<div class="form-group checkbox-inline" id="crm--organism-attachments-add-102009-20">
<label for="release-checkbox" id="crm--organism-attachments-add-102009-21">Liberar para ÁREA DE DOWNLOADS DO CLIENTE (EXTRANET)</label>
<input type="checkbox" id="release-checkbox" id="crm--organism-attachments-add-102009-22">
</div>
<div class="form-actions" id="crm--organism-attachments-add-102009-23">
<button type="button" id="crm--organism-attachments-add-102009-24">Cancelar</button>
<button type="submit" id="crm--organism-attachments-add-102009-25">Salvar</button>
</div>
</form>
`;
    }
};
organismAttachmentsEdit = __decorate([
    customElement('crm--organism-attachments-add-102009')
], organismAttachmentsEdit);
export { organismAttachmentsEdit };
