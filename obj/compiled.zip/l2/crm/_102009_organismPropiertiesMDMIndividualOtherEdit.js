var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismPropiertiesMDMIndividualOtherEdit" project="102009" folder="crm" enhancement="_100554_enhancementLit" groupName="crm" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPropiertiesMDMIndividualOtherEdit = class organismPropiertiesMDMIndividualOtherEdit extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`crm--organism-propierties-m-d-m-individual-other-edit-102009 .organism-container{padding:24px;background-color:var(--bg-primary-color)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .panel{border:1px solid var(--bg-secondary-color);padding:24px;background-color:var(--bg-primary-color-lighter)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .subtitle{color:var(--text-primary-color);font-size:var(--font-size-20);font-weight:var(--font-weight-bold);margin-bottom:24px;text-align:left}crm--organism-propierties-m-d-m-individual-other-edit-102009 .field-group{display:flex;flex-direction:column;margin-bottom:var(--space-16)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .label{width:100%;color:var(--text-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);text-align:left;margin-bottom:var(--space-8)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .select,crm--organism-propierties-m-d-m-individual-other-edit-102009 .input,crm--organism-propierties-m-d-m-individual-other-edit-102009 .textarea{width:100%;padding:var(--space-8);border:1px solid var(--grey-color);border-radius:4px;font-size:var(--font-size-16);background-color:var(--bg-primary-color-lighter)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .textarea{resize:vertical;min-height:80px}crm--organism-propierties-m-d-m-individual-other-edit-102009 .radio-group{display:flex;gap:var(--space-16)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .radio-label{display:flex;align-items:center;color:var(--text-primary-color);font-size:var(--font-size-16)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .radio{margin-right:var(--space-8)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .warning{color:var(--error-color);font-size:var(--font-size-12)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .buttons{display:flex;justify-content:flex-end;gap:var(--space-16);margin-top:24px}crm--organism-propierties-m-d-m-individual-other-edit-102009 .button{padding:var(--space-8) var(--space-16);border:1px solid var(--grey-color);border-radius:4px;background-color:var(--bg-primary-color-lighter);color:var(--text-primary-color);font-size:var(--font-size-16);cursor:pointer;transition:background-color var(--transition-normal)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .button:hover{background-color:var(--bg-primary-color-lighter-hover)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .button.primary{background-color:var(--active-color);color:var(--bg-primary-color-lighter)}crm--organism-propierties-m-d-m-individual-other-edit-102009 .button.primary:hover{background-color:var(--active-color-hover)}`);
    }
    render() {
        return html `<div class="organism-container" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-1">
<div class="panel" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-3">
<h2 class="subtitle" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-4">Outras Informações</h2>
<div class="field-group" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-5">
<label class="label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-6">Status</label>
<select class="select" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-7">
<option value="ativo">Ativo</option>
<option value="desativado">Desativado</option>
</select>
<span class="warning" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-8">Atenção: Alterações para <strong>Desativado</strong> são <strong>irreversíveis</strong>.</span>
</div>
<div class="field-group" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-9">
<label class="label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-10">Motivo da Alteração do Status</label>
<input type="text" class="input" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-11" placeholder="Digite o motivo" required>
</div>
<div class="field-group" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-12">
<label class="label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-13">Sexo</label>
<div class="radio-group" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-14">
<label class="radio-label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-15"><input type="radio" name="sexo" value="masculino" class="radio"> Masculino</label>
<label class="radio-label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-16"><input type="radio" name="sexo" value="feminino" class="radio"> Feminino</label>
</div>
</div>
<div class="field-group" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-17">
<label class="label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-18">Telefone</label>
<input type="text" class="input" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-19" placeholder="Formato: (11) 99999-9999">
</div>
<div class="field-group" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-20">
<label class="label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-21">Fax</label>
<input type="text" class="input" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-22" placeholder="Formato: (11) 99999-9999">
</div>
<div class="field-group" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-23">
<label class="label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-24">Web</label>
<input type="url" class="input" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-25" placeholder="Ex: https://www.exemplo.com">
</div>
<div class="field-group" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-26">
<label class="label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-27">Email</label>
<input type="email" class="input" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-28" placeholder="Ex: usuario@exemplo.com">
</div>
<div class="field-group" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-29">
<label class="label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-30">RG</label>
<input type="text" class="input" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-31" placeholder="Formato: 99.999.999-9">
</div>
<div class="field-group" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-32">
<label class="label" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-33">Descrição</label>
<textarea class="textarea" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-34" placeholder="Digite uma descrição"></textarea>
</div>
<div class="buttons" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-35">
<button class="button" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-36">Voltar</button>
<button class="button" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-37">Cancelar</button>
<button class="button primary" id="crm--organism-propierties-m-d-m-individual-other-edit-102009-38">Salvar</button>
</div>
</div>
</div>
`;
    }
};
organismPropiertiesMDMIndividualOtherEdit = __decorate([
    customElement('crm--organism-propierties-m-d-m-individual-other-edit-102009')
], organismPropiertiesMDMIndividualOtherEdit);
export { organismPropiertiesMDMIndividualOtherEdit };
