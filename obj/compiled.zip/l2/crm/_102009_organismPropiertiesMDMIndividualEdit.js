/// <mls shortName="organismPropiertiesMDMIndividualEdit" project="102009" folder="crm" enhancement="_100554_enhancementLit" groupName="crm" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_/l2/icaOrganismBase';
let organismPropiertiesMDMIndividualEdit = class organismPropiertiesMDMIndividualEdit extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`crm--organism-propierties-m-d-m-individual-edit-102009 .container{padding:16px;font-family:var(--font-family-primary)}crm--organism-propierties-m-d-m-individual-edit-102009 .title{color:var(--text-primary-color);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:16px}crm--organism-propierties-m-d-m-individual-edit-102009 .warning{color:var(--warning-color);font-size:var(--font-size-16);margin-bottom:24px}crm--organism-propierties-m-d-m-individual-edit-102009 .panel{border:1px solid var(--grey-color);padding:16px;background-color:var(--bg-primary-color)}crm--organism-propierties-m-d-m-individual-edit-102009 .panel label{display:block;margin-bottom:8px;font-weight:var(--font-weight-normal);color:var(--text-primary-color)}crm--organism-propierties-m-d-m-individual-edit-102009 .panel input{width:100%;padding:8px;border:1px solid var(--grey-color-dark);border-radius:4px;font-size:var(--font-size-16);margin-bottom:16px}crm--organism-propierties-m-d-m-individual-edit-102009 .panel .save-button{padding:8px;background-color:var(--success-color);color:var(--bg-primary-color);border:none;border-radius:4px;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;margin-top:16px}crm--organism-propierties-m-d-m-individual-edit-102009 .panel .save-button:hover{background-color:var(--success-color-hover)}`);
    }
    render() {
        return html `<h3>In developed</h3>`;
    }
};
organismPropiertiesMDMIndividualEdit = __decorate([
    customElement('crm--organism-propierties-m-d-m-individual-edit-102009')
], organismPropiertiesMDMIndividualEdit);
export { organismPropiertiesMDMIndividualEdit };
