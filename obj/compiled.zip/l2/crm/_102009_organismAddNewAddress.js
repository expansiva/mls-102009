var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismAddNewAddress" project="102009" folder="crm" enhancement="_100554_enhancementLit" groupName="crm" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAddNewAddress = class organismAddNewAddress extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`crm--organism-add-new-address-102009{background-color:var(--bg-primary-color);color:var(--text-primary-color);font-family:var(--font-family-primary);padding:var(--space-16)}crm--organism-add-new-address-102009 .organism-add-new-address{max-width:600px;margin:0 auto}crm--organism-add-new-address-102009 .organism-add-new-address h2{font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16);color:var(--text-primary-color)}crm--organism-add-new-address-102009 .organism-add-new-address .address-form{display:flex;flex-direction:column;gap:var(--space-8)}crm--organism-add-new-address-102009 .organism-add-new-address .address-form label{font-size:var(--font-size-16);font-weight:var(--font-weight-normal);color:var(--text-primary-color)}crm--organism-add-new-address-102009 .organism-add-new-address .address-form input,crm--organism-add-new-address-102009 .organism-add-new-address .address-form select{padding:var(--space-8);border:1px solid var(--grey-color);border-radius:4px;font-size:var(--font-size-16);background-color:var(--bg-primary-color-lighter)}crm--organism-add-new-address-102009 .organism-add-new-address .address-form input:focus,crm--organism-add-new-address-102009 .organism-add-new-address .address-form select:focus{border-color:var(--active-color);background-color:var(--bg-primary-color-lighter-focus)}crm--organism-add-new-address-102009 .organism-add-new-address .address-form .cep-field{display:flex;gap:var(--space-8)}crm--organism-add-new-address-102009 .organism-add-new-address .address-form .search-cep-btn{padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);border:none;border-radius:4px;cursor:pointer;transition:background-color var(--transition-normal);background-color:var(--info-color);color:var(--bg-primary-color-lighter)}crm--organism-add-new-address-102009 .organism-add-new-address .address-form .search-cep-btn:hover{background-color:var(--info-color-hover)}crm--organism-add-new-address-102009 .organism-add-new-address .address-form span{font-size:var(--font-size-12);color:var(--text-secondary-color)}crm--organism-add-new-address-102009 .organism-add-new-address .map-container{margin:var(--space-16) 0}crm--organism-add-new-address-102009 .organism-add-new-address .map-container .map-placeholder{height:200px;background-color:var(--bg-secondary-color);display:flex;align-items:center;justify-content:center;font-size:var(--font-size-16);color:var(--text-primary-color);border:1px solid var(--grey-color)}crm--organism-add-new-address-102009 .organism-add-new-address .update-geo-btn,crm--organism-add-new-address-102009 .organism-add-new-address .save-btn{padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);border:none;border-radius:4px;cursor:pointer;transition:background-color var(--transition-normal);margin-right:var(--space-8)}crm--organism-add-new-address-102009 .organism-add-new-address .update-geo-btn{background-color:var(--info-color);color:var(--bg-primary-color-lighter)}crm--organism-add-new-address-102009 .organism-add-new-address .update-geo-btn:hover{background-color:var(--info-color-hover)}crm--organism-add-new-address-102009 .organism-add-new-address .save-btn{background-color:var(--success-color);color:var(--bg-primary-color-lighter)}crm--organism-add-new-address-102009 .organism-add-new-address .save-btn:hover{background-color:var(--success-color-hover)}`);
        // New property to control visibility of custom type input
        this.showCustomType = false;
    }
    // Handler for type select change
    handleTypeChange(e) {
        const target = e.target;
        this.showCustomType = target.value === 'Outros';
    }
    render() {
        return html `<div class="organism-add-new-address" id="crm--organism-add-new-address-102009-1">
<h2 id="crm--organism-add-new-address-102009-2">Editar Endereço</h2>
<form class="address-form" id="crm--organism-add-new-address-102009-3">
<label for="tipo-endereco" id="crm--organism-add-new-address-102009-14">Tipo de Endereço:</label>
<select id="tipo-endereco" id="crm--organism-add-new-address-102009-15" @change=${this.handleTypeChange}>
<option value="Comercial">Comercial</option>
<option value="Residencial">Residencial</option>
<option value="Entrega">Entrega</option>
<option value="Cobrança">Cobrança</option>
<option value="Outros">Outros</option>
</select>
${this.showCustomType ? html `<label for="custom-tipo" id="crm--organism-add-new-address-102009-22">Tipo Personalizado:</label>
<input type="text" id="custom-tipo" placeholder="Digite o tipo personalizado" id="crm--organism-add-new-address-102009-23">` : ''}
<label for="rua" id="crm--organism-add-new-address-102009-4">Rua:</label>
<input type="text" id="rua" value="Rua Exemplo" id="crm--organism-add-new-address-102009-5">
<label for="bairro" id="crm--organism-add-new-address-102009-6">Bairro:</label>
<input type="text" id="bairro" value="Bairro Exemplo" id="crm--organism-add-new-address-102009-7">
<label for="cep" id="crm--organism-add-new-address-102009-8">CEP:</label>
<input type="text" id="cep" value="12345-678" id="crm--organism-add-new-address-102009-9">
<label for="cidade" id="crm--organism-add-new-address-102009-10">Cidade:</label>
<input type="text" id="cidade" value="Cidade Exemplo" id="crm--organism-add-new-address-102009-11">
<label for="uf" id="crm--organism-add-new-address-102009-12">UF:</label>
<select id="uf" id="crm--organism-add-new-address-102009-13">
<option value="AC">AC</option>
<option value="AL">AL</option>
<option value="AP">AP</option>
<option value="AM">AM</option>
<option value="BA">BA</option>
<option value="CE">CE</option>
<option value="DF">DF</option>
<option value="ES">ES</option>
<option value="GO">GO</option>
<option value="MA">MA</option>
<option value="MT">MT</option>
<option value="MS">MS</option>
<option value="MG">MG</option>
<option value="PA">PA</option>
<option value="PB">PB</option>
<option value="PR">PR</option>
<option value="PE">PE</option>
<option value="PI">PI</option>
<option value="RJ">RJ</option>
<option value="RN">RN</option>
<option value="RS">RS</option>
<option value="RO">RO</option>
<option value="RR">RR</option>
<option value="SC">SC</option>
<option value="SP">SP</option>
<option value="SE">SE</option>
<option value="TO">TO</option>
</select>
<span id="crm--organism-add-new-address-102009-16">Geo_RegiaoID: 123</span>
<span id="crm--organism-add-new-address-102009-17">Geo_CidadeID: 456</span>
</form>
<div class="map-container" id="crm--organism-add-new-address-102009-18">
<div class="map-placeholder" id="crm--organism-add-new-address-102009-19">Mapa - Localização Atual</div>
</div>
<button class="update-geo-btn" id="crm--organism-add-new-address-102009-20">Atualizar Geolocalização</button>
<button class="save-btn" id="crm--organism-add-new-address-102009-21">Salvar</button>
</div>
`;
    }
};
__decorate([
    state()
], organismAddNewAddress.prototype, "showCustomType", void 0);
organismAddNewAddress = __decorate([
    customElement('crm--organism-add-new-address-102009')
], organismAddNewAddress);
export { organismAddNewAddress };
