var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismAddRelationship" project="102009" folder="crm" enhancement="_100554_enhancementLit" groupName="crm" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAddRelationship = class organismAddRelationship extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`crm--organism-add-relationship-102009 .organism-add-relationship{background-color:var(--bg-primary-color);padding:var(--space-24);font-family:var(--font-family-primary);color:var(--text-primary-color)}crm--organism-add-relationship-102009 .organism-add-relationship__header{margin-bottom:var(--space-24)}crm--organism-add-relationship-102009 .organism-add-relationship__header .organism-add-relationship__title{font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color)}crm--organism-add-relationship-102009 .organism-add-relationship__options{margin-bottom:var(--space-24)}crm--organism-add-relationship-102009 .organism-add-relationship__options .organism-add-relationship__option{margin-bottom:var(--space-16);display:flex;align-items:flex-start}crm--organism-add-relationship-102009 .organism-add-relationship__options .organism-add-relationship__option input[type="radio"]{margin-right:var(--space-8)}crm--organism-add-relationship-102009 .organism-add-relationship__options .organism-add-relationship__option label{font-weight:var(--font-weight-normal);color:var(--text-primary-color)}crm--organism-add-relationship-102009 .organism-add-relationship__options .organism-add-relationship__option .organism-add-relationship__description{margin-left:var(--space-24);font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}crm--organism-add-relationship-102009 .organism-add-relationship__confirmation{margin-bottom:var(--space-24)}crm--organism-add-relationship-102009 .organism-add-relationship__confirmation .organism-add-relationship__confirm-text{font-size:var(--font-size-16);color:var(--text-primary-color)}crm--organism-add-relationship-102009 .organism-add-relationship__visual{display:flex;justify-content:space-between;margin-bottom:var(--space-24)}crm--organism-add-relationship-102009 .organism-add-relationship__visual .organism-add-relationship__entity{display:flex;align-items:center;width:45%}crm--organism-add-relationship-102009 .organism-add-relationship__visual .organism-add-relationship__entity--left{justify-content:flex-start}crm--organism-add-relationship-102009 .organism-add-relationship__visual .organism-add-relationship__entity--right{justify-content:flex-end}crm--organism-add-relationship-102009 .organism-add-relationship__visual .organism-add-relationship__entity .organism-add-relationship__icon{width:var(--space-32);height:var(--space-32);margin-right:var(--space-8);fill:var(--text-secondary-color)}crm--organism-add-relationship-102009 .organism-add-relationship__visual .organism-add-relationship__entity .organism-add-relationship__entity-info .organism-add-relationship__entity-name{font-size:var(--font-size-16);font-weight:var(--font-weight-bold);color:var(--text-primary-color)}crm--organism-add-relationship-102009 .organism-add-relationship__visual .organism-add-relationship__entity .organism-add-relationship__entity-info .organism-add-relationship__entity-type{font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}crm--organism-add-relationship-102009 .organism-add-relationship__actions{display:flex;justify-content:flex-end;gap:var(--space-16)}crm--organism-add-relationship-102009 .organism-add-relationship__actions .organism-add-relationship__button{padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);border:none;border-radius:var(--space-8);cursor:pointer;transition:background-color var(--transition-normal)}crm--organism-add-relationship-102009 .organism-add-relationship__actions .organism-add-relationship__button--save{background-color:var(--success-color);color:var(--bg-primary-color)}crm--organism-add-relationship-102009 .organism-add-relationship__actions .organism-add-relationship__button--save:hover{background-color:var(--success-color-hover)}crm--organism-add-relationship-102009 .organism-add-relationship__actions .organism-add-relationship__button--cancel{background-color:var(--error-color);color:var(--bg-primary-color)}crm--organism-add-relationship-102009 .organism-add-relationship__actions .organism-add-relationship__button--cancel:hover{background-color:var(--error-color-hover)}`);
    }
    render() {
        return html `<div class="organism-add-relationship">
      <header class="organism-add-relationship__header">
        <h1 class="organism-add-relationship__title">Selecione o tipo de relacionamento com: 174289 - Empresa ABC - Empresa</h1>
      </header>
      <section class="organism-add-relationship__options">
        <div class="organism-add-relationship__option">
          <input type="radio" id="empregado" name="relacionamento" value="empregado" checked>
          <label for="empregado">Empregado</label>
          <p class="organism-add-relationship__description">Descrição do relacionamento como empregado.</p>
        </div>
        <div class="organism-add-relationship__option">
          <input type="radio" id="cliente" name="relacionamento" value="cliente">
          <label for="cliente">Cliente</label>
          <p class="organism-add-relationship__description">Descrição do relacionamento como cliente.</p>
        </div>
        <div class="organism-add-relationship__option">
          <input type="radio" id="parceiro" name="relacionamento" value="parceiro">
          <label for="parceiro">Parceiro</label>
          <p class="organism-add-relationship__description">Descrição do relacionamento como parceiro.</p>
        </div>
        <div class="organism-add-relationship__option">
          <input type="radio" id="prestador" name="relacionamento" value="prestador">
          <label for="prestador">Prestador Serviços</label>
          <p class="organism-add-relationship__description">Descrição do relacionamento como prestador de serviços.</p>
        </div>
        <div class="organism-add-relationship__option">
          <input type="radio" id="carteira" name="relacionamento" value="carteira">
          <label for="carteira">Carteira Clientes</label>
          <p class="organism-add-relationship__description">Descrição do relacionamento como carteira de clientes.</p>
        </div>
      </section>
      <section class="organism-add-relationship__confirmation">
        <p class="organism-add-relationship__confirm-text">Deseja Confirmar a Inclusão deste Relacionamento?</p>
      </section>
      <section class="organism-add-relationship__visual">
        <div class="organism-add-relationship__entity organism-add-relationship__entity--left">
          <svg class="organism-add-relationship__icon" viewBox="0 0 24 24"><path d="M12 2C13.1 2 14 2.9 14 4C14 5.1 13.1 6 12 6C10.9 6 10 5.1 10 4C10 2.9 10.9 2 12 2ZM21 9V7L15 1H5C3.89 1 3 1.89 3 3V21C3 22.11 3.89 23 5 23H19C20.11 23 21 22.11 21 21V9M19 9H14V4H5V21H19V9Z"/></svg>
          <div class="organism-add-relationship__entity-info">
            <p class="organism-add-relationship__entity-name">João Silva - Pessoa</p>
            <p class="organism-add-relationship__entity-type">Empregado</p>
          </div>
        </div>
        <div class="organism-add-relationship__entity organism-add-relationship__entity--versius">X</div>
        <div class="organism-add-relationship__entity organism-add-relationship__entity--right">
          <svg class="organism-add-relationship__icon" viewBox="0 0 24 24"><path d="M12 2L2 7L12 12L22 7L12 2M2 17L12 22L22 17V10L12 15L2 10V17Z"/></svg>
          <div class="organism-add-relationship__entity-info">
            <p class="organism-add-relationship__entity-name">Empresa ABC - Empresa</p>
            <p class="organism-add-relationship__entity-type">Empregador</p>
          </div>
        </div>
      </section>
      <footer class="organism-add-relationship__actions">
        <button class="organism-add-relationship__button organism-add-relationship__button--save">Salvar</button>
        <button class="organism-add-relationship__button organism-add-relationship__button--cancel">Cancelar</button>
      </footer>
    </div>`;
    }
};
organismAddRelationship = __decorate([
    customElement('crm--organism-add-relationship-102009')
], organismAddRelationship);
export { organismAddRelationship };
