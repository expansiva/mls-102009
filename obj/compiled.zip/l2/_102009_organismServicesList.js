/// <mls shortName="organismServicesList" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismServicesList = class _102009_organismServicesList extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-services-list-102009 .services-list-container{max-width:1200px;margin:0 auto;padding:0 var(--spacing-md)}organism-services-list-102009 .services-list-container .services-header{text-align:center;margin-bottom:var(--spacing-xl)}organism-services-list-102009 .services-list-container .services-header h1{font-size:var(--font-size-xxl);font-weight:var(--font-weight-bold);color:var(--color-primary);margin-bottom:var(--spacing-sm);line-height:var(--line-height-sm)}organism-services-list-102009 .services-list-container .services-header p{font-size:var(--font-size-lg);color:var(--color-text-secondary);line-height:var(--line-height-md)}organism-services-list-102009 .services-list-container .services-grid{display:grid;grid-template-columns:repeat(auto-fit, minmax(280px, 1fr));gap:var(--spacing-lg)}organism-services-list-102009 .services-list-container .services-grid .service-card{background:var(--color-surface);border-radius:var(--border-radius-md);box-shadow:var(--shadow-sm);overflow:hidden;transition:var(--transition-base);border:1px solid var(--color-border)}organism-services-list-102009 .services-list-container .services-grid .service-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-md)}organism-services-list-102009 .services-list-container .services-grid .service-card .service-image{height:200px;overflow:hidden}organism-services-list-102009 .services-list-container .services-grid .service-card .service-image img{width:100%;height:100%;object-fit:cover;transition:var(--transition-base)}organism-services-list-102009 .services-list-container .services-grid .service-card .service-content{padding:var(--spacing-md)}organism-services-list-102009 .services-list-container .services-grid .service-card .service-content h3{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-primary);margin-bottom:var(--spacing-sm);line-height:var(--line-height-sm)}organism-services-list-102009 .services-list-container .services-grid .service-card .service-content p{color:var(--color-text-secondary);line-height:var(--line-height-md);margin-bottom:var(--spacing-md)}organism-services-list-102009 .services-list-container .services-grid .service-card .service-content .service-price{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-accent);margin-bottom:var(--spacing-md)}organism-services-list-102009 .services-list-container .services-grid .service-card .service-content .btn-details{width:100%;padding:var(--spacing-sm) var(--spacing-md);background-color:var(--color-primary);color:white;border:none;border-radius:var(--border-radius-sm);font-size:var(--font-size-md);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-base)}organism-services-list-102009 .services-list-container .services-grid .service-card .service-content .btn-details:hover{background-color:var(--color-accent);transform:translateY(-1px)}`);
    }
    render() {
        return html `
      <section class="services-list-container">
        <div class="services-header">
          <h1>Nossos Serviços</h1>
          <p>Cuidamos do seu pet com carinho e profissionalismo</p>
        </div>
        
        <div class="services-grid">
          <div class="service-card" data-service="banho">
            <div class="service-image">
              <img src="https://images.unsplash.com/photo-1597595735781-6a57fb8e3e3d?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjB0YWtpbmclMjBiYXRoJTIwZ3Jvb21pbmclMjBzYWxvbnxlbnwwfHx8fDE3NTMyOTE5NzZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Cachorro tomando banho">
            </div>
            <div class="service-content">
              <h3>Banho</h3>
              <p>Banho completo com produtos de qualidade, secagem e perfume.</p>
              <div class="service-price">A partir de R$ 25,00</div>
              <button class="btn-details" onclick="showServiceDetails('banho')">Ver Detalhes</button>
            </div>
          </div>
          
          <div class="service-card" data-service="tosa">
            <div class="service-image">
              <img src="https://images.unsplash.com/photo-1644675443401-ea4c14bad0e6?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBncm9vbWluZyUyMGhhaXJjdXQlMjBwcm9mZXNzaW9uYWx8ZW58MHx8fHwxNzUzMzY1MTQ5fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Cachorro sendo tosado">
            </div>
            <div class="service-content">
              <h3>Tosa</h3>
              <p>Tosa higiênica e estética para deixar seu pet ainda mais bonito.</p>
              <div class="service-price">A partir de R$ 35,00</div>
              <button class="btn-details" onclick="showServiceDetails('tosa')">Ver Detalhes</button>
            </div>
          </div>
          
          <div class="service-card" data-service="consulta">
            <div class="service-image">
              <img src="https://images.unsplash.com/photo-1625321171045-1fea4ac688e9?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJpYW4lMjBleGFtaW5pbmclMjBwZXQlMjBjb25zdWx0YXRpb258ZW58MHx8fHwxNzUzMzY1MTUwfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Veterinário examinando pet">
            </div>
            <div class="service-content">
              <h3>Consulta Veterinária</h3>
              <p>Consultas com veterinários experientes para cuidar da saúde do seu pet.</p>
              <div class="service-price">A partir de R$ 80,00</div>
              <button class="btn-details" onclick="showServiceDetails('consulta')">Ver Detalhes</button>
            </div>
          </div>
          
          <div class="service-card" data-service="vacinacao">
            <div class="service-image">
              <img src="https://images.unsplash.com/photo-1719464454959-9cf304ef4774?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjB2YWNjaW5hdGlvbiUyMHZldGVyaW5hcnklMjBpbmplY3Rpb258ZW58MHx8fHwxNzUzMjkxOTc4fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Pet sendo vacinado">
            </div>
            <div class="service-content">
              <h3>Vacinação</h3>
              <p>Vacinas essenciais para manter seu pet protegido e saudável.</p>
              <div class="service-price">A partir de R$ 45,00</div>
              <button class="btn-details" onclick="showServiceDetails('vacinacao')">Ver Detalhes</button>
            </div>
          </div>
        </div>
      </section>
    `;
    }
};
_102009_organismServicesList = __decorate([
    customElement('organism-services-list-102009')
], _102009_organismServicesList);
export { _102009_organismServicesList };
