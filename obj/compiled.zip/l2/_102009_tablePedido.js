/// <mls shortName="tablePedido" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
export const modelPrisma = `
model Pedido {
  id Int @id @default(autoincrement())
  usuarioId Int 
  valorTotal Float 
  status String? 
  dataCriacao DateTime
}
`;
