/// <mls shortName="organismPetSelector" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismPetSelector = class _102009_organismPetSelector extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-pet-selector-102009 .pet-selector-container{max-width:800px;margin:0 auto;padding:0 var(--spacing-md)}organism-pet-selector-102009 .pet-selector-container .section-header{text-align:center;margin-bottom:var(--spacing-lg)}organism-pet-selector-102009 .pet-selector-container .section-header h3{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-xs)}organism-pet-selector-102009 .pet-selector-container .section-header p{font-size:var(--font-size-md);color:var(--color-text-secondary)}organism-pet-selector-102009 .pet-selector-container .pets-list{display:grid;grid-template-columns:repeat(auto-fit, minmax(250px, 1fr));gap:var(--spacing-md);margin-bottom:var(--spacing-lg)}organism-pet-selector-102009 .pet-selector-container .pets-list .pet-card{border:2px solid var(--color-border);border-radius:var(--border-radius-md);padding:var(--spacing-md);background:var(--color-surface);display:flex;align-items:center;gap:var(--spacing-md);cursor:pointer;transition:var(--transition-base);position:relative}organism-pet-selector-102009 .pet-selector-container .pets-list .pet-card:hover{border-color:var(--color-primary);box-shadow:var(--shadow-sm)}organism-pet-selector-102009 .pet-selector-container .pets-list .pet-card img{width:60px;height:60px;border-radius:50%;object-fit:cover}organism-pet-selector-102009 .pet-selector-container .pets-list .pet-card .pet-info{flex:1}organism-pet-selector-102009 .pet-selector-container .pets-list .pet-card .pet-info h4{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-xs)}organism-pet-selector-102009 .pet-selector-container .pets-list .pet-card .pet-info p{font-size:var(--font-size-sm);color:var(--color-text-secondary);margin-bottom:var(--spacing-xs)}organism-pet-selector-102009 .pet-selector-container .pets-list .pet-card .pet-info .pet-status{font-size:var(--font-size-xs);background:var(--color-success);color:white;padding:2px var(--spacing-xs);border-radius:var(--border-radius-xs)}organism-pet-selector-102009 .pet-selector-container .pets-list .pet-card input[type="radio"]{margin-left:auto}organism-pet-selector-102009 .pet-selector-container .pets-list .pet-card:has(input[type="radio"]:checked){border-color:var(--color-primary);background:var(--color-overlay)}organism-pet-selector-102009 .pet-selector-container .pets-list .add-pet-card{border:2px dashed var(--color-border);border-radius:var(--border-radius-md);padding:var(--spacing-md);background:var(--color-surface);display:flex;align-items:center;gap:var(--spacing-md);cursor:pointer;transition:var(--transition-base)}organism-pet-selector-102009 .pet-selector-container .pets-list .add-pet-card:hover{border-color:var(--color-secondary);background:rgba(249,178,51,0.1)}organism-pet-selector-102009 .pet-selector-container .pets-list .add-pet-card .add-pet-icon{width:60px;height:60px;border-radius:50%;background:var(--color-secondary);display:flex;align-items:center;justify-content:center;font-size:var(--font-size-xl);color:white;font-weight:var(--font-weight-bold)}organism-pet-selector-102009 .pet-selector-container .pets-list .add-pet-card .add-pet-text h4{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-xs)}organism-pet-selector-102009 .pet-selector-container .pets-list .add-pet-card .add-pet-text p{font-size:var(--font-size-sm);color:var(--color-text-secondary)}organism-pet-selector-102009 .pet-selector-container .new-pet-form{border:2px solid var(--color-border);border-radius:var(--border-radius-md);padding:var(--spacing-lg);background:var(--color-surface);margin-bottom:var(--spacing-lg)}organism-pet-selector-102009 .pet-selector-container .new-pet-form h4{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-md)}organism-pet-selector-102009 .pet-selector-container .new-pet-form .form-row{display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-md);margin-bottom:var(--spacing-md)}@media (max-width:480px){organism-pet-selector-102009 .pet-selector-container .new-pet-form .form-row{grid-template-columns:1fr}}organism-pet-selector-102009 .pet-selector-container .new-pet-form .form-group label{display:block;font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-xs)}organism-pet-selector-102009 .pet-selector-container .new-pet-form .form-group input,organism-pet-selector-102009 .pet-selector-container .new-pet-form .form-group select{width:100%;padding:var(--spacing-sm);border:2px solid var(--color-border);border-radius:var(--border-radius-sm);font-size:var(--font-size-md);transition:var(--transition-base)}organism-pet-selector-102009 .pet-selector-container .new-pet-form .form-group input:focus,organism-pet-selector-102009 .pet-selector-container .new-pet-form .form-group select:focus{outline:none;border-color:var(--color-primary)}organism-pet-selector-102009 .pet-selector-container .new-pet-form .form-actions{display:flex;gap:var(--spacing-sm);justify-content:flex-end}organism-pet-selector-102009 .pet-selector-container .form-actions{text-align:center}organism-pet-selector-102009 .pet-selector-container .form-actions .schedule-btn{padding:var(--spacing-md) var(--spacing-xl);font-size:var(--font-size-lg);font-weight:var(--font-weight-bold)}organism-pet-selector-102009 .pet-selector-container .btn-primary{background:var(--color-primary);color:white;border:none;padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--border-radius-sm);cursor:pointer;transition:var(--transition-base);font-size:var(--font-size-md)}organism-pet-selector-102009 .pet-selector-container .btn-primary:hover{background:var(--color-link-visited)}organism-pet-selector-102009 .pet-selector-container .btn-secondary{background:transparent;color:var(--color-text-secondary);border:2px solid var(--color-border);padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--border-radius-sm);cursor:pointer;transition:var(--transition-base);font-size:var(--font-size-md)}organism-pet-selector-102009 .pet-selector-container .btn-secondary:hover{border-color:var(--color-primary);color:var(--color-primary)}`);
    }
    render() {
        return html `
<div class="pet-selector-container" id="pet-selector-1">
  <div class="section-header" id="pet-selector-2">
    <h3 id="pet-selector-3">Selecione seu Pet</h3>
    <p id="pet-selector-4">Escolha qual pet receberá o serviço ou cadastre um novo</p>
  </div>
  
  <div class="pets-list" id="pet-selector-5">
    <div class="pet-card" id="pet-selector-6">
      <img src="https://images.unsplash.com/photo-1609348490161-a879e4327ae9?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxnb2xkZW4lMjByZXRyaWV2ZXIlMjBkb2clMjBwb3J0cmFpdCUyMGhhcHB5fGVufDB8fHx8MTc1MzM2NTQzMXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Foto do pet" id="pet-selector-7">
      <div class="pet-info" id="pet-selector-8">
        <h4 id="pet-selector-9">Rex</h4>
        <p id="pet-selector-10">Golden Retriever • 3 anos</p>
        <span class="pet-status" id="pet-selector-11">Ativo</span>
      </div>
      <input type="radio" name="selected-pet" value="rex" id="pet-selector-12">
    </div>
    
    <div class="pet-card" id="pet-selector-13">
      <img src="https://images.unsplash.com/photo-1675191855383-4b80d79a0628?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXJzaWFuJTIwY2F0JTIwcG9ydHJhaXQlMjBmbHVmZnklMjB3aGl0ZXxlbnwwfHx8fDE3NTMzNjU0MzF8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Foto do pet" id="pet-selector-14">
      <div class="pet-info" id="pet-selector-15">
        <h4 id="pet-selector-16">Mimi</h4>
        <p id="pet-selector-17">Persa • 2 anos</p>
        <span class="pet-status" id="pet-selector-18">Ativo</span>
      </div>
      <input type="radio" name="selected-pet" value="mimi" id="pet-selector-19">
    </div>
    
    <div class="add-pet-card" id="pet-selector-20">
      <div class="add-pet-icon" id="pet-selector-21">+</div>
      <div class="add-pet-text" id="pet-selector-22">
        <h4 id="pet-selector-23">Adicionar Novo Pet</h4>
        <p id="pet-selector-24">Cadastre um novo pet</p>
      </div>
    </div>
  </div>
  
  <div class="new-pet-form" style="display: none;" id="pet-selector-25">
    <h4 id="pet-selector-26">Cadastrar Novo Pet</h4>
    <div class="form-row" id="pet-selector-27">
      <div class="form-group" id="pet-selector-28">
        <label for="pet-name" id="pet-selector-29">Nome do Pet</label>
        <input type="text" id="pet-name" name="pet-name" placeholder="Digite o nome" id="pet-selector-30">
      </div>
      <div class="form-group" id="pet-selector-31">
        <label for="pet-species" id="pet-selector-32">Espécie</label>
        <select id="pet-species" name="pet-species" id="pet-selector-33">
          <option value="" id="pet-selector-34">Selecione</option>
          <option value="cao" id="pet-selector-35">Cão</option>
          <option value="gato" id="pet-selector-36">Gato</option>
          <option value="outro" id="pet-selector-37">Outro</option>
        </select>
      </div>
    </div>
    <div class="form-row" id="pet-selector-38">
      <div class="form-group" id="pet-selector-39">
        <label for="pet-breed" id="pet-selector-40">Raça</label>
        <input type="text" id="pet-breed" name="pet-breed" placeholder="Digite a raça" id="pet-selector-41">
      </div>
      <div class="form-group" id="pet-selector-42">
        <label for="pet-age" id="pet-selector-43">Idade</label>
        <input type="number" id="pet-age" name="pet-age" placeholder="Anos" id="pet-selector-44">
      </div>
    </div>
    <div class="form-actions" id="pet-selector-45">
      <button type="button" class="btn-secondary cancel-pet" id="pet-selector-46">Cancelar</button>
      <button type="button" class="btn-primary save-pet" id="pet-selector-47">Salvar Pet</button>
    </div>
  </div>
  
  <div class="form-actions" id="pet-selector-48">
    <button type="submit" class="btn-primary schedule-btn" id="pet-selector-49">Agendar Serviço</button>
  </div>
</div>

    `;
    }
};
_102009_organismPetSelector = __decorate([
    customElement('organism-pet-selector-102009')
], _102009_organismPetSelector);
export { _102009_organismPetSelector };
