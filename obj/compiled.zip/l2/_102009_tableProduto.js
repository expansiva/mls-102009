/// <mls shortName="tableProduto" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
export const modelPrisma = `
model Produto {
  id Int @id @default(autoincrement())
  nome String 
  descricao String? 
  preco Float 
  estoque Int 
  categoriaId Int 
  imagem String? 
  destaque Boolean?
}
`;
