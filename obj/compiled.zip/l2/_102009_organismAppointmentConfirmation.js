/// <mls shortName="organismAppointmentConfirmation" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAppointmentConfirmation = class _102009_organismAppointmentConfirmation extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-appointment-confirmation-102009 .confirmation-container{max-width:600px;margin:0 auto;padding:0 var(--spacing-md);text-align:center}organism-appointment-confirmation-102009 .confirmation-container .confirmation-success{margin-bottom:var(--spacing-xl)}organism-appointment-confirmation-102009 .confirmation-container .confirmation-success .success-icon{width:80px;height:80px;background:var(--color-success);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:var(--font-size-xxl);color:white;margin:0 auto var(--spacing-md)}organism-appointment-confirmation-102009 .confirmation-container .confirmation-success h2{font-size:var(--font-size-xxl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-xs)}organism-appointment-confirmation-102009 .confirmation-container .confirmation-success p{font-size:var(--font-size-lg);color:var(--color-text-secondary)}organism-appointment-confirmation-102009 .confirmation-container .appointment-details{margin-bottom:var(--spacing-xl)}organism-appointment-confirmation-102009 .confirmation-container .appointment-details h3{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-md)}organism-appointment-confirmation-102009 .confirmation-container .appointment-details .detail-card{border:2px solid var(--color-border);border-radius:var(--border-radius-md);padding:var(--spacing-lg);background:var(--color-surface);text-align:left}organism-appointment-confirmation-102009 .confirmation-container .appointment-details .detail-card .detail-row{display:flex;justify-content:space-between;align-items:center;padding:var(--spacing-sm) 0;border-bottom:1px solid var(--color-border)}organism-appointment-confirmation-102009 .confirmation-container .appointment-details .detail-card .detail-row:last-child{border-bottom:none}organism-appointment-confirmation-102009 .confirmation-container .appointment-details .detail-card .detail-row .label{font-weight:var(--font-weight-bold);color:var(--color-text-secondary)}organism-appointment-confirmation-102009 .confirmation-container .appointment-details .detail-card .detail-row .value{font-weight:var(--font-weight-bold);color:var(--color-text-normal)}organism-appointment-confirmation-102009 .confirmation-container .appointment-details .detail-card .detail-row .value.price{color:var(--color-primary);font-size:var(--font-size-lg)}organism-appointment-confirmation-102009 .confirmation-container .email-notification{display:flex;align-items:center;gap:var(--spacing-md);background:var(--color-overlay);padding:var(--spacing-md);border-radius:var(--border-radius-md);margin-bottom:var(--spacing-xl)}organism-appointment-confirmation-102009 .confirmation-container .email-notification .notification-icon{font-size:var(--font-size-xl)}organism-appointment-confirmation-102009 .confirmation-container .email-notification .notification-text{text-align:left}organism-appointment-confirmation-102009 .confirmation-container .email-notification .notification-text h4{font-size:var(--font-size-md);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-xs)}organism-appointment-confirmation-102009 .confirmation-container .email-notification .notification-text p{font-size:var(--font-size-sm);color:var(--color-text-secondary)}organism-appointment-confirmation-102009 .confirmation-container .confirmation-actions{display:flex;gap:var(--spacing-md);justify-content:center}@media (max-width:480px){organism-appointment-confirmation-102009 .confirmation-container .confirmation-actions{flex-direction:column}}organism-appointment-confirmation-102009 .confirmation-container .btn-primary{background:var(--color-primary);color:white;border:none;padding:var(--spacing-md) var(--spacing-lg);border-radius:var(--border-radius-sm);cursor:pointer;transition:var(--transition-base);font-size:var(--font-size-md);font-weight:var(--font-weight-bold)}organism-appointment-confirmation-102009 .confirmation-container .btn-primary:hover{background:var(--color-link-visited)}organism-appointment-confirmation-102009 .confirmation-container .btn-secondary{background:transparent;color:var(--color-text-secondary);border:2px solid var(--color-border);padding:var(--spacing-md) var(--spacing-lg);border-radius:var(--border-radius-sm);cursor:pointer;transition:var(--transition-base);font-size:var(--font-size-md)}organism-appointment-confirmation-102009 .confirmation-container .btn-secondary:hover{border-color:var(--color-primary);color:var(--color-primary)}`);
    }
    render() {
        return html `
      <div class="confirmation-container" style="display: none;" id="appointment-confirmation-1">
  <div class="confirmation-success" id="appointment-confirmation-2">
    <div class="success-icon" id="appointment-confirmation-3">✓</div>
    <h2 id="appointment-confirmation-4">Agendamento Confirmado!</h2>
    <p id="appointment-confirmation-5">Seu agendamento foi realizado com sucesso</p>
  </div>
  
  <div class="appointment-details" id="appointment-confirmation-6">
    <h3 id="appointment-confirmation-7">Detalhes do Agendamento</h3>
    <div class="detail-card" id="appointment-confirmation-8">
      <div class="detail-row" id="appointment-confirmation-9">
        <span class="label" id="appointment-confirmation-10">Serviço:</span>
        <span class="value" id="confirmed-service">Banho</span>
      </div>
      <div class="detail-row" id="appointment-confirmation-11">
        <span class="label" id="appointment-confirmation-12">Pet:</span>
        <span class="value" id="confirmed-pet">Rex</span>
      </div>
      <div class="detail-row" id="appointment-confirmation-13">
        <span class="label" id="appointment-confirmation-14">Data:</span>
        <span class="value" id="confirmed-date">25/07/2025</span>
      </div>
      <div class="detail-row" id="appointment-confirmation-15">
        <span class="label" id="appointment-confirmation-16">Horário:</span>
        <span class="value" id="confirmed-time">10:00</span>
      </div>
      <div class="detail-row" id="appointment-confirmation-17">
        <span class="label" id="appointment-confirmation-18">Valor:</span>
        <span class="value price" id="confirmed-price">R$ 35,00</span>
      </div>
    </div>
  </div>
  
  <div class="email-notification" id="appointment-confirmation-19">
    <div class="notification-icon" id="appointment-confirmation-20">📧</div>
    <div class="notification-text" id="appointment-confirmation-21">
      <h4 id="appointment-confirmation-22">Lembrete por Email</h4>
      <p id="appointment-confirmation-23">Você receberá um lembrete por email 24 horas antes do agendamento</p>
    </div>
  </div>
  
  <div class="confirmation-actions" id="appointment-confirmation-24">
    <button type="button" class="btn-secondary" id="appointment-confirmation-25">Voltar ao Início</button>
    <button type="button" class="btn-primary" id="appointment-confirmation-26">Agendar Outro Serviço</button>
  </div>
</div>

    `;
    }
};
_102009_organismAppointmentConfirmation = __decorate([
    customElement('organism-appointment-confirmation-102009')
], _102009_organismAppointmentConfirmation);
export { _102009_organismAppointmentConfirmation };
