/// <mls shortName="perfil" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let _102009_perfil = class _102009_perfil extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`perfil-102009{min-height:100vh;display:flex;flex-direction:column;background-color:var(--color-background);color:var(--color-text-normal);font-family:var(--font-family-primary)}perfil-102009 main{flex:1;padding:var(--spacing-lg) 0;max-width:1200px;margin:0 auto;width:100%}@media (max-width:768px){perfil-102009 main{padding:var(--spacing-md) var(--spacing-sm)}}`);
    }
    initPage() {
    }
};
_102009_perfil = __decorate([
    customElement('perfil-102009')
], _102009_perfil);
export { _102009_perfil };
