/// <mls shortName="layer1Context" project="102009" enhancement="_blank" />
import { scheduling } from "./_102009_layer1SchedulingDB";
import { serviceOrder } from "./_102009_layer1ServiceOrderDB";
export function createContext(param) {
    if (!param.inDeveloped)
        throw new Error('Not implement api production');
    const ctx = {
        io: {
            scheduling,
            serviceOrder
        }
    };
    return ctx;
}
