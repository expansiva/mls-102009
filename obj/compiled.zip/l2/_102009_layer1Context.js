/// <mls shortName="layer1Context" project="102009" enhancement="_blank" />
import { schedulingIndexedDB } from "./_102009_layer1SchedulingIndexedDB";
import { serviceOrderIndexedDB } from "./_102009_layer1ServiceOrderIndexedDB";
export function createContext(param) {
    if (!param.inDeveloped)
        throw new Error('Not implement api production');
    const ctx = {
        io: {
            petshopDB: {
                scheduling: schedulingIndexedDB,
                serviceOrder: serviceOrderIndexedDB
            }
        }
    };
    return ctx;
}
