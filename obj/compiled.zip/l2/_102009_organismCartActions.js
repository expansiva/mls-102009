/// <mls shortName="organismCartActions" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismCartActions = class _102009_organismCartActions extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-cart-actions-102009{grid-column:1 / -1}organism-cart-actions-102009 .actions-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-lg);box-shadow:var(--shadow-sm);display:flex;justify-content:space-between;align-items:center;gap:var(--spacing-lg)}@media (max-width:768px){organism-cart-actions-102009 .actions-container{flex-direction:column;gap:var(--spacing-md)}}organism-cart-actions-102009 .action-buttons{display:flex;gap:var(--spacing-md)}@media (max-width:768px){organism-cart-actions-102009 .action-buttons{width:100%;justify-content:center}}organism-cart-actions-102009 .secondary-btn{background:var(--color-background);border:1px solid var(--color-border);color:var(--color-text-normal);padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--border-radius-sm);cursor:pointer;font-weight:var(--font-weight-bold);display:flex;align-items:center;gap:var(--spacing-xs);transition:var(--transition-base)}organism-cart-actions-102009 .secondary-btn:hover{border-color:var(--color-primary);color:var(--color-primary);transform:translateY(-2px)}organism-cart-actions-102009 .secondary-btn .btn-icon{font-size:var(--font-size-lg)}organism-cart-actions-102009 .checkout-section{display:flex;flex-direction:column;align-items:flex-end;gap:var(--spacing-sm)}@media (max-width:768px){organism-cart-actions-102009 .checkout-section{align-items:center;width:100%}}organism-cart-actions-102009 .checkout-section .security-badges{display:flex;align-items:center;gap:var(--spacing-xs);margin-bottom:var(--spacing-xs)}organism-cart-actions-102009 .checkout-section .security-badges .security-badge{height:24px;width:auto}organism-cart-actions-102009 .checkout-section .security-badges .security-text{font-size:var(--font-size-sm);color:var(--color-text-secondary)}organism-cart-actions-102009 .checkout-section .primary-btn{background:var(--color-primary);color:var(--color-background);border:none;padding:var(--spacing-md) var(--spacing-xl);border-radius:var(--border-radius-sm);cursor:pointer;font-weight:var(--font-weight-bold);font-size:var(--font-size-lg);display:flex;align-items:center;gap:var(--spacing-sm);transition:var(--transition-base);box-shadow:var(--shadow-md)}organism-cart-actions-102009 .checkout-section .primary-btn:hover{background:var(--color-accent);transform:translateY(-2px);box-shadow:var(--shadow-lg)}organism-cart-actions-102009 .checkout-section .primary-btn .btn-icon{font-size:var(--font-size-lg)}organism-cart-actions-102009 .checkout-section .primary-btn .btn-total{background:rgba(255,255,255,0.2);padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);margin-left:var(--spacing-sm)}organism-cart-actions-102009 .checkout-section .payment-methods{display:flex;align-items:center;gap:var(--spacing-xs);font-size:var(--font-size-sm);color:var(--color-text-secondary)}organism-cart-actions-102009 .checkout-section .payment-methods .payment-icons{display:flex;gap:var(--spacing-xs)}organism-cart-actions-102009 .checkout-section .payment-methods .payment-icons .payment-icon{height:20px;width:auto}`);
    }
    render() {
        return html `
      <div class="actions-container">
        <div class="action-buttons">
          <button class="clear-cart-btn secondary-btn">
            <span class="btn-icon">🗑️</span>
            Limpar Carrinho
          </button>
          <button class="continue-shopping-btn secondary-btn">
            <span class="btn-icon">🛍️</span>
            Continuar Comprando
          </button>
        </div>
        
        <div class="checkout-section">
          <div class="security-badges">
            <img src="https://images.unsplash.com/photo-1550420818-740e287f237c?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxzZWN1cmUlMjBzaG9wcGluZyUyMGJhZGdlJTIwc3NsfGVufDB8fHx8MTc1MzM2NTY2Mnww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Compra Segura" class="security-badge">
            <img src="https://images.unsplash.com/photo-1613825787302-22acac0de2fc?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxzc2wlMjBjZXJ0aWZpY2F0ZSUyMGJhZGdlJTIwc2VjdXJpdHl8ZW58MHx8fHwxNzUzMzY1NjYzfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="SSL Certificado" class="security-badge">
            <span class="security-text">Compra 100% segura</span>
          </div>
          
          <button class="checkout-btn primary-btn">
            <span class="btn-icon">🔒</span>
            Finalizar Compra
            <span class="btn-total">R$ 225,20</span>
          </button>
          
          <div class="payment-methods">
            <span>Aceitamos:</span>
            <div class="payment-icons">
              <img src="https://images.unsplash.com/photo-1660732106134-f3009a1e90ea?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxjcmVkaXQlMjBjYXJkJTIwcGF5bWVudCUyMGljb258ZW58MHx8fHwxNzUzMjkyMzAzfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Cartão de Crédito" class="payment-icon">
              <img src="https://images.unsplash.com/photo-1643455464171-aaaaa1042fc8?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwaXglMjBwYXltZW50JTIwYnJhemlsJTIwaWNvbnxlbnwwfHx8fDE3NTMyOTIzMDR8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="PIX" class="payment-icon">
              <img src="https://images.unsplash.com/photo-1560294662-ecab97f90f92?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxib2xldG8lMjBwYXltZW50JTIwYnJhemlsJTIwaWNvbnxlbnwwfHx8fDE3NTMzNjU2NjR8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Boleto" class="payment-icon">
            </div>
          </div>
        </div>
      </div>
    `;
    }
};
_102009_organismCartActions = __decorate([
    customElement('organism-cart-actions-102009')
], _102009_organismCartActions);
export { _102009_organismCartActions };
