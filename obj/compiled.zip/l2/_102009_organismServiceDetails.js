/// <mls shortName="organismServiceDetails" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismServiceDetails = class _102009_organismServiceDetails extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-service-details-102009 .service-details-container{max-width:1200px;margin:0 auto;padding:0 var(--spacing-md)}organism-service-details-102009 .service-details-container .details-header{display:flex;align-items:center;gap:var(--spacing-md);margin-bottom:var(--spacing-xl)}organism-service-details-102009 .service-details-container .details-header .btn-back{padding:var(--spacing-sm) var(--spacing-md);background-color:var(--color-surface);color:var(--color-primary);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);cursor:pointer;transition:var(--transition-base);font-size:var(--font-size-md)}organism-service-details-102009 .service-details-container .details-header .btn-back:hover{background-color:var(--color-primary);color:white}organism-service-details-102009 .service-details-container .details-header h2{font-size:var(--font-size-xxl);font-weight:var(--font-weight-bold);color:var(--color-primary);line-height:var(--line-height-sm)}organism-service-details-102009 .service-details-container .details-content{display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-xl)}@media (max-width:768px){organism-service-details-102009 .service-details-container .details-content{grid-template-columns:1fr}}organism-service-details-102009 .service-details-container .details-content .details-image img{width:100%;height:400px;object-fit:cover;border-radius:var(--border-radius-md);box-shadow:var(--shadow-sm)}organism-service-details-102009 .service-details-container .details-content .details-info .service-description,organism-service-details-102009 .service-details-container .details-content .details-info .service-includes,organism-service-details-102009 .service-details-container .details-content .details-info .service-pricing,organism-service-details-102009 .service-details-container .details-content .details-info .service-duration{margin-bottom:var(--spacing-lg)}organism-service-details-102009 .service-details-container .details-content .details-info .service-description h3,organism-service-details-102009 .service-details-container .details-content .details-info .service-includes h3,organism-service-details-102009 .service-details-container .details-content .details-info .service-pricing h3,organism-service-details-102009 .service-details-container .details-content .details-info .service-duration h3{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-primary);margin-bottom:var(--spacing-sm);line-height:var(--line-height-sm)}organism-service-details-102009 .service-details-container .details-content .details-info .service-description p,organism-service-details-102009 .service-details-container .details-content .details-info .service-includes p,organism-service-details-102009 .service-details-container .details-content .details-info .service-pricing p,organism-service-details-102009 .service-details-container .details-content .details-info .service-duration p{color:var(--color-text-secondary);line-height:var(--line-height-md)}organism-service-details-102009 .service-details-container .details-content .details-info .service-includes ul{list-style:none;padding:0}organism-service-details-102009 .service-details-container .details-content .details-info .service-includes ul li{padding:var(--spacing-xs) 0;color:var(--color-text-secondary);position:relative;padding-left:var(--spacing-md)}organism-service-details-102009 .service-details-container .details-content .details-info .service-includes ul li:before{content:'✓';color:var(--color-success);font-weight:var(--font-weight-bold);position:absolute;left:0}organism-service-details-102009 .service-details-container .details-content .details-info .pricing-table .price-item{display:flex;justify-content:space-between;align-items:center;padding:var(--spacing-sm);background-color:var(--color-surface);border-radius:var(--border-radius-sm);margin-bottom:var(--spacing-xs)}organism-service-details-102009 .service-details-container .details-content .details-info .pricing-table .price-item .price-size{color:var(--color-text-normal);font-weight:var(--font-weight-normal)}organism-service-details-102009 .service-details-container .details-content .details-info .pricing-table .price-item .price-value{color:var(--color-accent);font-weight:var(--font-weight-bold);font-size:var(--font-size-lg)}organism-service-details-102009 .service-details-container .details-content .details-info .booking-section{margin-top:var(--spacing-xl);padding-top:var(--spacing-lg);border-top:1px solid var(--color-border)}organism-service-details-102009 .service-details-container .details-content .details-info .booking-section .btn-schedule{width:100%;padding:var(--spacing-md);background-color:var(--color-secondary);color:white;border:none;border-radius:var(--border-radius-sm);font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-base);margin-bottom:var(--spacing-sm)}organism-service-details-102009 .service-details-container .details-content .details-info .booking-section .btn-schedule:hover{background-color:var(--color-accent);transform:translateY(-2px);box-shadow:var(--shadow-md)}organism-service-details-102009 .service-details-container .details-content .details-info .booking-section .booking-note{text-align:center;color:var(--color-text-secondary);font-size:var(--font-size-sm);line-height:var(--line-height-md)}`);
    }
    render() {
        return html `
  <section class="service-details-container" id="service-details-1" style="display: none;">
  <div class="details-header" id="service-details-2">
    <button class="btn-back" id="service-details-3" onclick="hideServiceDetails()">← Voltar</button>
    <h2 id="service-details-4">Detalhes do Serviço</h2>
  </div>
  
  <div class="details-content" id="service-details-5">
    <div class="details-image" id="service-details-6">
      <img id="service-details-7" src="" alt="">
    </div>
    
    <div class="details-info" id="service-details-8">
      <div class="service-description" id="service-details-9">
        <h3 id="service-details-10">Descrição</h3>
        <p id="service-details-11">Descrição detalhada do serviço...</p>
      </div>
      
      <div class="service-includes" id="service-details-12">
        <h3 id="service-details-13">O que está incluído</h3>
        <ul id="service-details-14">
          <!-- Items will be populated by JavaScript -->
        </ul>
      </div>
      
      <div class="service-pricing" id="service-details-15">
        <h3 id="service-details-16">Preços</h3>
        <div class="pricing-table" id="service-details-17">
          <!-- Pricing will be populated by JavaScript -->
        </div>
      </div>
      
      <div class="service-duration" id="service-details-18">
        <h3 id="service-details-19">Duração</h3>
        <p id="service-details-20">Tempo estimado do serviço</p>
      </div>
      
      <div class="booking-section" id="service-details-21">
        <button class="btn-schedule" id="service-details-22" onclick="scheduleService()">Agendar Agora</button>
        <p class="booking-note" id="service-details-23">Horário de funcionamento: Segunda a Sábado, das 8h às 18h</p>
      </div>
    </div>
  </div>
</section>

    `;
    }
};
_102009_organismServiceDetails = __decorate([
    customElement('organism-service-details-102009')
], _102009_organismServiceDetails);
export { _102009_organismServiceDetails };
