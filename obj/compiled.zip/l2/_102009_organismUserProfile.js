/// <mls shortName="organismUserProfile" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismUserProfile = class _102009_organismUserProfile extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-user-profile-102009 .user-profile-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-xl);margin-bottom:var(--spacing-xl);box-shadow:var(--shadow-sm)}organism-user-profile-102009 .user-profile-container .profile-header{display:flex;align-items:center;gap:var(--spacing-lg);margin-bottom:var(--spacing-xl)}organism-user-profile-102009 .user-profile-container .profile-header .profile-avatar{position:relative}organism-user-profile-102009 .user-profile-container .profile-header .profile-avatar .avatar-image{width:120px;height:120px;border-radius:50%;object-fit:cover;border:4px solid var(--color-primary)}organism-user-profile-102009 .user-profile-container .profile-header .profile-avatar .change-avatar-btn{position:absolute;bottom:0;right:0;background:var(--color-primary);color:white;border:none;border-radius:var(--border-radius-sm);padding:var(--spacing-xs);font-size:var(--font-size-xs);cursor:pointer;transition:var(--transition-base)}organism-user-profile-102009 .user-profile-container .profile-header .profile-avatar .change-avatar-btn:hover{background:var(--color-link-hover)}organism-user-profile-102009 .user-profile-container .profile-header .profile-info h1{font-size:var(--font-size-xxl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin:0 0 var(--spacing-xs) 0}organism-user-profile-102009 .user-profile-container .profile-header .profile-info .profile-subtitle{color:var(--color-text-secondary);font-size:var(--font-size-md);margin:0}organism-user-profile-102009 .user-profile-container .profile-form .form-section{margin-bottom:var(--spacing-xl)}organism-user-profile-102009 .user-profile-container .profile-form .form-section h2{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-lg);padding-bottom:var(--spacing-sm);border-bottom:2px solid var(--color-border)}organism-user-profile-102009 .user-profile-container .profile-form .form-section .form-row{display:flex;gap:var(--spacing-lg);margin-bottom:var(--spacing-md)}@media (max-width:768px){organism-user-profile-102009 .user-profile-container .profile-form .form-section .form-row{flex-direction:column;gap:var(--spacing-md)}}organism-user-profile-102009 .user-profile-container .profile-form .form-section .form-group{flex:1}organism-user-profile-102009 .user-profile-container .profile-form .form-section .form-group.full-width{flex:100%}organism-user-profile-102009 .user-profile-container .profile-form .form-section .form-group label{display:block;font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-xs);font-size:var(--font-size-sm)}organism-user-profile-102009 .user-profile-container .profile-form .form-section .form-group input{width:100%;padding:var(--spacing-sm);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);font-size:var(--font-size-md);transition:var(--transition-base)}organism-user-profile-102009 .user-profile-container .profile-form .form-section .form-group input:focus{outline:none;border-color:var(--color-primary);box-shadow:0 0 0 3px var(--color-overlay)}organism-user-profile-102009 .user-profile-container .profile-form .form-actions{display:flex;gap:var(--spacing-md);justify-content:flex-end;padding-top:var(--spacing-lg);border-top:1px solid var(--color-border)}organism-user-profile-102009 .user-profile-container .profile-form .form-actions .btn-secondary{background:transparent;color:var(--color-text-secondary);border:1px solid var(--color-border);padding:var(--spacing-sm) var(--spacing-lg);border-radius:var(--border-radius-sm);cursor:pointer;transition:var(--transition-base)}organism-user-profile-102009 .user-profile-container .profile-form .form-actions .btn-secondary:hover{background:var(--color-surface);border-color:var(--color-primary)}organism-user-profile-102009 .user-profile-container .profile-form .form-actions .btn-primary{background:var(--color-primary);color:white;border:none;padding:var(--spacing-sm) var(--spacing-lg);border-radius:var(--border-radius-sm);cursor:pointer;transition:var(--transition-base)}organism-user-profile-102009 .user-profile-container .profile-form .form-actions .btn-primary:hover{background:var(--color-link-hover)}`);
    }
    render() {
        return html `
<div class="user-profile-container" id="user-profile-1">
  <div class="profile-header" id="user-profile-2">
    <div class="profile-avatar" id="user-profile-3">
      <img src="https://images.unsplash.com/photo-1701463387028-3947648f1337?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBtYW4lMjBhdmF0YXIlMjBwcm9maWxlJTIwcGljdHVyZXxlbnwwfHx8fDE3NTMyOTI0MTV8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Foto do perfil" class="avatar-image" id="user-profile-4">
      <button class="change-avatar-btn" id="user-profile-5">Alterar foto</button>
    </div>
    <div class="profile-info" id="user-profile-6">
      <h1 id="user-profile-7">Meu Perfil</h1>
      <p class="profile-subtitle" id="user-profile-8">Gerencie suas informações pessoais</p>
    </div>
  </div>
  
  <div class="profile-form" id="user-profile-9">
    <form class="user-data-form" id="user-profile-10">
      <div class="form-section" id="user-profile-11">
        <h2 id="user-profile-12">Dados Pessoais</h2>
        <div class="form-row" id="user-profile-13">
          <div class="form-group" id="user-profile-14">
            <label for="nome" id="user-profile-15">Nome completo</label>
            <input type="text" id="nome" name="nome" value="Guilherme Pereira" required="" >
          </div>
          <div class="form-group" id="user-profile-16">
            <label for="email" id="user-profile-17">E-mail</label>
            <input type="email" id="email" name="email" value="guilherme@email.com" required="" >
          </div>
        </div>
        <div class="form-row" id="user-profile-18">
          <div class="form-group" id="user-profile-19">
            <label for="telefone" id="user-profile-20">Telefone</label>
            <input type="tel" id="telefone" name="telefone" value="(11) 99999-9999" required="" >
          </div>
          <div class="form-group" id="user-profile-21">
            <label for="cpf" id="user-profile-22">CPF</label>
            <input type="text" id="cpf" name="cpf" value="123.456.789-00" required="" >
          </div>
        </div>
        <div class="form-row" id="user-profile-23">
          <div class="form-group full-width" id="user-profile-24">
            <label for="endereco" id="user-profile-25">Endereço completo</label>
            <input type="text" id="endereco" name="endereco" value="Rua das Flores, 123 - Centro - São Paulo/SP" >
          </div>
        </div>
      </div>
      
      <div class="form-section" id="user-profile-26">
        <h2 id="user-profile-27">Alterar Senha</h2>
        <div class="form-row" id="user-profile-28">
          <div class="form-group" id="user-profile-29">
            <label for="senha-atual" id="user-profile-30">Senha atual</label>
            <input type="password" id="senha-atual" name="senha-atual" >
          </div>
          <div class="form-group" id="user-profile-31">
            <label for="nova-senha" id="user-profile-32">Nova senha</label>
            <input type="password" id="nova-senha" name="nova-senha" >
          </div>
        </div>
        <div class="form-row" id="user-profile-33">
          <div class="form-group" id="user-profile-34">
            <label for="confirmar-senha" id="user-profile-35">Confirmar nova senha</label>
            <input type="password" id="confirmar-senha" name="confirmar-senha" >
          </div>
        </div>
      </div>
      
      <div class="form-actions" id="user-profile-36">
        <button type="button" class="btn-secondary" id="user-profile-37">Cancelar</button>
        <button type="submit" class="btn-primary" id="user-profile-38">Salvar alterações</button>
      </div>
    </form>
  </div>
</div>

    `;
    }
};
_102009_organismUserProfile = __decorate([
    customElement('organism-user-profile-102009')
], _102009_organismUserProfile);
export { _102009_organismUserProfile };
