/// <mls shortName="organismAppointmentsHistory" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAppointmentsHistory = class _102009_organismAppointmentsHistory extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-appointments-history-102009 .appointments-history-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-xl);margin-bottom:var(--spacing-xl);box-shadow:var(--shadow-sm)}organism-appointments-history-102009 .appointments-history-container .section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-lg)}organism-appointments-history-102009 .appointments-history-container .section-header h2{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin:0}organism-appointments-history-102009 .appointments-history-container .section-header .filter-options .filter-select{padding:var(--spacing-sm) var(--spacing-md);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);background:white;cursor:pointer}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card{background:white;border-radius:var(--border-radius-md);padding:var(--spacing-lg);margin-bottom:var(--spacing-md);box-shadow:var(--shadow-sm);display:flex;align-items:center;gap:var(--spacing-lg);transition:var(--transition-base)}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card:hover{box-shadow:var(--shadow-md)}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-date{background:var(--color-primary);color:white;border-radius:var(--border-radius-sm);padding:var(--spacing-md);text-align:center;min-width:60px}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-date .day{display:block;font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);line-height:1}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-date .month{display:block;font-size:var(--font-size-xs);margin-top:var(--spacing-xs)}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-info{flex:1}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-info h3{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin:0 0 var(--spacing-xs) 0}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-info .appointment-time{color:var(--color-text-secondary);margin:0 0 var(--spacing-xs) 0}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-info .appointment-professional{color:var(--color-text-secondary);font-size:var(--font-size-sm);margin:0}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status{text-align:right}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status .status-badge{display:block;padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);font-size:var(--font-size-xs);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-xs)}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status .status-badge.concluido{background:var(--color-success);color:white}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status .status-badge.agendado{background:var(--color-warning);color:white}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status .status-badge.cancelado{background:var(--color-error);color:white}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status .appointment-price{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-primary)}`);
    }
    render() {
        return html `
  <div class="appointments-history-container" id="appointment-history-1">
  <div class="section-header" id="appointment-history-2">
    <h2 id="appointment-history-3">Histórico de Agendamentos</h2>
    <div class="filter-options" id="appointment-history-4">
      <select class="filter-select" id="appointment-history-5">
        <option value="todos" id="appointment-history-6">Todos os status</option>
        <option value="agendado" id="appointment-history-7">Agendados</option>
        <option value="concluido" id="appointment-history-8">Concluídos</option>
        <option value="cancelado" id="appointment-history-9">Cancelados</option>
      </select>
    </div>
  </div>
  
  <div class="appointments-list" id="appointment-history-10">
    <div class="appointment-card status-concluido" id="appointment-history-11">
      <div class="appointment-date" id="appointment-history-12">
        <span class="day" id="appointment-history-13">15</span>
        <span class="month" id="appointment-history-14">JUL</span>
      </div>
      <div class="appointment-info" id="appointment-history-15">
        <h3 id="appointment-history-16">Banho e Tosa - Rex</h3>
        <p class="appointment-time" id="appointment-history-17">14:00 - 15:30</p>
        <p class="appointment-professional" id="appointment-history-18">Profissional: Maria Silva</p>
      </div>
      <div class="appointment-status" id="appointment-history-19">
        <span class="status-badge concluido" id="appointment-history-20">Concluído</span>
        <span class="appointment-price" id="appointment-history-21">R$ 45,00</span>
      </div>
    </div>
    
    <div class="appointment-card status-agendado" id="appointment-history-22">
      <div class="appointment-date" id="appointment-history-23">
        <span class="day" id="appointment-history-24">28</span>
        <span class="month" id="appointment-history-25">JUL</span>
      </div>
      <div class="appointment-info" id="appointment-history-26">
        <h3 id="appointment-history-27">Consulta Veterinária - Luna</h3>
        <p class="appointment-time" id="appointment-history-28">10:00 - 10:30</p>
        <p class="appointment-professional" id="appointment-history-29">Dr. João Santos</p>
      </div>
      <div class="appointment-status" id="appointment-history-30">
        <span class="status-badge agendado" id="appointment-history-31">Agendado</span>
        <span class="appointment-price" id="appointment-history-32">R$ 80,00</span>
      </div>
    </div>
    
    <div class="appointment-card status-concluido" id="appointment-history-33">
      <div class="appointment-date" id="appointment-history-34">
        <span class="day" id="appointment-history-35">08</span>
        <span class="month" id="appointment-history-36">JUL</span>
      </div>
      <div class="appointment-info" id="appointment-history-37">
        <h3 id="appointment-history-38">Vacinação - Rex</h3>
        <p class="appointment-time" id="appointment-history-39">16:00 - 16:15</p>
        <p class="appointment-professional" id="appointment-history-40">Dr. Ana Costa</p>
      </div>
      <div class="appointment-status" id="appointment-history-41">
        <span class="status-badge concluido" id="appointment-history-42">Concluído</span>
        <span class="appointment-price" id="appointment-history-43">R$ 120,00</span>
      </div>
    </div>
  </div>
</div>

    `;
    }
};
_102009_organismAppointmentsHistory = __decorate([
    customElement('organism-appointments-history-102009')
], _102009_organismAppointmentsHistory);
export { _102009_organismAppointmentsHistory };
