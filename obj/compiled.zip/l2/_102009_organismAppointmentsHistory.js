/// <mls shortName="organismAppointmentsHistory" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAppointmentsHistory = class _102009_organismAppointmentsHistory extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-appointments-history-102009 .appointments-history-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-xl);margin-bottom:var(--spacing-xl);box-shadow:var(--shadow-sm)}organism-appointments-history-102009 .appointments-history-container .section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-lg)}organism-appointments-history-102009 .appointments-history-container .section-header h2{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin:0}organism-appointments-history-102009 .appointments-history-container .section-header .filter-options .filter-select{padding:var(--spacing-sm) var(--spacing-md);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);background:white;cursor:pointer}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card{background:white;border-radius:var(--border-radius-md);padding:var(--spacing-lg);margin-bottom:var(--spacing-md);box-shadow:var(--shadow-sm);display:flex;align-items:center;gap:var(--spacing-lg);transition:var(--transition-base)}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card:hover{box-shadow:var(--shadow-md)}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-date{background:var(--color-primary);color:white;border-radius:var(--border-radius-sm);padding:var(--spacing-md);text-align:center;min-width:60px}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-date .day{display:block;font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);line-height:1}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-date .month{display:block;font-size:var(--font-size-xs);margin-top:var(--spacing-xs)}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-info{flex:1}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-info h3{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin:0 0 var(--spacing-xs) 0}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-info .appointment-time{color:var(--color-text-secondary);margin:0 0 var(--spacing-xs) 0}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-info .appointment-professional{color:var(--color-text-secondary);font-size:var(--font-size-sm);margin:0}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status{text-align:right}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status .status-badge{display:block;padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);font-size:var(--font-size-xs);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-xs)}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status .status-badge.concluido{background:var(--color-success);color:white}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status .status-badge.agendado{background:var(--color-warning);color:white}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status .status-badge.cancelado{background:var(--color-error);color:white}organism-appointments-history-102009 .appointments-history-container .appointments-list .appointment-card .appointment-status .appointment-price{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-primary)}`);
    }
    render() {
        return html `
      <div class="appointments-history-container">
        <div class="section-header">
          <h2>Histórico de Agendamentos</h2>
          <div class="filter-options">
            <select class="filter-select">
              <option value="todos">Todos os status</option>
              <option value="agendado">Agendados</option>
              <option value="concluido">Concluídos</option>
              <option value="cancelado">Cancelados</option>
            </select>
          </div>
        </div>
        
        <div class="appointments-list">
          <div class="appointment-card status-concluido">
            <div class="appointment-date">
              <span class="day">15</span>
              <span class="month">JUL</span>
            </div>
            <div class="appointment-info">
              <h3>Banho e Tosa - Rex</h3>
              <p class="appointment-time">14:00 - 15:30</p>
              <p class="appointment-professional">Profissional: Maria Silva</p>
            </div>
            <div class="appointment-status">
              <span class="status-badge concluido">Concluído</span>
              <span class="appointment-price">R$ 45,00</span>
            </div>
          </div>
          
          <div class="appointment-card status-agendado">
            <div class="appointment-date">
              <span class="day">28</span>
              <span class="month">JUL</span>
            </div>
            <div class="appointment-info">
              <h3>Consulta Veterinária - Luna</h3>
              <p class="appointment-time">10:00 - 10:30</p>
              <p class="appointment-professional">Dr. João Santos</p>
            </div>
            <div class="appointment-status">
              <span class="status-badge agendado">Agendado</span>
              <span class="appointment-price">R$ 80,00</span>
            </div>
          </div>
          
          <div class="appointment-card status-concluido">
            <div class="appointment-date">
              <span class="day">08</span>
              <span class="month">JUL</span>
            </div>
            <div class="appointment-info">
              <h3>Vacinação - Rex</h3>
              <p class="appointment-time">16:00 - 16:15</p>
              <p class="appointment-professional">Dr. Ana Costa</p>
            </div>
            <div class="appointment-status">
              <span class="status-badge concluido">Concluído</span>
              <span class="appointment-price">R$ 120,00</span>
            </div>
          </div>
        </div>
      </div>
    `;
    }
};
_102009_organismAppointmentsHistory = __decorate([
    customElement('organism-appointments-history-102009')
], _102009_organismAppointmentsHistory);
export { _102009_organismAppointmentsHistory };
