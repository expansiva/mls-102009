/// <mls shortName="layer4Scheduling" project="102009" enhancement="_blank" />
export var SchedulingStatus;
(function (SchedulingStatus) {
    SchedulingStatus["PENDING"] = "PENDING";
    SchedulingStatus["CONFIRMED"] = "CONFIRMED";
    SchedulingStatus["COMPLETED"] = "COMPLETED";
    SchedulingStatus["CANCELED"] = "CANCELED";
})(SchedulingStatus || (SchedulingStatus = {}));
;
