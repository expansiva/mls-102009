/// <mls shortName="layer4ServiceOrder" project="102009" enhancement="_blank" />
export var ServiceOrderStatus;
(function (ServiceOrderStatus) {
    ServiceOrderStatus["WAITING"] = "WAITING";
    ServiceOrderStatus["IN_PROGRESS"] = "IN_PROGRESS";
    ServiceOrderStatus["READY_FOR_COLLECTION"] = "READY_FOR_COLLECTION";
    ServiceOrderStatus["BILLED"] = "BILLED";
    ServiceOrderStatus["CANCELED"] = "CANCELED";
})(ServiceOrderStatus || (ServiceOrderStatus = {}));
;
