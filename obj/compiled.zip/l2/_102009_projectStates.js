/// <mls shortName="projectStates" project="102009" enhancement="_blank" />
import { initState } from './_100554_collabState';
export const homeVersion = 3;
export const aboutVersion = 2;
export const contactVersion = 5;
// ex: ui.actualPage
initState('ui', {
    actualPage: 'home',
    pageVersions: {
        home: homeVersion,
        about: aboutVersion,
        contact: contactVersion
    }
});
initState('auth', {
    user: null
});
