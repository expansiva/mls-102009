/// <mls shortName="layer3UpdServiceOrder" project="102009" enhancement="_blank" />
export async function updServiceOrder(ctx, data) {
    return await ctx.io.serviceOrder.upd(data);
}
