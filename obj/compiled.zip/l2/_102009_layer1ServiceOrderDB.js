/// <mls shortName="layer1ServiceOrderDB" project="102009" enhancement="_blank" />
import { STORE_NAME_SERVICEORDER, openDB } from "./_102009_layer1IndexedDb";
class ServiceOrder {
    //-----------METHODS----------- 
    async upd(param) {
        return await this.saveServiceOrderData(param);
    }
    async add(param) {
        return await this.saveServiceOrderData(param);
    }
    async del(id) {
        return await this.deleteServiceOrderData(id);
    }
    async list() {
        return await this.getAllServiceOrderData();
    }
    async getById(id) {
        return await this.getServiceOrderData(id);
    }
    //-----------IMPLEMENTS------------
    async saveServiceOrderData(data) {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME_SERVICEORDER, "readwrite");
        data.version = Date.now().toString();
        tx.objectStore(STORE_NAME_SERVICEORDER).put(data);
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve(data);
            tx.onerror = () => reject(tx.error);
        });
    }
    async getServiceOrderData(id) {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME_SERVICEORDER, "readonly");
        const request = tx.objectStore(STORE_NAME_SERVICEORDER).get(id);
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => reject(request.error);
        });
    }
    async getAllServiceOrderData() {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME_SERVICEORDER, "readonly");
        const request = tx.objectStore(STORE_NAME_SERVICEORDER).getAll();
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    async deleteServiceOrderData(id) {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME_SERVICEORDER, "readwrite");
        tx.objectStore(STORE_NAME_SERVICEORDER).delete(id);
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }
}
export const serviceOrder = new ServiceOrder();
