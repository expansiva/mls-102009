/// <mls shortName="layer1ServiceOrderDB" project="102009" enhancement="_blank" />
class ServiceOrder {
    constructor() {
        //--------VARIABLES-------------
        this.DB_NAME = "PetshopDB";
        this.VERSION = 1;
        this.STORE_NAME = "service_order_data";
    }
    //-----------METHODS----------- 
    async upd(param) {
        return await this.saveServiceOrderData(param);
    }
    async add(param) {
        return await this.saveServiceOrderData(param);
    }
    async del(id) {
        return await this.deleteServiceOrderData(id);
    }
    async list() {
        return await this.getAllServiceOrderData();
    }
    async getById(id) {
        return await this.getServiceOrderData(id);
    }
    //-----------IMPLEMENTS------------
    openDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.DB_NAME, this.VERSION);
            request.onupgradeneeded = () => {
                const db = request.result;
                if (!db.objectStoreNames.contains(this.STORE_NAME)) {
                    db.createObjectStore(this.STORE_NAME, { keyPath: "id" });
                }
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    async saveServiceOrderData(data) {
        const db = await this.openDB();
        const tx = db.transaction(this.STORE_NAME, "readwrite");
        data.version = Date.now().toString();
        tx.objectStore(this.STORE_NAME).put(data);
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve(data);
            tx.onerror = () => reject(tx.error);
        });
    }
    async getServiceOrderData(id) {
        const db = await this.openDB();
        const tx = db.transaction(this.STORE_NAME, "readonly");
        const request = tx.objectStore(this.STORE_NAME).get(id);
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => reject(request.error);
        });
    }
    async getAllServiceOrderData() {
        const db = await this.openDB();
        const tx = db.transaction(this.STORE_NAME, "readonly");
        const request = tx.objectStore(this.STORE_NAME).getAll();
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    async deleteServiceOrderData(id) {
        const db = await this.openDB();
        const tx = db.transaction(this.STORE_NAME, "readwrite");
        tx.objectStore(this.STORE_NAME).delete(id);
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }
}
export const serviceOrder = new ServiceOrder();
