/// <mls shortName="carrinho" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let _102009_carrinho = class _102009_carrinho extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`carrinho-102009{min-height:100vh;display:flex;flex-direction:column;font-family:var(--font-family-primary);background-color:var(--color-background);color:var(--color-text-normal)}carrinho-102009 main{flex:1;padding:var(--spacing-lg) var(--spacing-md);max-width:1200px;margin:0 auto;width:100%;display:grid;grid-template-columns:2fr 1fr;gap:var(--spacing-xl)}@media (max-width:768px){carrinho-102009 main{grid-template-columns:1fr;padding:var(--spacing-md) var(--spacing-sm);gap:var(--spacing-lg)}}`);
    }
    initPage() {
    }
};
_102009_carrinho = __decorate([
    customElement('carrinho-102009')
], _102009_carrinho);
export { _102009_carrinho };
