/// <mls shortName="layer2GetByIdScheduling" project="102009" enhancement="_blank" />
import * as layer3 from "./_102009_layer3GetByIdScheduling";
export async function getByIdScheduling(ctx, data) {
    const ret = {
        statusCode: 200,
        ok: true,
        data: undefined,
        error: undefined
    };
    try {
        if (!data || !data.id)
            throw new Error('[layer2GetByIdScheduling]:Into the data');
        ret.data = await layer3.getByIdScheduling(ctx, data.id);
        return ret;
    }
    catch (e) {
        ret.statusCode = 400;
        ret.ok = false;
        ret.error = e.message;
        return ret;
    }
}
