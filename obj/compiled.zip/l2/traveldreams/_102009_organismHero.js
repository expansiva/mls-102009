/// <mls shortName="organismHero" project="102009" folder="traveldreams" enhancement="_100554_enhancementLit" groupName="traveldreams" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismHero = class organismHero extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`traveldreams--organism-hero-102009{background:var(--bg-primary-color-lighter);font-family:var(--font-family-primary)}traveldreams--organism-hero-102009 .hero-container{display:flex;align-items:center;justify-content:space-between;max-width:1200px;margin:0 auto;padding:var(--space-48) var(--space-24);min-height:480px}@media (max-width:768px){traveldreams--organism-hero-102009 .hero-container{flex-direction:column-reverse;text-align:center;padding:var(--space-24) var(--space-8)}}traveldreams--organism-hero-102009 .hero-text{flex:1 1 0;max-width:540px}traveldreams--organism-hero-102009 .hero-text h1{font-size:var(--font-size-48);font-weight:var(--font-weight-bolder);color:var(--text-primary-color);line-height:var(--line-height-large);margin-bottom:var(--space-24)}traveldreams--organism-hero-102009 .hero-text p{font-size:var(--font-size-20);color:var(--text-primary-color-lighter);margin-bottom:var(--space-32)}traveldreams--organism-hero-102009 .hero-text .hero-cta{display:inline-block;background:var(--bg-secondary-color);color:#fff;font-size:var(--font-size-20);font-weight:var(--font-weight-bold);padding:var(--space-16) var(--space-32);border-radius:32px;text-decoration:none;transition:background var(--transition-normal)}traveldreams--organism-hero-102009 .hero-text .hero-cta:hover,traveldreams--organism-hero-102009 .hero-text .hero-cta:focus{background:var(--bg-secondary-color-hover);color:#fff;outline:none}traveldreams--organism-hero-102009 .hero-image{flex:1 1 0;display:flex;justify-content:flex-end;align-items:center}traveldreams--organism-hero-102009 .hero-image img{max-width:380px;width:100%;height:auto;border-radius:24px;box-shadow:0 8px 32px rgba(28,145,205,0.1)}@media (max-width:768px){traveldreams--organism-hero-102009 .hero-image{justify-content:center;margin-bottom:var(--space-24)}}`);
    }
    render() {
        return html `<div class="hero-container" id="hero">
          <div class="hero-text" id="traveldreams--hero-102009-1">
            <h1 id="traveldreams--hero-102009-2">Descubra o mundo com a Travel Dreams</h1>
            <p id="traveldreams--hero-102009-3">Planeje sua próxima viagem de forma simples, rápida e segura. Destinos incríveis, hotéis selecionados e experiências inesquecíveis esperam por você!</p>
            <a href="#destinations" class="hero-cta" id="traveldreams--hero-102009-4">Comece agora</a>
          </div>
          <div class="hero-image" id="traveldreams--hero-102009-5">
            <img src="https://chamados.expansiva.com.br/novosite/turista.png" alt="Turista feliz explorando o mundo" id="traveldreams--hero-102009-6">
          </div>
        </div>
      `;
    }
};
organismHero = __decorate([
    customElement('traveldreams--organism-hero-102009')
], organismHero);
export { organismHero };
