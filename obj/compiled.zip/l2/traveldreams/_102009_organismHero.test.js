/// <mls shortName="organismHero" project="102009" enhancement="_blank" folder="traveldreams" />
export const integrations = [];
export const tests = [];
