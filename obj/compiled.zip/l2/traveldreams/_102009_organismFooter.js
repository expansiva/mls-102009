var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismFooter" project="102009" folder="traveldreams" enhancement="_100554_enhancementLit" groupName="traveldreams" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismFooter = class organismFooter extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`traveldreams--organism-footer-102009{background:var(--bg-primary-color);font-family:var(--font-family-primary);color:var(--text-primary-color-lighter)}traveldreams--organism-footer-102009 .footer-container{max-width:1200px;margin:0 auto;padding:var(--space-40) var(--space-24);display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-start;gap:var(--space-32)}@media (max-width:768px){traveldreams--organism-footer-102009 .footer-container{flex-direction:column;align-items:center;gap:var(--space-24);text-align:center}}traveldreams--organism-footer-102009 .footer-logo img{height:40px;width:auto;display:block;margin-bottom:var(--space-16)}traveldreams--organism-footer-102009 .footer-links{display:flex;flex-direction:column;gap:var(--space-8)}traveldreams--organism-footer-102009 .footer-links a{color:var(--link-color);text-decoration:none;font-size:var(--font-size-16)}traveldreams--organism-footer-102009 .footer-links a:hover,traveldreams--organism-footer-102009 .footer-links a:focus{color:var(--link-color-hover);text-decoration:underline}traveldreams--organism-footer-102009 .footer-social{display:flex;gap:var(--space-16)}traveldreams--organism-footer-102009 .footer-social a{color:var(--text-primary-color-lighter);font-size:var(--font-size-24);transition:color var(--transition-normal)}traveldreams--organism-footer-102009 .footer-social a:hover,traveldreams--organism-footer-102009 .footer-social a:focus{color:var(--text-primary-color)}traveldreams--organism-footer-102009 .footer-copy{width:100%;margin-top:var(--space-24);font-size:var(--font-size-12);color:var(--grey-color-darker);text-align:center}`);
    }
    // Helper to render social icon with tooltip
    renderSocialIcon(href, aria, icon, hint, idA, idSpan, idTooltip) {
        return html `
      <a href="${href}" title="${hint}" aria-label="${aria}" id="${idA}" class="footer-social-link">
        <span aria-hidden="true" id="${idSpan}">${icon}</span>
        <span class="footer-social-tooltip" id="${idTooltip}">${hint}</span>
      </a>
    `;
    }
    render() {
        return html `<div class="footer-container" id="traveldreams--footer-102009-1">
      <div class="footer-logo" id="traveldreams--footer-102009-2">
        <img src="https://chamados.expansiva.com.br/novosite/logo.svg" alt="Travel Dreams - Logo rodapé" id="traveldreams--footer-102009-3">
        <div id="traveldreams--footer-102009-4">Travel Dreams Agência de Viagens</div>
      </div>
      <div class="footer-links" id="traveldreams--footer-102009-5">
        <a href="#destinations" id="traveldreams--footer-102009-6">Destinos</a>
        <a href="#hotels" id="traveldreams--footer-102009-7">Hotéis</a>
        <a href="#flights" id="traveldreams--footer-102009-8">Voos</a>
        <a href="#bookings" id="traveldreams--footer-102009-9">Reservas</a>
        <a href="#subscribe" id="traveldreams--footer-102009-10">Newsletter</a>
      </div>
      <div class="footer-social" id="traveldreams--footer-102009-11">
        ${this.renderSocialIcon('#', 'Instagram', '📷', 'Instagram', 'traveldreams--footer-102009-12', 'traveldreams--footer-102009-13', 'traveldreams--footer-102009-tooltip-1')}
        ${this.renderSocialIcon('#', 'Facebook', '🐦', 'Facebook', 'traveldreams--footer-102009-14', 'traveldreams--footer-102009-15', 'traveldreams--footer-102009-tooltip-2')}
        ${this.renderSocialIcon('#', 'WhatsApp', '📱', 'WhatsApp', 'traveldreams--footer-102009-16', 'traveldreams--footer-102009-17', 'traveldreams--footer-102009-tooltip-3')}
      </div>
      <div class="footer-copy" id="traveldreams--footer-102009-18">
        © 2025 Travel Dreams. Todos os direitos reservados.
      </div>
    </div>
    `;
    }
};
organismFooter = __decorate([
    customElement('traveldreams--organism-footer-102009')
], organismFooter);
export { organismFooter };
