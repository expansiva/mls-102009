/// <mls shortName="organismPromoSteps" project="102009" folder="traveldreams" enhancement="_100554_enhancementLit" groupName="traveldreams" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPromoSteps = class organismPromoSteps extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`traveldreams--organism-promo-steps-102009{background:var(--bg-primary-color);font-family:var(--font-family-primary)}traveldreams--organism-promo-steps-102009 .steps-container{max-width:1200px;margin:0 auto;padding:var(--space-48) var(--space-24);text-align:center}traveldreams--organism-promo-steps-102009 h2{font-size:var(--font-size-24);color:var(--text-primary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-32)}traveldreams--organism-promo-steps-102009 .steps-list{display:flex;justify-content:center;gap:var(--space-40)}@media (max-width:768px){traveldreams--organism-promo-steps-102009 .steps-list{flex-direction:column;gap:var(--space-24);align-items:center}}traveldreams--organism-promo-steps-102009 .step{background:var(--bg-primary-color-lighter);border-radius:16px;box-shadow:0 2px 8px rgba(28,145,205,0.06);padding:var(--space-32) var(--space-24);max-width:320px;flex:1 1 0;display:flex;flex-direction:column;align-items:center}traveldreams--organism-promo-steps-102009 .step .step-icon{font-size:var(--font-size-40);color:var(--text-secondary-color);margin-bottom:var(--space-16);background:var(--bg-secondary-color-lighter);border-radius:50%;width:64px;height:64px;display:flex;align-items:center;justify-content:center}traveldreams--organism-promo-steps-102009 .step .step-title{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-8)}traveldreams--organism-promo-steps-102009 .step .step-desc{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);line-height:var(--line-height-medium)}`);
    }
    render() {
        return html `<div class="steps-container" id="promo">
          <h2 id="traveldreams--promo-steps-102009-1">Reserve sua próxima viagem em 3 passos fáceis</h2>
          <div class="steps-list" id="traveldreams--promo-steps-102009-2">
            <div class="step" id="traveldreams--promo-steps-102009-3">
              <div class="step-icon" aria-hidden="true" id="traveldreams--promo-steps-102009-4">📍</div>
              <div class="step-title" id="traveldreams--promo-steps-102009-5">Escolha o destino</div>
              <div class="step-desc" id="traveldreams--promo-steps-102009-6">Explore nossos destinos e encontre o lugar perfeito para sua próxima aventura.</div>
            </div>
            <div class="step" id="traveldreams--promo-steps-102009-7">
              <div class="step-icon" aria-hidden="true" id="traveldreams--promo-steps-102009-8">💼</div>
              <div class="step-title" id="traveldreams--promo-steps-102009-9">Reserve com facilidade</div>
              <div class="step-desc" id="traveldreams--promo-steps-102009-10">Selecione hotéis, voos e experiências em poucos cliques, com total segurança.</div>
            </div>
            <div class="step" id="traveldreams--promo-steps-102009-11">
              <div class="step-icon" aria-hidden="true" id="traveldreams--promo-steps-102009-12">✈️</div>
              <div class="step-title" id="traveldreams--promo-steps-102009-13">Aproveite a viagem</div>
              <div class="step-desc" id="traveldreams--promo-steps-102009-14">Viaje tranquilo e viva momentos inesquecíveis com a Travel Dreams.</div>
            </div>
          </div>
        </div>
      `;
    }
};
organismPromoSteps = __decorate([
    customElement('traveldreams--organism-promo-steps-102009')
], organismPromoSteps);
export { organismPromoSteps };
