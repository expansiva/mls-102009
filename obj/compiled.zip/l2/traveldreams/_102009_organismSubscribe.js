/// <mls shortName="organismSubscribe" project="102009" folder="traveldreams" enhancement="_100554_enhancementLit" groupName="traveldreams" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismSubscribe = class organismSubscribe extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`traveldreams--organism-subscribe-102009{background:var(--bg-primary-color-lighter);font-family:var(--font-family-primary)}traveldreams--organism-subscribe-102009 .subscribe-container{max-width:600px;margin:0 auto;padding:var(--space-48) var(--space-24);text-align:center;border-radius:24px;box-shadow:0 2px 8px rgba(28,145,205,0.06)}traveldreams--organism-subscribe-102009 h2{font-size:var(--font-size-24);color:var(--text-primary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-24)}traveldreams--organism-subscribe-102009 form{display:flex;flex-direction:column;gap:var(--space-16);align-items:center;margin-bottom:var(--space-16)}traveldreams--organism-subscribe-102009 form input[type="email"]{padding:var(--space-16);font-size:var(--font-size-16);border:1px solid var(--grey-color);border-radius:8px;width:100%;max-width:320px;outline:none;transition:border var(--transition-normal)}traveldreams--organism-subscribe-102009 form input[type="email"]:focus{border-color:var(--text-primary-color)}traveldreams--organism-subscribe-102009 form button[type="submit"]{background:var(--bg-secondary-color);color:#fff;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);padding:var(--space-16) var(--space-32);border:none;border-radius:32px;cursor:pointer;transition:background var(--transition-normal)}traveldreams--organism-subscribe-102009 form button[type="submit"]:hover,traveldreams--organism-subscribe-102009 form button[type="submit"]:focus{background:var(--bg-secondary-color-hover);outline:none}traveldreams--organism-subscribe-102009 .subscribe-success{color:var(--success-color);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);margin-top:var(--space-16)}traveldreams--organism-subscribe-102009 .subscribe-error{color:var(--error-color);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);margin-top:var(--space-16)}`);
    }
    render() {
        return html `<div class="subscribe-container" id="subscribe">
          <h2 id="traveldreams--subscribe-102009-1">Receba novidades e ofertas exclusivas</h2>
          <form autocomplete="off" novalidate="" id="traveldreams--subscribe-102009-2">
            <input type="email" name="email" placeholder="Seu e-mail" aria-label="Seu e-mail" required="" id="traveldreams--subscribe-102009-3">
            <button type="submit" id="traveldreams--subscribe-102009-4">Inscrever-se</button>
          </form>
          <div class="subscribe-success" style="display:none;" id="traveldreams--subscribe-102009-5">Obrigado por se inscrever! Em breve você receberá novidades.</div>
          <div class="subscribe-error" style="display:none;" id="traveldreams--subscribe-102009-6">Por favor, insira um e-mail válido.</div>
        </div>
      `;
    }
};
organismSubscribe = __decorate([
    customElement('traveldreams--organism-subscribe-102009')
], organismSubscribe);
export { organismSubscribe };
