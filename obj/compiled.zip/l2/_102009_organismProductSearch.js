/// <mls shortName="organismProductSearch" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismProductSearch = class _102009_organismProductSearch extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-product-search-102009{margin-bottom:var(--spacing-lg)}organism-product-search-102009 .search-container{position:relative;max-width:500px}organism-product-search-102009 .search-container .search-bar{display:flex;background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--border-radius-md);overflow:hidden;box-shadow:var(--shadow-sm)}organism-product-search-102009 .search-container .search-bar .search-input{flex:1;padding:var(--spacing-md);border:none;outline:none;font-size:var(--font-size-md);background:transparent;color:var(--color-text-normal)}organism-product-search-102009 .search-container .search-bar .search-input::placeholder{color:var(--color-text-disabled)}organism-product-search-102009 .search-container .search-bar .search-button{padding:var(--spacing-md);background:var(--color-primary);border:none;color:var(--color-background);cursor:pointer;transition:var(--transition-fast)}organism-product-search-102009 .search-container .search-bar .search-button:hover{background:var(--color-link-hover)}organism-product-search-102009 .search-container .search-suggestions{position:absolute;top:100%;left:0;right:0;background:var(--color-surface);border:1px solid var(--color-border);border-top:none;border-radius:0 0 var(--border-radius-md) var(--border-radius-md);box-shadow:var(--shadow-md);z-index:100}organism-product-search-102009 .search-container .search-suggestions .suggestion-item{padding:var(--spacing-sm) var(--spacing-md);cursor:pointer;transition:var(--transition-fast)}organism-product-search-102009 .search-container .search-suggestions .suggestion-item:hover{background:var(--color-overlay)}`);
    }
    render() {
        return html `
  <div class="search-container" id="product-search-1">
  <div class="search-bar" id="product-search-2">
    <input type="text" placeholder="Buscar produtos..." class="search-input" id="product-search-3">
    <button class="search-button" id="product-search-4">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" id="product-search-5">
        <path d="M21 21L16.514 16.506L21 21ZM19 10.5C19 15.194 15.194 19 10.5 19C5.806 19 2 15.194 2 10.5C2 5.806 5.806 2 10.5 2C15.194 2 19 5.806 19 10.5Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" id="product-search-6"></path>
      </svg>
    </button>
  </div>
  <div class="search-suggestions" style="display: none;" id="product-search-7">
    <div class="suggestion-item" id="product-search-8">Ração Premium</div>
    <div class="suggestion-item" id="product-search-9">Brinquedo Corda</div>
    <div class="suggestion-item" id="product-search-10">Coleira</div>
  </div>
</div>

      `;
    }
};
_102009_organismProductSearch = __decorate([
    customElement('organism-product-search-102009')
], _102009_organismProductSearch);
export { _102009_organismProductSearch };
