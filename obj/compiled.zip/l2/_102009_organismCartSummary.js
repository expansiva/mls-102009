/// <mls shortName="organismCartSummary" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismCartSummary = class _102009_organismCartSummary extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-cart-summary-102009 .summary-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-lg);box-shadow:var(--shadow-sm);position:sticky;top:var(--spacing-lg)}organism-cart-summary-102009 .summary-title{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-primary);margin-bottom:var(--spacing-lg);border-bottom:2px solid var(--color-border);padding-bottom:var(--spacing-sm)}organism-cart-summary-102009 .summary-details{margin-bottom:var(--spacing-lg)}organism-cart-summary-102009 .summary-details .summary-line{display:flex;justify-content:space-between;align-items:center;padding:var(--spacing-sm) 0;font-size:var(--font-size-md)}organism-cart-summary-102009 .summary-details .summary-line.discount{color:var(--color-success);font-weight:var(--font-weight-bold)}organism-cart-summary-102009 .summary-details .summary-line.total{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-cart-summary-102009 .summary-details .free-shipping{color:var(--color-success);font-weight:var(--font-weight-bold)}organism-cart-summary-102009 .summary-details .summary-divider{border:none;border-top:1px solid var(--color-border);margin:var(--spacing-md) 0}organism-cart-summary-102009 .coupon-section{margin-bottom:var(--spacing-lg)}organism-cart-summary-102009 .coupon-section h3{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-sm);color:var(--color-text-normal)}organism-cart-summary-102009 .coupon-section .coupon-input-group{display:flex;gap:var(--spacing-xs)}organism-cart-summary-102009 .coupon-section .coupon-input-group .coupon-input{flex:1;padding:var(--spacing-sm);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);font-size:var(--font-size-sm)}organism-cart-summary-102009 .coupon-section .coupon-input-group .coupon-input:focus{outline:none;border-color:var(--color-primary);box-shadow:0 0 0 2px var(--color-overlay)}organism-cart-summary-102009 .coupon-section .coupon-input-group .apply-coupon-btn{background:var(--color-secondary);color:var(--color-text-normal);border:none;padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--border-radius-sm);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-fast)}organism-cart-summary-102009 .coupon-section .coupon-input-group .apply-coupon-btn:hover{background:var(--color-accent);color:var(--color-background)}organism-cart-summary-102009 .shipping-info h3{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-sm);color:var(--color-text-normal)}organism-cart-summary-102009 .shipping-info .shipping-option{display:flex;align-items:flex-start;gap:var(--spacing-sm);padding:var(--spacing-sm);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);margin-bottom:var(--spacing-xs);cursor:pointer;transition:var(--transition-fast)}organism-cart-summary-102009 .shipping-info .shipping-option:hover{border-color:var(--color-primary);background:var(--color-overlay)}organism-cart-summary-102009 .shipping-info .shipping-option.selected{border-color:var(--color-primary);background:var(--color-overlay)}organism-cart-summary-102009 .shipping-info .shipping-option input[type="radio"]{margin-top:2px}organism-cart-summary-102009 .shipping-info .shipping-option label{flex:1;cursor:pointer;display:flex;flex-direction:column;gap:var(--spacing-xs)}organism-cart-summary-102009 .shipping-info .shipping-option label strong{color:var(--color-text-normal)}organism-cart-summary-102009 .shipping-info .shipping-option label span{font-size:var(--font-size-sm);color:var(--color-text-secondary)}`);
    }
    render() {
        return html `
  <div class="summary-container" id="cart-summary-1">
  <h2 class="summary-title" id="cart-summary-2">Resumo do Pedido</h2>
  <div class="summary-details" id="cart-summary-3">
    <div class="summary-line" id="cart-summary-4">
      <span id="cart-summary-5">Subtotal (4 itens)</span>
      <span id="cart-summary-6">R$ 237,20</span>
    </div>
    <div class="summary-line" id="cart-summary-7">
      <span id="cart-summary-8">Frete</span>
      <span class="free-shipping" id="cart-summary-9">Grátis</span>
    </div>
    <div class="summary-line discount" id="cart-summary-10">
      <span id="cart-summary-11">Desconto Cliente Fiel</span>
      <span id="cart-summary-12">-R$ 12,00</span>
    </div>
    <hr class="summary-divider" id="cart-summary-13">
    <div class="summary-line total" id="cart-summary-14">
      <span id="cart-summary-15">Total</span>
      <span id="cart-summary-16">R$ 225,20</span>
    </div>
  </div>

  <div class="coupon-section" id="cart-summary-17">
    <h3 id="cart-summary-18">Cupom de Desconto</h3>
    <div class="coupon-input-group" id="cart-summary-19">
      <input type="text" placeholder="Digite seu cupom" class="coupon-input" id="cart-summary-20">
      <button class="apply-coupon-btn" id="cart-summary-21">Aplicar</button>
    </div>
  </div>

  <div class="shipping-info" id="cart-summary-22">
    <h3 id="cart-summary-23">Entrega</h3>
    <div class="shipping-option selected" id="cart-summary-24">
      <input type="radio" name="shipping" id="cart-summary-25" checked="">
      <label for="cart-summary-25" id="cart-summary-26">
        <strong id="cart-summary-27">Entrega Grátis</strong>
        <span id="cart-summary-28">Receba em 3-5 dias úteis</span>
      </label>
    </div>
    <div class="shipping-option" id="cart-summary-29">
      <input type="radio" name="shipping" id="cart-summary-30">
      <label for="cart-summary-30" id="cart-summary-31">
        <strong id="cart-summary-32">Entrega Expressa - R$ 15,00</strong>
        <span id="cart-summary-33">Receba em 1-2 dias úteis</span>
      </label>
    </div>
  </div>
</div>

    `;
    }
};
_102009_organismCartSummary = __decorate([
    customElement('organism-cart-summary-102009')
], _102009_organismCartSummary);
export { _102009_organismCartSummary };
