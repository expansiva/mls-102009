/// <mls shortName="layer3GetByIdScheduling" project="102009" enhancement="_blank" />
export async function getByIdScheduling(ctx, id) {
    return await ctx.io.petshopDB.scheduling.getById(id);
}
