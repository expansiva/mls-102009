/// <mls shortName="layer2ListScheduling" project="102009" enhancement="_blank" />
import * as layer3 from "./_102009_layer3ListScheduling";
export async function listScheduling(ctx, data) {
    const ret = {
        statusCode: 200,
        ok: true,
        data: undefined,
        error: undefined
    };
    try {
        ret.data = await layer3.listScheduling(ctx);
        return ret;
    }
    catch (e) {
        ret.statusCode = 400;
        ret.ok = false;
        ret.error = e.message;
        return ret;
    }
}
