/// <mls shortName="home" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let _102009_home = class _102009_home extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`home-102009{font-family:var(--font-family-primary);color:var(--color-text-normal);background-color:var(--color-background);line-height:var(--line-height-md)}home-102009 .container{max-width:1200px;margin:0 auto;padding:0 var(--spacing-md)}home-102009 .section-title{font-size:var(--font-size-xxl);font-weight:var(--font-weight-bold);color:var(--color-primary);text-align:center;margin-bottom:var(--spacing-lg)}home-102009 .section-subtitle{font-size:var(--font-size-lg);color:var(--color-text-secondary);text-align:center;margin-bottom:var(--spacing-xl)}home-102009 .btn{padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--border-radius-sm);font-weight:var(--font-weight-bold);text-decoration:none;display:inline-block;transition:var(--transition-base);border:none;cursor:pointer;font-size:var(--font-size-md)}home-102009 .btn.btn-primary{background-color:var(--color-primary);color:white}home-102009 .btn.btn-primary:hover{background-color:var(--color-link-visited);transform:translateY(-2px);box-shadow:var(--shadow-md)}home-102009 .btn.btn-secondary{background-color:var(--color-secondary);color:var(--color-text-normal)}home-102009 .btn.btn-secondary:hover{background-color:var(--color-accent);color:white;transform:translateY(-2px);box-shadow:var(--shadow-md)}home-102009 .btn.btn-outline{background-color:transparent;color:var(--color-primary);border:2px solid var(--color-primary)}home-102009 .btn.btn-outline:hover{background-color:var(--color-primary);color:white}home-102009 .btn.btn-small{padding:var(--spacing-xs) var(--spacing-sm);font-size:var(--font-size-sm)}`);
    }
    initPage() {
    }
};
_102009_home = __decorate([
    customElement('home-102009')
], _102009_home);
export { _102009_home };
