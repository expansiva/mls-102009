/// <mls shortName="layer3DelServiceOrder" project="102009" enhancement="_blank" />
export async function delServiceOrder(ctx, id) {
    return await ctx.io.serviceOrder.del(id);
}
