/// <mls shortName="layer3UpdScheduling" project="102009" enhancement="_blank" />
export async function updScheduling(ctx, data) {
    return await ctx.io.petshopDB.scheduling.upd(data);
}
