/// <mls shortName="organismOrderSummary" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismOrderSummary = class _102009_organismOrderSummary extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-order-summary-102009 .order-summary-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-lg);box-shadow:var(--shadow-sm);position:sticky;top:100px}organism-order-summary-102009 .order-summary-container h2{color:var(--color-primary);font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-lg);text-align:center}organism-order-summary-102009 .order-summary-container .order-items{margin-bottom:var(--spacing-lg)}organism-order-summary-102009 .order-summary-container .order-items .order-item{display:flex;align-items:center;padding:var(--spacing-md);border-bottom:1px solid var(--color-border)}organism-order-summary-102009 .order-summary-container .order-items .order-item:last-child{border-bottom:none}organism-order-summary-102009 .order-summary-container .order-items .order-item .item-image{width:60px;height:60px;object-fit:cover;border-radius:var(--border-radius-sm);margin-right:var(--spacing-md)}organism-order-summary-102009 .order-summary-container .order-items .order-item .item-details{flex:1}organism-order-summary-102009 .order-summary-container .order-items .order-item .item-details h4{color:var(--color-text-normal);font-size:var(--font-size-md);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-xs)}organism-order-summary-102009 .order-summary-container .order-items .order-item .item-details p{color:var(--color-text-secondary);font-size:var(--font-size-sm);margin-bottom:var(--spacing-xs)}organism-order-summary-102009 .order-summary-container .order-items .order-item .item-details .item-price{color:var(--color-primary);font-weight:var(--font-weight-bold);font-size:var(--font-size-lg)}organism-order-summary-102009 .order-summary-container .order-totals{margin-bottom:var(--spacing-lg)}organism-order-summary-102009 .order-summary-container .order-totals .total-line{display:flex;justify-content:space-between;align-items:center;padding:var(--spacing-xs) 0;color:var(--color-text-normal)}organism-order-summary-102009 .order-summary-container .order-totals .total-line.discount{color:var(--color-success)}organism-order-summary-102009 .order-summary-container .order-totals .total-line.final{border-top:2px solid var(--color-primary);padding-top:var(--spacing-sm);margin-top:var(--spacing-sm);font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-order-summary-102009 .order-summary-container .delivery-info{padding:var(--spacing-md);background:var(--color-background);border-radius:var(--border-radius-sm);border-left:4px solid var(--color-secondary)}organism-order-summary-102009 .order-summary-container .delivery-info h3{color:var(--color-text-normal);font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-sm)}organism-order-summary-102009 .order-summary-container .delivery-info p{color:var(--color-text-secondary);font-size:var(--font-size-sm);margin-bottom:var(--spacing-xs)}organism-order-summary-102009 .order-summary-container .delivery-info p:last-child{margin-bottom:0}organism-order-summary-102009 .order-summary-container .delivery-info p strong{color:var(--color-text-normal)}`);
    }
    render() {
        return html `
      <div class="order-summary-container">
        <h2>Resumo do Pedido</h2>
        <div class="order-items">
          <div class="order-item">
            <img src="https://images.unsplash.com/photo-1684882726821-2999db517441?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwZG9nJTIwZm9vZCUyMGJhZyUyMHBldCUyMG51dHJpdGlvbnxlbnwwfHx8fDE3NTMyOTIxNzl8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Ração Premium" class="item-image">
            <div class="item-details">
              <h4>Ração Premium para Cães Adultos</h4>
              <p>Quantidade: 2</p>
              <span class="item-price">R$ 89,90</span>
            </div>
          </div>
          
          <div class="order-item">
            <img src="https://images.unsplash.com/photo-1681597088032-2366641716e3?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBjaGV3JTIwdG95JTIwY29sb3JmdWwlMjBwZXQlMjBhY2Nlc3Nvcnl8ZW58MHx8fHwxNzUzMzY1NzU5fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Brinquedo" class="item-image">
            <div class="item-details">
              <h4>Brinquedo Mordedor</h4>
              <p>Quantidade: 1</p>
              <span class="item-price">R$ 24,90</span>
            </div>
          </div>
        </div>
        
        <div class="order-totals">
          <div class="total-line">
            <span>Subtotal:</span>
            <span>R$ 114,80</span>
          </div>
          <div class="total-line">
            <span>Frete:</span>
            <span>R$ 15,00</span>
          </div>
          <div class="total-line discount">
            <span>Desconto:</span>
            <span>-R$ 5,00</span>
          </div>
          <div class="total-line final">
            <span>Total:</span>
            <span>R$ 124,80</span>
          </div>
        </div>
        
        <div class="delivery-info">
          <h3>Informações de Entrega</h3>
          <p><strong>Prazo:</strong> 3-5 dias úteis</p>
          <p><strong>Endereço:</strong> Rua das Flores, 123 - Centro</p>
        </div>
      </div>
    `;
    }
};
_102009_organismOrderSummary = __decorate([
    customElement('organism-order-summary-102009')
], _102009_organismOrderSummary);
export { _102009_organismOrderSummary };
