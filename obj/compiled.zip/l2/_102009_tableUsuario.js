/// <mls shortName="tableUsuario" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
export const modelPrisma = `
model Usuario {
  id Int @id @default(autoincrement())
  nome String email String senha String? tipo String status String? facebookId String? instagramId String?
}
`;
