/// <mls shortName="layer1SchedulingDB" project="102009" enhancement="_blank" />
class Scheduling {
    constructor() {
        //--------VARIABLES-------------
        this.DB_NAME = "PetshopDB";
        this.VERSION = 1;
        this.STORE_NAME = "scheduling_data";
    }
    //-----------METHODS----------- 
    async upd(param) {
        return await this.saveSchedulingData(param);
    }
    async add(param) {
        return await this.saveSchedulingData(param);
    }
    async del(id) {
        return await this.deleteSchedulingData(id);
    }
    async list() {
        return await this.getAllSchedulingData();
    }
    async getById(id) {
        return await this.getSchedulingData(id);
    }
    async recordCount() {
        return await this.getRecordCount();
    }
    async listByClient(clientId) {
        return await this.getRecordsByClient(clientId);
    }
    //-----------IMPLEMENTS------------
    openDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.DB_NAME, this.VERSION);
            request.onupgradeneeded = () => {
                const db = request.result;
                if (!db.objectStoreNames.contains(this.STORE_NAME)) {
                    db.createObjectStore(this.STORE_NAME, { keyPath: "id" });
                }
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    async saveSchedulingData(data) {
        const db = await this.openDB();
        const tx = db.transaction(this.STORE_NAME, "readwrite");
        data.version = Date.now().toString();
        tx.objectStore(this.STORE_NAME).put(data);
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve(data);
            tx.onerror = () => reject(tx.error);
        });
    }
    async getRecordCount() {
        const db = await this.openDB();
        const transaction = db.transaction(this.STORE_NAME, 'readonly');
        const store = transaction.objectStore(this.STORE_NAME);
        const request = store.count();
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result || 0);
            request.onerror = () => reject(request.error);
        });
    }
    async getSchedulingData(id) {
        const db = await this.openDB();
        const tx = db.transaction(this.STORE_NAME, "readonly");
        const request = tx.objectStore(this.STORE_NAME).get(id);
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => reject(request.error);
        });
    }
    async getAllSchedulingData() {
        const db = await this.openDB();
        const tx = db.transaction(this.STORE_NAME, "readonly");
        const request = tx.objectStore(this.STORE_NAME).getAll();
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    async deleteSchedulingData(id) {
        const db = await this.openDB();
        const tx = db.transaction(this.STORE_NAME, "readwrite");
        tx.objectStore(this.STORE_NAME).delete(id);
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }
    async getRecordsByClient(clientId) {
        return new Promise((resolve, reject) => {
            const openRequest = indexedDB.open(this.DB_NAME, this.VERSION);
            openRequest.onerror = () => reject(openRequest.error);
            openRequest.onsuccess = () => {
                const db = openRequest.result;
                const tx = db.transaction(this.STORE_NAME, "readonly");
                const store = tx.objectStore(this.STORE_NAME);
                const getAllRequest = store.getAll();
                getAllRequest.onsuccess = () => {
                    const allRecords = getAllRequest.result || [];
                    const filtered = allRecords.filter((item) => item?.data.clientMdmId === clientId);
                    resolve(filtered);
                    db.close();
                };
                getAllRequest.onerror = () => reject(getAllRequest.error);
            };
        });
    }
}
export const scheduling = new Scheduling();
