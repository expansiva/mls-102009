/// <mls shortName="tablePagamento" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
export const modelPrisma = `
model Pagamento {
  id Int @id @default(autoincrement())
  pedidoId Int 
  metodo String 
  dados Json 
  status String?
}
`;
