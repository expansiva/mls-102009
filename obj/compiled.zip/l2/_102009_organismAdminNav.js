/// <mls shortName="organismAdminNav" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAdminNav = class _102009_organismAdminNav extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-admin-nav-102009 .admin-nav{display:flex;justify-content:space-between;align-items:center;padding:var(--spacing-md) var(--spacing-lg)}organism-admin-nav-102009 .admin-nav .nav-brand{display:flex;align-items:center;gap:var(--spacing-sm)}organism-admin-nav-102009 .admin-nav .nav-brand .logo{width:40px;height:40px;border-radius:var(--border-radius-sm)}organism-admin-nav-102009 .admin-nav .nav-brand h1{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-primary);margin:0}organism-admin-nav-102009 .admin-nav .nav-user{display:flex;align-items:center;gap:var(--spacing-md)}organism-admin-nav-102009 .admin-nav .nav-user .welcome-text{color:var(--color-text-secondary);font-size:var(--font-size-sm)}organism-admin-nav-102009 .admin-nav .nav-user .logout-btn{background-color:var(--color-error);color:white;border:none;padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);cursor:pointer;font-size:var(--font-size-sm);transition:var(--transition-base)}organism-admin-nav-102009 .admin-nav .nav-user .logout-btn:hover{opacity:.9}`);
    }
    render() {
        return html `
<nav class="admin-nav" id="admin-nav-1">
  <div class="nav-brand" id="admin-nav-2">
    <img src="https://images.unsplash.com/photo-1628760584600-6c31148991e9?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXRzaG9wJTIwbG9nbyUyMG1vZGVybiUyMGNsZWFuJTIwZGVzaWdufGVufDB8fHx8MTc1MzM2NTk5MXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="PetShop Admin" class="logo" id="admin-nav-3">
    <h1 id="admin-nav-4">Painel Administrativo</h1>
  </div>
  <div class="nav-user" id="admin-nav-5">
    <span class="welcome-text" id="admin-nav-6">Bem-vindo, Admin</span>
    <button class="logout-btn" id="admin-nav-7">Sair</button>
  </div>
</nav>

    `;
    }
};
_102009_organismAdminNav = __decorate([
    customElement('organism-admin-nav-102009')
], _102009_organismAdminNav);
export { _102009_organismAdminNav };
