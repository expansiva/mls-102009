/// <mls shortName="tableItempedido" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
export const modelPrisma = `
model ItemPedido {
  id Int @id @default(autoincrement())
  pedidoId Int 
  produtoId Int 
  quantidade Int 
  precoUnitario Float
}
`;
