/// <mls shortName="pageAdminOrderEdit" project="102009" enhancement="_blank" folder="petshop" />
export const defs = {
    "meta": {
        "projectId": 102009,
        "folder": "petshop",
        "shortName": "pageAdminOrderEdit",
        "type": "page",
        "devFidelity": "scaffold",
        "group": "petshop",
        "tags": [
            "lit",
            "page"
        ]
    },
    "references": {
        "plugins": [],
        "statesRO": [],
        "statesRW": [],
        "statesWO": [],
        "imports": []
    },
    "planning": {
        "userRequestsEnhancements": [],
        "constraints": []
    }
};
