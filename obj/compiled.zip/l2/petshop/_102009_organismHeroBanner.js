/// <mls shortName="organismHeroBanner" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismHeroBanner = class organismHeroBanner extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-hero-banner-102009{display:flex;align-items:center;justify-content:center;background:linear-gradient(90deg, var(--bg-secondary-color-lighter) 0%, var(--bg-primary-color-lighter) 100%);min-height:340px;padding:var(--space-32) 0}petshop--organism-hero-banner-102009 .banner-content{display:flex;align-items:center;gap:var(--space-40);max-width:1100px;width:100%;flex-wrap:wrap}petshop--organism-hero-banner-102009 .banner-text{flex:1 1 320px}petshop--organism-hero-banner-102009 .banner-text h1{font-size:var(--font-size-40);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-16);line-height:var(--line-height-large)}petshop--organism-hero-banner-102009 .banner-text p{font-size:var(--font-size-20);color:var(--text-secondary-color-darker);margin-bottom:var(--space-24);line-height:var(--line-height-medium)}petshop--organism-hero-banner-102009 .banner-text .cta-btn{display:inline-block;background:var(--text-secondary-color);color:var(--bg-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);padding:var(--space-16) var(--space-32);border-radius:32px;text-decoration:none;transition:background var(--transition-normal),color var(--transition-normal);box-shadow:0 2px 8px var(--grey-color-light)}petshop--organism-hero-banner-102009 .banner-text .cta-btn:hover,petshop--organism-hero-banner-102009 .banner-text .cta-btn:focus{background:var(--text-secondary-color-hover);color:var(--bg-primary-color)}petshop--organism-hero-banner-102009 .banner-image{flex:1 1 260px;display:flex;align-items:center;justify-content:center}petshop--organism-hero-banner-102009 .banner-image img{width:260px;height:260px;object-fit:cover;border-radius:50%;box-shadow:0 4px 24px var(--grey-color-light);background:var(--bg-primary-color)}@media (max-width:768px){petshop--organism-hero-banner-102009 .banner-content{flex-direction:column;align-items:center;gap:var(--space-24)}petshop--organism-hero-banner-102009 .banner-image img{width:180px;height:180px}petshop--organism-hero-banner-102009 .banner-text h1{font-size:var(--font-size-24)}}`);
    }
    render() {
        return html `<div class="banner-content" id="petshop--hero-banner-102009-1">
          <div class="banner-text" id="petshop--hero-banner-102009-2">
            <h1 id="petshop--hero-banner-102009-3">Bem-vindo ao Petshop Amigo!</h1>
            <p id="petshop--hero-banner-102009-4">Cuidado, carinho e tudo para o seu pet em um só lugar. Agende banho, tosa ou encontre os melhores produtos para seu melhor amigo!</p>
            <a href="/agendamento" class="cta-btn" id="petshop--hero-banner-102009-5">Agende um banho &amp; tosa</a>
          </div>
          <div class="banner-image" id="petshop--hero-banner-102009-6">
            <img src="https://images.unsplash.com/photo-1711185891190-0f66509c0b9c?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGRvZyUyMGFmdGVyJTIwYmF0aCUyMHBldHNob3AlMjBiYW5uZXJ8ZW58MHx8fHwxNzU0NDExMzE1fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Cachorro feliz após banho" id="petshop--hero-banner-102009-7">
          </div>
        </div>
      `;
    }
};
organismHeroBanner = __decorate([
    customElement('petshop--organism-hero-banner-102009')
], organismHeroBanner);
export { organismHeroBanner };
