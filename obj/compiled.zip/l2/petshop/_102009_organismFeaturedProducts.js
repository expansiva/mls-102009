/// <mls shortName="organismFeaturedProducts" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { exec } from "./_102019_layer1Exec";
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { MdmType, AttachmentType } from "./_102019_layer4Mdm";
let organismFeaturedProducts = class organismFeaturedProducts extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-featured-products-102009{background:var(--bg-secondary-color);padding:var(--space-48) 0}petshop--organism-featured-products-102009 .products-container{max-width:1100px;margin:0 auto;display:flex;flex-direction:column;align-items:center}petshop--organism-featured-products-102009 h2{color:var(--text-primary-color);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:var(--space-32);text-align:center}petshop--organism-featured-products-102009 .products-list{display:flex;gap:var(--space-32);flex-wrap:wrap;justify-content:center;width:100%}petshop--organism-featured-products-102009 .product-card{background:var(--bg-primary-color);border-radius:16px;box-shadow:0 2px 8px var(--grey-color-light);padding:var(--space-24);display:flex;flex-direction:column;align-items:center;width:200px;min-height:300px;text-align:center;transition:box-shadow var(--transition-normal)}petshop--organism-featured-products-102009 .product-card:hover,petshop--organism-featured-products-102009 .product-card:focus{box-shadow:0 4px 16px var(--grey-color)}petshop--organism-featured-products-102009 .product-card .product-image{width:120px;height:120px;margin-bottom:var(--space-16)}petshop--organism-featured-products-102009 .product-card .product-image img{width:100%;height:100%;object-fit:cover;border-radius:12px;background:var(--bg-secondary-color-lighter)}petshop--organism-featured-products-102009 .product-card .product-title{font-size:var(--font-size-16);font-weight:var(--font-weight-bold);color:var(--text-primary-color-darker);margin-bottom:var(--space-8)}petshop--organism-featured-products-102009 .product-card .product-price{font-size:var(--font-size-16);color:var(--text-secondary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-8)}petshop--organism-featured-products-102009 .product-card .product-action{margin-top:auto}petshop--organism-featured-products-102009 .product-card .product-action a{display:inline-block;background:var(--text-primary-color);color:var(--bg-primary-color);font-size:var(--font-size-12);font-weight:var(--font-weight-bold);padding:var(--space-8) var(--space-16);border-radius:24px;text-decoration:none;transition:background var(--transition-normal),color var(--transition-normal)}petshop--organism-featured-products-102009 .product-card .product-action a:hover,petshop--organism-featured-products-102009 .product-card .product-action a:focus{background:var(--text-primary-color-hover);color:var(--bg-primary-color)}@media (max-width:768px){petshop--organism-featured-products-102009 .products-list{gap:var(--space-16)}petshop--organism-featured-products-102009 .product-card{width:140px;min-height:220px;padding:var(--space-16)}petshop--organism-featured-products-102009 .product-image{width:80px;height:80px}}`);
        this.mdmProducts = [];
    }
    //---------------------------
    async firstUpdated() {
        this.init();
    }
    render() {
        return html `
    <div class="products-container">
      <h2>Produtos em destaque</h2>
      <div class="products-list" id="petshop--featured-products-102009-3">
        ${this.mdmProducts.map((prod, index) => this.renderItem(prod, index))}
      </div>
    </div>
      `;
    }
    renderItem(prod, index) {
        if (index > 3)
            return html ``;
        const reg = prod.data.registrationData;
        let img = 'https://images.unsplash.com/photo-1583860332956-0cd934c28cec?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBiZWQlMjBjb21mb3J0YWJsZSUyMGJsdWUlMjBncmVlbnxlbnwwfHx8fDE3NTQ0MTEzMTZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080';
        if (prod.data.attachments && prod.data.attachments.length > 0) {
            prod.data.attachments.forEach((i) => {
                if (i.type === AttachmentType.MEDIA_PROFILE_PIC)
                    img = i.url;
            });
        }
        return html `
      <div class="product-card">
        <div class="product-image">
          <img src="${img}" alt="Caminha confortável para pets">
        </div>
        <div class="product-title">${reg.name}</div>
        <div class="product-price">R$ 50,00</div>
        <div class="product-action">
          <a href="/pageProduct">Comprar</a>
        </div>
      </div>
    `;
    }
    //--------------------------
    init() {
        this.loadProd();
    }
    async loadProd() {
        const req = {
            action: 'MDMGetListByType',
            inDeveloped: true,
            version: '1',
            params: { type: MdmType.Produto },
        };
        const response = await exec(req);
        if (response.ok) {
            this.mdmProducts = response.data.map((item) => {
                const item2 = item;
                return item2;
            });
        }
    }
};
__decorate([
    state()
], organismFeaturedProducts.prototype, "mdmProducts", void 0);
organismFeaturedProducts = __decorate([
    customElement('petshop--organism-featured-products-102009')
], organismFeaturedProducts);
export { organismFeaturedProducts };
