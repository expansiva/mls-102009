"use strict";
/// <mls shortName="organismAdminAddProduct" project="102009" enhancement="_blank" folder="petshop" />
