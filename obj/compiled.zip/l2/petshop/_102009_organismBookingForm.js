/// <mls shortName="organismBookingForm" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismBookingForm = class organismBookingForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-booking-form-102009{background:var(--bg-primary-color);border-radius:var(--space-16);box-shadow:0 2px 8px 0 rgba(211,211,211,0.2);padding:var(--space-32) var(--space-40);margin-bottom:var(--space-32);max-width:480px;width:100%;font-family:var(--font-family-primary)}@media (max-width:768px){petshop--organism-booking-form-102009{padding:var(--space-16) var(--space-8);max-width:100%}}petshop--organism-booking-form-102009 h2{color:var(--text-primary-color);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:var(--space-24);text-align:center}petshop--organism-booking-form-102009 form{display:flex;flex-direction:column;gap:var(--space-16)}petshop--organism-booking-form-102009 label{font-size:var(--font-size-16);color:var(--text-primary-color-darker);margin-bottom:var(--space-8);font-weight:var(--font-weight-normal)}petshop--organism-booking-form-102009 input,petshop--organism-booking-form-102009 select{padding:var(--space-8);border:1px solid var(--grey-color-dark);border-radius:var(--space-8);font-size:var(--font-size-16);font-family:var(--font-family-primary);background:var(--bg-primary-color-lighter);color:var(--text-primary-color-darker);transition:border-color var(--transition-normal)}petshop--organism-booking-form-102009 input:focus,petshop--organism-booking-form-102009 select:focus{border-color:var(--text-primary-color);outline:none}petshop--organism-booking-form-102009 .form-row{display:flex;gap:var(--space-16)}@media (max-width:544px){petshop--organism-booking-form-102009 .form-row{flex-direction:column;gap:var(--space-8)}}petshop--organism-booking-form-102009 .form-actions{display:flex;flex-direction:column;align-items:center;margin-top:var(--space-24)}petshop--organism-booking-form-102009 button[type="submit"]{background:var(--text-secondary-color);color:var(--bg-primary-color);border:none;border-radius:var(--space-8);padding:var(--space-8) var(--space-32);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-normal)}petshop--organism-booking-form-102009 button[type="submit"]:hover{background:var(--text-secondary-color-hover)}petshop--organism-booking-form-102009 button[type="submit"]:disabled{background:var(--text-secondary-color-disabled);cursor:not-allowed}petshop--organism-booking-form-102009 .form-error{color:var(--error-color);font-size:var(--font-size-12);margin-top:var(--space-8)}petshop--organism-booking-form-102009 .confirmation-message{color:var(--success-color);font-size:var(--font-size-16);text-align:center;margin-top:var(--space-16)}`);
    }
    render() {
        return html `<h2 id="petshop--booking-form-102009-1">Agende Banho &amp; Tosa</h2>
      <form autocomplete="off" id="petshop--booking-form-102009-2">
        <div class="form-row" id="petshop--booking-form-102009-3">
          <div style="flex:1;" id="petshop--booking-form-102009-4">
            <label for="service" id="petshop--booking-form-102009-5">Serviço *</label>
            <select id="service" name="service" required="">
              <option value="" id="petshop--booking-form-102009-6">Selecione</option>
              <option value="banho" id="petshop--booking-form-102009-7">Banho</option>
              <option value="tosa" id="petshop--booking-form-102009-8">Tosa</option>
              <option value="banho_tosa" id="petshop--booking-form-102009-9">Banho + Tosa</option>
            </select>
          </div>
          <div style="flex:1;" id="petshop--booking-form-102009-10">
            <label for="date" id="petshop--booking-form-102009-11">Data *</label>
            <input type="date" id="date" name="date" required="" min="2025-08-06">
          </div>
        </div>
        <div class="form-row" id="petshop--booking-form-102009-12">
          <div style="flex:1;" id="petshop--booking-form-102009-13">
            <label for="time" id="petshop--booking-form-102009-14">Horário *</label>
            <select id="time" name="time" required="">
              <option value="" id="petshop--booking-form-102009-15">Selecione</option>
              <option value="09:00" id="petshop--booking-form-102009-16">09:00</option>
              <option value="10:00" id="petshop--booking-form-102009-17">10:00</option>
              <option value="11:00" id="petshop--booking-form-102009-18">11:00</option>
              <option value="13:00" id="petshop--booking-form-102009-19">13:00</option>
              <option value="14:00" id="petshop--booking-form-102009-20">14:00</option>
              <option value="15:00" id="petshop--booking-form-102009-21">15:00</option>
              <option value="16:00" id="petshop--booking-form-102009-22">16:00</option>
            </select>
          </div>
        </div>
        <hr style="margin:@space-16 0; border:0; border-top:1px solid @grey-color-light;" id="petshop--booking-form-102009-23">
        <div class="form-row" id="petshop--booking-form-102009-24">
          <div style="flex:1;" id="petshop--booking-form-102009-25">
            <label for="pet-name" id="petshop--booking-form-102009-26">Nome do Pet *</label>
            <input type="text" id="pet-name" name="pet-name" required="" placeholder="Ex: Thor">
          </div>
          <div style="flex:1;" id="petshop--booking-form-102009-27">
            <label for="pet-type" id="petshop--booking-form-102009-28">Tipo do Pet *</label>
            <select id="pet-type" name="pet-type" required="">
              <option value="" id="petshop--booking-form-102009-29">Selecione</option>
              <option value="cachorro" id="petshop--booking-form-102009-30">Cachorro</option>
              <option value="gato" id="petshop--booking-form-102009-31">Gato</option>
              <option value="ave" id="petshop--booking-form-102009-32">Ave</option>
              <option value="outro" id="petshop--booking-form-102009-33">Outro</option>
            </select>
          </div>
        </div>
        <div class="form-row" id="petshop--booking-form-102009-34">
          <div style="flex:1;" id="petshop--booking-form-102009-35">
            <label for="pet-size" id="petshop--booking-form-102009-36">Porte *</label>
            <select id="pet-size" name="pet-size" required="">
              <option value="" id="petshop--booking-form-102009-37">Selecione</option>
              <option value="pequeno" id="petshop--booking-form-102009-38">Pequeno</option>
              <option value="medio" id="petshop--booking-form-102009-39">Médio</option>
              <option value="grande" id="petshop--booking-form-102009-40">Grande</option>
            </select>
          </div>
        </div>
        <hr style="margin:@space-16 0; border:0; border-top:1px solid @grey-color-light;" id="petshop--booking-form-102009-41">
        <div class="form-row" id="petshop--booking-form-102009-42">
          <div style="flex:1;" id="petshop--booking-form-102009-43">
            <label for="tutor-name" id="petshop--booking-form-102009-44">Nome do Tutor *</label>
            <input type="text" id="tutor-name" name="tutor-name" required="" placeholder="Seu nome">
          </div>
        </div>
        <div class="form-row" id="petshop--booking-form-102009-45">
          <div style="flex:1;" id="petshop--booking-form-102009-46">
            <label for="tutor-email" id="petshop--booking-form-102009-47">E-mail *</label>
            <input type="email" id="tutor-email" name="tutor-email" required="" placeholder="seu@email.com">
          </div>
          <div style="flex:1;" id="petshop--booking-form-102009-48">
            <label for="tutor-phone" id="petshop--booking-form-102009-49">Telefone *</label>
            <input type="tel" id="tutor-phone" name="tutor-phone" required="" placeholder="(99) 99999-9999" pattern="\(\d{2}\) \d{5}-\d{4}">
          </div>
        </div>
        <div class="form-actions" id="petshop--booking-form-102009-50">
          <button type="submit" id="petshop--booking-form-102009-51">Agendar</button>
          <div class="form-error" style="display:none;" id="petshop--booking-form-102009-52">Por favor, preencha todos os campos obrigatórios e escolha um horário disponível.</div>
          <div class="confirmation-message" style="display:none;" id="petshop--booking-form-102009-53">Agendamento realizado com sucesso! Você receberá um e-mail de confirmação.</div>
        </div>
      </form>
    `;
    }
};
organismBookingForm = __decorate([
    customElement('petshop--organism-booking-form-102009')
], organismBookingForm);
export { organismBookingForm };
