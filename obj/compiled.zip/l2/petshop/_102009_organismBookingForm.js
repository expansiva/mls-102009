/// <mls shortName="organismBookingForm" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { setState, getState } from '_100554_/l2/collabState';
import { exec } from "./_102019_layer1Exec";
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { MdmType } from "./_102019_layer4Mdm";
let organismBookingForm = class organismBookingForm extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-booking-form-102009{background:var(--bg-primary-color);border-radius:var(--space-16);box-shadow:0 2px 8px 0 rgba(211,211,211,0.2);padding:var(--space-32) var(--space-40);margin-bottom:var(--space-32);max-width:480px;width:100%;font-family:var(--font-family-primary)}@media (max-width:768px){petshop--organism-booking-form-102009{padding:var(--space-16) var(--space-8);max-width:100%}}petshop--organism-booking-form-102009 h2{color:var(--text-primary-color);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:var(--space-24);text-align:center}petshop--organism-booking-form-102009 form{display:flex;flex-direction:column;gap:var(--space-16)}petshop--organism-booking-form-102009 label{font-size:var(--font-size-16);color:var(--text-primary-color-darker);margin-bottom:var(--space-8);font-weight:var(--font-weight-normal)}petshop--organism-booking-form-102009 input,petshop--organism-booking-form-102009 select{padding:var(--space-8);border:1px solid var(--grey-color-dark);border-radius:var(--space-8);font-size:var(--font-size-16);font-family:var(--font-family-primary);background:var(--bg-primary-color-lighter);color:var(--text-primary-color-darker);transition:border-color var(--transition-normal)}petshop--organism-booking-form-102009 input:focus,petshop--organism-booking-form-102009 select:focus{border-color:var(--text-primary-color);outline:none}petshop--organism-booking-form-102009 .form-row{display:flex;gap:var(--space-16)}@media (max-width:544px){petshop--organism-booking-form-102009 .form-row{flex-direction:column;gap:var(--space-8)}}petshop--organism-booking-form-102009 .form-actions{display:flex;flex-direction:column;align-items:center;margin-top:var(--space-24)}petshop--organism-booking-form-102009 button[type="submit"]{background:var(--text-secondary-color);color:var(--bg-primary-color);border:none;border-radius:var(--space-8);padding:var(--space-8) var(--space-32);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-normal)}petshop--organism-booking-form-102009 button[type="submit"]:hover{background:var(--text-secondary-color-hover)}petshop--organism-booking-form-102009 button[type="submit"]:disabled{background:var(--text-secondary-color-disabled);cursor:not-allowed}petshop--organism-booking-form-102009 .form-error{color:var(--error-color);font-size:var(--font-size-12);margin-top:var(--space-8)}petshop--organism-booking-form-102009 .confirmation-message{color:var(--success-color);font-size:var(--font-size-16);text-align:center;margin-top:var(--space-16)}`);
        this.myPets = [];
        this.services = [];
        this.error = '';
        this.loading = false;
    }
    //-------------------------------
    firstUpdated() {
        this.init();
    }
    render() {
        return html `<h2>Agende Banho &amp; Tosa</h2>
      <form autocomplete="off">
        <div class="form-row">
          <div style="flex:1;">
            <label for="service">Serviço *</label>
            <select id="service" name="service" required="">
              <option value="">Selecione</option>
              ${this.services.map((serv, index) => html `
                  <option value="${index}">${serv.data.registrationData.name}</option>
              `)}
            </select>
          </div>
        </div>
        <div class="form-row">
          <div style="flex:1;">
            <label for="service">Pet *</label>
            <select id="service" name="service" required="">
              <option value="">Selecione</option>
              ${this.services.map((serv, index) => html `
                  <option value="${index}">${serv.data.registrationData.name}</option>
              `)}
            </select>
          </div>
        </div>
        <div class="form-row" >
          <div style="flex:1;">
            <label for="date" id="petshop--booking-form-102009-11">Data *</label>
            <input type="date" id="date" name="date" required="" min="2025-08-06">
          </div>
          <div style="flex:1;" id="petshop--booking-form-102009-10">
            <label for="time" id="petshop--booking-form-102009-14">Horário *</label>
            <select id="time" name="time" required="">
              <option value="" id="petshop--booking-form-102009-15">Selecione</option>
              <option value="09:00" id="petshop--booking-form-102009-16">09:00</option>
              <option value="10:00" id="petshop--booking-form-102009-17">10:00</option>
              <option value="11:00" id="petshop--booking-form-102009-18">11:00</option>
              <option value="13:00" id="petshop--booking-form-102009-19">13:00</option>
              <option value="14:00" id="petshop--booking-form-102009-20">14:00</option>
              <option value="15:00" id="petshop--booking-form-102009-21">15:00</option>
              <option value="16:00" id="petshop--booking-form-102009-22">16:00</option>
            </select>
          </div>
        </div>
        
        <div class="form-actions" id="petshop--booking-form-102009-50">
          <button type="submit" id="petshop--booking-form-102009-51">Agendar</button>
        </div>
      </form>
    `;
    }
    //---------------------------
    async init() {
        this.mdmData = getState('ui.petshop.login');
        this.myPets = getState('ui.petshop.client.myPets') || [];
        this.services = getState('ui.petshop.client.services') || [];
        this.loadInfos();
    }
    async loadInfos() {
        await this.getMyPets();
        await this.getServices();
    }
    async getMyPets() {
        if (!this.mdmData) {
            this.error = 'Falata parametros para pegar os pets';
            return;
        }
        const ids = [];
        if (this.mdmData.data.relationships) {
            this.mdmData.data.relationships.forEach((r) => {
                if (r.type === 'R_PF_OWNER_OF_PET')
                    ids.push(r.relatedMdmId);
            });
        }
        const req = {
            action: 'MDMGetListByIds',
            inDeveloped: true,
            version: '1',
            params: { ids }
        };
        const response = await exec(req);
        if (!response.ok) {
            this.error = response.error;
            this.loading = false;
            return;
        }
        this.myPets = response.data.filter((item) => item != null);
        setState('ui.petshop.client.myPets', this.myPets);
    }
    async getServices() {
        const req = {
            action: 'MDMGetListByType',
            inDeveloped: true,
            version: '1',
            params: { type: MdmType.Servico }
        };
        const response = await exec(req);
        if (!response.ok) {
            this.error = response.error;
            this.loading = false;
            return;
        }
        this.services = response.data.filter((item) => item != null);
        setState('ui.petshop.client.services', this.services);
    }
};
__decorate([
    state()
], organismBookingForm.prototype, "mdmData", void 0);
__decorate([
    state()
], organismBookingForm.prototype, "myPets", void 0);
__decorate([
    state()
], organismBookingForm.prototype, "services", void 0);
__decorate([
    state()
], organismBookingForm.prototype, "error", void 0);
__decorate([
    state()
], organismBookingForm.prototype, "loading", void 0);
organismBookingForm = __decorate([
    customElement('petshop--organism-booking-form-102009')
], organismBookingForm);
export { organismBookingForm };
