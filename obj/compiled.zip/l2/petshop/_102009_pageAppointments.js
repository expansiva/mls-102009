/// <mls shortName="pageAppointments" project="102009" enhancement="_100554_enhancementLit" folder="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageAppointments = class PageAppointments extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--page-appointments-102009{display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color)}petshop--page-appointments-102009 header{flex-shrink:0}petshop--page-appointments-102009 main{display:flex;flex-direction:column;gap:.5rem;padding:var(--space-32) 0 var(--space-32) 0;background:var(--bg-secondary-color)}petshop--page-appointments-102009 main petshop--organism-view-my-appointments-102009{max-width:978px;margin:0 auto}@media (max-width:768px){petshop--page-appointments-102009 main{padding:var(--space-16) 0 var(--space-16) 0}}petshop--page-appointments-102009 main #agendamento-core-main-1{flex:1 0 auto;display:flex;flex-direction:row;align-items:flex-start;gap:1rem;justify-content:center}petshop--page-appointments-102009 footer{flex-shrink:0}`);
    }
    initPage() {
    }
};
PageAppointments = __decorate([
    customElement('petshop--page-appointments-102009')
], PageAppointments);
export { PageAppointments };
