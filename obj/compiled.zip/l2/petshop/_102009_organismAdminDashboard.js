/// <mls shortName="organismAdminDashboard" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAdminDashboard = class organismAdminDashboard extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-dashboard-102009 .admin-dashboard{background:var(--bg-primary-color);padding:var(--space-32);font-family:var(--font-family-primary)}petshop--organism-admin-dashboard-102009 .admin-dashboard .admin-dashboard__title{font-size:var(--font-size-24);color:var(--text-primary-color-darker);margin-bottom:var(--space-24);font-weight:var(--font-weight-bold)}petshop--organism-admin-dashboard-102009 .admin-dashboard .admin-dashboard__metrics{display:flex;gap:var(--space-32);margin-bottom:var(--space-32)}petshop--organism-admin-dashboard-102009 .admin-dashboard .admin-dashboard__metrics .admin-dashboard__metric{background:var(--bg-secondary-color-lighter);border-radius:8px;padding:var(--space-24);min-width:160px;text-align:center}petshop--organism-admin-dashboard-102009 .admin-dashboard .admin-dashboard__metrics .admin-dashboard__metric .admin-dashboard__metric-label{color:var(--text-primary-color);font-size:var(--font-size-12);margin-bottom:var(--space-8);display:block}petshop--organism-admin-dashboard-102009 .admin-dashboard .admin-dashboard__metrics .admin-dashboard__metric .admin-dashboard__metric-value{color:var(--text-secondary-color-darker);font-size:var(--font-size-24);font-weight:var(--font-weight-bold)}petshop--organism-admin-dashboard-102009 .admin-dashboard .admin-dashboard__charts{display:flex;gap:var(--space-32)}petshop--organism-admin-dashboard-102009 .admin-dashboard .admin-dashboard__charts .admin-dashboard__chart{background:var(--bg-secondary-color-lighter);border-radius:8px;padding:var(--space-16);flex:1;text-align:center}petshop--organism-admin-dashboard-102009 .admin-dashboard .admin-dashboard__charts .admin-dashboard__chart img{width:100%;max-width:260px;height:auto;margin-bottom:var(--space-8)}petshop--organism-admin-dashboard-102009 .admin-dashboard .admin-dashboard__charts .admin-dashboard__chart .admin-dashboard__chart-label{color:var(--text-primary-color);font-size:var(--font-size-12)}@media (max-width:768px){petshop--organism-admin-dashboard-102009 .admin-dashboard__metrics,petshop--organism-admin-dashboard-102009 .admin-dashboard__charts{flex-direction:column;gap:var(--space-16)}}`);
    }
    render() {
        return html `<section class="admin-dashboard" id="dashboard">
        <h1 class="admin-dashboard__title" id="petshop--admin-dashboard-102009-1">Visão Geral</h1>
        <div class="admin-dashboard__metrics" id="petshop--admin-dashboard-102009-2">
          <div class="admin-dashboard__metric" id="petshop--admin-dashboard-102009-3">
            <span class="admin-dashboard__metric-label" id="petshop--admin-dashboard-102009-4">Agendamentos Hoje</span>
            <span class="admin-dashboard__metric-value" id="petshop--admin-dashboard-102009-5">5</span>
          </div>
          <div class="admin-dashboard__metric" id="petshop--admin-dashboard-102009-6">
            <span class="admin-dashboard__metric-label" id="petshop--admin-dashboard-102009-7">Vendas do Mês</span>
            <span class="admin-dashboard__metric-value" id="petshop--admin-dashboard-102009-8">R$ 2.350,00</span>
          </div>
          <div class="admin-dashboard__metric" id="petshop--admin-dashboard-102009-9">
            <span class="admin-dashboard__metric-label" id="petshop--admin-dashboard-102009-10">Novos Clientes</span>
            <span class="admin-dashboard__metric-value" id="petshop--admin-dashboard-102009-11">8</span>
          </div>
        </div>
      </section>
    `;
    }
};
organismAdminDashboard = __decorate([
    customElement('petshop--organism-admin-dashboard-102009')
], organismAdminDashboard);
export { organismAdminDashboard };
