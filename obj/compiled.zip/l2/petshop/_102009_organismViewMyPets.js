var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismViewMyPets" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismViewMyPets = class organismViewMyPets extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-view-my-pets-102009{width:100%;height:100%}petshop--organism-view-my-pets-102009 .organism-view-my-pets{display:flex;flex-direction:column;gap:var(--space-24);height:calc(100% - 1px);overflow-y:auto}petshop--organism-view-my-pets-102009 td span{cursor:pointer;color:var(--active-color)}petshop--organism-view-my-pets-102009 .filters{display:flex;gap:var(--space-16);margin-bottom:var(--space-16)}petshop--organism-view-my-pets-102009 .add-pet-btn{margin-bottom:var(--space-16)}petshop--organism-view-my-pets-102009 .pets-table button{width:auto}@media (max-width:768px){petshop--organism-view-my-pets-102009 .filters{flex-direction:column}}`);
        this.scenary = 'list';
    }
    render() {
        if (this.scenary === 'list')
            return this.renderList();
        return this.renderEdit();
    }
    renderList() {
        return html `
      <div class="organism-view-my-pets section-card"> 
        <section class="pets-list-section">
          <h2>Meus Pets</h2>
          <div class="filters">
            <div class="form-group">
              <label for="filter-type">Tipo de Pet</label>
              <select id="filter-type">
                <option value="">Todos</option>
                <option value="cachorro">Cachorro</option>
                <option value="gato">Gato</option>
              </select>
            </div>
            <div class="form-group">
              <label for="filter-name">Nome</label>
              <input type="text" id="filter-name" placeholder="Buscar por nome">
            </div>
            <div class="form-group" style="width:70%">
              <button style="margin-top:30px; margin-left:auto" class="btn btn-save">Adicionar Novo Pet</button>
            </div>
          </div>
          
          <table class="pets-table">
            <thead>
              <tr>
                <th>Nome</th>
                <th>Tipo</th>
                <th>Dono</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Rex</td>
                <td>Cachorro</td>
                <td>João Silva</td>
                <td><span  @click=${() => this.changeScneray('add')}>Editar</span></td>
              </tr>
              <tr>
                <td>Whiskers</td>
                <td>Gato</td>
                <td>Maria Oliveira</td>
                <td><span  @click=${() => this.changeScneray('add')}>Editar</span></td>
              </tr>
            </tbody>
          </table>
        </section>
      </div>`;
    }
    renderEdit() {
        return html `
        <div class="organism-view-my-pets section-card"> 
          <section class="pet-form-section">
            <div>
              <h2>Cadastrar/Editar Pet</h2>
              <form>
                <div class="form-group">
                  <label for="pet-name">Nome</label>
                  <input type="text" id="pet-name" value="Rex">
                </div>
                <div class="form-group">
                  <label for="pet-type">Tipo</label>
                  <select id="pet-type">
                    <option value="cachorro" selected>Cachorro</option>
                    <option value="gato">Gato</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="pet-breed">Raça</label>
                  <input type="text" id="pet-breed" value="Labrador">
                </div>
                <div class="form-group">
                  <label for="pet-age">Idade</label>
                  <input type="number" id="pet-age" value="3">
                </div>
                <div class="form-group">
                  <label for="pet-notes">Observações</label>
                  <textarea id="pet-notes">Pet saudável e ativo.</textarea>
                </div>
                <div class="form-actions" >
                <button class="btn btn-delete" >Deletar</button>
                <button class="btn btn-back" @click=${() => this.changeScneray('list')}>Cancelar</button>
                <button class="btn btn-save" >Salvar</button>
                </div>
                
              </form>
            </div>
          </section>
        </div>`;
    }
    changeScneray(scenary) {
        this.scenary = scenary;
    }
};
__decorate([
    state()
], organismViewMyPets.prototype, "scenary", void 0);
organismViewMyPets = __decorate([
    customElement('petshop--organism-view-my-pets-102009')
], organismViewMyPets);
export { organismViewMyPets };
