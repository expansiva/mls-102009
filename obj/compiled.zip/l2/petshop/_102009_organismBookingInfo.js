/// <mls shortName="organismBookingInfo" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismBookingInfo = class organismBookingInfo extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-booking-info-102009{display:block;background:var(--bg-primary-color-lighter);border-radius:var(--space-16);box-shadow:0 1px 4px 0 rgba(211,211,211,0.1);padding:var(--space-24) var(--space-32);max-width:480px;width:100%;font-family:var(--font-family-primary);color:var(--text-primary-color-darker);font-size:var(--font-size-16);margin-bottom:var(--space-32)}@media (max-width:768px){petshop--organism-booking-info-102009{padding:var(--space-16) var(--space-8);max-width:100%}}petshop--organism-booking-info-102009 h3{color:var(--text-secondary-color-darker);font-size:var(--font-size-20);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}petshop--organism-booking-info-102009 ul{margin:0 0 var(--space-16) 0;padding-left:var(--space-24)}petshop--organism-booking-info-102009 ul li{margin-bottom:var(--space-8);line-height:var(--line-height-large)}petshop--organism-booking-info-102009 .info-note{background:var(--bg-secondary-color-lighter);border-left:4px solid var(--text-secondary-color);padding:var(--space-8) var(--space-16);border-radius:var(--space-8);font-size:var(--font-size-12);color:var(--text-primary-color-darker)}`);
    }
    render() {
        return html `<h3 id="petshop--booking-info-102009-1">Como funciona o agendamento?</h3>
      <ul id="petshop--booking-info-102009-2">
        <li id="petshop--booking-info-102009-3">Escolha o serviço desejado, data e horário disponíveis.</li>
        <li id="petshop--booking-info-102009-4">Preencha os dados do seu pet e do tutor corretamente.</li>
        <li id="petshop--booking-info-102009-5">Após o envio, você receberá um e-mail de confirmação do agendamento.</li>
        <li id="petshop--booking-info-102009-6">Chegue com 10 minutos de antecedência ao horário marcado.</li>
      </ul>
      <div class="info-note" id="petshop--booking-info-102009-7">
        <strong id="petshop--booking-info-102009-8">Importante:</strong> Cancelamentos devem ser feitos com pelo menos 2h de antecedência. Horários disponíveis podem variar conforme demanda.<br id="petshop--booking-info-102009-9">
        Para dúvidas, entre em contato pelo WhatsApp ou telefone.
      </div>
    `;
    }
};
organismBookingInfo = __decorate([
    customElement('petshop--organism-booking-info-102009')
], organismBookingInfo);
export { organismBookingInfo };
