/// <mls shortName="adminPanel" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageAdminPanel = class PageAdminPanel extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--admin-panel-102009{display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color)}petshop--admin-panel-102009 header{flex:0 0 auto;width:100%;z-index:10}petshop--admin-panel-102009 aside{flex:0 0 240px;min-width:220px;background:var(--bg-secondary-color-lighter);z-index:5}petshop--admin-panel-102009 main{flex:1 1 auto;display:flex;flex-direction:column;gap:var(--space-32);background:var(--bg-primary-color);padding-left:240px;padding-right:0}@media (max-width:768px){petshop--admin-panel-102009 main{padding-left:0}}petshop--admin-panel-102009 footer{flex:0 0 auto;width:100%;background:var(--bg-primary-color-darker);margin-top:auto}@media (max-width:768px){petshop--admin-panel-102009{flex-direction:column}petshop--admin-panel-102009 aside{min-width:100%;flex:0 0 auto}petshop--admin-panel-102009 main{padding-left:0}}`);
    }
    initPage() {
    }
};
PageAdminPanel = __decorate([
    customElement('petshop--admin-panel-102009')
], PageAdminPanel);
export { PageAdminPanel };
