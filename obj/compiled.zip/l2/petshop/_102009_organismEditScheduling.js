var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismEditScheduling" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { setState, getState } from '_100554_/l2/collabState';
import { propertyDataSource } from './_100554_collabDecorators';
import { petshopExec } from "./_102009_layer1Exec";
import { exec } from "./_102019_layer1Exec";
import { SchedulingStatus, ServiceOrderStatus } from './_102009_commonGlobal';
import { MdmType } from "./_102019_layer4Mdm";
let organismEditScheduling = class organismEditScheduling extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-edit-scheduling-102009{display:block;padding:1rem}petshop--organism-edit-scheduling-102009 .section-card{border:none;box-shadow:none}petshop--organism-edit-scheduling-102009 .scheduling-summary{list-style:none;margin:0;padding:0}petshop--organism-edit-scheduling-102009 .scheduling-summary li{margin-bottom:var(--space-8);font-size:var(--font-size-16);color:var(--text-primary-color);line-height:var(--line-height-medium)}petshop--organism-edit-scheduling-102009 .scheduling-summary li.li-edit,petshop--organism-edit-scheduling-102009 .scheduling-summary li.li-link{margin-top:2rem;border-top:1px solid var(--grey-color-dark);padding-top:1rem}`);
        this.loadingCancel = false;
        this.loadingConfirm = false;
        this.employees = [];
    }
    async firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        const data = getState('ui.petshop.admin.scheduling.selected');
        this.schedulingData = data;
        await this.getService(data.details.service.serviceMdmId);
        await this.getEmployers();
        if (this.schedulingData.details.serviceOrderId) {
            this.getOrderData(this.schedulingData.details.serviceOrderId);
        }
    }
    render() {
        const statusText = this.schedulingData?.details.status === SchedulingStatus.CONFIRMED ? 'Confirmado' : this.schedulingData?.details.status === SchedulingStatus.CANCELED ? 'Cancelado' : 'Pendente';
        const isPending = this.schedulingData?.details.status === SchedulingStatus.PENDING;
        return html `
        <div class="section-card">
        <h3>Detalhes do Agendamento</h3>
        <ul class="scheduling-summary">
            <li>Nome do Cliente: <span>${this.schedulingData?.details.tutor.name || ''}</span></li>
            <li>Nome do Serviço: <span>${this.schedulingData?.details.service.name || ''}</span></li>
            <li>Pet: <span>${this.schedulingData?.details.pet.name || ''}</span></li>
            <li>Data: <span>${new Date(this.schedulingData?.details.startDateTime || '').toLocaleString() || ''}</span></li>
            <li>Status: <span>${statusText}</span></li>

            ${this.schedulingData?.details.status === SchedulingStatus.PENDING ? html `
                    <li class="li-edit">

                        <div class="form-group">
                            <select id="employees"
                                ?disabled=${this.loadingCancel || this.loadingConfirm}
                                @change=${(e) => { this.employerSelected = this.employees[+(e.target.value)]; }}
                                
                            >
                                <option value="">Selecione o funcionário</option>
                                ${this.employees.map((item, index) => {
            const name = item.data.type === MdmType.PessoaFisica ? item.data.registrationData.name : item.data.registrationData.fantasyName;
            return html `<option value=${index}> ${name}</option>`;
        })}
                            </select>
                        </div>
                    </li>
                ` : ''}
        </ul>
        <div class="form-actions">
            ${this.schedulingData?.details.status === SchedulingStatus.PENDING ?
            html `
                    <button class="btn btn-delete" @click=${this.handleClickCancel} ?disabled=${this.loadingCancel || this.loadingConfirm} ?hidden=${!isPending}>
                        Recusar Serviço
                        ${this.loadingCancel ? html `<span class="loading"></span>` : html ``}
                </button>` : ''}
            ${this.schedulingData?.details.status === SchedulingStatus.PENDING ?
            html `<button class="btn btn-save" @click=${this.handleClickGenerateOS} ?disabled=${this.loadingConfirm || this.loadingCancel} ?hidden=${!isPending}>
                    Aprovar Serviço
                    ${this.loadingConfirm ? html `<span class="loading"></span>` : html ``}
                </button>` : ''}
        </div>

        </div>
        ${this.renderOrderService()}

        ${this.labelError ? html `<span class="error-message">${this.labelError}</span>` : ''}

        `;
    }
    renderOrderService() {
        const status = {
            WAITING: 'Aguardando serviço',
            IN_PROGRESS: 'Em andamento',
            BILLED: 'Faturado',
            CANCELED: 'Cancelado',
            READY_FOR_COLLECTION: 'Pronto para retirada',
        };
        const statusText = status[this.orderData?.details?.status || ''];
        return html `
        
            ${this.schedulingData?.details.serviceOrderId ? html `
                <div class="section-card">
                    <h3>Detalhes Ordem de serviço </h3>

                    <ul class="scheduling-summary">
                        <li>Nome do Funcionario: <span>${this.orderData?.details.employee.name || ''}</span></li>
                        <li>
                            Valor:
                            <span>
                                ${this.orderData?.details.totalAmount != null
            ? this.orderData.details.totalAmount.toLocaleString('pt-BR', {
                style: 'currency',
                currency: 'BRL',
            })
            : ''}
                            </span>
                        </li>

                        <li>Status: <span>${statusText}</span></li>
                        <li><a href="/pageAdminOrderEdit" @click=${() => { setState('ui.petshop.admin.order.selected', this.orderData); }}>Ver detalhes</a></li>

                    </ul>
                </div>
            
            ` : ''}
        `;
    }
    async getService(id) {
        const req = {
            action: 'MDMGetById',
            inDeveloped: true,
            version: '1',
            params: { id }
        };
        const response = await exec(req);
        if (!response.ok) {
            this.labelError = response.error || 'Não encontrado informações do serviço';
            return;
        }
        this.service = response.data;
    }
    async getOrderData(id) {
        const req = {
            action: 'ServiceOrderGetById',
            inDeveloped: true,
            version: '1',
            params: { id }
        };
        const response = await petshopExec(req);
        if (!response.ok) {
            this.labelError = response.error || 'Não encontrado informações da ordem de serviço';
            return;
        }
        this.orderData = response.data;
    }
    async getEmployers() {
        const ids = [];
        if (!this.service) {
            this.labelError = 'Não encontrado informações do serviço';
            return;
        }
        if (this.service.data.relationships) {
            this.service.data.relationships.forEach((r) => {
                ids.push(r.relatedMdmId);
            });
        }
        const req = {
            action: 'MDMGetListByIds',
            inDeveloped: true,
            version: '1',
            params: { ids }
        };
        const response = await exec(req);
        if (!response.ok) {
            this.labelError = response.error;
            return;
        }
        this.employees = response.data.filter((item) => item != null);
    }
    async handleClickCancel() {
        this.labelError = '';
        if (!this.schedulingData) {
            this.labelError = 'Nenhum agendamento selecionado!';
            return;
        }
        if (this.schedulingData.details.status !== SchedulingStatus.PENDING) {
            this.labelError = 'Ação permitida apenas para agendamentos pendentes';
            return;
        }
        this.loadingCancel = true;
        this.schedulingData.details.status = SchedulingStatus.CANCELED;
        const req = {
            action: 'SchedulingUpd',
            inDeveloped: true,
            version: '1',
            params: this.schedulingData
        };
        const response = await petshopExec(req);
        this.loadingCancel = false;
        if (!response.ok) {
            this.labelError = response.error;
            return;
        }
    }
    async handleClickGenerateOS() {
        this.labelError = '';
        if (!this.schedulingData || !this.schedulingData.id) {
            this.labelError = 'Nenhum agendamento selecionado!';
            return;
        }
        if (this.schedulingData.details.status !== SchedulingStatus.PENDING) {
            this.labelError = 'Ação permitida apenas para agendamentos pendentes';
            return;
        }
        const agendamentoDate = new Date(this.schedulingData.details.startDateTime);
        const agora = new Date();
        if (agendamentoDate < agora) {
            this.labelError = 'Não é permitido gerar OS para agendamentos com data/hora passada!';
            return;
        }
        if (!this.employerSelected || !this.employerSelected.id) {
            this.labelError = 'Selecionar funcionário';
            return;
        }
        this.loadingConfirm = true;
        const nameEmployer = this.employerSelected.data.type === MdmType.PessoaFisica ? this.employerSelected.data.registrationData.name : this.employerSelected.data.registrationData.fantasyName;
        const data = {
            details: {
                schedulingId: this.schedulingData.id,
                status: ServiceOrderStatus.WAITING,
                totalAmount: (this.service?.data).serviceData?.priceRegular || 0,
                executionDateTime: new Date(Date.now()).toISOString(),
                client: this.schedulingData.details.tutor,
                pet: this.schedulingData.details.pet,
                serviceProvided: {
                    serviceMdmId: this.service?.id || 0,
                    priceCharged: (this.service?.data).serviceData?.priceRegular || 0,
                    name: (this.service?.data.registrationData).name || '',
                },
                employee: {
                    employeeMdmId: this.employerSelected.id || 0,
                    name: nameEmployer
                },
                history: [],
                isExternalAuthorization: false,
                notes: ''
            }
        };
        const req = {
            action: 'ServiceOrderAdd',
            inDeveloped: true,
            version: '1',
            params: data
        };
        const response = await petshopExec(req);
        if (!response.ok) {
            this.labelError = response.error;
            return;
        }
        this.orderData = response.data;
        const ok = await this.updateScheduling(response.data.id);
        if (ok) {
            this.loadingConfirm = false;
        }
    }
    async updateScheduling(id) {
        if (!this.schedulingData || !this.schedulingData.id) {
            this.labelError = 'Nenhum agendamento selecionado!';
            return false;
        }
        if (!id) {
            this.labelError = 'Nenhum ordem de serviço encontrada!';
            return false;
        }
        this.schedulingData.details.status = SchedulingStatus.CONFIRMED;
        this.schedulingData.details.serviceOrderId = id;
        const req = {
            action: 'SchedulingUpd',
            inDeveloped: true,
            version: '1',
            params: this.schedulingData
        };
        const response = await petshopExec(req);
        if (!response.ok) {
            this.labelError = response.error;
            return false;
        }
        return true;
    }
};
__decorate([
    state()
], organismEditScheduling.prototype, "loadingCancel", void 0);
__decorate([
    state()
], organismEditScheduling.prototype, "loadingConfirm", void 0);
__decorate([
    state()
], organismEditScheduling.prototype, "schedulingData", void 0);
__decorate([
    state()
], organismEditScheduling.prototype, "employees", void 0);
__decorate([
    state()
], organismEditScheduling.prototype, "employerSelected", void 0);
__decorate([
    state()
], organismEditScheduling.prototype, "service", void 0);
__decorate([
    state()
], organismEditScheduling.prototype, "orderData", void 0);
__decorate([
    propertyDataSource()
], organismEditScheduling.prototype, "labelError", void 0);
__decorate([
    propertyDataSource()
], organismEditScheduling.prototype, "labelOk", void 0);
__decorate([
    propertyDataSource()
], organismEditScheduling.prototype, "action", void 0);
organismEditScheduling = __decorate([
    customElement('petshop--organism-edit-scheduling-102009')
], organismEditScheduling);
export { organismEditScheduling };
