/// <mls shortName="organismAdminNav" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let OrganismAdminNav = class OrganismAdminNav extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-nav-102009{display:block}petshop--organism-admin-nav-102009 .admin-sidebar{height:100vh;width:220px;background:var(--bg-secondary-color-lighter);border-right:1px solid var(--grey-color);display:flex;flex-direction:column;align-items:center;justify-content:space-between;padding:var(--space-32) var(--space-16);font-family:var(--font-family-primary)}petshop--organism-admin-nav-102009 .sidebar__profile{display:flex;flex-direction:column;align-items:center;gap:var(--space-8);text-align:center;padding-bottom:var(--space-24);border-bottom:1px solid var(--grey-color);width:100%}petshop--organism-admin-nav-102009 .sidebar__profile .sidebar__avatar{width:72px;height:72px;border-radius:50%;object-fit:cover;border:2px solid var(--grey-color)}petshop--organism-admin-nav-102009 .sidebar__profile .sidebar__username{color:var(--text-primary-color-darker);font-size:var(--font-size-16);font-weight:var(--font-weight-bold)}petshop--organism-admin-nav-102009 .sidebar__menu{flex:1;display:flex;flex-direction:column;width:100%;list-style:none;margin:var(--space-24) 0;padding:0;gap:var(--space-8)}petshop--organism-admin-nav-102009 .sidebar__menu .sidebar__link{display:block;padding:var(--space-8) var(--space-16);color:var(--text-primary-color);text-decoration:none;font-size:var(--font-size-16);border-radius:4px;transition:background var(--transition-normal)}petshop--organism-admin-nav-102009 .sidebar__menu .sidebar__link:hover,petshop--organism-admin-nav-102009 .sidebar__menu .sidebar__link:focus{background:var(--bg-primary-color-hover);color:var(--text-secondary-color-darker)}petshop--organism-admin-nav-102009 .sidebar__menu .sidebar__link--active{background:var(--bg-primary-color-focus);color:var(--text-secondary-color-darker);font-weight:var(--font-weight-bold)}petshop--organism-admin-nav-102009 .sidebar__footer{border-top:1px solid var(--grey-color);width:100%;padding-top:var(--space-16);text-align:center}petshop--organism-admin-nav-102009 .sidebar__footer .sidebar__logout{color:var(--error-color);text-decoration:none;font-weight:var(--font-weight-bold);transition:color var(--transition-normal)}petshop--organism-admin-nav-102009 .sidebar__footer .sidebar__logout:hover{color:var(--error-color-hover)}@media (max-width:768px){petshop--organism-admin-nav-102009 .admin-sidebar{position:relative;width:100%;height:auto;flex-direction:row;justify-content:space-around;padding:var(--space-16)}petshop--organism-admin-nav-102009 .sidebar__menu{flex-direction:row;justify-content:center}petshop--organism-admin-nav-102009 .sidebar__footer{display:none}}`);
    }
    render() {
        return html `
      <nav class="admin-sidebar" id="petshop--admin-nav-102009">
        <div class="sidebar__profile">
          <img
            src="https://images.unsplash.com/photo-1628157588553-5eeea00af15c?auto=format&fit=crop&w=200&q=80"
            alt="Foto de perfil"
            class="sidebar__avatar"
          />
          <span class="sidebar__username">Olá, Guilherme</span>
        </div>

        <ul class="sidebar__menu">
          <li><a href="/pageAdminDashboard" class="sidebar__link sidebar__link--active">Dashboard</a></li>
          <li><a href="/pageAdminScheduling" class="sidebar__link">Agendamentos</a></li>
          <li><a href="/pageAdminProduct" class="sidebar__link">Produtos</a></li>
          <li><a href="/pageAdminService" class="sidebar__link">Serviços</a></li>
        </ul>

        <div class="sidebar__footer">
          <a href="/pageLogin" class="sidebar__logout">Sair</a>
        </div>
      </nav>
    `;
    }
};
OrganismAdminNav = __decorate([
    customElement('petshop--organism-admin-nav-102009')
], OrganismAdminNav);
export { OrganismAdminNav };
