/// <mls shortName="organismAdminNav" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAdminNav = class organismAdminNav extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-nav-102009 .admin-nav{display:flex;align-items:center;justify-content:space-between;background:var(--bg-primary-color-lighter);padding:var(--space-16) var(--space-32);border-bottom:1px solid var(--grey-color);font-family:var(--font-family-primary)}petshop--organism-admin-nav-102009 .admin-nav .admin-nav__logo img{height:40px}petshop--organism-admin-nav-102009 .admin-nav .admin-nav__menu{display:flex;gap:var(--space-24);list-style:none;margin:0;padding:0}petshop--organism-admin-nav-102009 .admin-nav .admin-nav__menu .admin-nav__link{color:var(--text-primary-color);font-size:var(--font-size-16);text-decoration:none;padding:var(--space-8) var(--space-16);border-radius:4px;transition:background var(--transition-slow)}petshop--organism-admin-nav-102009 .admin-nav .admin-nav__menu .admin-nav__link:hover,petshop--organism-admin-nav-102009 .admin-nav .admin-nav__menu .admin-nav__link:focus{background:var(--bg-secondary-color-lighter);color:var(--text-primary-color-darker)}petshop--organism-admin-nav-102009 .admin-nav .admin-nav__menu .admin-nav__link--active{background:var(--bg-secondary-color-lighter);color:var(--text-secondary-color-darker);font-weight:var(--font-weight-bold)}petshop--organism-admin-nav-102009 .admin-nav .admin-nav__user{display:flex;align-items:center;gap:var(--space-16)}petshop--organism-admin-nav-102009 .admin-nav .admin-nav__user .admin-nav__user-name{color:var(--text-primary-color-darker);font-size:var(--font-size-16)}petshop--organism-admin-nav-102009 .admin-nav .admin-nav__user .admin-nav__logout{background:none;border:none;cursor:pointer;padding:var(--space-8);border-radius:50%;transition:background var(--transition-slow)}petshop--organism-admin-nav-102009 .admin-nav .admin-nav__user .admin-nav__logout:hover,petshop--organism-admin-nav-102009 .admin-nav .admin-nav__user .admin-nav__logout:focus{background:var(--bg-secondary-color-lighter)}petshop--organism-admin-nav-102009 .admin-nav .admin-nav__user .admin-nav__logout img{width:24px;height:24px}@media (max-width:768px){petshop--organism-admin-nav-102009 .admin-nav{flex-direction:column;align-items:flex-start;gap:var(--space-16)}}`);
    }
    render() {
        return html `<nav class="admin-nav" id="petshop--admin-nav-102009-1">
        <div class="admin-nav__logo" id="petshop--admin-nav-102009-2">
          <img src="https://images.unsplash.com/photo-1579623828015-bd63cc261a09?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXRzaG9wJTIwYWRtaW4lMjBsb2dvfGVufDB8fHx8MTc1NDQxMTUyOXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Logo Petshop Admin" id="petshop--admin-nav-102009-3">
        </div>
        <ul class="admin-nav__menu" id="petshop--admin-nav-102009-4">
          <li id="petshop--admin-nav-102009-5"><a href="/pageAdminDashboard" class="admin-nav__link admin-nav__link--active" id="petshop--admin-nav-102009-6">Dashboard</a></li>
          <li id="petshop--admin-nav-102009-7"><a href="/pageAdminScheduling" class="admin-nav__link" id="petshop--admin-nav-102009-8">Agendamentos</a></li>
          <li id="petshop--admin-nav-102009-9"><a href="/pageAdminProduct" class="admin-nav__link" id="petshop--admin-nav-102009-10">Produtos</a></li>
    
            <li id="petshop--admin-nav-102009-17">
                <a  class="admin-nav__link" href="/pageAdminService" id="petshop--nav-102009-31">Serviços</a>
            </li>
            <li id="petshop--admin-nav-102009-17">
                <a  class="admin-nav__link" href="/pageLogin" id="petshop--nav-102009-30">Sair</a>
            </li>
        </ul>
        <div class="admin-nav__user" id="petshop--admin-nav-102009-13">
          <span class="admin-nav__user-name" id="petshop--admin-nav-102009-14">Olá, Guilherme</span>
          <button class="admin-nav__logout" title="Sair" aria-label="Sair" id="petshop--admin-nav-102009-15">
            <img src="https://images.unsplash.com/photo-1625670413987-0ae649494c61?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxsb2dvdXQlMjBpY29ufGVufDB8fHx8MTc1NDQxMTUzMHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Sair" id="petshop--admin-nav-102009-16">
          </button>
        </div>
      </nav>
    `;
    }
};
organismAdminNav = __decorate([
    customElement('petshop--organism-admin-nav-102009')
], organismAdminNav);
export { organismAdminNav };
