/// <mls shortName="produtos" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageProdutos = class PageProdutos extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--produtos-102009{display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color)}petshop--produtos-102009>body{flex:1 1 auto;display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color)}petshop--produtos-102009 header{width:100%;background:var(--bg-primary-color-lighter);box-shadow:0 1px 0 var(--grey-color-light);z-index:10}petshop--produtos-102009 main{display:flex;flex:1 1 auto;flex-direction:row;gap:var(--space-32);max-width:1200px;margin:var(--space-32) auto var(--space-32) auto;width:100%;padding:0 var(--space-16)}@media (max-width:768px){petshop--produtos-102009 main{flex-direction:column;gap:var(--space-16);padding:0 var(--space-8)}}petshop--produtos-102009 aside{min-width:260px;max-width:320px}@media (max-width:768px){petshop--produtos-102009 aside{min-width:0;max-width:100%;width:100%;margin-bottom:var(--space-16)}}petshop--produtos-102009 footer{width:100%;background:var(--bg-primary-color-lighter);margin-top:auto;box-shadow:0 -1px 0 var(--grey-color-light)}`);
    }
    initPage() {
    }
};
PageProdutos = __decorate([
    customElement('petshop--produtos-102009')
], PageProdutos);
export { PageProdutos };
