var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismViewMyAppointments" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { setState, getState } from '_100554_/l2/collabState';
import { petshopExec } from "./_102009_layer1Exec";
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { SchedulingStatus } from './_102009_layer4Scheduling';
let organismViewMyAppointments = class organismViewMyAppointments extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-view-my-appointments-102009{width:100%}petshop--organism-view-my-appointments-102009 .section-card{margin-bottom:var(--space-24)}petshop--organism-view-my-appointments-102009 a:hover{color:#fff !important}petshop--organism-view-my-appointments-102009 .form-container{height:100%;overflow-y:auto}petshop--organism-view-my-appointments-102009 .status{padding:4px 8px;border-radius:8px;font-size:12px;font-weight:bold;color:#fff}petshop--organism-view-my-appointments-102009 td span.det{cursor:pointer;color:var(--active-color)}petshop--organism-view-my-appointments-102009 .status--pending{background:var(--warning-color)}petshop--organism-view-my-appointments-102009 .status--approved{background:var(--success-color)}petshop--organism-view-my-appointments-102009 .status--cancelled{background:var(--error-color)}`);
        this.scenary = 'list';
        this.scheduling = [];
        this.error = '';
        this.indexDetail = -1;
        this.filterData = '';
    }
    //-------------------------------
    firstUpdated() {
        this.init();
    }
    render() {
        if (this.scenary === 'list')
            return this.renderList();
        return this.renderEdit();
    }
    renderList() {
        return html `
        <div class="form-container">
            <h2>Meus Agendamentos</h2>
            <div style="display:flex">
                <div class="form-group" style="width:70%">
                    <label for="date-filter">Filtrar por Data</label>
                    <input type="date" id="date-filter" name="date-filter" @change=${(e) => this.filterData = e.target.value}>
                </div>
                <div class="form-group" style="width:30%; display: flex; align-items: end; justify-content: end;">
                    <a href="/pageAppointments" class="btn btn-save">Novo agendamento</a>
                    
                </div>
            </div>
            <div class="section-card">
                <table>
                    <thead>
                        <tr>
                            <th>Pet</th>
                            <th>Data</th>
                            <th>Horário</th>
                            <th>Serviço</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${this.scheduling.map((sch, index) => this.renderItem(sch, index))}
                    </tbody>
                </table>
            </div>
        </div>`;
    }
    renderItem(sch, index) {
        const data = this.getDataHorario(sch.data.startDateTime);
        const stateCLS = {
            'PENDING': 'status--pending',
            'CONFIRMED': 'status--approved',
            'CANCELED': 'status--cancelled',
            'COMPLETED': 'status--approved',
        };
        const stateLabel = {
            'PENDING': 'Pendente',
            'CONFIRMED': 'Aprovado',
            'CANCELED': 'Cancelado',
            'COMPLETED': 'Completo',
        };
        let display = '';
        if (this.filterData !== '') {
            display = this.filterData === data.vl ? '' : 'none';
        }
        return html `
        <tr style="display:${display}">
            <td>${sch.data.jsonBin.pet.name}</td>
            <td>${data.date}</td>
            <td>${data.time}</td>
            <td>${sch.data.jsonBin.service.name}</td>
            <td><span class="status ${stateCLS[sch.data.status]}">${stateLabel[sch.data.status]}</span></td>
            <td><span class="det" @click=${() => { this.indexDetail = index; this.changeScneray('add'); }}>Detalhes</span></td>
        </tr>`;
    }
    renderEdit() {
        const sch = this.scheduling[this.indexDetail];
        if (!sch)
            return html `<div>
            <div class="section-card">
                <h2>Detalhes do Agendamento</h2>
                <div class="form-group">
                    Nenhum agendamento selecionado
                </div>
                <div class="form-actions">
                    <button class="btn btn-back" @click=${() => this.changeScneray('list')}>Voltar à Lista</button>
                </div>
            </div>
        </div>`;
        const data = this.getDataHorario(sch.data.startDateTime);
        const stateLabel = {
            'PENDING': 'Pendente',
            'CONFIRMED': 'Aprovado',
            'CANCELED': 'Cancelado',
            'COMPLETED': 'Completo',
        };
        return html `
        <div>
            <div class="section-card">
                <h2>Detalhes do Agendamento</h2>
                <div class="form-group">
                    <label>Data:</label>
                    <span class="field-value">${data.date}</span>
                </div>
                <div class="form-group">
                    <label>Horário:</label>
                    <span class="field-value">${data.time}</span>
                </div>
                <div class="form-group">
                    <label>Serviço:</label>
                    <span class="field-value">${sch.data.jsonBin.service.name}</span>
                </div>
                <div class="form-group">
                    <label>Pet:</label>
                    <span class="field-value">${sch.data.jsonBin.pet.name}</span>
                </div>
                <div class="form-group">
                    <label>Status:</label>
                    <span class="field-value">${stateLabel[sch.data.status]}</span>
                </div>
                <div class="form-actions">
                    <button class="btn btn-delete" @click=${() => this.handleClickCancel()} >Cancelar Agendamento</button>
                    <button class="btn btn-back" @click=${() => this.changeScneray('list')}>Voltar à Lista</button>
                </div>
                ${this.error ? html `<div style="text-align:center">${this.error}</div>` : ''}
            </div>
        </div>`;
    }
    //---------------------------
    async init() {
        this.mdmData = getState('ui.petshop.login');
        this.scheduling = getState('ui.petshop.client.scheduling') || [];
        this.loadInfos();
    }
    async loadInfos() {
        await this.getScheduling();
    }
    async getScheduling() {
        if (!this.mdmData) {
            this.error = 'Falta parametros para pegar os pets';
            return;
        }
        const req = {
            action: 'SchedulingGetByClient',
            inDeveloped: true,
            version: '1',
            params: { clientId: this.mdmData.id || 0 }
        };
        const response = await petshopExec(req);
        if (!response.ok) {
            this.error = response.error;
            return;
        }
        this.scheduling = response.data.filter((item) => item != null);
        setState('ui.petshop.client.scheduling', this.scheduling);
    }
    changeScneray(scenary) {
        this.error = '';
        this.scenary = scenary;
    }
    getDataHorario(data) {
        const dateObj = new Date(data);
        const year = dateObj.getUTCFullYear();
        const month = String(dateObj.getUTCMonth() + 1).padStart(2, "0");
        const day = String(dateObj.getUTCDate()).padStart(2, "0");
        const hours = String(dateObj.getUTCHours()).padStart(2, "0");
        const minutes = String(dateObj.getUTCMinutes()).padStart(2, "0");
        const date = `${day}/${month}/${year}`;
        const time = `${hours}:${minutes}`;
        const vl = `${year}-${month}-${day}`;
        return { date, time, vl };
    }
    async handleClickCancel() {
        const sch = this.scheduling[this.indexDetail];
        if (!sch) {
            this.error = 'Nenhum agendamento selecionado!';
            return;
        }
        if (sch.data.status === SchedulingStatus.CANCELED) {
            this.error = 'Não pode alterar o status de um agendamento cancelado!';
            return;
        }
        sch.data.status = SchedulingStatus.CANCELED;
        const req = {
            action: 'SchedulingUpd',
            inDeveloped: true,
            version: '1',
            params: sch
        };
        const response = await petshopExec(req);
        if (!response.ok) {
            this.error = response.error;
            return;
        }
        this.changeScneray('list');
    }
};
__decorate([
    state()
], organismViewMyAppointments.prototype, "scenary", void 0);
__decorate([
    state()
], organismViewMyAppointments.prototype, "mdmData", void 0);
__decorate([
    state()
], organismViewMyAppointments.prototype, "scheduling", void 0);
__decorate([
    state()
], organismViewMyAppointments.prototype, "error", void 0);
__decorate([
    state()
], organismViewMyAppointments.prototype, "indexDetail", void 0);
__decorate([
    state()
], organismViewMyAppointments.prototype, "filterData", void 0);
organismViewMyAppointments = __decorate([
    customElement('petshop--organism-view-my-appointments-102009')
], organismViewMyAppointments);
export { organismViewMyAppointments };
