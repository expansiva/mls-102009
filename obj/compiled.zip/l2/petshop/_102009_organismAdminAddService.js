/// <mls shortName="organismAdminAddService" project="102009" enhancement="_100554_enhancementLit" folder="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { subscribe, unsubscribe } from '_100554_/l2/collabState';
import { propertyDataSource } from './_100554_collabDecorators';
import { exec } from "./_102019_layer1Exec";
import { MdmType } from "./_102019_layer4Mdm";
let organismAddService = class organismAddService extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        this.loading = false;
    }
    connectedCallback() {
        super.connectedCallback();
        subscribe([
            'ui.petshop.admin.organismAdminAddService.action',
        ], this);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe([
            'ui.petshop.admin.organismAdminAddService.action',
        ], this);
    }
    handleIcaStateChange(_key, _value) {
        if (_key === 'ui.petshop.admin.organismAdminAddService.action' && _value === 'save')
            this.handleClickSave();
    }
    render() {
        return html `<div class="form-container" id="petshop--organism-add-service-102009-1">
            <h2 id="petshop--organism-add-service-102009-2">Adicionar Novo Serviço</h2>
            <div class="form-group" id="petshop--organism-add-service-102009-3">
                <label for="nome-servico" id="petshop--organism-add-service-102009-4">Nome do Serviço</label>
                <input 
                    type="text" 
                    id="nome-servico" 
                    placeholder="Digite o nome do serviço" 
                    id="petshop--organism-add-service-102009-5"
                    required
                    ?disabled=${this.loading}
                    @input=${(e) => { this.nameService = e.target.value; }}
                >
            </div>
            <div class="form-group" id="petshop--organism-add-service-102009-6">
                <label for="descricao-servico" id="petshop--organism-add-service-102009-7">Descrição</label>
                <textarea 
                    id="descricao-servico" 
                    placeholder="Digite a descrição do serviço" 
                    id="petshop--organism-add-service-102009-8"
                    required
                    ?disabled=${this.loading}
                    @input=${(e) => { this.descriptionShort = e.target.value; }}
                ></textarea>
            </div>
            <div class="form-group" id="petshop--organism-add-service-102009-9">
                <label for="codigo-servico" id="petshop--organism-add-service-102009-10">Código do Serviço</label>
                <input 
                    type="text" 
                    id="codigo-servico" 
                    placeholder="Digite o código único do serviço" 
                    id="petshop--organism-add-service-102009-11"
                    ?disabled=${this.loading}
                    @input=${(e) => { this.serviceCode = e.target.value; }}
                >
            </div>

            <div class="form-actions" id="petshop--organism-add-service-102009-12">
                <button class="btn btn-back" id="petshop--organism-add-service-102009-13" @click=${this.handleClickBack} ?disabled=${this.loading}>Voltar</button>
                <button class="btn btn-save" id="petshop--organism-add-service-102009-14" @click=${this.handleClickSave} ?disabled=${this.loading}>
                    Salvar
                    ${this.loading ? html `<span class="loading"></span>` : html ``}
                </button>
                <a id="link-back" style="display:none" href="/pageAdminService"></a>

            </div>
            ${this.labelError ? html `<span class="error-message">${this.labelError}</span>` : ''}

</div>`;
    }
    handleClickBack(e) {
        e.preventDefault();
        if (this.link) {
            this.link.click();
        }
    }
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    clearErrors() {
        this.labelError = '';
    }
    async handleClickSave() {
        this.clearErrors();
        let hasErrors = false;
        if (!this.nameService) {
            this.labelError = 'Nome do serviço é obrigatório.';
            hasErrors = true;
        }
        else if (!this.descriptionShort) {
            this.labelError = 'Descrição do serviço é obrigatório.';
            hasErrors = true;
        }
        if (!hasErrors) {
            this.loading = true;
            await this.delay(1000);
            const params = {
                data: {
                    registrationData: {
                        name: this.nameService,
                        descriptionShort: this.descriptionShort,
                        serviceCode: this.serviceCode
                    },
                    type: MdmType.Servico,
                    status: 'A'
                }
            };
            const req = {
                action: 'MDMAdd',
                inDeveloped: true,
                version: '1',
                params,
            };
            const response = await exec(req);
            if (!response.ok) {
                this.labelError = response.error;
                this.loading = false;
                return;
            }
            this.loading = false;
            this.labelOk = 'Cadastro realizado com sucesso';
            if (this.link) {
                this.link.click();
            }
        }
    }
};
__decorate([
    state()
], organismAddService.prototype, "loading", void 0);
__decorate([
    propertyDataSource()
], organismAddService.prototype, "nameService", void 0);
__decorate([
    propertyDataSource()
], organismAddService.prototype, "descriptionShort", void 0);
__decorate([
    propertyDataSource()
], organismAddService.prototype, "serviceCode", void 0);
__decorate([
    propertyDataSource()
], organismAddService.prototype, "labelError", void 0);
__decorate([
    propertyDataSource()
], organismAddService.prototype, "labelOk", void 0);
__decorate([
    propertyDataSource()
], organismAddService.prototype, "action", void 0);
__decorate([
    query('#link-back')
], organismAddService.prototype, "link", void 0);
organismAddService = __decorate([
    customElement('petshop--organism-admin-add-service-102009')
], organismAddService);
export { organismAddService };
