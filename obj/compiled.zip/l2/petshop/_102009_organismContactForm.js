/// <mls shortName="organismContactForm" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismContactForm = class organismContactForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-contact-form-102009{background:var(--bg-primary-color);border-radius:var(--space-16);box-shadow:0 2px 12px 0 rgba(211,211,211,0.1);padding:var(--space-48) var(--space-40);min-width:340px;max-width:420px;width:100%;display:flex;flex-direction:column;gap:var(--space-24);font-family:var(--font-family-primary)}petshop--organism-contact-form-102009 h2{color:var(--text-primary-color);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}petshop--organism-contact-form-102009 form{display:flex;flex-direction:column;gap:var(--space-16)}petshop--organism-contact-form-102009 label{color:var(--text-primary-color-darker);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);margin-bottom:var(--space-8)}petshop--organism-contact-form-102009 input,petshop--organism-contact-form-102009 textarea{border:1px solid var(--grey-color);border-radius:var(--space-8);padding:var(--space-16);font-size:var(--font-size-16);font-family:var(--font-family-primary);background:var(--bg-primary-color-lighter);color:var(--text-primary-color-darker);transition:border-color var(--transition-normal)}petshop--organism-contact-form-102009 input:focus,petshop--organism-contact-form-102009 textarea:focus{border-color:var(--text-primary-color);outline:none}petshop--organism-contact-form-102009 textarea{min-height:120px;resize:vertical}petshop--organism-contact-form-102009 button[type="submit"]{background:var(--text-secondary-color);color:var(--bg-primary-color);border:none;border-radius:var(--space-8);padding:var(--space-16);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-normal);margin-top:var(--space-16)}petshop--organism-contact-form-102009 button[type="submit"]:hover{background:var(--text-secondary-color-hover)}petshop--organism-contact-form-102009 button[type="submit"]:active{background:var(--text-secondary-color-focus)}petshop--organism-contact-form-102009 button[type="submit"]:disabled{background:var(--text-secondary-color-disabled);cursor:not-allowed}`);
    }
    render() {
        return html `<h2 id="petshop--contact-form-102009-1">Fale Conosco</h2>
        <form autocomplete="off" id="petshop--contact-form-102009-2">
          <div id="petshop--contact-form-102009-3">
            <label for="contact-nome" id="petshop--contact-form-102009-4">Nome</label>
            <input type="text" id="contact-nome" name="nome" placeholder="Seu nome" required="">
          </div>
          <div id="petshop--contact-form-102009-5">
            <label for="contact-email" id="petshop--contact-form-102009-6">E-mail</label>
            <input type="email" id="contact-email" name="email" placeholder="seu@email.com" required="">
          </div>
          <div id="petshop--contact-form-102009-7">
            <label for="contact-mensagem" id="petshop--contact-form-102009-8">Mensagem</label>
            <textarea id="contact-mensagem" name="mensagem" placeholder="Como podemos ajudar?" required=""></textarea>
          </div>
          <button type="submit" id="petshop--contact-form-102009-9">Enviar mensagem</button>
        </form>
      `;
    }
};
organismContactForm = __decorate([
    customElement('petshop--organism-contact-form-102009')
], organismContactForm);
export { organismContactForm };
