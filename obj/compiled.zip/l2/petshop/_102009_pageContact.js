/// <mls shortName="pageContact" project="102009" enhancement="_100554_enhancementLit" folder="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageContact = class PageContact extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--page-contact-102009{display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color)}petshop--page-contact-102009 header{flex:0 0 auto}petshop--page-contact-102009 main{flex:1 0 auto;display:flex;flex-direction:row;justify-content:center;align-items:flex-start;gap:var(--space-64);padding:var(--space-48) 0;background:var(--bg-secondary-color-lighter)}@media (max-width:768px){petshop--page-contact-102009 main{flex-direction:column;align-items:stretch;gap:var(--space-32);padding:var(--space-24) 0}}petshop--page-contact-102009 footer{flex:0 0 auto}`);
    }
    initPage() {
    }
};
PageContact = __decorate([
    customElement('petshop--page-contact-102009')
], PageContact);
export { PageContact };
