/// <mls shortName="organismNav" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { getState } from '_100554_/l2/collabState';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { AttachmentType } from "./_102019_layer4Mdm";
let organismNav = class organismNav extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-nav-102009{background:var(--bg-primary-color);border-bottom:1px solid var(--grey-color);font-family:var(--font-family-primary)}petshop--organism-nav-102009 .nav-container{display:flex;align-items:center;justify-content:space-between;max-width:1200px;margin:0 auto;padding:var(--space-16) var(--space-24)}petshop--organism-nav-102009 .logo{display:flex;align-items:center}petshop--organism-nav-102009 .logo img{height:48px;width:48px;margin-right:var(--space-16)}petshop--organism-nav-102009 .logo .brand{font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color);letter-spacing:1px}petshop--organism-nav-102009 nav{flex:1;display:flex;justify-content:center}petshop--organism-nav-102009 nav ul{display:flex;gap:var(--space-32);list-style:none;margin:0;padding:0}petshop--organism-nav-102009 nav ul li a{color:var(--text-primary-color-darker);font-size:var(--font-size-16);text-decoration:none;font-weight:var(--font-weight-normal);transition:color var(--transition-normal)}petshop--organism-nav-102009 nav ul li a:hover,petshop--organism-nav-102009 nav ul li a:focus{color:var(--text-secondary-color)}petshop--organism-nav-102009 .social{display:flex;align-items:center;gap:var(--space-16)}petshop--organism-nav-102009 .social span{white-space:nowrap}petshop--organism-nav-102009 .social .social-perfil{background:rgba(240,236,227,0.376);border:none;cursor:pointer;padding:var(--space-8);border-radius:50%;transition:background var(--transition-slow);display:flex}petshop--organism-nav-102009 .social .social-perfil:hover,petshop--organism-nav-102009 .social .social-perfil:focus{background:var(--bg-secondary-color-lighter)}petshop--organism-nav-102009 .social .social-perfil img{width:30px;height:30px;border-radius:50%}`);
        this.name = '';
        this.nameCompany = '';
        this.imgCompany = '';
    }
    //--------------------------------------
    firstUpdated() {
        this.init();
    }
    render() {
        return html `<div class="nav-container" id="petshop--nav-102009-1">
          <a href="/" class="logo" aria-label="Página inicial" id="petshop--nav-102009-2">
            <img src="${this.imgCompany}" alt="Logo Petshop" id="petshop--nav-102009-3">
            <span class="brand" id="petshop--nav-102009-4">${this.nameCompany}</span>
          </a>
          <nav aria-label="Menu principal" id="petshop--nav-102009-5">
            <ul id="petshop--nav-102009-6">
              <li id="petshop--nav-102009-7">
                <a href="/pageHome" id="petshop--nav-102009-8">Home</a>
              </li>
              <li id="petshop--nav-102009-9">
                <a href="/pageAppointments" id="petshop--nav-102009-10">Agendamento</a>
              </li>
              <li id="petshop--nav-102009-11">
                <a href="/pageProduct" id="petshop--nav-102009-12">Produtos</a>
              </li>
              <li id="petshop--nav-102009-13">
                <a href="/pageContact" id="petshop--nav-102009-14">Contato</a>
              </li>
              <li id="petshop--nav-102009-13">
                <a href="/pageLogin" id="petshop--nav-102009-30">Sair</a>
              </li>
            </ul> 
            
          </nav>
          <div class="social">
            <span>Olá, ${this.name}</span>
            <a href="/pagePerfil" class="social-perfil">
                <img src="${this.img}" alt="Sair" id="petshop--admin-nav-102009-16">
              </a>
            </div>
        </div>
      `;
    }
    //----------------
    init() {
        this.mdmData = getState('ui.petshop.login');
        this.mdmCompany = getState('ui.petshop.enterprise');
        if (this.mdmData) {
            this.name = this.mdmData.data.registrationData.name;
            if (this.mdmData.data.attachments && this.mdmData.data.attachments.length > 0) {
                this.mdmData.data.attachments.forEach((i) => {
                    if (i.type === AttachmentType.MEDIA_PROFILE_PIC) {
                        this.img = i.url;
                    }
                });
            }
            if (this.img === '')
                this.img = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHx1c2VyJTIwcHJvZmlsZSUyMHBob3RvfGVufDB8fHx8MTc1NDQxMTUzMXww&ixlib=rb-4.1.0&q=80&w=200';
        }
        if (this.mdmCompany) {
            this.nameCompany = this.mdmCompany.data.registrationData.corporateName;
            if (this.mdmCompany.data.attachments && this.mdmCompany.data.attachments.length > 0) {
                this.mdmCompany.data.attachments.forEach((i) => {
                    if (i.type === AttachmentType.MEDIA_PROFILE_PIC) {
                        this.imgCompany = i.url;
                    }
                });
            }
            if (this.imgCompany === '')
                this.imgCompany = 'https://images.unsplash.com/photo-1701500096456-28186c4a306d?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXRzaG9wJTIwbG9nbyUyMGFuaW1hbCUyMHBhdyUyMGJsdWUlMjBncmVlbnxlbnwwfHx8fDE3NTQ0MTEzMTR8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080';
        }
    }
};
__decorate([
    state()
], organismNav.prototype, "mdmData", void 0);
__decorate([
    state()
], organismNav.prototype, "mdmCompany", void 0);
__decorate([
    state()
], organismNav.prototype, "name", void 0);
__decorate([
    state()
], organismNav.prototype, "img", void 0);
__decorate([
    state()
], organismNav.prototype, "nameCompany", void 0);
__decorate([
    state()
], organismNav.prototype, "imgCompany", void 0);
organismNav = __decorate([
    customElement('petshop--organism-nav-102009')
], organismNav);
export { organismNav };
