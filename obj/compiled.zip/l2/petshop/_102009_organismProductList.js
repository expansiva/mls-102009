/// <mls shortName="organismProductList" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { exec } from "./_102019_layer1Exec";
import { setState, getState, subscribe, unsubscribe } from '_100554_/l2/collabState';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { MdmType, AttachmentType } from "./_102019_layer4Mdm";
let organismProductList = class organismProductList extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-product-list-102009{flex:2 1 0;display:flex;flex-direction:column;gap:var(--space-32);font-family:var(--font-family-primary)}petshop--organism-product-list-102009 h1{font-size:var(--font-size-24);color:var(--text-primary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}petshop--organism-product-list-102009 .product-grid{display:grid;grid-template-columns:repeat(3, 1fr);gap:var(--space-24)}@media (max-width:1012px){petshop--organism-product-list-102009 .product-grid{grid-template-columns:repeat(2, 1fr)}}@media (max-width:768px){petshop--organism-product-list-102009 .product-grid{grid-template-columns:1fr}}petshop--organism-product-list-102009 .product-card{background:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 8px rgba(230,230,230,0.1);padding:var(--space-16);display:flex;flex-direction:column;align-items:center;transition:box-shadow var(--transition-normal)}petshop--organism-product-list-102009 .product-card:hover{box-shadow:0 4px 16px rgba(64,63,63,0.1)}petshop--organism-product-list-102009 .product-card img{width:120px;height:120px;object-fit:cover;border-radius:8px;margin-bottom:var(--space-16);background:var(--bg-secondary-color-lighter)}petshop--organism-product-list-102009 .product-card .product-name{font-size:var(--font-size-16);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);margin-bottom:var(--space-8);text-align:center}petshop--organism-product-list-102009 .product-card .product-type{font-size:var(--font-size-12);color:var(--text-secondary-color-darker);margin-bottom:var(--space-8);text-align:center}petshop--organism-product-list-102009 .product-card .product-price{font-size:var(--font-size-20);color:var(--text-secondary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}petshop--organism-product-list-102009 .product-card .product-actions{display:flex;gap:var(--space-8);width:100%;justify-content:center}petshop--organism-product-list-102009 .product-card .product-actions button{padding:var(--space-8) var(--space-16);border-radius:4px;border:none;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;background:var(--text-primary-color);color:var(--bg-primary-color);transition:background var(--transition-normal)}petshop--organism-product-list-102009 .product-card .product-actions button:hover{background:var(--text-primary-color-hover)}`);
        this.mdmProducts = [];
        this.carProducts = [];
    }
    //--------------------------------------
    connectedCallback() {
        super.connectedCallback();
        subscribe([
            'ui.petshop.client.pageProduct.action',
        ], this);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe([
            'ui.petshop.client.pageProduct.action',
        ], this);
    }
    handleIcaStateChange(_key, _value) {
        if (_key === 'ui.petshop.client.pageProduct.action' && _value === 'del') {
            this.carProducts = getState('ui.petshop.client.pageProduct.productCar');
            setState('ui.petshop.client.pageProduct.action', '');
        }
    }
    async firstUpdated() {
        this.loadProd();
    }
    render() {
        return html `
      <h1 id="petshop--product-list-102009-1">Catálogo de Produtos</h1>
      <div class="product-grid" id="petshop--product-list-102009-2">
        ${this.mdmProducts.map((prod, index) => this.renderItem(prod, index))}
      </div>
    `;
    }
    renderItem(prod, index) {
        const reg = prod.data.registrationData;
        let img = 'https://images.unsplash.com/photo-1583860332956-0cd934c28cec?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBiZWQlMjBjb21mb3J0YWJsZSUyMGJsdWUlMjBncmVlbnxlbnwwfHx8fDE3NTQ0MTEzMTZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080';
        if (prod.data.attachments && prod.data.attachments.length > 0) {
            prod.data.attachments.forEach((i) => {
                if (i.type === AttachmentType.MEDIA_PROFILE_PIC)
                    img = i.url;
            });
        }
        return html `
    <div class="product-card">
      <img src="${img}" alt="Bebedouro Automático">
      <div class="product-name">${reg.name}</div>
      <div class="product-type">${reg.descriptionShort}</div>
      <div class="product-price">R$ 50,00</div>
      <div class="product-actions">
        <button @click=${() => this.handleClickAdd(index)}>Adicionar ao Carrinho</button>
      </div>
    </div>
    `;
    }
    ;
    //--------------------------------------
    async loadProd() {
        const req = {
            action: 'MDMGetListByType',
            inDeveloped: true,
            version: '1',
            params: { type: MdmType.Produto },
        };
        const response = await exec(req);
        if (response.ok) {
            this.mdmProducts = response.data.map((item) => {
                const item2 = item;
                return item2;
            });
        }
    }
    handleClickAdd(idx) {
        if (!this.mdmProducts || !this.mdmProducts[idx])
            return;
        this.carProducts.push(this.mdmProducts[idx]);
        setState('ui.petshop.client.pageProduct.productCar', this.carProducts);
        setState('ui.petshop.client.pageProduct.action', 'add');
    }
};
__decorate([
    state()
], organismProductList.prototype, "mdmProducts", void 0);
__decorate([
    state()
], organismProductList.prototype, "carProducts", void 0);
organismProductList = __decorate([
    customElement('petshop--organism-product-list-102009')
], organismProductList);
export { organismProductList };
