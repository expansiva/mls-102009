/// <mls shortName="organismProductList" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismProductList = class organismProductList extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-product-list-102009{flex:2 1 0;display:flex;flex-direction:column;gap:var(--space-32);font-family:var(--font-family-primary)}petshop--organism-product-list-102009 h1{font-size:var(--font-size-24);color:var(--text-primary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}petshop--organism-product-list-102009 .product-grid{display:grid;grid-template-columns:repeat(3, 1fr);gap:var(--space-24)}@media (max-width:1012px){petshop--organism-product-list-102009 .product-grid{grid-template-columns:repeat(2, 1fr)}}@media (max-width:768px){petshop--organism-product-list-102009 .product-grid{grid-template-columns:1fr}}petshop--organism-product-list-102009 .product-card{background:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 8px rgba(230,230,230,0.1);padding:var(--space-16);display:flex;flex-direction:column;align-items:center;transition:box-shadow var(--transition-normal)}petshop--organism-product-list-102009 .product-card:hover{box-shadow:0 4px 16px rgba(64,63,63,0.1)}petshop--organism-product-list-102009 .product-card img{width:120px;height:120px;object-fit:cover;border-radius:8px;margin-bottom:var(--space-16);background:var(--bg-secondary-color-lighter)}petshop--organism-product-list-102009 .product-card .product-name{font-size:var(--font-size-16);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);margin-bottom:var(--space-8);text-align:center}petshop--organism-product-list-102009 .product-card .product-type{font-size:var(--font-size-12);color:var(--text-secondary-color-darker);margin-bottom:var(--space-8);text-align:center}petshop--organism-product-list-102009 .product-card .product-price{font-size:var(--font-size-20);color:var(--text-secondary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}petshop--organism-product-list-102009 .product-card .product-actions{display:flex;gap:var(--space-8);width:100%;justify-content:center}petshop--organism-product-list-102009 .product-card .product-actions button{padding:var(--space-8) var(--space-16);border-radius:4px;border:none;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;background:var(--text-primary-color);color:var(--bg-primary-color);transition:background var(--transition-normal)}petshop--organism-product-list-102009 .product-card .product-actions button:hover{background:var(--text-primary-color-hover)}`);
    }
    render() {
        return html `<h1 id="petshop--product-list-102009-1">Catálogo de Produtos</h1>
        <div class="product-grid" id="petshop--product-list-102009-2">
          <div class="product-card" id="petshop--product-list-102009-3">
            <img src="https://images.unsplash.com/photo-1616205255812-c07c8102cc02?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBmb29kJTIwYmFnJTIwcHJlbWl1bXxlbnwwfHx8fDE3NTQzNDE5OTV8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Ração Premium para Cães" id="petshop--product-list-102009-4">
            <div class="product-name" id="petshop--product-list-102009-5">Ração Premium para Cães</div>
            <div class="product-type" id="petshop--product-list-102009-6">Alimento • Cão</div>
            <div class="product-price" id="petshop--product-list-102009-7">R$ 89,90</div>
            <div class="product-actions" id="petshop--product-list-102009-8">
              <button id="petshop--product-list-102009-9">Adicionar ao Carrinho</button>
            </div>
          </div>
          <div class="product-card" id="petshop--product-list-102009-10">
            <img src="https://images.unsplash.com/photo-1665582894071-eb5b7c4d4656?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxjYXQlMjBpbnRlcmFjdGl2ZSUyMHRveSUyMGNvbG9yZnVsfGVufDB8fHx8MTc1NDQxMTQxNHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Brinquedo Interativo para Gatos" id="petshop--product-list-102009-11">
            <div class="product-name" id="petshop--product-list-102009-12">Brinquedo Interativo para Gatos</div>
            <div class="product-type" id="petshop--product-list-102009-13">Brinquedo • Gato</div>
            <div class="product-price" id="petshop--product-list-102009-14">R$ 29,90</div>
            <div class="product-actions" id="petshop--product-list-102009-15">
              <button id="petshop--product-list-102009-16">Adicionar ao Carrinho</button>
            </div>
          </div>
          <div class="product-card" id="petshop--product-list-102009-17">
            <img src="https://images.unsplash.com/photo-1608571899793-a1c0c27a7555?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBzaGFtcG9vJTIwYm90dGxlfGVufDB8fHx8MTc1NDQwNjUzMXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Shampoo Suave para Pets" id="petshop--product-list-102009-18">
            <div class="product-name" id="petshop--product-list-102009-19">Shampoo Suave para Pets</div>
            <div class="product-type" id="petshop--product-list-102009-20">Higiene • Todos</div>
            <div class="product-price" id="petshop--product-list-102009-21">R$ 19,90</div>
            <div class="product-actions" id="petshop--product-list-102009-22">
              <button id="petshop--product-list-102009-23">Adicionar ao Carrinho</button>
            </div>
          </div>
          <div class="product-card" id="petshop--product-list-102009-24">
            <img src="https://images.unsplash.com/photo-1655450075012-c0393e3cc1ce?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBiZWQlMjBjb3p5JTIwbW9kZXJufGVufDB8fHx8MTc1NDQxMTQxNXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Caminha Aconchegante" id="petshop--product-list-102009-25">
            <div class="product-name" id="petshop--product-list-102009-26">Caminha Aconchegante</div>
            <div class="product-type" id="petshop--product-list-102009-27">Acessório • Cão/Gato</div>
            <div class="product-price" id="petshop--product-list-102009-28">R$ 119,90</div>
            <div class="product-actions" id="petshop--product-list-102009-29">
              <button id="petshop--product-list-102009-30">Adicionar ao Carrinho</button>
            </div>
          </div>
          <div class="product-card" id="petshop--product-list-102009-31">
            <img src="https://images.unsplash.com/photo-1614242040107-f3b76c4475f0?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxiaXJkJTIwZm9vZCUyMHNlZWRzJTIwbWl4fGVufDB8fHx8MTc1NDQxMTQxNXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Sementes Selecionadas para Aves" id="petshop--product-list-102009-32">
            <div class="product-name" id="petshop--product-list-102009-33">Sementes Selecionadas para Aves</div>
            <div class="product-type" id="petshop--product-list-102009-34">Alimento • Ave</div>
            <div class="product-price" id="petshop--product-list-102009-35">R$ 14,90</div>
            <div class="product-actions" id="petshop--product-list-102009-36">
              <button id="petshop--product-list-102009-37">Adicionar ao Carrinho</button>
            </div>
          </div>
          <div class="product-card" id="petshop--product-list-102009-38">
            <img src="https://images.unsplash.com/photo-1544198841-10f34f31f8dd?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxhdXRvbWF0aWMlMjBwZXQlMjB3YXRlciUyMGRpc3BlbnNlcnxlbnwwfHx8fDE3NTQ0MTE0MTZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Bebedouro Automático" id="petshop--product-list-102009-39">
            <div class="product-name" id="petshop--product-list-102009-40">Bebedouro Automático</div>
            <div class="product-type" id="petshop--product-list-102009-41">Acessório • Todos</div>
            <div class="product-price" id="petshop--product-list-102009-42">R$ 49,90</div>
            <div class="product-actions" id="petshop--product-list-102009-43">
              <button id="petshop--product-list-102009-44">Adicionar ao Carrinho</button>
            </div>
          </div>
        </div>
      `;
    }
};
organismProductList = __decorate([
    customElement('petshop--organism-product-list-102009')
], organismProductList);
export { organismProductList };
