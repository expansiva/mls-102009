var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismAdminBookings" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state, property, query } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { propertyDataSource } from './_100554_collabDecorators';
import { setState } from '_100554_/l2/collabState';
import { petshopExec } from "./_102009_layer1Exec";
let OrganismAdminBookings = class OrganismAdminBookings extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-bookings-102009 .admin-bookings{background:var(--bg-primary-color, #fff);padding:32px;font-family:var(--font-family-primary, sans-serif)}petshop--organism-admin-bookings-102009 .admin-bookings__title{font-size:20px;margin-bottom:24px;font-weight:bold}petshop--organism-admin-bookings-102009 .admin-bookings__filters{display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap}petshop--organism-admin-bookings-102009 .admin-bookings__filters input,petshop--organism-admin-bookings-102009 .admin-bookings__filters select{padding:8px;font-size:14px;width:auto}petshop--organism-admin-bookings-102009 table{width:100%;border-collapse:collapse;background:#f9f9f9;border-radius:8px;overflow:hidden}petshop--organism-admin-bookings-102009 th,petshop--organism-admin-bookings-102009 td{padding:12px;text-align:left;border-bottom:1px solid #eee}petshop--organism-admin-bookings-102009 th{background:#f0f0f0;font-weight:bold}petshop--organism-admin-bookings-102009 .admin-bookings__status{padding:4px 8px;border-radius:8px;font-size:12px;font-weight:bold;color:#fff}petshop--organism-admin-bookings-102009 .admin-bookings__status--pending{background:var(--warning-color)}petshop--organism-admin-bookings-102009 .admin-bookings__status--approved{background:var(--success-color)}petshop--organism-admin-bookings-102009 .admin-bookings__status--cancelled{background:var(--error-color)}petshop--organism-admin-bookings-102009 .admin-bookings__action_td{display:flex}petshop--organism-admin-bookings-102009 .admin-bookings__action{border:none;padding:0;margin-right:6px;border-radius:4px;cursor:pointer;font-size:var(--font-size-16);width:30px;height:30px}petshop--organism-admin-bookings-102009 .admin-bookings__action--approve{background:var(--success-color);color:#fff}petshop--organism-admin-bookings-102009 .admin-bookings__action--approve svg{fill:currentColor}petshop--organism-admin-bookings-102009 .admin-bookings__action--cancel{background:var(--error-color);color:#fff}petshop--organism-admin-bookings-102009 .admin-bookings__action--cancel svg{fill:currentColor}petshop--organism-admin-bookings-102009 .admin-bookings__pagination{margin-top:16px;display:flex;justify-content:center;align-items:center;gap:12px}petshop--organism-admin-bookings-102009 .admin-bookings__pagination button{width:auto;padding:var(--space-8)}petshop--organism-admin-bookings-102009 .form-actions{margin-left:auto}petshop--organism-admin-bookings-102009 .form-actions button a{color:#ffffff}@media (max-width:768px){petshop--organism-admin-bookings-102009 input,petshop--organism-admin-bookings-102009 select{width:100%}}`);
        this.mode = 'with-filter';
        this.filterMode = '';
        this.titleHeader = '';
        this.search = '';
        this.statusFilter = '';
        this.filterService = '';
        this.filterDateStart = '';
        this.filterDateEnd = '';
        this.schedulings = [];
        this.filtered = [];
        this.currentPage = 1;
        this.pageSize = 5;
    }
    async firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        const req = {
            action: 'SchedulingList',
            inDeveloped: true,
            version: '1',
            params: { filter: '' }
        };
        const response = await petshopExec(req);
        if (!response.ok) {
            this.labelError = response.error;
            return;
        }
        this.schedulings = response.data.filter((item) => item != null);
        this.filtered = [...this.schedulings];
        this.applyFilters();
    }
    handleEdit(e, scheduling) {
        e.preventDefault();
        setState('ui.petshop.admin.scheduling.selected', scheduling);
        if (this.linkToEdit)
            this.linkToEdit.click();
    }
    handleSearch(e) {
        this.search = e.target.value.toLowerCase();
        this.applyFilters();
    }
    handleStatusFilter(e) {
        this.statusFilter = e.target.value;
        this.applyFilters();
    }
    handleDateStartFilter(e) {
        this.filterDateStart = e.target.value;
        this.applyFilters();
    }
    handleDateEndFilter(e) {
        this.filterDateEnd = e.target.value;
        this.applyFilters();
    }
    handleServiceFilter(e) {
        this.filterService = e.target.value;
        this.applyFilters();
    }
    applyFilters() {
        let list = [...this.schedulings];
        if (this.search) {
            list = list.filter(b => b.details.tutor.name.toLowerCase().includes(this.search) ||
                b.details.pet.name.toLowerCase().includes(this.search));
        }
        if (this.statusFilter) {
            list = list.filter(b => b.details.status === this.statusFilter);
        }
        let startDate = this.filterDateStart ? new Date(this.filterDateStart) : null;
        let endDate = this.filterDateEnd ? new Date(this.filterDateEnd) : null;
        if (this.filterMode) {
            const now = new Date();
            if (this.filterMode === 'today') {
                startDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
                endDate = startDate;
            }
            else if (this.filterMode === 'week') {
                // Calcula o domingo da semana atual
                const dayOfWeek = now.getUTCDay(); // 0 = domingo, 6 = sábado
                startDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - dayOfWeek));
                // Calcula o sábado da semana atual
                endDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + (6 - dayOfWeek)));
            }
        }
        if (startDate || endDate) {
            list = list.filter(b => {
                const date = new Date(b.details.startDateTime);
                const d = new Date(date);
                d.setUTCHours(0, 0, 0, 0);
                if (startDate)
                    startDate.setUTCHours(0, 0, 0, 0);
                if (endDate)
                    endDate.setUTCHours(0, 0, 0, 0);
                if (startDate && endDate) {
                    return d >= startDate && d <= endDate;
                }
                else if (startDate) {
                    const day = date.toISOString().slice(0, 10);
                    const target = startDate.toISOString().slice(0, 10);
                    return day === target;
                }
                else if (endDate) {
                    return d <= endDate;
                }
                return true;
            });
        }
        if (this.filterService) {
            list = list.filter(b => b.details.service.name === this.filterService);
        }
        this.currentPage = 1;
        this.filtered = list;
    }
    // ---- Paginação ----
    get paginated() {
        const start = (this.currentPage - 1) * this.pageSize;
        return this.filtered.slice(start, start + this.pageSize);
    }
    nextPage() {
        if (this.currentPage * this.pageSize < this.filtered.length) {
            this.currentPage++;
        }
    }
    prevPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
        }
    }
    // ---- Renderização ----
    render() {
        return html `
<section class="admin-bookings">
<h2 class="admin-bookings__title">${this.titleHeader || 'Gestão de Agendamentos'}</h2>
	${this.mode === 'with-filter' ? html `
		<div class="admin-bookings__filters">
			<input
				type="text"
				placeholder="Buscar cliente ou pet..."
				@input=${this.handleSearch}
				value=${this.search}
			/>
			<select @change=${this.handleStatusFilter}>
				<option value="">Todos os status</option>
				<option value="PENDING">Pendente</option>
				<option value="CONFIRMED">Aprovado</option>
				<option value="CANCELED">Cancelado</option>
				<option value="COMPLETED">Completado</option>
			</select>
			<input
				type="date"
				@change=${this.handleDateStartFilter}
				value=${this.filterDateStart}
				/>
			<input
					type="date"
					@change=${this.handleDateEndFilter}
					value=${this.filterDateEnd}
			/>

			<select @change=${this.handleServiceFilter}>
				<option value="">Todos os serviços</option>
				${this.getUniqueServices().map(service => html `<option value="${service}">${service}</option>`)}
			</select>

			<div class="form-actions"">
            	<button class="btn btn-save"><a href="/pageAdminSchedulingAdd">Novo agendamento</a></button>
        	</div>
		</div>
	` : ''}

	<table class="admin-bookings__table">
		<thead>
			<tr>
				<th>Cliente</th>
				<th>Pet</th>
				<th>Serviço</th>
				<th>Data</th>
				<th>Status</th>
				<th>Ações</th>
			</tr>
		</thead>
		<tbody>
			${this.paginated.map(b => html `
			<tr>
				<td>${b.details.tutor.name}</td>
				<td>${b.details.pet.name}</td>
				<td>${b.details.service.name}</td>
				<td>${new Date(b.details.startDateTime).toLocaleString()}</td>
				<td>
					<span class="admin-bookings__status admin-bookings__${this.getStatusCls(b.details.status)}">
					${this.getStatusLabel(b.details.status)}
					</span>
				</td>
				<td class="admin-bookings__action_td">
					<a href="#" @click="${(e) => this.handleEdit(e, b)}">Detalhes</button>
				</td>
			</tr>
			`)}
		</tbody>
	</table>
	<div class="admin-bookings__pagination">
		<button @click=${this.prevPage} ?disabled=${this.currentPage === 1}>← Anterior</button>
		<span>Página ${this.currentPage} de ${Math.ceil(this.filtered.length / this.pageSize) || 1}</span>
		<button @click=${this.nextPage} ?disabled=${this.currentPage * this.pageSize >= this.filtered.length}>Próxima →</button>
    	<a id="link-to-edit" style="display:none" href="/pageAdminEditScheduling"></a>
	</div>
</section>
`;
    }
    getStatusCls(status) {
        const stateCLS = {
            'PENDING': 'status--pending',
            'CONFIRMED': 'status--approved',
            'CANCELED': 'status--cancelled',
            'COMPLETED': 'status--approved',
        };
        return stateCLS[status] || '';
    }
    getStatusLabel(status) {
        const stateLabel = {
            'PENDING': 'Pendente',
            'CONFIRMED': 'Aprovado',
            'CANCELED': 'Cancelado',
            'COMPLETED': 'Completo',
        };
        return stateLabel[status] || '';
    }
    getUniqueServices() {
        const services = this.schedulings.map(b => b.details.service.name);
        return [...new Set(services)];
    }
};
__decorate([
    property()
], OrganismAdminBookings.prototype, "mode", void 0);
__decorate([
    property()
], OrganismAdminBookings.prototype, "filterMode", void 0);
__decorate([
    property()
], OrganismAdminBookings.prototype, "titleHeader", void 0);
__decorate([
    property()
], OrganismAdminBookings.prototype, "search", void 0);
__decorate([
    property()
], OrganismAdminBookings.prototype, "statusFilter", void 0);
__decorate([
    property()
], OrganismAdminBookings.prototype, "filterService", void 0);
__decorate([
    property()
], OrganismAdminBookings.prototype, "filterDateStart", void 0);
__decorate([
    property()
], OrganismAdminBookings.prototype, "filterDateEnd", void 0);
__decorate([
    state()
], OrganismAdminBookings.prototype, "schedulings", void 0);
__decorate([
    state()
], OrganismAdminBookings.prototype, "filtered", void 0);
__decorate([
    state()
], OrganismAdminBookings.prototype, "currentPage", void 0);
__decorate([
    propertyDataSource()
], OrganismAdminBookings.prototype, "labelError", void 0);
__decorate([
    propertyDataSource()
], OrganismAdminBookings.prototype, "labelOk", void 0);
__decorate([
    query('#link-to-edit')
], OrganismAdminBookings.prototype, "linkToEdit", void 0);
OrganismAdminBookings = __decorate([
    customElement('petshop--organism-admin-bookings-102009')
], OrganismAdminBookings);
export { OrganismAdminBookings };
