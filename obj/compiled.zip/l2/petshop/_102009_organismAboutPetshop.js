/// <mls shortName="organismAboutPetshop" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAboutPetshop = class organismAboutPetshop extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-about-petshop-102009{display:block;background:var(--bg-primary-color);padding:var(--space-48) 0}petshop--organism-about-petshop-102009 .about-container{max-width:900px;margin:0 auto;display:flex;flex-direction:column;align-items:center;text-align:center}petshop--organism-about-petshop-102009 h2{color:var(--text-primary-color);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:var(--space-24)}petshop--organism-about-petshop-102009 .about-text{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);line-height:var(--line-height-large);margin-bottom:var(--space-16)}petshop--organism-about-petshop-102009 .about-values{display:flex;gap:var(--space-24);flex-wrap:wrap;justify-content:center;margin-top:var(--space-16)}petshop--organism-about-petshop-102009 .about-values .value{background:var(--bg-secondary-color-lighter);border-radius:12px;padding:var(--space-16) var(--space-24);color:var(--text-secondary-color-darker);font-size:var(--font-size-12);font-weight:var(--font-weight-bold);box-shadow:0 1px 4px var(--grey-color-light)}@media (max-width:768px){petshop--organism-about-petshop-102009 .about-values{gap:var(--space-8)}}`);
    }
    render() {
        return html `<div class="about-container" id="petshop--about-petshop-102009-1">
          <h2 id="petshop--about-petshop-102009-2">Sobre o Petshop Amigo</h2>
          <div class="about-text" id="petshop--about-petshop-102009-3">
            O Petshop Amigo nasceu do amor pelos animais e da vontade de oferecer o melhor em serviços e produtos para pets de todas as espécies. Nossa missão é cuidar com carinho, respeito e profissionalismo, proporcionando bem-estar e felicidade para seu melhor amigo.
          </div>
          <div class="about-values" id="petshop--about-petshop-102009-4">
            <div class="value" id="petshop--about-petshop-102009-5">Carinho &amp; Respeito</div>
            <div class="value" id="petshop--about-petshop-102009-6">Profissionalismo</div>
            <div class="value" id="petshop--about-petshop-102009-7">Bem-estar animal</div>
            <div class="value" id="petshop--about-petshop-102009-8">Atendimento personalizado</div>
          </div>
        </div>
      `;
    }
};
organismAboutPetshop = __decorate([
    customElement('petshop--organism-about-petshop-102009')
], organismAboutPetshop);
export { organismAboutPetshop };
