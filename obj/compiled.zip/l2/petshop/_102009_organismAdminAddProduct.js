/// <mls shortName="organismAdminAddProduct" project="102009" enhancement="_100554_enhancementLit" folder="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { subscribe, unsubscribe } from '_100554_/l2/collabState';
import { propertyDataSource } from './_100554_collabDecorators';
import { exec } from "./_102019_layer1Exec";
import { MdmType } from "./_102019_commonGlobal";
let organismAddProduct = class organismAddProduct extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-add-product-102009{display:block;padding:var(--space-24);background-color:var(--bg-primary-color)}`);
        this.loading = false;
    }
    connectedCallback() {
        super.connectedCallback();
        subscribe([
            'ui.petshop.admin.organismAdminAddProduct.action',
        ], this);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe([
            'ui.petshop.admin.organismAdminAddProduct.action',
        ], this);
    }
    handleIcaStateChange(_key, _value) {
        if (_key === 'ui.petshop.admin.organismAdminAddProduct.action' && _value === 'save')
            this.handleClickSave();
    }
    render() {
        return html `<div>
            <h2>Adicionar Novo Produto</h2>
            <div class="form-group">
                <label for="product-name">Nome do Produto</label>
                <input 
                    type="text" 
                    id="product-name" 
                    name="product-name" 
                    required
                    ?disabled=${this.loading}
                    @input=${(e) => { this.nameProduct = e.target.value; }}
                    >
            </div>
            <div class="form-group">
                <label for="product-description">Descrição do Produto</label>
                <textarea 
                    id="product-description" 
                    name="product-description"
                    ?disabled=${this.loading}
                    @input=${(e) => { this.descriptionShort = e.target.value; }}    
                ></textarea>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-back" @click=${this.handleClickBack} ?disabled=${this.loading}>Voltar</button>
                <button type="submit" class="btn btn-save" @click=${this.handleClickSave} ?disabled=${this.loading}>
                    Salvar
                    ${this.loading ? html `<span class="loading"></span>` : html ``}
                </button>
                <a id="link-back" style="display:none" href="/pageAdminProduct"></a>
            </div>
            ${this.labelError ? html `<span class="error-message">${this.labelError}</span>` : ''}

</div>`;
    }
    handleClickBack(e) {
        e.preventDefault();
        if (this.link) {
            this.link.click();
        }
    }
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    clearErrors() {
        this.labelError = '';
    }
    async handleClickSave() {
        this.clearErrors();
        let hasErrors = false;
        if (!this.nameProduct) {
            this.labelError = 'Nome do produto é obrigatório.';
            hasErrors = true;
        }
        else if (!this.descriptionShort) {
            this.labelError = 'Descrição do produto é obrigatório.';
            hasErrors = true;
        }
        if (!hasErrors) {
            this.loading = true;
            await this.delay(1000);
            const params = {
                details: {
                    registrationData: {
                        name: this.nameProduct,
                        descriptionShort: this.descriptionShort,
                    },
                    type: MdmType.Produto,
                    status: 'A',
                }
            };
            const req = {
                action: 'MDMAdd',
                inDeveloped: true,
                version: '1',
                params,
            };
            const response = await exec(req);
            if (!response.ok) {
                this.labelError = response.error;
                this.loading = false;
                return;
            }
            this.loading = false;
            this.labelOk = 'Cadastro realizado com sucesso';
            if (this.link) {
                this.link.click();
            }
        }
    }
};
__decorate([
    state()
], organismAddProduct.prototype, "loading", void 0);
__decorate([
    propertyDataSource()
], organismAddProduct.prototype, "nameProduct", void 0);
__decorate([
    propertyDataSource()
], organismAddProduct.prototype, "descriptionShort", void 0);
__decorate([
    propertyDataSource()
], organismAddProduct.prototype, "labelError", void 0);
__decorate([
    propertyDataSource()
], organismAddProduct.prototype, "labelOk", void 0);
__decorate([
    propertyDataSource()
], organismAddProduct.prototype, "action", void 0);
__decorate([
    query('#link-back')
], organismAddProduct.prototype, "link", void 0);
organismAddProduct = __decorate([
    customElement('petshop--organism-admin-add-product-102009')
], organismAddProduct);
export { organismAddProduct };
