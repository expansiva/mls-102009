/// <mls shortName="agendamento" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageAgendamento = class PageAgendamento extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--agendamento-102009{display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color)}petshop--agendamento-102009 header{flex-shrink:0}petshop--agendamento-102009 main{flex:1 0 auto;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding:var(--space-32) 0 var(--space-32) 0;background:var(--bg-secondary-color)}@media (max-width:768px){petshop--agendamento-102009 main{padding:var(--space-16) 0 var(--space-16) 0}}petshop--agendamento-102009 footer{flex-shrink:0}`);
    }
    initPage() {
    }
};
PageAgendamento = __decorate([
    customElement('petshop--agendamento-102009')
], PageAgendamento);
export { PageAgendamento };
