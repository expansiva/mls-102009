/// <mls shortName="organismCartSummary" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismCartSummary = class organismCartSummary extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-cart-summary-102009{min-width:320px;max-width:380px;background:var(--bg-secondary-color-lighter);border-radius:8px;box-shadow:0 2px 8px rgba(230,230,230,0.1);padding:var(--space-24);font-family:var(--font-family-primary);display:flex;flex-direction:column;gap:var(--space-16);margin-left:var(--space-32)}@media (max-width:1012px){petshop--organism-cart-summary-102009{min-width:0;max-width:100%;margin-left:0;margin-top:var(--space-24)}}petshop--organism-cart-summary-102009 h2{font-size:var(--font-size-20);color:var(--text-primary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}petshop--organism-cart-summary-102009 .cart-items{display:flex;flex-direction:column;gap:var(--space-16);max-height:220px;overflow-y:auto}petshop--organism-cart-summary-102009 .cart-item{display:flex;align-items:center;gap:var(--space-8);background:var(--bg-primary-color);border-radius:6px;padding:var(--space-8)}petshop--organism-cart-summary-102009 .cart-item img{width:48px;height:48px;object-fit:cover;border-radius:6px;background:var(--bg-secondary-color-lighter)}petshop--organism-cart-summary-102009 .cart-item .item-info{flex:1 1 0;display:flex;flex-direction:column}petshop--organism-cart-summary-102009 .cart-item .item-info .item-name{font-size:var(--font-size-16);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold)}petshop--organism-cart-summary-102009 .cart-item .item-info .item-qty{font-size:var(--font-size-12);color:var(--text-secondary-color-darker)}petshop--organism-cart-summary-102009 .cart-item .item-price{font-size:var(--font-size-16);color:var(--text-secondary-color);font-weight:var(--font-weight-bold);margin-left:var(--space-8)}petshop--organism-cart-summary-102009 .cart-item .remove-btn{background:none;border:none;color:var(--error-color);font-size:var(--font-size-16);cursor:pointer;margin-left:var(--space-8)}petshop--organism-cart-summary-102009 .cart-item .remove-btn:hover{color:var(--error-color-hover)}petshop--organism-cart-summary-102009 .cart-total{display:flex;justify-content:space-between;align-items:center;font-size:var(--font-size-20);color:var(--text-primary-color);font-weight:var(--font-weight-bold);margin-top:var(--space-16)}petshop--organism-cart-summary-102009 .checkout-actions{display:flex;flex-direction:column;gap:var(--space-8);margin-top:var(--space-16)}petshop--organism-cart-summary-102009 .checkout-actions button{padding:var(--space-8) var(--space-16);border-radius:4px;border:none;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;background:var(--text-secondary-color);color:var(--bg-primary-color);transition:background var(--transition-normal)}petshop--organism-cart-summary-102009 .checkout-actions button:hover{background:var(--text-secondary-color-hover)}petshop--organism-cart-summary-102009 .checkout-actions .pix{background:var(--text-primary-color)}petshop--organism-cart-summary-102009 .checkout-actions .pix:hover{background:var(--text-primary-color-hover)}petshop--organism-cart-summary-102009 .empty-cart{text-align:center;color:var(--text-primary-color-lighter);font-size:var(--font-size-16);margin:var(--space-24) 0}`);
    }
    render() {
        return html `<h2 id="petshop--cart-summary-102009-1">Seu Carrinho</h2>
        <div class="cart-items" id="petshop--cart-summary-102009-2">
          <div class="cart-item" id="petshop--cart-summary-102009-3">
            <img src="https://images.unsplash.com/photo-1616205255812-c07c8102cc02?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBmb29kJTIwYmFnJTIwcHJlbWl1bXxlbnwwfHx8fDE3NTQzNDE5OTV8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Ração Premium para Cães" id="petshop--cart-summary-102009-4">
            <div class="item-info" id="petshop--cart-summary-102009-5">
              <div class="item-name" id="petshop--cart-summary-102009-6">Ração Premium para Cães</div>
              <div class="item-qty" id="petshop--cart-summary-102009-7">Qtd: 1</div>
            </div>
            <div class="item-price" id="petshop--cart-summary-102009-8">R$ 89,90</div>
            <button class="remove-btn" title="Remover" id="petshop--cart-summary-102009-9">×</button>
          </div>
          <div class="cart-item" id="petshop--cart-summary-102009-10">
            <img src="https://images.unsplash.com/photo-1665582894071-eb5b7c4d4656?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxjYXQlMjBpbnRlcmFjdGl2ZSUyMHRveSUyMGNvbG9yZnVsfGVufDB8fHx8MTc1NDQxMTQxNHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Brinquedo Interativo para Gatos" id="petshop--cart-summary-102009-11">
            <div class="item-info" id="petshop--cart-summary-102009-12">
              <div class="item-name" id="petshop--cart-summary-102009-13">Brinquedo Interativo para Gatos</div>
              <div class="item-qty" id="petshop--cart-summary-102009-14">Qtd: 2</div>
            </div>
            <div class="item-price" id="petshop--cart-summary-102009-15">R$ 59,80</div>
            <button class="remove-btn" title="Remover" id="petshop--cart-summary-102009-16">×</button>
          </div>
        </div>
        <div class="cart-total" id="petshop--cart-summary-102009-17">
          <span id="petshop--cart-summary-102009-18">Total</span>
          <span id="petshop--cart-summary-102009-19">R$ 149,70</span>
        </div>
        <div class="checkout-actions" id="petshop--cart-summary-102009-20">
          <button id="petshop--cart-summary-102009-21">Finalizar Compra (Cartão)</button>
          <button class="pix" id="petshop--cart-summary-102009-22">Pagar com Pix</button>
        </div>
      `;
    }
};
organismCartSummary = __decorate([
    customElement('petshop--organism-cart-summary-102009')
], organismCartSummary);
export { organismCartSummary };
