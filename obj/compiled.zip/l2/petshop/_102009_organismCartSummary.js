/// <mls shortName="organismCartSummary" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { setState, getState, subscribe, unsubscribe } from '_100554_/l2/collabState';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismCartSummary = class organismCartSummary extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-cart-summary-102009{min-width:320px;max-width:380px;background:var(--bg-secondary-color-lighter);border-radius:8px;box-shadow:0 2px 8px rgba(230,230,230,0.1);padding:var(--space-24);font-family:var(--font-family-primary);display:flex;flex-direction:column;gap:var(--space-16);margin-left:var(--space-32)}@media (max-width:1012px){petshop--organism-cart-summary-102009{min-width:0;max-width:100%;margin-left:0;margin-top:var(--space-24)}}petshop--organism-cart-summary-102009 h2{font-size:var(--font-size-20);color:var(--text-primary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}petshop--organism-cart-summary-102009 .cart-items{display:flex;flex-direction:column;gap:var(--space-16);max-height:220px;overflow-y:auto}petshop--organism-cart-summary-102009 .cart-item{display:flex;align-items:center;gap:var(--space-8);background:var(--bg-primary-color);border-radius:6px;padding:var(--space-8)}petshop--organism-cart-summary-102009 .cart-item img{width:48px;height:48px;object-fit:cover;border-radius:6px;background:var(--bg-secondary-color-lighter)}petshop--organism-cart-summary-102009 .cart-item .item-info{flex:1 1 0;display:flex;flex-direction:column}petshop--organism-cart-summary-102009 .cart-item .item-info .item-name{font-size:var(--font-size-16);color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold)}petshop--organism-cart-summary-102009 .cart-item .item-info .item-qty{font-size:var(--font-size-12);color:var(--text-secondary-color-darker)}petshop--organism-cart-summary-102009 .cart-item .item-price{font-size:var(--font-size-16);color:var(--text-secondary-color);font-weight:var(--font-weight-bold);margin-left:var(--space-8)}petshop--organism-cart-summary-102009 .cart-item .remove-btn{background:none;border:none;color:var(--error-color);font-size:var(--font-size-16);cursor:pointer;margin-left:var(--space-8)}petshop--organism-cart-summary-102009 .cart-item .remove-btn:hover{color:var(--error-color-hover)}petshop--organism-cart-summary-102009 .cart-total{display:flex;justify-content:space-between;align-items:center;font-size:var(--font-size-20);color:var(--text-primary-color);font-weight:var(--font-weight-bold);margin-top:var(--space-16)}petshop--organism-cart-summary-102009 .checkout-actions{display:flex;flex-direction:column;gap:var(--space-8);margin-top:var(--space-16)}petshop--organism-cart-summary-102009 .checkout-actions button{padding:var(--space-8) var(--space-16);border-radius:4px;border:none;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;background:var(--text-secondary-color);color:var(--bg-primary-color);transition:background var(--transition-normal)}petshop--organism-cart-summary-102009 .checkout-actions button:hover{background:var(--text-secondary-color-hover)}petshop--organism-cart-summary-102009 .checkout-actions .pix{background:var(--text-primary-color)}petshop--organism-cart-summary-102009 .checkout-actions .pix:hover{background:var(--text-primary-color-hover)}petshop--organism-cart-summary-102009 .empty-cart{text-align:center;color:var(--text-primary-color-lighter);font-size:var(--font-size-16);margin:var(--space-24) 0}`);
        this.carProducts = [];
    }
    //--------------------------------------
    connectedCallback() {
        super.connectedCallback();
        subscribe([
            'ui.petshop.client.pageProduct.action',
        ], this);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe([
            'ui.petshop.client.pageProduct.action',
        ], this);
    }
    handleIcaStateChange(_key, _value) {
        if (_key === 'ui.petshop.client.pageProduct.action' && _value === 'add') {
            this.carProducts = [...getState('ui.petshop.client.pageProduct.productCar')];
            setState('ui.petshop.client.pageProduct.action', '');
        }
    }
    render() {
        const tot = this.carProducts.length * 50;
        const vl = Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL',
        }).format(tot);
        return html `
      <h2 >Seu Carrinho</h2>
      <div class="cart-items" >
        ${this.carProducts.map((prod, index) => this.renderItem(prod, index))}
      </div>
      <div class="cart-total">
        <span>Total</span>
        <span>${vl}</span>
      </div>
      <div class="checkout-actions">
        <button>Finalizar Compra (Cartão)</button>
        <button class="pix">Pagar com Pix</button>
      </div>
      `;
    }
    renderItem(prod, index) {
        const reg = prod.data.registrationData;
        return html `
    <div class="cart-item">
      <img src="https://images.unsplash.com/photo-1544198841-10f34f31f8dd?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxhdXRvbWF0aWMlMjBwZXQlMjB3YXRlciUyMGRpc3BlbnNlcnxlbnwwfHx8fDE3NTQ0MTE0MTZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Bebedouro Automático">
      <div class="item-info">
        <div class="item-name">${reg.name}</div>
        <div class="item-qty">Qtd: 1</div>
      </div>
      <div class="item-price">R$ 50,00</div>
      <button class="remove-btn" title="Remover" @click=${() => this.handleClickDel(index)}>×</button>
    </div>
    `;
    }
    //--------------------------
    handleClickDel(idx) {
        if (!this.carProducts || !this.carProducts[idx])
            return;
        this.carProducts.splice(idx, 1);
        this.carProducts = [...this.carProducts];
        setState('ui.petshop.client.pageProduct.productCar', this.carProducts);
        setState('ui.petshop.client.pageProduct.action', 'del');
    }
};
__decorate([
    state()
], organismCartSummary.prototype, "carProducts", void 0);
organismCartSummary = __decorate([
    customElement('petshop--organism-cart-summary-102009')
], organismCartSummary);
export { organismCartSummary };
