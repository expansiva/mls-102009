/// <mls shortName="organismAdminContent" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAdminContent = class organismAdminContent extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-content-102009 .admin-content{background:var(--bg-primary-color);padding:var(--space-32);font-family:var(--font-family-primary)}petshop--organism-admin-content-102009 .admin-content .admin-content__title{font-size:var(--font-size-20);color:var(--text-primary-color-darker);margin-bottom:var(--space-24);font-weight:var(--font-weight-bold)}petshop--organism-admin-content-102009 .admin-content .admin-content__form{background:var(--bg-secondary-color-lighter);border-radius:8px;padding:var(--space-24);display:flex;flex-direction:column;gap:var(--space-24)}petshop--organism-admin-content-102009 .admin-content .admin-content__field{display:flex;flex-direction:column;gap:var(--space-8)}petshop--organism-admin-content-102009 .admin-content .admin-content__label{color:var(--text-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-bold)}petshop--organism-admin-content-102009 .admin-content .admin-content__banner-preview{margin-bottom:var(--space-8)}petshop--organism-admin-content-102009 .admin-content .admin-content__banner-preview img{width:100%;max-width:320px;border-radius:8px}petshop--organism-admin-content-102009 .admin-content .admin-content__input{font-size:var(--font-size-16);padding:var(--space-8);border:1px solid var(--grey-color);border-radius:4px;background:var(--bg-primary-color)}petshop--organism-admin-content-102009 .admin-content .admin-content__textarea{font-size:var(--font-size-16);padding:var(--space-8);border:1px solid var(--grey-color);border-radius:4px;background:var(--bg-primary-color);resize:vertical}petshop--organism-admin-content-102009 .admin-content .admin-content__actions{display:flex;justify-content:flex-end}petshop--organism-admin-content-102009 .admin-content .admin-content__actions .admin-content__save{background:var(--success-color);color:#fff;border:none;border-radius:4px;padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-slow)}petshop--organism-admin-content-102009 .admin-content .admin-content__actions .admin-content__save:hover,petshop--organism-admin-content-102009 .admin-content .admin-content__actions .admin-content__save:focus{background:var(--success-color-hover)}@media (max-width:768px){petshop--organism-admin-content-102009 .admin-content__form{padding:var(--space-16)}petshop--organism-admin-content-102009 .admin-content__banner-preview img{max-width:100%}}`);
    }
    render() {
        return html `<section class="admin-content" id="content">
        <h2 class="admin-content__title" id="petshop--admin-content-102009-1">Gestão de Conteúdo</h2>
        <form class="admin-content__form" id="petshop--admin-content-102009-2">
          <div class="admin-content__field" id="petshop--admin-content-102009-3">
            <label for="home-banner" class="admin-content__label" id="petshop--admin-content-102009-4">Banner da Home</label>
            <div class="admin-content__banner-preview" id="petshop--admin-content-102009-5">
              <img src="https://images.unsplash.com/photo-1698926636530-bbe3d8be1f82?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxiYW5uZXIlMjBwZXRzaG9wJTIwYWxlZ3JlfGVufDB8fHx8MTc1NDQxMTUzMnww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Banner atual da Home" id="petshop--admin-content-102009-6">
            </div>
            <input type="file" id="home-banner" name="home-banner" class="admin-content__input">
          </div>
          <div class="admin-content__field" id="petshop--admin-content-102009-7">
            <label for="about-text" class="admin-content__label" id="petshop--admin-content-102009-8">Texto Institucional</label>
            <textarea id="about-text" name="about-text" class="admin-content__textarea" rows="5">Somos um petshop dedicado ao bem-estar do seu pet. Atualize este texto para refletir a missão do seu negócio.</textarea>
          </div>
          <div class="admin-content__actions" id="petshop--admin-content-102009-9">
            <button type="submit" class="admin-content__save" id="petshop--admin-content-102009-10">Salvar Alterações</button>
          </div>
        </form>
      </section>
    `;
    }
};
organismAdminContent = __decorate([
    customElement('petshop--organism-admin-content-102009')
], organismAdminContent);
export { organismAdminContent };
