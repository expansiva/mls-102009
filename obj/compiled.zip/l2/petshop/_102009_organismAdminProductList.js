var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismAdminProductList" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAdminProductList = class organismAdminProductList extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-product-list-102009 .organism-admin-product-list{padding:var(--space-24);background-color:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}petshop--organism-admin-product-list-102009 .filter-controls{display:flex;gap:var(--space-8);align-items:center;justify-content:space-between}petshop--organism-admin-product-list-102009 .filter-controls input{width:300px}@media (max-width:768px){petshop--organism-admin-product-list-102009 .organism-admin-product-list{padding:var(--space-16)}}`);
    }
    render() {
        return html `<div class="organism-admin-product-list" id="petshop--organism-admin-product-list-102009-1">
<h2 id="petshop--organism-admin-product-list-102009-2">Lista de Produtos</h2>
<div class="form-group" id="petshop--organism-admin-product-list-102009-3">
<label for="filter-name" id="petshop--organism-admin-product-list-102009-4">Filtrar por Nome:</label>
<div class="filter-controls" id="petshop--organism-admin-product-list-102009-29">
<input type="text" id="filter-name" placeholder="Digite o nome do produto" id="petshop--organism-admin-product-list-102009-5">
<button class="btn btn-save" id="petshop--organism-admin-product-list-102009-30">Adicionar</button>
</div>
</div>
<table id="petshop--organism-admin-product-list-102009-6">
<thead id="petshop--organism-admin-product-list-102009-7">
<tr id="petshop--organism-admin-product-list-102009-8">
<th id="petshop--organism-admin-product-list-102009-9">Nome</th>
<th id="petshop--organism-admin-product-list-102009-10">Descrição</th>
<th id="petshop--organism-admin-product-list-102009-11">Ações</th>
</tr>
</thead>
<tbody id="petshop--organism-admin-product-list-102009-12">
<tr id="petshop--organism-admin-product-list-102009-13">
<td id="petshop--organism-admin-product-list-102009-14">Ração para Cães</td>
<td id="petshop--organism-admin-product-list-102009-15">Ração premium para cães adultos.</td>
<td id="petshop--organism-admin-product-list-102009-16"><a href="#edit-1">Editar</a></td>
</tr>
<tr id="petshop--organism-admin-product-list-102009-17">
<td id="petshop--organism-admin-product-list-102009-18">Brinquedo para Gatos</td>
<td id="petshop--organism-admin-product-list-102009-19">Brinquedo interativo para gatos.</td>
<td id="petshop--organism-admin-product-list-102009-20"><a href="#edit-2">Editar</a></td>
</tr>
<tr id="petshop--organism-admin-product-list-102009-21">
<td id="petshop--organism-admin-product-list-102009-22">Coleira para Cães</td>
<td id="petshop--organism-admin-product-list-102009-23">Coleira resistente e confortável.</td>
<td id="petshop--organism-admin-product-list-102009-24"><a href="#edit-3">Editar</a></td>
</tr>
</tbody>
</table>
<div class="pagination" id="petshop--organism-admin-product-list-102009-25">
<button id="petshop--organism-admin-product-list-102009-26">Anterior</button>
<span id="petshop--organism-admin-product-list-102009-27">Página 1 de 5</span>
<button id="petshop--organism-admin-product-list-102009-28">Próxima</button>
</div>
</div>`;
    }
};
organismAdminProductList = __decorate([
    customElement('petshop--organism-admin-product-list-102009')
], organismAdminProductList);
export { organismAdminProductList };
