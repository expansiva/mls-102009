/// <mls shortName="organismAdminProductList" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { setState } from '_100554_/l2/collabState';
import { exec } from "./_102019_layer1Exec";
import { MdmType } from "./_102019_commonGlobal";
let organismAdminProductList = class organismAdminProductList extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-product-list-102009 .organism-admin-product-list{padding:var(--space-24);background-color:var(--bg-primary-color)}petshop--organism-admin-product-list-102009 .filter-controls{display:flex;gap:var(--space-8);align-items:center;justify-content:space-between}petshop--organism-admin-product-list-102009 .filter-controls input{width:300px}petshop--organism-admin-product-list-102009 .filter-controls a{color:#ffffff}petshop--organism-admin-product-list-102009 th{cursor:pointer}petshop--organism-admin-product-list-102009 th:hover{background-color:var(--bg-secondary-color-hover)}@media (max-width:768px){petshop--organism-admin-product-list-102009 .organism-admin-product-list{padding:var(--space-16)}petshop--organism-admin-product-list-102009 .filter-controls{flex-direction:column;align-items:stretch}petshop--organism-admin-product-list-102009 .filter-controls input{width:100%}}`);
        this.filterText = '';
        this.sortColumn = 'name';
        this.sortDirection = 'asc';
        this.currentPage = 1;
        this.itemsPerPage = 5;
    }
    async firstUpdated() {
        const req = {
            action: 'MDMGetListByType',
            inDeveloped: true,
            version: '1',
            params: { type: MdmType.Produto },
        };
        const response = await exec(req);
        if (response.ok) {
            this.mdmProducts = response.data.map((item) => {
                const item2 = item;
                return item2;
            });
        }
    }
    get filteredProducts() {
        if (!this.mdmProducts)
            return [];
        return this.mdmProducts.filter(mdmProducts => mdmProducts.details.registrationData?.name.toLowerCase().includes(this.filterText.toLowerCase()) ||
            mdmProducts.details.registrationData.descriptionShort.toLowerCase().includes(this.filterText.toLowerCase()));
    }
    // Sort filtered products
    get sortedProducts() {
        const sorted = [...this.filteredProducts];
        sorted.sort((a, b) => {
            let aVal = (a.details?.registrationData)[this.sortColumn];
            let bVal = (b.details?.registrationData)[this.sortColumn];
            if (typeof aVal === 'string')
                aVal = aVal.toLowerCase();
            if (typeof bVal === 'string')
                bVal = bVal.toLowerCase();
            if (aVal < bVal)
                return this.sortDirection === 'asc' ? -1 : 1;
            if (aVal > bVal)
                return this.sortDirection === 'asc' ? 1 : -1;
            return 0;
        });
        return sorted;
    }
    // Get total pages
    get totalPages() {
        return Math.ceil(this.sortedProducts.length / this.itemsPerPage);
    }
    // Get paginated products for current page
    get paginatedProducts() {
        const start = (this.currentPage - 1) * this.itemsPerPage;
        const end = start + this.itemsPerPage;
        return this.sortedProducts.slice(start, end);
    }
    // Get visible pages for pagination (show current -1, current, current +1, clamped to 1 and totalPages)
    get visiblePages() {
        const pages = [];
        const start = Math.max(1, this.currentPage - 1);
        const end = Math.min(this.totalPages, this.currentPage + 1);
        for (let i = start; i <= end; i++) {
            pages.push(i);
        }
        return pages;
    }
    // Handle sort click
    handleSort(column) {
        if (this.sortColumn === column) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        }
        else {
            this.sortColumn = column;
            this.sortDirection = 'asc';
        }
    }
    // Handle edit action
    handleEdit(e, product) {
        e.preventDefault();
        setState('ui.petshop.admin.product.selected', product);
        if (this.linkToEdit)
            this.linkToEdit.click();
    }
    // Handle previous page
    handlePrevPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
        }
    }
    // Handle next page
    handleNextPage() {
        if (this.currentPage < this.totalPages) {
            this.currentPage++;
        }
    }
    // Handle page number click
    handlePageClick(page) {
        this.currentPage = page;
    }
    render() {
        return html `<div class="organism-admin-product-list" id="petshop--organism-admin-product-list-102009-1">
<h2 id="petshop--organism-admin-product-list-102009-2">Lista de Produtos</h2>
<div class="form-group" id="petshop--organism-admin-product-list-102009-3">
<label for="filter-name" id="petshop--organism-admin-product-list-102009-4">Filtrar por Nome ou Categoria:</label>
<div class="filter-controls" id="petshop--organism-admin-product-list-102009-29">
<input type="text" id="filter-name" placeholder="Digite o nome ou categoria" @input="${(e) => this.filterText = e.target.value}" id="petshop--organism-admin-product-list-102009-5">
<button class="btn btn-save" id="petshop--organism-admin-product-list-102009-30"><a href="/pageAdminAddProduct">Adicionar novo</a></button>
</div>
</div>
<table id="petshop--organism-admin-product-list-102009-6">
<thead id="petshop--organism-admin-product-list-102009-7">
<tr id="petshop--organism-admin-product-list-102009-8">
<th @click="${() => this.handleSort('name')}" id="petshop--organism-admin-product-list-102009-9">Nome ${this.sortColumn === 'name' ? (this.sortDirection === 'asc' ? '↑' : '↓') : ''}</th>
<th @click="${() => this.handleSort('descriptionShort')}" id="petshop--organism-admin-product-list-102009-12">Descrição ${this.sortColumn === 'descriptionShort' ? (this.sortDirection === 'asc' ? '↑' : '↓') : ''}</th>
<th id="petshop--organism-admin-product-list-102009-13">Ações</th>
</tr>
</thead>
<tbody id="petshop--organism-admin-product-list-102009-14">
${this.paginatedProducts.map(product => html `
<tr>
<td>${product.details.registrationData?.name}</td>
<td>${product.details.registrationData?.descriptionShort}</td>

<td>
<a href="#" @click="${(e) => this.handleEdit(e, product)}">Editar</button>
</td>
</tr>
`)}
</tbody>
</table>
<div class="pagination" id="petshop--organism-admin-product-list-102009-25">
<button @click="${this.handlePrevPage}" ?disabled="${this.currentPage === 1}" id="petshop--organism-admin-product-list-102009-26">Anterior</button>
${this.visiblePages.map(page => html `<button @click="${() => this.handlePageClick(page)}" class="${page === this.currentPage ? 'active' : ''}">${page}</button>`)}
<button @click="${this.handleNextPage}" ?disabled="${this.currentPage === this.totalPages}" id="petshop--organism-admin-product-list-102009-28">Próxima</button>
    <a id="link-to-edit" style="display:none" href="/pageAdminEditProduct"></a>

</div>
</div>`;
    }
};
__decorate([
    state()
], organismAdminProductList.prototype, "mdmProducts", void 0);
__decorate([
    state()
], organismAdminProductList.prototype, "filterText", void 0);
__decorate([
    state()
], organismAdminProductList.prototype, "sortColumn", void 0);
__decorate([
    state()
], organismAdminProductList.prototype, "sortDirection", void 0);
__decorate([
    state()
], organismAdminProductList.prototype, "currentPage", void 0);
__decorate([
    state()
], organismAdminProductList.prototype, "itemsPerPage", void 0);
__decorate([
    query('#link-to-edit')
], organismAdminProductList.prototype, "linkToEdit", void 0);
organismAdminProductList = __decorate([
    customElement('petshop--organism-admin-product-list-102009')
], organismAdminProductList);
export { organismAdminProductList };
