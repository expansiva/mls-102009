/// <mls shortName="organismAdminScheduling" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { subscribe, unsubscribe } from '_100554_/l2/collabState';
import { propertyDataSource } from './_100554_collabDecorators';
import { exec } from "./_102019_layer1Exec";
import { MdmType } from "./_102019_layer4Mdm";
import { petshopExec } from "./_102009_layer1Exec";
import { SchedulingStatus } from './_102009_layer4Scheduling';
let organismAdminScheduling = class organismAdminScheduling extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-scheduling-102009 .scheduling-container{padding:var(--space-24);background-color:var(--bg-primary-color)}petshop--organism-admin-scheduling-102009 .user-list{list-style:none;padding:0;margin-bottom:var(--space-16);margin-top:var(--space-16)}petshop--organism-admin-scheduling-102009 .user-item{padding:var(--space-8);background-color:var(--bg-secondary-color);border:1px solid var(--grey-color);border-radius:4px;margin-bottom:var(--space-8);cursor:pointer;transition:background-color var(--transition-normal)}petshop--organism-admin-scheduling-102009 .user-item:hover{background-color:var(--bg-secondary-color-hover)}petshop--organism-admin-scheduling-102009 .user-item:focus{outline:2px solid var(--active-color);outline-offset:2px}`);
        this.loading = false;
        this.users = [];
        this.pets = [];
        this.services = [];
        this.currentStep = 'user-selection';
    }
    async firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        await this.getServices();
    }
    connectedCallback() {
        super.connectedCallback();
        subscribe([
            'ui.petshop.admin.organismAdminScheduling.action',
        ], this);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe([
            'ui.petshop.admin.organismAdminScheduling.action',
        ], this);
    }
    handleIcaStateChange(_key, _value) {
        if (_key === 'ui.petshop.admin.organismAdminScheduling.action' && _value === 'save')
            this.handleSave();
        if (_key === 'ui.petshop.admin.organismAdminScheduling.action' && _value === 'search')
            this.handleSearch();
    }
    render() {
        return html `<div class="scheduling-container">
        ${this.currentStep === 'user-selection' ? this.renderSelectUser() : this.renderAddScheduling()}`;
    }
    renderSelectUser() {
        return html `
        <section>
        <h2>Pesquisar Usuário</h2>
        <div class="form-group">
            <label for="user-search">Buscar por nome, e-mail ou ID</label>
            <input type="text" id="user-search" placeholder="Digite para pesquisar" @input=${(e) => this.searchText = e.target.value}>
        </div>
        <div class="form-actions"">
            <button class="btn btn-save"  @click="${this.handleSearch}">Pesquisar</button>
        </div>
        <ul class="user-list">
            ${this.users.map((user) => {
            return html `<li class="user-item" @click=${() => this.handleContinue(user)}>${user.data.registrationData.name}</li>`;
        })}
        </ul>
        ${this.labelError ? html `<span class="error-message">${this.labelError}</span>` : ''}

        </section>
`;
    }
    renderAddScheduling() {
        return html `
            <section>
            <h2>Agendamento</h2>
            <div class="form-group">
                <label for="date-select">Cliente</label>
                <input readonly type="text" value="${(this.userSelected?.data.registrationData).name}"}
            </div>
            <div class="form-group">
                <label for="pet-select">Selecionar Pet</label>
                <select id="pet-select" @change=${(e) => { this.petSelected = this.pets[+(e.target.value)]; }}>
                    <option value="">Escolha um pet</option>
                    ${this.pets.map((pet, index) => html `<option value="${index}">${pet.data.registrationData.name}</option>`)}
                </select>
            </div>
            <div class="form-group">
                <label for="date-select">Data</label>
                <input type="datetime-local" id="date-select" value="2025-10-15" @input=${(e) => { this.date = e.target.value; }}
            </div>
            <div class="form-group">
                <label for="service-select">Serviço</label>
                <select id="service-select" @change=${(e) => { this.serviceSelected = this.services[+(e.target.value)]; }}>
                    <option value="">Escolha um serviço</option>
                    ${this.services.map((pet, index) => html `<option value="${index}">${pet.data.registrationData.name}</option>`)}
                </select>
            </div>
            <div class="form-actions">
                <button class="btn btn-back" @click="${this.handleBack}">Voltar</button>
                <button class="btn btn-save" @click=${this.handleSave} ?disabled=${this.loading}>
                    Agendar
                    ${this.loading ? html `<span class="loading"></span>` : html ``}
                </button>
                <a id="link-back" style="display:none" href="/pageAdminDashboard"></a>
                
            </div>
            ${this.labelError ? html `<span class="error-message">${this.labelError}</span>` : ''}

            </section>
`;
    }
    async handleContinue(user) {
        await this.getMyPets(user);
        this.userSelected = user;
        this.currentStep = 'scheduling';
    }
    handleBack() {
        this.currentStep = 'user-selection';
    }
    async getMyPets(user) {
        if (!user) {
            this.labelError = 'Falta parametros para pegar os pets';
            return;
        }
        const ids = [];
        if (user.data.relationships) {
            user.data.relationships.forEach((r) => {
                if (r.type === 'R_PF_OWNER_OF_PET')
                    ids.push(r.relatedMdmId);
            });
        }
        const req = {
            action: 'MDMGetListByIds',
            inDeveloped: true,
            version: '1',
            params: { ids }
        };
        const response = await exec(req);
        if (!response.ok) {
            this.labelError = response.error;
            this.loading = false;
            return;
        }
        this.pets = response.data.filter((item) => item != null);
    }
    async getServices() {
        const req = {
            action: 'MDMGetListByType',
            inDeveloped: true,
            version: '1',
            params: { type: MdmType.Servico }
        };
        const response = await exec(req);
        if (!response.ok) {
            this.labelError = response.error;
            this.loading = false;
            return;
        }
        this.services = response.data.filter((item) => item != null);
    }
    async handleSave() {
        this.labelError = '';
        if (!this.userSelected) {
            this.labelError = 'Nenhum cliente selecionado!';
            return;
        }
        if (!this.petSelected) {
            this.labelError = 'Pet obrigatório.';
            return;
        }
        if (!this.serviceSelected) {
            this.labelError = 'Selecione um serviço';
            return;
        }
        if (!this.date) {
            this.labelError = 'Informe uma data';
            return;
        }
        this.loading = true;
        let phoneClient = '';
        if (this.userSelected.data.contactData && this.userSelected.data.contactData.phone) {
            phoneClient = this.userSelected.data.contactData.phone[0].number;
        }
        const params = {
            data: {
                clientMdmId: this.userSelected.id || '',
                petMdmId: this.petSelected.id || '',
                serviceMdmId: this.serviceSelected.id || '',
                startDateTime: new Date(this.date || '').toISOString(),
                status: SchedulingStatus.PENDING,
                serviceOrderId: null,
                jsonBin: {
                    tutor: {
                        name: this.userSelected.data.registrationData.name,
                        phone: phoneClient,
                    },
                    pet: {
                        name: this.petSelected.data.registrationData.name,
                        species: this.petSelected.data.registrationData.species,
                        breed: this.petSelected.data.registrationData.breed,
                        allergies: [],
                    },
                    service: {
                        name: this.serviceSelected.data.registrationData.name,
                        serviceCode: this.serviceSelected.data.registrationData.serviceCode,
                    },
                },
            }
        };
        const req = {
            action: 'SchedulingAdd',
            inDeveloped: true,
            version: '1',
            params,
        };
        const response = await petshopExec(req);
        if (!response.ok) {
            this.labelError = response.error || 'Error';
            this.loading = false;
            return;
        }
        this.loading = false;
        if (this.link)
            this.link.click();
    }
    async handleSearch() {
        this.labelError = '';
        this.loading = true;
        const req = {
            action: 'MDMGetList',
            inDeveloped: true,
            version: '1',
            params: { filter: this.searchText || '' }
        };
        const mdm = await exec(req);
        if (!mdm.ok) {
            this.labelError = mdm.error || 'Erro';
            this.loading = false;
            return;
        }
        if (!mdm.data) {
            this.labelError = 'Mdm nao encontrado';
            this.loading = false;
            return;
        }
        this.users = mdm.data.filter((item) => item.data.type === MdmType.PessoaFisica);
        this.loading = false;
    }
};
__decorate([
    state()
], organismAdminScheduling.prototype, "loading", void 0);
__decorate([
    propertyDataSource()
], organismAdminScheduling.prototype, "labelError", void 0);
__decorate([
    propertyDataSource()
], organismAdminScheduling.prototype, "labelOk", void 0);
__decorate([
    propertyDataSource()
], organismAdminScheduling.prototype, "searchText", void 0);
__decorate([
    propertyDataSource()
], organismAdminScheduling.prototype, "userSelected", void 0);
__decorate([
    propertyDataSource()
], organismAdminScheduling.prototype, "petSelected", void 0);
__decorate([
    propertyDataSource()
], organismAdminScheduling.prototype, "serviceSelected", void 0);
__decorate([
    propertyDataSource()
], organismAdminScheduling.prototype, "date", void 0);
__decorate([
    propertyDataSource()
], organismAdminScheduling.prototype, "action", void 0);
__decorate([
    state()
], organismAdminScheduling.prototype, "users", void 0);
__decorate([
    state()
], organismAdminScheduling.prototype, "pets", void 0);
__decorate([
    state()
], organismAdminScheduling.prototype, "services", void 0);
__decorate([
    state()
], organismAdminScheduling.prototype, "currentStep", void 0);
__decorate([
    query('#link-back')
], organismAdminScheduling.prototype, "link", void 0);
organismAdminScheduling = __decorate([
    customElement('petshop--organism-admin-scheduling-102009')
], organismAdminScheduling);
export { organismAdminScheduling };
