/// <mls shortName="organismAdminSidebar" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAdminSidebar = class organismAdminSidebar extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-sidebar-102009 .admin-sidebar{background:var(--bg-secondary-color-lighter);padding:var(--space-24) var(--space-16);min-width:220px;font-family:var(--font-family-primary);border-right:1px solid var(--grey-color)}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__title{font-size:var(--font-size-16);color:var(--text-primary-color-darker);margin-bottom:var(--space-16);font-weight:var(--font-weight-bold)}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__shortcuts{list-style:none;margin:0 0 var(--space-24) 0;padding:0}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__shortcuts .admin-sidebar__shortcut{display:flex;align-items:center;justify-content:space-between;color:var(--text-primary-color);text-decoration:none;padding:var(--space-8) var(--space-8);border-radius:4px;margin-bottom:var(--space-8);transition:background var(--transition-slow)}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__shortcuts .admin-sidebar__shortcut:hover,petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__shortcuts .admin-sidebar__shortcut:focus{background:var(--bg-primary-color-hover);color:var(--text-primary-color-darker)}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__badge{display:inline-block;padding:0 var(--space-8);border-radius:12px;font-size:var(--font-size-12);font-weight:var(--font-weight-bold)}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__badge--info{background:var(--bg-primary-color-darker);color:var(--text-primary-color-lighter)}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__badge--success{background:var(--bg-secondary-color);color:var(--text-secondary-color-darker)}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__badge--warning{background:var(--warning-color);color:#fff}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__status{margin-top:var(--space-24)}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__status-list{list-style:none;margin:0;padding:0}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__status-list .admin-sidebar__status-label{color:var(--text-primary-color);font-size:var(--font-size-12)}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__status-list .admin-sidebar__status-value{margin-left:var(--space-8)}petshop--organism-admin-sidebar-102009 .admin-sidebar .admin-sidebar__status-list li{display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--space-8)}@media (max-width:768px){petshop--organism-admin-sidebar-102009 .admin-sidebar{min-width:100%;border-right:none;border-bottom:1px solid var(--grey-color)}}`);
    }
    render() {
        return html `<aside class="admin-sidebar" id="petshop--admin-sidebar-102009-1">
        <div class="admin-sidebar__quick" id="petshop--admin-sidebar-102009-2">
          <h3 class="admin-sidebar__title" id="petshop--admin-sidebar-102009-3">Atalhos</h3>
          <ul class="admin-sidebar__shortcuts" id="petshop--admin-sidebar-102009-4">
            <li id="petshop--admin-sidebar-102009-5"><a href="#bookings" class="admin-sidebar__shortcut" id="petshop--admin-sidebar-102009-6">Agendamentos <span class="admin-sidebar__badge admin-sidebar__badge--info" id="petshop--admin-sidebar-102009-7">3 novos</span></a></li>
            <li id="petshop--admin-sidebar-102009-8"><a href="#products" class="admin-sidebar__shortcut" id="petshop--admin-sidebar-102009-9">Produtos <span class="admin-sidebar__badge admin-sidebar__badge--success" id="petshop--admin-sidebar-102009-10">12 ativos</span></a></li>
            <li id="petshop--admin-sidebar-102009-11"><a href="#content" class="admin-sidebar__shortcut" id="petshop--admin-sidebar-102009-12">Conteúdo</a></li>
          </ul>
        </div>
        <div class="admin-sidebar__status" id="petshop--admin-sidebar-102009-13">
          <h3 class="admin-sidebar__title" id="petshop--admin-sidebar-102009-14">Status</h3>
          <ul class="admin-sidebar__status-list" id="petshop--admin-sidebar-102009-15">
            <li id="petshop--admin-sidebar-102009-16">
              <span class="admin-sidebar__status-label" id="petshop--admin-sidebar-102009-17">Agendamentos pendentes</span>
              <span class="admin-sidebar__status-value admin-sidebar__badge admin-sidebar__badge--warning" id="petshop--admin-sidebar-102009-18">2</span>
            </li>
            <li id="petshop--admin-sidebar-102009-19">
              <span class="admin-sidebar__status-label" id="petshop--admin-sidebar-102009-20">Pedidos em andamento</span>
              <span class="admin-sidebar__status-value admin-sidebar__badge admin-sidebar__badge--info" id="petshop--admin-sidebar-102009-21">1</span>
            </li>
          </ul>
        </div>
      </aside>
    `;
    }
};
organismAdminSidebar = __decorate([
    customElement('petshop--organism-admin-sidebar-102009')
], organismAdminSidebar);
export { organismAdminSidebar };
