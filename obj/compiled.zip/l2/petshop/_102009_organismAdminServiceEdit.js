var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismAdminServiceEdit" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { getState } from '_100554_/l2/collabState';
import { propertyDataSource } from './_100554_collabDecorators';
import { exec } from "./_102019_layer1Exec";
let organismAdminServiceEdit = class organismAdminServiceEdit extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-admin-service-edit-102009{display:block;padding:var(--space-24);background-color:var(--bg-primary-color)}`);
        this.loading = false;
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        const data = getState('ui.petshop.admin.service.selected');
        this.mdmData = data;
    }
    render() {
        return html `<div class="form-container" id="petshop--organism-admin-service-edit-102009-1"
>
<h2 id="petshop--organism-admin-service-edit-102009-2">Editar Serviço</h2>
<section id="petshop--organism-admin-service-edit-102009-3">
<div class="form-group" id="petshop--organism-admin-service-edit-102009-5">
<label for="name" id="petshop--organism-admin-service-edit-102009-6">Nome</label>
<input
  type="text"
  id="name"
  name="name"
  required
  id="petshop--organism-admin-service-edit-102009-7"
  ?disabled=${this.loading}
  .value=${this.nameService || ''}
  @input=${this.handleInputChange}
>
</div>
<div class="form-group" id="petshop--organism-admin-service-edit-102009-8">
<label for="descriptionShort" id="petshop--organism-admin-service-edit-102009-9">Descrição Curta</label>
<textarea id="descriptionShort" name="descriptionShort" required id="petshop--organism-admin-service-edit-102009-10"
  .value=${this.descriptionShort || ''}
  @input=${this.handleInputChange}
></textarea>
</div>
<div class="form-group" id="petshop--organism-admin-service-edit-102009-11">
<label for="serviceCode" id="petshop--organism-admin-service-edit-102009-12">Código do Serviço</label>
<input type="text" id="serviceCode" name="serviceCode" required id="petshop--organism-admin-service-edit-102009-13"
  .value=${this.serviceCode || ''}
  @input=${this.handleInputChange}
>
</div>
</section>
<section id="petshop--organism-admin-service-edit-102009-14">
<div class="form-group" id="petshop--organism-admin-service-edit-102009-16">
<label for="category" id="petshop--organism-admin-service-edit-102009-17">Categoria</label>
<select id="category" name="category" id="petshop--organism-admin-service-edit-102009-18"
  .value=${this.category || ''}
  @change=${this.handleInputChange}
>
<option value="banho-tosa" id="petshop--organism-admin-service-edit-102009-19">Banho & Tosa</option>
<option value="consulta" id="petshop--organism-admin-service-edit-102009-20">Consulta</option>
</select>
</div>
<div class="form-group" id="petshop--organism-admin-service-edit-102009-21">
<label for="priceRegular" id="petshop--organism-admin-service-edit-102009-22">Preço Regular</label>
<input type="number" id="priceRegular" name="priceRegular" step="0.01" required id="petshop--organism-admin-service-edit-102009-23"
  .value=${this.priceRegular || ''}
  @input=${this.handleInputChange}
>
</div>
<div class="form-group" id="petshop--organism-admin-service-edit-102009-24">
<label for="priceSubscription" id="petshop--organism-admin-service-edit-102009-25">Preço Assinatura</label>
<input type="number" id="priceSubscription" name="priceSubscription" step="0.01" id="petshop--organism-admin-service-edit-102009-26"
  .value=${this.priceSubscription || ''}
  @input=${this.handleInputChange}
>
</div>
<div class="form-group" id="petshop--organism-admin-service-edit-102009-27">
<label for="durationMinutes" id="petshop--organism-admin-service-edit-102009-28">Duração (minutos)</label>
<input type="number" id="durationMinutes" name="durationMinutes" required id="petshop--organism-admin-service-edit-102009-29"
  .value=${this.durationMinutes || ''}
  @input=${this.handleInputChange}
>
</div>
<div class="form-group" id="petshop--organism-admin-service-edit-102009-30">
<label for="speciesSuitability" id="petshop--organism-admin-service-edit-102009-31">Adequação a Espécies</label>
<input type="text" id="speciesSuitability" name="speciesSuitability" id="petshop--organism-admin-service-edit-102009-32"
  .value=${this.speciesSuitability ? this.speciesSuitability.join(', ') : ''}
  @input=${this.handleInputChange}
>
</div>
<div class="form-group" id="petshop--organism-admin-service-edit-102009-35">
<label for="sizeSuitability" id="petshop--organism-admin-service-edit-102009-36">Adequação a Tamanhos</label>
<input type="text" id="sizeSuitability" name="sizeSuitability" id="petshop--organism-admin-service-edit-102009-37"
  .value=${this.sizeSuitability ? this.sizeSuitability.join(', ') : ''}
  @input=${this.handleInputChange}
>
</div>
<div class="form-group" id="petshop--organism-admin-service-edit-102009-41">
<label for="requiredResources" id="petshop--organism-admin-service-edit-102009-42">Recursos Necessários</label>
<input type="text" id="requiredResources" name="requiredResources" id="petshop--organism-admin-service-edit-102009-43"
  .value=${this.requiredResources ? this.requiredResources.join(', ') : ''}
  @input=${this.handleInputChange}
>
</div>
<div class="form-group" id="petshop--organism-admin-service-edit-102009-46">
<label for="employeeCommission" id="petshop--organism-admin-service-edit-102009-47">Comissão do Funcionário</label>
<input type="number" id="employeeCommission" name="employeeCommission" step="0.01" min="0" max="1" id="petshop--organism-admin-service-edit-102009-48"
  .value=${this.employeeCommission || ''}
  @input=${this.handleInputChange}
>
</div>
</section>
    <div class="form-actions">
            <a id="link-back" href="/pageAdminService" class="btn btn-back" ?disabled=${this.loading}>Voltar</a>
            <button class="btn-save" @click=${this.handleClickSave} ?disabled=${this.loading}>
            Salvar
                ${this.loading ? html `<span class="loading"></span>` : html ``}
            </button>
    </div>
    ${this.labelError ? html `<span class="error-message">${this.labelError}</span>` : ''}
`;
    }
    handleInputChange(event) {
        const target = event.target;
        const { id, value } = target;
        switch (id) {
            case 'name':
                this.nameService = value;
                break;
            case 'descriptionShort':
                this.descriptionShort = value;
                break;
            case 'serviceCode':
                this.serviceCode = value;
                break;
            case 'category':
                this.category = value;
                break;
            case 'priceRegular':
                this.priceRegular = value;
                break;
            case 'priceSubscription':
                this.priceSubscription = value;
                break;
            case 'durationMinutes':
                this.durationMinutes = value;
                break;
            case 'speciesSuitability':
                // Parse comma-separated values into array
                this.speciesSuitability = value.split(',').map(s => s.trim()).filter(s => s);
                break;
            case 'sizeSuitability':
                // Parse comma-separated values into array
                this.sizeSuitability = value.split(',').map(s => s.trim()).filter(s => s);
                break;
            case 'requiredResources':
                // Parse comma-separated values into array
                this.requiredResources = value.split(',').map(s => s.trim()).filter(s => s);
                break;
            case 'employeeCommission':
                this.employeeCommission = value;
                break;
            default:
                break;
        }
    }
    // New handler for multiple selects
    handleSelectMultipleChange(event) {
        const target = event.target;
        const { id } = target;
        const selectedOptions = Array.from(target.selectedOptions).map(option => option.value);
        switch (id) {
            case 'speciesSuitability':
                this.speciesSuitability = selectedOptions;
                break;
            case 'sizeSuitability':
                this.sizeSuitability = selectedOptions;
                break;
            case 'requiredResources':
                this.requiredResources = selectedOptions;
                break;
            default:
                break;
        }
    }
    clearErrors() {
        this.labelError = '';
        this.labelOk = '';
    }
    async handleClickSave() {
        this.clearErrors();
        let hasErrors = false;
        if (!this.nameService) {
            this.labelError = 'Nome do serviço é obrigatório.';
            hasErrors = true;
        }
        else if (!this.descriptionShort) {
            this.labelError = 'Descrição do serviço é obrigatório.';
            hasErrors = true;
        }
        if (!hasErrors) {
            this.loading = true;
            const dataToUpd = { ...this.mdmData };
            const rgData = dataToUpd.data?.registrationData;
            rgData.name = this.nameService || '';
            rgData.descriptionShort = this.descriptionShort || '';
            rgData.serviceCode = this.serviceCode || '';
            if (!dataToUpd.data.serviceData) {
                dataToUpd.data.serviceData = {
                    category: '',
                    durationMinutes: 0,
                    priceRegular: 0,
                    employeeCommission: 0,
                    priceSubscription: 0,
                    requiredResources: [],
                    sizeSuitability: [],
                    speciesSuitability: []
                };
            }
            dataToUpd.data.serviceData.category = this.category || '';
            dataToUpd.data.serviceData.durationMinutes = +(this.durationMinutes || 0);
            dataToUpd.data.serviceData.priceRegular = +(this.priceRegular || 0);
            dataToUpd.data.serviceData.employeeCommission = +(this.employeeCommission || 0);
            dataToUpd.data.serviceData.priceSubscription = +(this.priceSubscription || 0);
            dataToUpd.data.serviceData.requiredResources = this.requiredResources || [];
            dataToUpd.data.serviceData.sizeSuitability = this.sizeSuitability || [];
            dataToUpd.data.serviceData.speciesSuitability = this.speciesSuitability || [];
            const params = dataToUpd;
            const req = {
                action: 'MDMUpd',
                inDeveloped: true,
                version: '1',
                params,
            };
            const response = await exec(req);
            if (!response.ok) {
                this.labelError = response.error;
                this.loading = false;
                return;
            }
            this.loading = false;
            this.labelOk = 'Cadastro atualizado com sucesso';
            if (this.link) {
                this.link.click();
            }
        }
    }
};
__decorate([
    state()
], organismAdminServiceEdit.prototype, "loading", void 0);
__decorate([
    state()
], organismAdminServiceEdit.prototype, "mdmData", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "nameService", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "descriptionShort", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "serviceCode", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "category", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "priceRegular", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "priceSubscription", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "durationMinutes", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "speciesSuitability", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "sizeSuitability", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "requiredResources", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "employeeCommission", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "labelError", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "labelOk", void 0);
__decorate([
    propertyDataSource()
], organismAdminServiceEdit.prototype, "action", void 0);
__decorate([
    query('#link-back')
], organismAdminServiceEdit.prototype, "link", void 0);
organismAdminServiceEdit = __decorate([
    customElement('petshop--organism-admin-service-edit-102009')
], organismAdminServiceEdit);
export { organismAdminServiceEdit };
