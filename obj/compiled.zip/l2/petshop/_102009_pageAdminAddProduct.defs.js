"use strict";
/// <mls shortName="pageAdminAddProduct" project="102009" enhancement="_blank" folder="petshop" />
