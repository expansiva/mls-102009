/// <mls shortName="organismAdminOrderEdit" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { getState } from '_100554_/l2/collabState';
import { propertyDataSource } from './_100554_collabDecorators';
import { exec } from "./_102019_layer1Exec";
import { MdmType } from "./_102019_layer4Mdm";
let organismAdminOrderEdit = class organismAdminOrderEdit extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        this.loading = false;
        this.employees = [];
    }
    async firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        const data = getState('ui.petshop.admin.order.selected');
        this.orderData = data;
        const serviceId = data.data.serviceMdmId;
        await this.getService(serviceId);
        await this.getEmployers();
    }
    render() {
        return html `
        <div class="form-container">
            <h2>Editar Ordem de Serviço</h2>
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" @change=${this.onChangeStatus}>
                    <option value="IN_PROGRESS">Em Andamento</option>
                    <option value="READY_FOR_COLLECTION">Pronto para Retirada</option>
                    <option value="BILLED">Faturado</option>
                    <option value="CANCELED">Cancelado</option>
                </select>
            </div>
            <div class="form-group">
                <label for="service">Serviço</label>
                <input type="text" id="service" value=${this.service?.data.registrationData?.name} readonly >
            </div>
            <div class="form-group">
                <label for="pet">Pet</label>
                <input type="text" id="pet" value="${this.orderData?.data.jsonBin.pet.name}" readonly>
            </div>
            <div class="form-group">
                <label for="client">Cliente</label>
                <input type="text" id="client" value="${this.orderData?.data.jsonBin.client.name}" readonly>
            </div>
            <div class="form-group">
                <label for="employee">Funcionário</label>
                <select id="employees"
                    ?disabled=${this.loading}
                    value=${this.employees.findIndex((item) => item.id === this.orderData?.data.employeeMdmId)}
                    @change=${(e) => this.onChangeEmployer}
                >
                    ${this.employees.map((item, index) => {
            const name = item.data.type === MdmType.PessoaFisica ? item.data.registrationData.name : item.data.registrationData.fantasyName;
            return html `<option value=${index}> ${name}</option>`;
        })}
                </select>
            </div>
            <div class="form-group">
                <label for="value">Valor</label>
                <input
                    type="number"
                    id="value"
                    value=${this.orderData?.data.totalAmount}
                    @change=${this.onChangeBilling}
                >
            </div>
            <div class="form-actions">
                <button class="btn btn-back">Voltar</button>
                <button class="btn btn-save">Salvar</button>
            </div>
        </div>`;
    }
    onChangeStatus(e) {
        const value = e.target.value;
        if (!this.orderData)
            return;
        this.orderData.data.status = value;
    }
    onChangeBilling(e) {
        const value = e.target.value;
        if (!this.orderData)
            return;
        this.orderData.data.totalAmount = Number.parseFloat(value);
    }
    onChangeEmployer(e) {
        const value = e.target.value;
        if (!this.orderData)
            return;
        const selected = this.employees[+value];
        if (!selected || !selected.id)
            return;
        this.orderData.data.employeeMdmId = selected.id;
        const name = selected.data.type === MdmType.PessoaFisica ? selected.data.registrationData.name : selected.data.registrationData.fantasyName;
        this.orderData.data.jsonBin.employee.name = name;
    }
    async getService(id) {
        const req = {
            action: 'MDMGetById',
            inDeveloped: true,
            version: '1',
            params: { id }
        };
        const response = await exec(req);
        if (!response.ok) {
            this.labelError = response.error || 'Não encontrado informações do serviço';
            return;
        }
        this.service = response.data;
    }
    async getEmployers() {
        const ids = [];
        if (!this.service) {
            this.labelError = 'Não encontrado informações do serviço';
            return;
        }
        if (this.service.data.relationships) {
            this.service.data.relationships.forEach((r) => {
                ids.push(r.relatedMdmId);
            });
        }
        const req = {
            action: 'MDMGetListByIds',
            inDeveloped: true,
            version: '1',
            params: { ids }
        };
        const response = await exec(req);
        if (!response.ok) {
            this.labelError = response.error;
            return;
        }
        this.employees = response.data.filter((item) => item != null);
    }
};
__decorate([
    state()
], organismAdminOrderEdit.prototype, "loading", void 0);
__decorate([
    state()
], organismAdminOrderEdit.prototype, "orderData", void 0);
__decorate([
    state()
], organismAdminOrderEdit.prototype, "employees", void 0);
__decorate([
    state()
], organismAdminOrderEdit.prototype, "service", void 0);
__decorate([
    propertyDataSource()
], organismAdminOrderEdit.prototype, "labelError", void 0);
__decorate([
    propertyDataSource()
], organismAdminOrderEdit.prototype, "labelOk", void 0);
__decorate([
    propertyDataSource()
], organismAdminOrderEdit.prototype, "action", void 0);
organismAdminOrderEdit = __decorate([
    customElement('petshop--organism-admin-order-edit-102009')
], organismAdminOrderEdit);
export { organismAdminOrderEdit };
