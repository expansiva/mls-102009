/// <mls shortName="organismFeaturedServices" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
import { exec } from "./_102019_layer1Exec";
import { MdmType } from "./_102019_commonGlobal";
let organismFeaturedServices = class organismFeaturedServices extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-featured-services-102009{background:var(--bg-primary-color);padding:var(--space-48) 0;display:block}petshop--organism-featured-services-102009 .services-container{max-width:1100px;margin:0 auto;display:flex;flex-direction:column;align-items:center}petshop--organism-featured-services-102009 h2{color:var(--text-primary-color);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:var(--space-32);text-align:center}petshop--organism-featured-services-102009 .services-list{display:flex;gap:var(--space-40);flex-wrap:wrap;justify-content:center;width:100%}petshop--organism-featured-services-102009 .service-card{background:var(--bg-secondary-color-lighter);border-radius:16px;box-shadow:0 2px 8px var(--grey-color-light);padding:var(--space-24);display:flex;flex-direction:column;align-items:center;width:220px;min-height:220px;text-align:center;transition:box-shadow var(--transition-normal)}petshop--organism-featured-services-102009 .service-card:hover,petshop--organism-featured-services-102009 .service-card:focus{box-shadow:0 4px 16px var(--grey-color)}petshop--organism-featured-services-102009 .service-card .icon{width:48px;height:48px;margin-bottom:var(--space-16);display:flex;align-items:center;justify-content:center;background:var(--bg-primary-color-lighter);border-radius:50%;transition:background var(--transition-normal)}petshop--organism-featured-services-102009 .service-card .icon svg{width:32px;height:32px;color:var(--text-secondary-color)}petshop--organism-featured-services-102009 .service-card .service-title{font-size:var(--font-size-16);font-weight:var(--font-weight-bold);color:var(--text-primary-color-darker);margin-bottom:var(--space-8)}petshop--organism-featured-services-102009 .service-card .service-desc{font-size:var(--font-size-12);color:var(--text-primary-color-lighter);line-height:var(--line-height-medium)}petshop--organism-featured-services-102009 .product-action{margin-top:auto}petshop--organism-featured-services-102009 .product-action a{display:inline-block;background:var(--text-primary-color);color:var(--bg-primary-color);font-size:var(--font-size-12);font-weight:var(--font-weight-bold);padding:var(--space-8) var(--space-16);border-radius:24px;text-decoration:none;transition:background var(--transition-normal),color var(--transition-normal)}petshop--organism-featured-services-102009 .product-action a:hover,petshop--organism-featured-services-102009 .product-action a:focus{background:var(--text-primary-color-hover);color:var(--bg-primary-color)}@media (max-width:768px){petshop--organism-featured-services-102009 .services-list{gap:var(--space-16)}petshop--organism-featured-services-102009 .service-card{width:160px;min-height:160px;padding:var(--space-16)}}@media (max-width:544px){petshop--organism-featured-services-102009 .services-list{gap:var(--space-8)}petshop--organism-featured-services-102009 .service-card{width:120px;min-height:120px;padding:var(--space-8)}petshop--organism-featured-services-102009 .service-card .icon{width:36px;height:36px}petshop--organism-featured-services-102009 .service-card .icon svg{width:24px;height:24px}}`);
        this.mdmServices = [];
    }
    //--------------------------------
    async firstUpdated() {
        this.init();
    }
    render() {
        return html `
    <div class="services-container">
      <h2>Nossos principais serviços</h2>
      <div class="services-list">
        ${this.mdmServices.map((serv, index) => this.renderItem(serv, index))}
      </div>
    </div>
      `;
    }
    renderItem(serv, index) {
        if (index > 3)
            return html ``;
        const reg = serv.details.registrationData;
        return html `
    <div class="service-card">
      <div class="icon">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3a2 2 0 1 1 0 4a2 2 0 0 1 0-4zm0 14.2c-2.5 0-4.71-1.28-6-3.22c.03-1.99 4-3.08 6-3.08s5.97 1.09 6 3.08c-1.29 1.94-3.5 3.22-6 3.22z" fill="#1C91CD"></path></svg>
      </div>
      <div class="service-title">${reg.name}</div>
      <div class="service-desc">${reg.descriptionShort}</div>
      <div class="product-action">
          <a href="/pageAppointments">Agendar</a>
        </div>
    </div>

    `;
    }
    //-------------------------
    init() {
        this.loadServ();
    }
    async loadServ() {
        const req = {
            action: 'MDMGetListByType',
            inDeveloped: true,
            version: '1',
            params: { type: MdmType.Servico },
        };
        const response = await exec(req);
        if (response.ok) {
            this.mdmServices = response.data.map((item) => {
                const item2 = item;
                return item2;
            });
        }
    }
};
__decorate([
    state()
], organismFeaturedServices.prototype, "mdmServices", void 0);
organismFeaturedServices = __decorate([
    customElement('petshop--organism-featured-services-102009')
], organismFeaturedServices);
export { organismFeaturedServices };
