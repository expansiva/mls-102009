/// <mls shortName="organismFeaturedServices" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismFeaturedServices = class organismFeaturedServices extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-featured-services-102009{background:var(--bg-primary-color);padding:var(--space-48) 0;display:block}petshop--organism-featured-services-102009 .services-container{max-width:1100px;margin:0 auto;display:flex;flex-direction:column;align-items:center}petshop--organism-featured-services-102009 h2{color:var(--text-primary-color);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);margin-bottom:var(--space-32);text-align:center}petshop--organism-featured-services-102009 .services-list{display:flex;gap:var(--space-40);flex-wrap:wrap;justify-content:center;width:100%}petshop--organism-featured-services-102009 .service-card{background:var(--bg-secondary-color-lighter);border-radius:16px;box-shadow:0 2px 8px var(--grey-color-light);padding:var(--space-24);display:flex;flex-direction:column;align-items:center;width:220px;min-height:220px;text-align:center;transition:box-shadow var(--transition-normal)}petshop--organism-featured-services-102009 .service-card:hover,petshop--organism-featured-services-102009 .service-card:focus{box-shadow:0 4px 16px var(--grey-color)}petshop--organism-featured-services-102009 .service-card .icon{width:48px;height:48px;margin-bottom:var(--space-16);display:flex;align-items:center;justify-content:center;background:var(--bg-primary-color-lighter);border-radius:50%;transition:background var(--transition-normal)}petshop--organism-featured-services-102009 .service-card .icon svg{width:32px;height:32px;color:var(--text-secondary-color)}petshop--organism-featured-services-102009 .service-card .service-title{font-size:var(--font-size-16);font-weight:var(--font-weight-bold);color:var(--text-primary-color-darker);margin-bottom:var(--space-8)}petshop--organism-featured-services-102009 .service-card .service-desc{font-size:var(--font-size-12);color:var(--text-primary-color-lighter);line-height:var(--line-height-medium)}@media (max-width:768px){petshop--organism-featured-services-102009 .services-list{gap:var(--space-16)}petshop--organism-featured-services-102009 .service-card{width:160px;min-height:160px;padding:var(--space-16)}}@media (max-width:544px){petshop--organism-featured-services-102009 .services-list{gap:var(--space-8)}petshop--organism-featured-services-102009 .service-card{width:120px;min-height:120px;padding:var(--space-8)}petshop--organism-featured-services-102009 .service-card .icon{width:36px;height:36px}petshop--organism-featured-services-102009 .service-card .icon svg{width:24px;height:24px}}`);
    }
    render() {
        return html `<div class="services-container" id="petshop--featured-services-102009-1">
          <h2 id="petshop--featured-services-102009-2">Nossos principais serviços</h2>
          <div class="services-list" id="petshop--featured-services-102009-3">
            <div class="service-card" id="petshop--featured-services-102009-4">
              <div class="icon" id="petshop--featured-services-102009-5">
                <svg viewBox="0 0 24 24" fill="currentColor" id="petshop--featured-services-102009-6"><circle cx="12" cy="12" r="10" id="petshop--featured-services-102009-7"></circle><path d="M12 7a2 2 0 1 1 0 4a2 2 0 0 1 0-4zm0 6c-2.21 0-4 1.79-4 4h8c0-2.21-1.79-4-4-4z" fill="#52C41A" id="petshop--featured-services-102009-8"></path></svg>
              </div>
              <div class="service-title" id="petshop--featured-services-102009-9">Banho &amp; Tosa</div>
              <div class="service-desc" id="petshop--featured-services-102009-10">Higiene, beleza e bem-estar para seu pet, com todo carinho.</div>
            </div>
            <div class="service-card" id="petshop--featured-services-102009-11">
              <div class="icon" id="petshop--featured-services-102009-12">
                <svg viewBox="0 0 24 24" fill="currentColor" id="petshop--featured-services-102009-13"><rect x="4" y="4" width="16" height="16" rx="8" id="petshop--featured-services-102009-14"></rect><path d="M12 8a4 4 0 1 1 0 8a4 4 0 0 1 0-8z" fill="#1C91CD" id="petshop--featured-services-102009-15"></path></svg>
              </div>
              <div class="service-title" id="petshop--featured-services-102009-16">Consultas Veterinárias</div>
              <div class="service-desc" id="petshop--featured-services-102009-17">Profissionais experientes para cuidar da saúde do seu pet.</div>
            </div>
            <div class="service-card" id="petshop--featured-services-102009-18">
              <div class="icon" id="petshop--featured-services-102009-19">
                <svg viewBox="0 0 24 24" fill="currentColor" id="petshop--featured-services-102009-20"><rect x="2" y="10" width="20" height="4" rx="2" id="petshop--featured-services-102009-21"></rect><circle cx="6" cy="12" r="2" fill="#52C41A" id="petshop--featured-services-102009-22"></circle><circle cx="18" cy="12" r="2" fill="#1C91CD" id="petshop--featured-services-102009-23"></circle></svg>
              </div>
              <div class="service-title" id="petshop--featured-services-102009-24">Vacinação</div>
              <div class="service-desc" id="petshop--featured-services-102009-25">Vacinas essenciais para cães, gatos e outros pets.</div>
            </div>
            <div class="service-card" id="petshop--featured-services-102009-26">
              <div class="icon" id="petshop--featured-services-102009-27">
                <svg viewBox="0 0 24 24" fill="currentColor" id="petshop--featured-services-102009-28"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3a2 2 0 1 1 0 4a2 2 0 0 1 0-4zm0 14.2c-2.5 0-4.71-1.28-6-3.22c.03-1.99 4-3.08 6-3.08s5.97 1.09 6 3.08c-1.29 1.94-3.5 3.22-6 3.22z" fill="#1C91CD" id="petshop--featured-services-102009-29"></path></svg>
              </div>
              <div class="service-title" id="petshop--featured-services-102009-30">Hotel &amp; Day Care</div>
              <div class="service-desc" id="petshop--featured-services-102009-31">Hospedagem e recreação para seu pet com segurança e diversão.</div>
            </div>
          </div>
        </div>
      `;
    }
};
organismFeaturedServices = __decorate([
    customElement('petshop--organism-featured-services-102009')
], organismFeaturedServices);
export { organismFeaturedServices };
