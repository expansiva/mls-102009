/// <mls shortName="organismProductFilters" project="102009" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismProductFilters = class organismProductFilters extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--organism-product-filters-102009{display:block;background:var(--bg-secondary-color-lighter);border-radius:8px;padding:var(--space-24);box-shadow:0 2px 8px rgba(230,230,230,0.1);font-family:var(--font-family-primary)}petshop--organism-product-filters-102009 h2{font-size:var(--font-size-20);color:var(--text-primary-color);margin-bottom:var(--space-16);font-weight:var(--font-weight-bold)}petshop--organism-product-filters-102009 form{display:flex;flex-direction:column;gap:var(--space-24)}petshop--organism-product-filters-102009 .filter-group{display:flex;flex-direction:column;gap:var(--space-8)}petshop--organism-product-filters-102009 .filter-group label{font-size:var(--font-size-16);color:var(--text-primary-color-darker);font-weight:var(--font-weight-normal);margin-bottom:var(--space-8)}petshop--organism-product-filters-102009 .filter-group select,petshop--organism-product-filters-102009 .filter-group input[type="range"]{padding:var(--space-8);border-radius:4px;border:1px solid var(--grey-color-dark);font-size:var(--font-size-16);background:var(--bg-primary-color);color:var(--text-primary-color-darker);transition:border-color var(--transition-normal)}petshop--organism-product-filters-102009 .filter-group select:focus,petshop--organism-product-filters-102009 .filter-group input[type="range"]:focus{border-color:var(--text-primary-color);outline:none}petshop--organism-product-filters-102009 .filter-group .range-values{display:flex;justify-content:space-between;font-size:var(--font-size-12);color:var(--text-primary-color-lighter);margin-top:var(--space-8)}petshop--organism-product-filters-102009 .filter-actions{display:flex;gap:var(--space-8);margin-top:var(--space-16)}petshop--organism-product-filters-102009 .filter-actions button{flex:1 1 0;padding:var(--space-8) var(--space-16);border-radius:4px;border:none;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-normal),color var(--transition-normal)}petshop--organism-product-filters-102009 .filter-actions button.apply{background:var(--text-primary-color);color:var(--bg-primary-color)}petshop--organism-product-filters-102009 .filter-actions button.apply:hover{background:var(--text-primary-color-hover)}petshop--organism-product-filters-102009 .filter-actions button.reset{background:var(--grey-color-light);color:var(--text-primary-color-darker)}petshop--organism-product-filters-102009 .filter-actions button.reset:hover{background:var(--grey-color)}`);
    }
    render() {
        return html `<h2 id="petshop--product-filters-102009-1">Filtrar Produtos</h2>
        <form id="petshop--product-filters-102009-2">
          <div class="filter-group" id="petshop--product-filters-102009-3">
            <label for="categoria" id="petshop--product-filters-102009-4">Categoria</label>
            <select id="categoria" name="categoria">
              <option value="" id="petshop--product-filters-102009-5">Todas</option>
              <option value="alimentos" id="petshop--product-filters-102009-6">Alimentos</option>
              <option value="brinquedos" id="petshop--product-filters-102009-7">Brinquedos</option>
              <option value="higiene" id="petshop--product-filters-102009-8">Higiene</option>
              <option value="acessorios" id="petshop--product-filters-102009-9">Acessórios</option>
            </select>
          </div>
          <div class="filter-group" id="petshop--product-filters-102009-10">
            <label for="tipo-pet" id="petshop--product-filters-102009-11">Tipo de Pet</label>
            <select id="tipo-pet" name="tipo-pet">
              <option value="" id="petshop--product-filters-102009-12">Todos</option>
              <option value="cao" id="petshop--product-filters-102009-13">Cão</option>
              <option value="gato" id="petshop--product-filters-102009-14">Gato</option>
              <option value="ave" id="petshop--product-filters-102009-15">Ave</option>
              <option value="outros" id="petshop--product-filters-102009-16">Outros</option>
            </select>
          </div>
          <div class="filter-group" id="petshop--product-filters-102009-17">
            <label for="preco" id="petshop--product-filters-102009-18">Preço</label>
            <input type="range" id="preco" name="preco" min="10" max="500" step="10" value="250">
            <div class="range-values" id="petshop--product-filters-102009-19">
              <span id="petshop--product-filters-102009-20">R$10</span>
              <span id="petshop--product-filters-102009-21">R$500</span>
            </div>
          </div>
          <div class="filter-actions" id="petshop--product-filters-102009-22">
            <button type="submit" class="apply" id="petshop--product-filters-102009-23">Aplicar</button>
            <button type="reset" class="reset" id="petshop--product-filters-102009-24">Limpar</button>
          </div>
        </form>
      `;
    }
};
organismProductFilters = __decorate([
    customElement('petshop--organism-product-filters-102009')
], organismProductFilters);
export { organismProductFilters };
