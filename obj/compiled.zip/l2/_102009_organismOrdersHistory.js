/// <mls shortName="organismOrdersHistory" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismOrdersHistory = class _102009_organismOrdersHistory extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-orders-history-102009 .orders-history-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-xl);margin-bottom:var(--spacing-xl);box-shadow:var(--shadow-sm)}organism-orders-history-102009 .orders-history-container .section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-lg)}organism-orders-history-102009 .orders-history-container .section-header h2{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin:0}organism-orders-history-102009 .orders-history-container .section-header .filter-options .filter-select{padding:var(--spacing-sm) var(--spacing-md);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);background:white;cursor:pointer}organism-orders-history-102009 .orders-history-container .orders-list .order-card{background:white;border-radius:var(--border-radius-md);padding:var(--spacing-lg);margin-bottom:var(--spacing-lg);box-shadow:var(--shadow-sm);transition:var(--transition-base)}organism-orders-history-102009 .orders-history-container .orders-list .order-card:hover{box-shadow:var(--shadow-md)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-md);padding-bottom:var(--spacing-sm);border-bottom:1px solid var(--color-border)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-header .order-number .label{color:var(--color-text-secondary);font-size:var(--font-size-sm);margin-right:var(--spacing-xs)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-header .order-number .number{font-weight:var(--font-weight-bold);color:var(--color-text-normal)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-header .order-date{color:var(--color-text-secondary);font-size:var(--font-size-sm)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-header .status-badge{padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);font-size:var(--font-size-xs);font-weight:var(--font-weight-bold)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-header .status-badge.entregue{background:var(--color-success);color:white}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-header .status-badge.transporte{background:var(--color-warning);color:white}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-header .status-badge.preparando{background:var(--color-secondary);color:white}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-items{margin-bottom:var(--spacing-md)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-items .order-item{display:flex;align-items:center;gap:var(--spacing-md);padding:var(--spacing-sm) 0;border-bottom:1px solid var(--color-border)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-items .order-item:last-child{border-bottom:none}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-items .order-item .item-image{width:60px;height:60px;border-radius:var(--border-radius-sm);object-fit:cover}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-items .order-item .item-info{flex:1}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-items .order-item .item-info h4{font-size:var(--font-size-md);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin:0 0 var(--spacing-xs) 0}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-items .order-item .item-info .item-details{color:var(--color-text-secondary);font-size:var(--font-size-sm);margin:0}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-footer{display:flex;justify-content:space-between;align-items:center;padding-top:var(--spacing-md);border-top:1px solid var(--color-border)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-footer .order-total .total-label{color:var(--color-text-secondary);margin-right:var(--spacing-xs)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-footer .order-total .total-value{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-footer .order-actions{display:flex;gap:var(--spacing-sm)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-footer .order-actions .btn-secondary{background:transparent;color:var(--color-text-secondary);border:1px solid var(--color-border);padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--border-radius-sm);cursor:pointer;transition:var(--transition-base)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-footer .order-actions .btn-secondary:hover{background:var(--color-surface);border-color:var(--color-primary)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-footer .order-actions .btn-primary{background:var(--color-primary);color:white;border:none;padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--border-radius-sm);cursor:pointer;transition:var(--transition-base)}organism-orders-history-102009 .orders-history-container .orders-list .order-card .order-footer .order-actions .btn-primary:hover{background:var(--color-link-hover)}`);
    }
    render() {
        return html `
      <div class="orders-history-container">
        <div class="section-header">
          <h2>Histórico de Compras</h2>
          <div class="filter-options">
            <select class="filter-select">
              <option value="todos">Todos os pedidos</option>
              <option value="entregue">Entregues</option>
              <option value="transporte">Em transporte</option>
              <option value="preparando">Preparando</option>
            </select>
          </div>
        </div>
        
        <div class="orders-list">
          <div class="order-card">
            <div class="order-header">
              <div class="order-number">
                <span class="label">Pedido</span>
                <span class="number">#12345</span>
              </div>
              <div class="order-date">20/07/2024</div>
              <div class="order-status">
                <span class="status-badge entregue">Entregue</span>
              </div>
            </div>
            <div class="order-items">
              <div class="order-item">
                <img src="https://images.unsplash.com/photo-1611443522715-3220344f1a37?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwZG9nJTIwZm9vZCUyMGJhZ3xlbnwwfHx8fDE3NTMyOTE4ODh8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Ração Premium" class="item-image">
                <div class="item-info">
                  <h4>Ração Premium Golden para Cães Adultos 15kg</h4>
                  <p class="item-details">Quantidade: 1 | R$ 89,90</p>
                </div>
              </div>
              <div class="order-item">
                <img src="https://images.unsplash.com/photo-1666374806301-babd33b758e5?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxyb3BlJTIwZG9nJTIwdG95fGVufDB8fHx8MTc1MzM2NTg3M3ww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Brinquedo" class="item-image">
                <div class="item-info">
                  <h4>Brinquedo Mordedor Corda</h4>
                  <p class="item-details">Quantidade: 2 | R$ 24,90</p>
                </div>
              </div>
            </div>
            <div class="order-footer">
              <div class="order-total">
                <span class="total-label">Total:</span>
                <span class="total-value">R$ 139,70</span>
              </div>
              <div class="order-actions">
                <button class="btn-secondary">Ver detalhes</button>
                <button class="btn-primary">Comprar novamente</button>
              </div>
            </div>
          </div>
          
          <div class="order-card">
            <div class="order-header">
              <div class="order-number">
                <span class="label">Pedido</span>
                <span class="number">#12344</span>
              </div>
              <div class="order-date">18/07/2024</div>
              <div class="order-status">
                <span class="status-badge transporte">Em transporte</span>
              </div>
            </div>
            <div class="order-items">
              <div class="order-item">
                <img src="https://images.unsplash.com/photo-1694709300885-6d902dbef98d?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxjYXQlMjBsaXR0ZXIlMjBiYWd8ZW58MHx8fHwxNzUzMzY1ODczfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Areia sanitária" class="item-image">
                <div class="item-info">
                  <h4>Areia Sanitária Aglomerante 4kg</h4>
                  <p class="item-details">Quantidade: 3 | R$ 45,90</p>
                </div>
              </div>
            </div>
            <div class="order-footer">
              <div class="order-total">
                <span class="total-label">Total:</span>
                <span class="total-value">R$ 137,70</span>
              </div>
              <div class="order-actions">
                <button class="btn-secondary">Rastrear pedido</button>
                <button class="btn-primary">Ver detalhes</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    }
};
_102009_organismOrdersHistory = __decorate([
    customElement('organism-orders-history-102009')
], _102009_organismOrdersHistory);
export { _102009_organismOrdersHistory };
