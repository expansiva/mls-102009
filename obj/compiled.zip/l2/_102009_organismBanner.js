/// <mls shortName="organismBanner" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismBanner = class _102009_organismBanner extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-banner-102009 .hero-banner{background:linear-gradient(135deg, var(--color-surface) 0%, var(--color-overlay) 100%);padding:var(--spacing-xxl) 0}organism-banner-102009 .banner-container{max-width:1200px;margin:0 auto;padding:0 var(--spacing-md);display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-xl);align-items:center}organism-banner-102009 .banner-content .banner-title{font-size:3rem;font-weight:var(--font-weight-bold);color:var(--color-primary);margin-bottom:var(--spacing-md);line-height:var(--line-height-sm)}organism-banner-102009 .banner-content .banner-subtitle{font-size:var(--font-size-lg);color:var(--color-text-secondary);margin-bottom:var(--spacing-xl);line-height:var(--line-height-lg)}organism-banner-102009 .banner-content .banner-actions{display:flex;gap:var(--spacing-md);flex-wrap:wrap}organism-banner-102009 .banner-image img{width:100%;height:auto;border-radius:var(--border-radius-lg);box-shadow:var(--shadow-lg)}@media (max-width:768px){organism-banner-102009 .banner-container{grid-template-columns:1fr;text-align:center}organism-banner-102009 .banner-content .banner-title{font-size:2rem}}`);
    }
    render() {
        return html `
      <section class="hero-banner">
        <div class="banner-container">
          <div class="banner-content">
            <h1 class="banner-title">Cuidado completo para seu melhor amigo</h1>
            <p class="banner-subtitle">Serviços veterinários, banho e tosa, produtos de qualidade e muito amor para seu pet</p>
            <div class="banner-actions">
              <button class="btn btn-primary">Agendar Serviço</button>
              <button class="btn btn-secondary">Ver Produtos</button>
            </div>
          </div>
          <div class="banner-image">
            <img src="https://images.unsplash.com/photo-1606098216818-40939b7c98ad?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGRvZ3MlMjBhbmQlMjBjYXRzJTIwYXQlMjBwZXQlMjBncm9vbWluZyUyMHNhbG9ufGVufDB8fHx8MTc1MzI5MTg4Nnww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Pets felizes no petshop">
          </div>
        </div>
      </section>
    `;
    }
};
_102009_organismBanner = __decorate([
    customElement('organism-banner-102009')
], _102009_organismBanner);
export { _102009_organismBanner };
