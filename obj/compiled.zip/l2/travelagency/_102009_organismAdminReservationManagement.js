/// <mls shortName="organismAdminReservationManagement" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAdminReservationManagement = class organismAdminReservationManagement extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-admin-reservation-management-102009 .admin-section{background:var(--bg-primary-color);border-radius:var(--space-8);margin-bottom:var(--space-32);padding:var(--space-24);box-shadow:0 2px 8px 0 rgba(211,211,211,0.1)}travelagency--organism-admin-reservation-management-102009 .admin-section .section-header{margin-bottom:var(--space-24)}travelagency--organism-admin-reservation-management-102009 .admin-section .section-header h2{font-size:var(--font-size-24);color:var(--text-primary-color);font-weight:var(--font-weight-bold)}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table{width:100%;border-collapse:collapse}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table th,travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table td{padding:var(--space-16);text-align:left;border-bottom:1px solid var(--grey-color)}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table th{color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);background:var(--bg-secondary-color-lighter)}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table .btn{margin-right:var(--space-8)}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table .btn.btn-small{padding:var(--space-8) var(--space-16);font-size:var(--font-size-12)}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table .btn.btn-secondary{background:var(--bg-secondary-color);color:var(--text-primary-color)}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table .btn.btn-secondary:hover{background:var(--bg-secondary-color-hover)}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table .btn.btn-danger{background:var(--error-color);color:#fff}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table .btn.btn-danger:hover{background:var(--error-color-hover)}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table .status-badge{display:inline-block;padding:0 var(--space-8);border-radius:var(--space-8);font-size:var(--font-size-12)}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table .status-badge.status-confirmed{background:var(--success-color);color:#fff}travelagency--organism-admin-reservation-management-102009 .admin-section .admin-table .status-badge.status-pending{background:var(--warning-color);color:#fff}`);
    }
    render() {
        return html `<section class="admin-section" id="travelagency--admin-reservation-management-102009-1">
        <div class="section-header" id="travelagency--admin-reservation-management-102009-2">
          <h2 id="travelagency--admin-reservation-management-102009-3">Gestão de Reservas</h2>
        </div>
        <table class="admin-table" id="travelagency--admin-reservation-management-102009-4">
          <thead id="travelagency--admin-reservation-management-102009-5">
            <tr id="travelagency--admin-reservation-management-102009-6">
              <th id="travelagency--admin-reservation-management-102009-7">Cliente</th>
              <th id="travelagency--admin-reservation-management-102009-8">Pacote</th>
              <th id="travelagency--admin-reservation-management-102009-9">Data da Reserva</th>
              <th id="travelagency--admin-reservation-management-102009-10">Status</th>
              <th id="travelagency--admin-reservation-management-102009-11">Ações</th>
            </tr>
          </thead>
          <tbody id="travelagency--admin-reservation-management-102009-12">
            <tr id="travelagency--admin-reservation-management-102009-13">
              <td id="travelagency--admin-reservation-management-102009-14">Lucas Silva</td>
              <td id="travelagency--admin-reservation-management-102009-15">Rio de Janeiro</td>
              <td id="travelagency--admin-reservation-management-102009-16">01/08/2025</td>
              <td id="travelagency--admin-reservation-management-102009-17"><span class="status-badge status-confirmed" id="travelagency--admin-reservation-management-102009-18">Confirmada</span></td>
              <td id="travelagency--admin-reservation-management-102009-19">
                <button class="btn btn-small btn-secondary" id="travelagency--admin-reservation-management-102009-20">Editar</button>
                <button class="btn btn-small btn-danger" id="travelagency--admin-reservation-management-102009-21">Excluir</button>
              </td>
            </tr>
            <tr id="travelagency--admin-reservation-management-102009-22">
              <td id="travelagency--admin-reservation-management-102009-23">Maria Souza</td>
              <td id="travelagency--admin-reservation-management-102009-24">Salvador</td>
              <td id="travelagency--admin-reservation-management-102009-25">05/08/2025</td>
              <td id="travelagency--admin-reservation-management-102009-26"><span class="status-badge status-pending" id="travelagency--admin-reservation-management-102009-27">Pendente</span></td>
              <td id="travelagency--admin-reservation-management-102009-28">
                <button class="btn btn-small btn-secondary" id="travelagency--admin-reservation-management-102009-29">Editar</button>
                <button class="btn btn-small btn-danger" id="travelagency--admin-reservation-management-102009-30">Excluir</button>
              </td>
            </tr>
          </tbody>
        </table>
      </section>
    `;
    }
};
organismAdminReservationManagement = __decorate([
    customElement('travelagency--organism-admin-reservation-management-102009')
], organismAdminReservationManagement);
export { organismAdminReservationManagement };
