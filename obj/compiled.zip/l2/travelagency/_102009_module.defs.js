"use strict";
/// <mls shortName="module" project="102009" enhancement="_blank" folder="travelagency" />
