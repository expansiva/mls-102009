/// <mls shortName="organismClientSidebar" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismClientSidebar = class organismClientSidebar extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-client-sidebar-102009{display:block;background:var(--bg-secondary-color-lighter);height:100%;min-width:220px;padding:var(--space-24) var(--space-16)}travelagency--organism-client-sidebar-102009 .sidebar-nav ul{list-style:none;margin:0;padding:0}travelagency--organism-client-sidebar-102009 .sidebar-nav ul li{margin-bottom:var(--space-16)}travelagency--organism-client-sidebar-102009 .sidebar-nav ul li a{display:flex;align-items:center;font-family:var(--font-family-primary);font-size:var(--font-size-16);color:var(--text-primary-color);text-decoration:none;padding:var(--space-8) var(--space-16);border-radius:4px;transition:background var(--transition-normal)}travelagency--organism-client-sidebar-102009 .sidebar-nav ul li a .icon{margin-right:var(--space-8);font-size:var(--font-size-20)}travelagency--organism-client-sidebar-102009 .sidebar-nav ul li a:hover{background:var(--bg-secondary-color);color:var(--text-secondary-color)}travelagency--organism-client-sidebar-102009 .sidebar-nav ul li.active a{background:var(--bg-secondary-color);color:var(--text-secondary-color);font-weight:var(--font-weight-bold)}`);
    }
    render() {
        return html `<nav class="sidebar-nav" id="travelagency--client-sidebar-102009-1">
          <ul id="travelagency--client-sidebar-102009-2">
            <li class="active" id="travelagency--client-sidebar-102009-3"><a href="#reservas" id="travelagency--client-sidebar-102009-4"><span class="icon" id="travelagency--client-sidebar-102009-5">📅</span> Minhas Reservas</a></li>
            <li id="travelagency--client-sidebar-102009-6"><a href="#avaliacoes" id="travelagency--client-sidebar-102009-7"><span class="icon" id="travelagency--client-sidebar-102009-8">⭐</span> Minhas Avaliações</a></li>
          </ul>
        </nav>
      `;
    }
};
organismClientSidebar = __decorate([
    customElement('travelagency--organism-client-sidebar-102009')
], organismClientSidebar);
export { organismClientSidebar };
