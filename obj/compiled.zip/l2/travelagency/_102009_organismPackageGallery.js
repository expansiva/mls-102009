/// <mls shortName="organismPackageGallery" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPackageGallery = class organismPackageGallery extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-package-gallery-102009 .package-gallery__container{background:var(--bg-secondary-color-lighter);border-radius:8px;padding:var(--space-24);margin-bottom:var(--space-40);display:flex;flex-direction:column;align-items:center;box-shadow:0 1px 4px var(--grey-color-dark)}travelagency--organism-package-gallery-102009 .package-gallery__main-image{width:100%;max-width:520px;height:320px;border-radius:8px;overflow:hidden;margin-bottom:var(--space-16);background:var(--grey-color-light);display:flex;align-items:center;justify-content:center}travelagency--organism-package-gallery-102009 .package-gallery__main-image img{width:100%;height:100%;object-fit:cover;border-radius:8px}travelagency--organism-package-gallery-102009 .package-gallery__thumbnails{display:flex;gap:var(--space-16);justify-content:center}travelagency--organism-package-gallery-102009 .package-gallery__thumb-btn{border:none;background:transparent;padding:0;cursor:pointer;border-radius:4px;transition:box-shadow var(--transition-slow)}travelagency--organism-package-gallery-102009 .package-gallery__thumb-btn:hover,travelagency--organism-package-gallery-102009 .package-gallery__thumb-btn:focus{box-shadow:0 0 0 2px var(--active-color)}travelagency--organism-package-gallery-102009 .package-gallery__thumb-btn img{width:72px;height:48px;object-fit:cover;border-radius:4px;background:var(--grey-color-light)}@media (max-width:768px){organism-package-gallery .package-gallery__main-image{max-width:100%;height:180px}organism-package-gallery .package-gallery__thumbnails img{width:48px;height:32px}}`);
    }
    render() {
        return html `<div class="package-gallery__container" id="travelagency--package-gallery-102009-1">
        <div class="package-gallery__main-image" id="travelagency--package-gallery-102009-2">
          <img src="https://images.unsplash.com/photo-1546769821-d1137cf15c15?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxWaXN0YSUyMGElQzMlQTlyZWElMjBkbyUyMFJpbyUyMGRlJTIwSmFuZWlybyUyMGNvbSUyMG8lMjBDcmlzdG8lMjBSZWRlbnRvcnxlbnwwfHx8fDE3NTUxMDc0MjJ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Vista aérea do Rio de Janeiro com o Cristo Redentor" id="travelagency--package-gallery-102009-3">
        </div>
        <div class="package-gallery__thumbnails" id="travelagency--package-gallery-102009-4">
          <button class="package-gallery__thumb-btn" aria-label="Ver foto 1" id="travelagency--package-gallery-102009-5">
            <img src="https://images.unsplash.com/photo-1655997113841-4da21c357225?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxDcmlzdG8lMjBSZWRlbnRvciUyMFJpbyUyMGRlJTIwSmFuZWlyb3xlbnwwfHx8fDE3NTUxMDc0MjJ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Cristo Redentor" id="travelagency--package-gallery-102009-6">
          </button>
          <button class="package-gallery__thumb-btn" aria-label="Ver foto 2" id="travelagency--package-gallery-102009-7">
            <img src="https://images.unsplash.com/photo-1698320856830-246e897b8e9b?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxQcmFpYSUyMGRlJTIwQ29wYWNhYmFuYSUyMFJpbyUyMGRlJTIwSmFuZWlyb3xlbnwwfHx8fDE3NTUwMzE0NjZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Praia de Copacabana" id="travelagency--package-gallery-102009-8">
          </button>
          <button class="package-gallery__thumb-btn" aria-label="Ver foto 3" id="travelagency--package-gallery-102009-9">
            <img src="https://images.unsplash.com/photo-1442347504183-965bd14449ac?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxQJUMzJUEzbyUyMGRlJTIwQSVDMyVBNyVDMyVCQWNhciUyMFJpbyUyMGRlJTIwSmFuZWlyb3xlbnwwfHx8fDE3NTUxMDc0MjN8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Pão de Açúcar" id="travelagency--package-gallery-102009-10">
          </button>
          <button class="package-gallery__thumb-btn" aria-label="Ver foto 4" id="travelagency--package-gallery-102009-11">
            <img src="https://images.unsplash.com/photo-1596618502142-d2a9d0c1fc2e?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxIb3RlbCUyMGNvbSUyMHBpc2NpbmElMjBSaW8lMjBkZSUyMEphbmVpcm98ZW58MHx8fHwxNzU1MTA3NDIzfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Hotel com piscina" id="travelagency--package-gallery-102009-12">
          </button>
        </div>
      </div>
    `;
    }
};
organismPackageGallery = __decorate([
    customElement('travelagency--organism-package-gallery-102009')
], organismPackageGallery);
export { organismPackageGallery };
