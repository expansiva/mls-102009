/// <mls shortName="register" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageRegister = class PageRegister extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--register-102009{display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color)}travelagency--register-102009>header{width:100%;background:var(--bg-primary-color);box-shadow:0 2px 8px 0 rgba(192,192,192,0.08);z-index:10}travelagency--register-102009>main{flex:1 0 auto;display:flex;flex-direction:column;justify-content:center;align-items:center;background:var(--bg-primary-color);padding:var(--space-32) 0}travelagency--register-102009>footer{width:100%;background:var(--bg-secondary-color-lighter);flex-shrink:0;box-shadow:0 -2px 8px 0 rgba(192,192,192,0.06)}`);
    }
    initPage() {
    }
};
PageRegister = __decorate([
    customElement('travelagency--register-102009')
], PageRegister);
export { PageRegister };
