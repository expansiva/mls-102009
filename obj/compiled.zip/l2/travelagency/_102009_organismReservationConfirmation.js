/// <mls shortName="organismReservationConfirmation" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismReservationConfirmation = class organismReservationConfirmation extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-reservation-confirmation-102009{display:block}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__container{background:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 8px rgba(192,192,192,0.1);max-width:480px;margin:var(--space-24) auto var(--space-32) auto;padding:var(--space-32) var(--space-24);text-align:center}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__icon{margin-bottom:var(--space-16)}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__icon img{width:56px;height:56px}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__title{font-family:var(--font-family-primary);font-size:var(--font-size-24);color:var(--success-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-8)}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__message{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);margin-bottom:var(--space-16)}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__details{background:var(--bg-secondary-color-lighter);border-radius:4px;padding:var(--space-16);margin-bottom:var(--space-16)}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__details ul{list-style:none;padding:0;margin:0}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__details ul li{font-size:var(--font-size-16);color:var(--text-primary-color);margin-bottom:var(--space-8)}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__details ul li strong{color:var(--text-secondary-color)}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__back{display:inline-block;margin-top:var(--space-8);color:var(--link-color);font-weight:var(--font-weight-bold);text-decoration:none;transition:color var(--transition-slow)}travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__back:hover{color:var(--link-color-hover);text-decoration:underline}@media (max-width:544px){travelagency--organism-reservation-confirmation-102009 .reservation-confirmation__container{padding:var(--space-16) var(--space-8)}}`);
    }
    render() {
        return html `<section class="reservation-confirmation__container" id="travelagency--reservation-confirmation-102009-1">
        <div class="reservation-confirmation__icon" id="travelagency--reservation-confirmation-102009-2">
          <img src="https://images.unsplash.com/photo-1527957557037-d079c24f24be?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHwlQzMlQURjb25lJTIwZGUlMjBzdWNlc3NvJTIwY2hlY2ttYXJrJTIwdmVyZGV8ZW58MHx8fHwxNzU1MTA3NTIyfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Reserva confirmada" id="travelagency--reservation-confirmation-102009-3">
        </div>
        <h2 class="reservation-confirmation__title" id="travelagency--reservation-confirmation-102009-4">Reserva confirmada!</h2>
        <p class="reservation-confirmation__message" id="travelagency--reservation-confirmation-102009-5">
          Sua reserva foi efetuada com sucesso.<br id="travelagency--reservation-confirmation-102009-6">
          Enviamos os detalhes para seu e-mail.
        </p>
        <div class="reservation-confirmation__details" id="travelagency--reservation-confirmation-102009-7">
          <ul id="travelagency--reservation-confirmation-102009-8">
            <li id="travelagency--reservation-confirmation-102009-9"><strong id="travelagency--reservation-confirmation-102009-10">Nome:</strong> Lucas</li>
            <li id="travelagency--reservation-confirmation-102009-11"><strong id="travelagency--reservation-confirmation-102009-12">Pacote:</strong> Rio de Janeiro - 5 dias</li>
            <li id="travelagency--reservation-confirmation-102009-13"><strong id="travelagency--reservation-confirmation-102009-14">Data de ida:</strong> 20/09/2025</li>
            <li id="travelagency--reservation-confirmation-102009-15"><strong id="travelagency--reservation-confirmation-102009-16">Data de volta:</strong> 25/09/2025</li>
            <li id="travelagency--reservation-confirmation-102009-17"><strong id="travelagency--reservation-confirmation-102009-18">Status do pagamento:</strong> Aprovado</li>
          </ul>
        </div>
        <a href="/" class="reservation-confirmation__back" id="travelagency--reservation-confirmation-102009-19">Voltar para página inicial</a>
      </section>
    `;
    }
};
organismReservationConfirmation = __decorate([
    customElement('travelagency--organism-reservation-confirmation-102009')
], organismReservationConfirmation);
export { organismReservationConfirmation };
