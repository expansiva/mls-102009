/// <mls shortName="organismPaymentIntegration" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPaymentIntegration = class organismPaymentIntegration extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-payment-integration-102009{display:block}travelagency--organism-payment-integration-102009 .payment-integration__container{background:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 8px rgba(192,192,192,0.1);max-width:480px;margin:var(--space-24) auto var(--space-24) auto;padding:var(--space-32) var(--space-24)}travelagency--organism-payment-integration-102009 .payment-integration__title{font-family:var(--font-family-primary);font-size:var(--font-size-24);color:var(--text-primary-color);margin-bottom:var(--space-24);font-weight:var(--font-weight-bold);text-align:center}travelagency--organism-payment-integration-102009 .payment-integration__form{display:flex;flex-direction:column;gap:var(--space-16)}travelagency--organism-payment-integration-102009 .payment-integration__group{display:flex;flex-direction:column;gap:var(--space-8)}travelagency--organism-payment-integration-102009 .payment-integration__group label{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);font-weight:var(--font-weight-normal)}travelagency--organism-payment-integration-102009 .payment-integration__group input{border:1px solid var(--grey-color-dark);border-radius:4px;padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);font-family:var(--font-family-primary);background:var(--bg-secondary-color-lighter);color:var(--text-primary-color);transition:border-color var(--transition-slow)}travelagency--organism-payment-integration-102009 .payment-integration__group input:focus{border-color:var(--active-color);outline:none}travelagency--organism-payment-integration-102009 .payment-integration__group--row{flex-direction:row;gap:var(--space-16)}travelagency--organism-payment-integration-102009 .payment-integration__group--row>div{flex:1}travelagency--organism-payment-integration-102009 .payment-integration__submit{margin-top:var(--space-16);background:#fff;color:var(--bg-primary-color);font-size:var(--font-size-16);font-family:var(--font-family-primary);font-weight:var(--font-weight-bold);border:none;border-radius:4px;padding:var(--space-16);cursor:pointer;transition:background var(--transition-slow)}travelagency--organism-payment-integration-102009 .payment-integration__submit:hover{background:#fff}travelagency--organism-payment-integration-102009 .payment-integration__secure{display:flex;align-items:center;gap:var(--space-8);margin-top:var(--space-16);font-size:var(--font-size-16);color:var(--text-primary-color-lighter)}travelagency--organism-payment-integration-102009 .payment-integration__secure img{width:24px;height:24px}@media (max-width:544px){travelagency--organism-payment-integration-102009 .payment-integration__container{padding:var(--space-16) var(--space-8)}travelagency--organism-payment-integration-102009 .payment-integration__group--row{flex-direction:column;gap:var(--space-8)}}`);
    }
    render() {
        return html `<section class="payment-integration__container" id="travelagency--payment-integration-102009-1">
        <h2 class="payment-integration__title" id="travelagency--payment-integration-102009-2">Pagamento</h2>
        <form class="payment-integration__form" autocomplete="off" id="travelagency--payment-integration-102009-3">
          <div class="payment-integration__group" id="travelagency--payment-integration-102009-4">
            <label for="card-number" id="travelagency--payment-integration-102009-5">Número do cartão *</label>
            <input type="text" id="card-number" name="card_number" maxlength="19" required="" placeholder="0000 0000 0000 0000">
          </div>
          <div class="payment-integration__group payment-integration__group--row" id="travelagency--payment-integration-102009-6">
            <div id="travelagency--payment-integration-102009-7">
              <label for="card-expiry" id="travelagency--payment-integration-102009-8">Validade *</label>
              <input type="text" id="card-expiry" name="card_expiry" maxlength="5" required="" placeholder="MM/AA">
            </div>
            <div id="travelagency--payment-integration-102009-9">
              <label for="card-cvc" id="travelagency--payment-integration-102009-10">CVC *</label>
              <input type="text" id="card-cvc" name="card_cvc" maxlength="4" required="" placeholder="123">
            </div>
          </div>
          <div class="payment-integration__group" id="travelagency--payment-integration-102009-11">
            <label for="card-holder" id="travelagency--payment-integration-102009-12">Nome impresso no cartão *</label>
            <input type="text" id="card-holder" name="card_holder" required="" placeholder="Nome do titular">
          </div>
          <button type="submit" class="payment-integration__submit" id="travelagency--payment-integration-102009-13">Pagar e finalizar reserva</button>
        </form>
        <div class="payment-integration__secure" id="travelagency--payment-integration-102009-14">
          <img src="https://images.unsplash.com/photo-1588942458058-55beb017132c?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHwlQzMlQURjb25lJTIwZGUlMjBjYWRlYWRvJTIwc2VndXJvJTIwcGFnYW1lbnRvfGVufDB8fHx8MTc1NTEwNzUyMnww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Pagamento seguro" id="travelagency--payment-integration-102009-15">
          <span id="travelagency--payment-integration-102009-16">Pagamento 100% seguro via Stripe</span>
        </div>
      </section>
    `;
    }
};
organismPaymentIntegration = __decorate([
    customElement('travelagency--organism-payment-integration-102009')
], organismPaymentIntegration);
export { organismPaymentIntegration };
