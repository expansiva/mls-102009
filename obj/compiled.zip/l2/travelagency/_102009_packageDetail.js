/// <mls shortName="packageDetail" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PagePackageDetail = class PagePackageDetail extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--package-detail-102009{display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color)}travelagency--package-detail-102009 header{width:100%;background:var(--bg-primary-color);box-shadow:0 1px 4px var(--grey-color-dark);z-index:10}travelagency--package-detail-102009 main.main-content{flex:1;width:100%;max-width:900px;margin:0 auto;padding:var(--space-40) 0;display:flex;flex-direction:column;gap:var(--space-40)}travelagency--package-detail-102009 footer{width:100%;background:var(--bg-secondary-color-lighter);box-shadow:0 -1px 4px var(--grey-color-dark);margin-top:auto}@media (max-width:768px){travelagency--package-detail-102009 package-detail-102009 main.main-content{padding:var(--space-16) 0;max-width:100%;gap:var(--space-24)}}`);
    }
    initPage() {
    }
};
PagePackageDetail = __decorate([
    customElement('travelagency--package-detail-102009')
], PagePackageDetail);
export { PagePackageDetail };
