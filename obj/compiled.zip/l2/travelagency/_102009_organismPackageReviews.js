/// <mls shortName="organismPackageReviews" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPackageReviews = class organismPackageReviews extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-package-reviews-102009 .package-reviews__container{background:var(--bg-primary-color);border-radius:8px;box-shadow:0 1px 4px var(--grey-color-dark);padding:var(--space-32);margin-bottom:var(--space-40);font-family:var(--font-family-primary)}travelagency--organism-package-reviews-102009 .package-reviews__title{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-16)}travelagency--organism-package-reviews-102009 .package-reviews__list{display:flex;flex-direction:column;gap:var(--space-24);margin-bottom:var(--space-32)}travelagency--organism-package-reviews-102009 .package-reviews__item{background:var(--bg-secondary-color-lighter);border-radius:6px;padding:var(--space-16);box-shadow:0 1px 2px var(--grey-color-darker);display:flex;flex-direction:column;gap:var(--space-8)}travelagency--organism-package-reviews-102009 .package-reviews__rating{display:flex;align-items:center;gap:var(--space-8);font-size:var(--font-size-16);color:var(--warning-color);font-weight:var(--font-weight-bold)}travelagency--organism-package-reviews-102009 .package-reviews__stars{font-size:var(--font-size-16);letter-spacing:1px}travelagency--organism-package-reviews-102009 .package-reviews__score{color:var(--text-primary-color-lighter);font-size:var(--font-size-16);margin-left:var(--space-8)}travelagency--organism-package-reviews-102009 .package-reviews__comment{color:var(--text-primary-color-lighter);font-size:var(--font-size-16)}travelagency--organism-package-reviews-102009 .package-reviews__author{font-weight:var(--font-weight-bold);color:var(--text-secondary-color);margin-right:var(--space-8)}travelagency--organism-package-reviews-102009 .package-reviews__form-block{background:var(--bg-secondary-color-lighter);border-radius:6px;padding:var(--space-16);box-shadow:0 1px 2px var(--grey-color-darker)}travelagency--organism-package-reviews-102009 .package-reviews__form-title{font-size:var(--font-size-16);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-8)}travelagency--organism-package-reviews-102009 .package-reviews__form{display:flex;flex-direction:column;gap:var(--space-8)}travelagency--organism-package-reviews-102009 .package-reviews__form-label{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);margin-bottom:2px}travelagency--organism-package-reviews-102009 .package-reviews__form-select,travelagency--organism-package-reviews-102009 .package-reviews__form-textarea{font-size:var(--font-size-16);padding:var(--space-8);border-radius:4px;border:1px solid var(--grey-color-dark);background:var(--bg-primary-color-lighter);color:var(--text-primary-color);font-family:var(--font-family-primary);resize:vertical}travelagency--organism-package-reviews-102009 .package-reviews__form-btn{background:var(--active-color);color:var(--bg-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);border:none;border-radius:4px;padding:var(--space-8) var(--space-24);cursor:pointer;margin-top:var(--space-8);transition:background var(--transition-slow)}travelagency--organism-package-reviews-102009 .package-reviews__form-btn:hover,travelagency--organism-package-reviews-102009 .package-reviews__form-btn:focus{background:var(--active-color-hover)}@media (max-width:768px){organism-package-reviews .package-reviews__container{padding:var(--space-16)}}`);
    }
    render() {
        return html `<div class="package-reviews__container" id="travelagency--package-reviews-102009-1">
        <h2 class="package-reviews__title" id="travelagency--package-reviews-102009-2">Avaliações dos Clientes</h2>
        <div class="package-reviews__list" id="travelagency--package-reviews-102009-3">
          <div class="package-reviews__item" id="travelagency--package-reviews-102009-4">
            <div class="package-reviews__rating" id="travelagency--package-reviews-102009-5">
              <span class="package-reviews__stars" id="travelagency--package-reviews-102009-6">★★★★★</span>
              <span class="package-reviews__score" id="travelagency--package-reviews-102009-7">5.0</span>
            </div>
            <div class="package-reviews__comment" id="travelagency--package-reviews-102009-8">
              <span class="package-reviews__author" id="travelagency--package-reviews-102009-9">Ana Paula</span>
              <p class="package-reviews__text" id="travelagency--package-reviews-102009-10">Viagem maravilhosa! Tudo muito organizado e o hotel era excelente. Recomendo muito!</p>
            </div>
          </div>
          <div class="package-reviews__item" id="travelagency--package-reviews-102009-11">
            <div class="package-reviews__rating" id="travelagency--package-reviews-102009-12">
              <span class="package-reviews__stars" id="travelagency--package-reviews-102009-13">★★★★☆</span>
              <span class="package-reviews__score" id="travelagency--package-reviews-102009-14">4.0</span>
            </div>
            <div class="package-reviews__comment" id="travelagency--package-reviews-102009-15">
              <span class="package-reviews__author" id="travelagency--package-reviews-102009-16">Carlos Silva</span>
              <p class="package-reviews__text" id="travelagency--package-reviews-102009-17">Gostei bastante, só achei o traslado um pouco demorado. No geral, experiência ótima!</p>
            </div>
          </div>
        </div>
        <div class="package-reviews__form-block" id="travelagency--package-reviews-102009-18">
          <h3 class="package-reviews__form-title" id="travelagency--package-reviews-102009-19">Adicionar Avaliação</h3>
          <form class="package-reviews__form" id="travelagency--package-reviews-102009-20">
            <label class="package-reviews__form-label" for="review-rating" id="travelagency--package-reviews-102009-21">Nota:</label>
            <select id="review-rating" class="package-reviews__form-select" name="rating">
              <option value="5" id="travelagency--package-reviews-102009-22">5 - Excelente</option>
              <option value="4" id="travelagency--package-reviews-102009-23">4 - Muito bom</option>
              <option value="3" id="travelagency--package-reviews-102009-24">3 - Bom</option>
              <option value="2" id="travelagency--package-reviews-102009-25">2 - Regular</option>
              <option value="1" id="travelagency--package-reviews-102009-26">1 - Ruim</option>
            </select>
            <label class="package-reviews__form-label" for="review-comment" id="travelagency--package-reviews-102009-27">Comentário:</label>
            <textarea id="review-comment" class="package-reviews__form-textarea" name="comment" rows="3" placeholder="Conte como foi sua experiência..."></textarea>
            <button type="submit" class="package-reviews__form-btn" id="travelagency--package-reviews-102009-28">Enviar Avaliação</button>
          </form>
        </div>
      </div>
    `;
    }
};
organismPackageReviews = __decorate([
    customElement('travelagency--organism-package-reviews-102009')
], organismPackageReviews);
export { organismPackageReviews };
