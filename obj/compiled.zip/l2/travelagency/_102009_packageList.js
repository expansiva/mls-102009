/// <mls shortName="packageList" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PagePackageList = class PagePackageList extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--package-list-102009{min-height:100vh;background:var(--bg-primary-color);display:flex;flex-direction:column}travelagency--package-list-102009>header{flex:0 0 auto;background:var(--bg-primary-color);border-bottom:1px solid var(--grey-color)}travelagency--package-list-102009>.layout{flex:1 1 auto;display:flex;flex-direction:row;max-width:1200px;margin:0 auto;width:100%;padding:var(--space-32) var(--space-16);box-sizing:border-box}travelagency--package-list-102009>.layout>aside{flex:0 0 280px;margin-right:var(--space-32)}travelagency--package-list-102009>.layout>main{flex:1 1 0;min-width:0}travelagency--package-list-102009>footer{flex:0 0 auto;background:var(--bg-secondary-color-lighter);border-top:1px solid var(--grey-color);margin-top:var(--space-32)}@media (max-width:1012px){travelagency--package-list-102009 package-list-102009>.layout{max-width:100%;padding:var(--space-24) var(--space-8)}travelagency--package-list-102009 package-list-102009>.layout>aside{flex:0 0 220px;margin-right:var(--space-16)}}@media (max-width:768px){travelagency--package-list-102009 package-list-102009>.layout{flex-direction:column;padding:var(--space-16) var(--space-8)}travelagency--package-list-102009 package-list-102009>.layout>aside{margin-right:0;margin-bottom:var(--space-24);flex:0 0 auto}travelagency--package-list-102009 package-list-102009>.layout>main{flex:1 1 0}}`);
    }
    initPage() {
    }
};
PagePackageList = __decorate([
    customElement('travelagency--package-list-102009')
], PagePackageList);
export { PagePackageList };
