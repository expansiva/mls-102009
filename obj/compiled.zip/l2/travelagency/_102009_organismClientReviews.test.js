/// <mls shortName="organismClientReviews" project="102009" enhancement="_blank" folder="travelagency" />
export const integrations = [];
export const tests = [];
