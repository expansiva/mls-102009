var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismNav" project="102009" enhancement="_100554_enhancementLit" groupName="travelagency" />
import { html, css } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismNav = class organismNav extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`travelagency--organism-nav-102009 .nav-container{display:flex;align-items:center;justify-content:space-between;background:var(--bg-primary-color);padding:var(--space-16) var(--space-32);border-bottom:1px solid var(--grey-color);position:relative}@media (max-width:768px){travelagency--organism-nav-102009 .nav-container{flex-direction:row;aligns-items:center;padding:var(--space-16)}}travelagency--organism-nav-102009 .nav-logo img{height:40px;width:auto;display:block}travelagency--organism-nav-102009 .nav-links{display:flex;gap:var(--space-24)}@media (max-width:768px){travelagency--organism-nav-102009 .nav-links{display:none}}travelagency--organism-nav-102009 .nav-link{color:var(--text-primary-color);font-size:var(--font-size-16);text-decoration:none;font-weight:var(--font-weight-normal);transition:color var(--transition-normal)}travelagency--organism-nav-102009 .nav-link:hover,travelagency--organism-nav-102009 .nav-link:focus{color:var(--link-color-hover)}travelagency--organism-nav-102009 .nav-link.nav-link-active{color:var(--link-color);font-weight:var(--font-weight-bold)}travelagency--organism-nav-102009 .nav-actions{display:flex;gap:var(--space-16)}@media (max-width:768px){travelagency--organism-nav-102009 .nav-actions{display:none}}travelagency--organism-nav-102009 .nav-btn{padding:var(--space-8) var(--space-24);border-radius:4px;font-size:var(--font-size-16);font-family:var(--font-family-primary);border:none;cursor:pointer;text-decoration:none;transition:background var(--transition-normal),color var(--transition-normal)}travelagency--organism-nav-102009 .nav-btn.nav-btn-login{background:var(--bg-secondary-color);color:var(--text-primary-color)}travelagency--organism-nav-102009 .nav-btn.nav-btn-login:hover,travelagency--organism-nav-102009 .nav-btn.nav-btn-login:focus{background:var(--bg-secondary-color-hover)}travelagency--organism-nav-102009 .nav-btn.nav-btn-signup{background:var(--link-color);color:#fff;font-weight:var(--font-weight-bold)}travelagency--organism-nav-102009 .nav-btn.nav-btn-signup:hover,travelagency--organism-nav-102009 .nav-btn.nav-btn-signup:focus{background:var(--link-color-hover)}travelagency--organism-nav-102009 .nav-hamburger{display:none;background:none;border:none;flex-direction:column;justify-content:center;align-items:center;width:40px;height:40px;cursor:pointer;padding:0;margin-left:var(--space-16)}@media (max-width:768px){travelagency--organism-nav-102009 .nav-hamburger{display:flex}}travelagency--organism-nav-102009 .nav-hamburger .hamburger-bar{width:28px;height:3px;background:var(--text-primary-color);margin:3px 0;border-radius:2px;transition:background var(--transition-normal)}travelagency--organism-nav-102009 .mobile-menu-overlay{display:none;position:fixed;z-index:1000;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.35)}@media (max-width:768px){travelagency--organism-nav-102009 .mobile-menu-overlay.open{display:block}}travelagency--organism-nav-102009 .mobile-menu-content{background:var(--bg-primary-color);width:80vw;max-width:320px;height:100vh;position:fixed;top:0;right:0;box-shadow:-2px 0 8px rgba(0,0,0,0.08);display:flex;flex-direction:column;padding:var(--space-32) var(--space-24);animation:slideInMenu .3s cubic-bezier(.4, 0, .2, 1)}@media (min-width:769px){travelagency--organism-nav-102009 .mobile-menu-content{display:none}}travelagency--organism-nav-102009 .mobile-menu-close{background:none;border:none;font-size:2rem;color:var(--text-primary-color);align-self:flex-end;cursor:pointer;margin-bottom:var(--space-24)}travelagency--organism-nav-102009 .mobile-nav-links{display:flex;flex-direction:column;gap:var(--space-24);margin-bottom:var(--space-32)}travelagency--organism-nav-102009 .mobile-nav-links .nav-link{font-size:var(--font-size-20);color:var(--text-primary-color);font-weight:var(--font-weight-normal)}travelagency--organism-nav-102009 .mobile-nav-links .nav-link.nav-link-active{color:var(--link-color);font-weight:var(--font-weight-bold)}travelagency--organism-nav-102009 .mobile-nav-actions{display:flex;flex-direction:column;gap:var(--space-16)}travelagency--organism-nav-102009 .mobile-nav-actions .nav-btn{width:100%;text-align:center;font-size:var(--font-size-16)}@keyframes slideInMenu{from{right:-100vw;opacity:0}to{right:0;opacity:1}}`);
        this.menuOpen = false;
    }
    toggleMenu() {
        this.menuOpen = !this.menuOpen;
    }
    render() {
        return html `
      <div class="nav-container" id="travelagency--nav-102009-1">
        <a href="/" class="nav-logo" aria-label="Travel Agency Home" id="travelagency--nav-102009-2">
          <img src="https://images.unsplash.com/photo-1637489981573-e45e9297cb21?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHx0cmF2ZWwlMjBhZ2VuY3klMjBsb2dvfGVufDB8fHx8MTc1NTEwNzIwOHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Travel Agency Logo" id="travelagency--nav-102009-3">
        </a>
        <button class="nav-hamburger" id="travelagency--nav-102009-10" @click="${this.toggleMenu}" aria-label="Abrir menu de navegação" aria-expanded="${this.menuOpen ? 'true' : 'false'}" aria-controls="travelagency--nav-102009-menu">
          ===
        </button>
        <nav class="nav-links${this.menuOpen ? ' nav-links-open' : ''}" aria-label="Navegação principal" id="travelagency--nav-102009-4" ?hidden="${!this.menuOpen && this.isMobile()}"  >
          <a href="/" class="nav-link nav-link-active" id="travelagency--nav-102009-5">Home</a>
          <a href="/pacotes" class="nav-link" id="travelagency--nav-102009-6">Pacotes</a>
        </nav>
        <div class="nav-actions" id="travelagency--nav-102009-7">
          <a href="/login" class="nav-btn nav-btn-login" id="travelagency--nav-102009-8">Login</a>
          <a href="/cadastro" class="nav-btn nav-btn-signup" id="travelagency--nav-102009-9">Cadastro</a>
        </div>
      </div>
    `;
    }
    // Helper para detectar mobile (pode ser melhorado)
    isMobile() {
        return window.innerWidth <= 768;
    }
};
organismNav.styles = css `
    .nav-hamburger {
      display: none;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 40px;
      height: 40px;
      background: transparent;
      border: none;
      cursor: pointer;
      z-index: 11;
    }
    .nav-hamburger span {
      display: block;
      width: 28px;
      height: 3px;
      margin: 4px 0;
      background: #222;
      border-radius: 2px;
      transition: all 0.3s;
    }
    @media (max-width: 768px) {
      .nav-hamburger {
        display: flex;
      }
      .nav-links {
        display: none;
        position: absolute;
        top: 60px;
        left: 0;
        right: 0;
        background: #fff;
        flex-direction: column;
        align-items: flex-start;
        padding: 16px 24px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        z-index: 10;
      }
      .nav-links.nav-links-open {
        display: flex;
      }
      .nav-actions {
        display: none;
      }
    }
  `;
__decorate([
    state()
], organismNav.prototype, "menuOpen", void 0);
organismNav = __decorate([
    customElement('travelagency--organism-nav-102009')
], organismNav);
export { organismNav };
