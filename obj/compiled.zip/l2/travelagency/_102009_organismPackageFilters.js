/// <mls shortName="organismPackageFilters" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPackageFilters = class organismPackageFilters extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-package-filters-102009{display:block;background:var(--bg-secondary-color-lighter);padding:var(--space-32);border-radius:var(--space-16);box-shadow:0 2px 8px rgba(192,192,192,0.1)}travelagency--organism-package-filters-102009 .filters-form{display:flex;flex-direction:column;gap:var(--space-24)}travelagency--organism-package-filters-102009 .filter-group{display:flex;flex-direction:column}travelagency--organism-package-filters-102009 .filter-group label{font-size:var(--font-size-16);color:var(--text-primary-color);margin-bottom:var(--space-8);font-weight:var(--font-weight-bold)}travelagency--organism-package-filters-102009 .filter-group input{padding:var(--space-8) var(--space-16);border:1px solid var(--grey-color-dark);border-radius:var(--space-8);font-size:var(--font-size-16);background:var(--bg-primary-color);color:var(--text-primary-color);transition:border-color var(--transition-normal)}travelagency--organism-package-filters-102009 .filter-group input:focus{border-color:var(--text-secondary-color);outline:none}travelagency--organism-package-filters-102009 .btn-filtrar{margin-top:var(--space-16);padding:var(--space-8) var(--space-24);background:var(--text-secondary-color);color:var(--bg-primary-color);border:none;border-radius:var(--space-8);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-normal)}travelagency--organism-package-filters-102009 .btn-filtrar:hover{background:var(--text-secondary-color-hover)}@media (max-width:768px){organism-package-filters{padding:var(--space-16)}organism-package-filters .filters-form{gap:var(--space-16)}}`);
    }
    render() {
        return html `<form class="filters-form" id="travelagency--package-filters-102009-1">
          <div class="filter-group" id="travelagency--package-filters-102009-2">
            <label for="filter-destino" id="travelagency--package-filters-102009-3">Destino</label>
            <input type="text" id="filter-destino" name="destino" placeholder="Ex: Rio de Janeiro">
          </div>
          <div class="filter-group" id="travelagency--package-filters-102009-4">
            <label for="filter-data" id="travelagency--package-filters-102009-5">Data</label>
            <input type="date" id="filter-data" name="data">
          </div>
          <div class="filter-group" id="travelagency--package-filters-102009-6">
            <label for="filter-preco" id="travelagency--package-filters-102009-7">Preço máximo (R$)</label>
            <input type="number" id="filter-preco" name="preco" min="0" step="100" placeholder="Ex: 2000">
          </div>
          <button type="submit" class="btn-filtrar" id="travelagency--package-filters-102009-8">Filtrar</button>
        </form>
      `;
    }
};
organismPackageFilters = __decorate([
    customElement('travelagency--organism-package-filters-102009')
], organismPackageFilters);
export { organismPackageFilters };
