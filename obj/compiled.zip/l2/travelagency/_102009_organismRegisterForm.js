/// <mls shortName="organismRegisterForm" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismRegisterForm = class organismRegisterForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-register-form-102009{display:flex;justify-content:center;align-items:center;min-height:70vh;background:var(--bg-primary-color)}travelagency--organism-register-form-102009 .register-form__container{background:var(--bg-secondary-color-lighter);border-radius:8px;box-shadow:0 2px 16px 0 rgba(192,192,192,0.1);padding:var(--space-32) var(--space-40);max-width:400px;width:100%;margin:var(--space-32) auto}@media (max-width:544px){travelagency--organism-register-form-102009 .register-form__container{padding:var(--space-16) var(--space-8);max-width:100%}}travelagency--organism-register-form-102009 .register-form__title{font-family:var(--font-family-primary);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-24);text-align:center}travelagency--organism-register-form-102009 .register-form__form{display:flex;flex-direction:column;gap:var(--space-16)}travelagency--organism-register-form-102009 .register-form__field{display:flex;flex-direction:column;gap:var(--space-8)}travelagency--organism-register-form-102009 .register-form__label{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);font-weight:var(--font-weight-normal)}travelagency--organism-register-form-102009 .register-form__required{color:var(--error-color);font-weight:var(--font-weight-bold);margin-left:2px}travelagency--organism-register-form-102009 .register-form__input{padding:var(--space-8);border:1px solid var(--grey-color-dark);border-radius:4px;font-size:var(--font-size-16);font-family:var(--font-family-primary);color:var(--text-primary-color);background:var(--bg-primary-color);transition:border-color var(--transition-normal)}travelagency--organism-register-form-102009 .register-form__input:focus{border-color:#fff;outline:none}travelagency--organism-register-form-102009 .register-form__input:disabled{background:var(--bg-secondary-color-disabled);color:var(--text-primary-color-disabled)}travelagency--organism-register-form-102009 .register-form__error{color:var(--error-color);font-size:var(--font-size-12);min-height:16px;margin-top:2px}travelagency--organism-register-form-102009 .register-form__actions{margin-top:var(--space-16);display:flex;flex-direction:column;align-items:stretch}travelagency--organism-register-form-102009 .register-form__submit{background:#fff;color:var(--bg-primary-color);font-size:var(--font-size-16);font-family:var(--font-family-primary);font-weight:var(--font-weight-bold);border:none;border-radius:4px;padding:var(--space-8) 0;cursor:pointer;transition:background var(--transition-normal)}travelagency--organism-register-form-102009 .register-form__submit:hover{background:#fff}travelagency--organism-register-form-102009 .register-form__submit:active{background:#fff}travelagency--organism-register-form-102009 .register-form__submit:disabled{background:#fff;color:var(--bg-secondary-color-darker);cursor:not-allowed}travelagency--organism-register-form-102009 .register-form__login-link{margin-top:var(--space-16);text-align:center;font-size:var(--font-size-16);color:var(--text-primary-color-lighter)}travelagency--organism-register-form-102009 .register-form__link{color:var(--link-color);text-decoration:underline;margin-left:4px;transition:color var(--transition-normal)}travelagency--organism-register-form-102009 .register-form__link:hover{color:var(--link-color-hover)}travelagency--organism-register-form-102009 .register-form__link:active{color:var(--link-color-focus)}`);
    }
    render() {
        return html `<div class="register-form__container" id="travelagency--register-form-102009-1">
        <h1 class="register-form__title" id="travelagency--register-form-102009-2">Crie sua conta</h1>
        <form class="register-form__form" autocomplete="off" novalidate="" id="travelagency--register-form-102009-3">
          <div class="register-form__field" id="travelagency--register-form-102009-4">
            <label for="register-nome" class="register-form__label" id="travelagency--register-form-102009-5">Nome completo <span class="register-form__required" id="travelagency--register-form-102009-6">*</span></label>
            <input type="text" id="register-nome" name="nome" class="register-form__input" placeholder="Seu nome completo" required="">
            <span class="register-form__error" data-error-for="nome" id="travelagency--register-form-102009-7"></span>
          </div>
          <div class="register-form__field" id="travelagency--register-form-102009-8">
            <label for="register-email" class="register-form__label" id="travelagency--register-form-102009-9">E-mail <span class="register-form__required" id="travelagency--register-form-102009-10">*</span></label>
            <input type="email" id="register-email" name="email" class="register-form__input" placeholder="seu@email.com" required="">
            <span class="register-form__error" data-error-for="email" id="travelagency--register-form-102009-11"></span>
          </div>
          <div class="register-form__field" id="travelagency--register-form-102009-12">
            <label for="register-cpf" class="register-form__label" id="travelagency--register-form-102009-13">CPF <span class="register-form__required" id="travelagency--register-form-102009-14">*</span></label>
            <input type="text" id="register-cpf" name="cpf" class="register-form__input" placeholder="000.000.000-00" maxlength="14" required="">
            <span class="register-form__error" data-error-for="cpf" id="travelagency--register-form-102009-15"></span>
          </div>
          <div class="register-form__field" id="travelagency--register-form-102009-16">
            <label for="register-telefone" class="register-form__label" id="travelagency--register-form-102009-17">Telefone</label>
            <input type="tel" id="register-telefone" name="telefone" class="register-form__input" placeholder="(00) 00000-0000" maxlength="15">
            <span class="register-form__error" data-error-for="telefone" id="travelagency--register-form-102009-18"></span>
          </div>
          <div class="register-form__field" id="travelagency--register-form-102009-19">
            <label for="register-senha" class="register-form__label" id="travelagency--register-form-102009-20">Senha <span class="register-form__required" id="travelagency--register-form-102009-21">*</span></label>
            <input type="password" id="register-senha" name="senha" class="register-form__input" placeholder="Crie uma senha" minlength="6" required="">
            <span class="register-form__error" data-error-for="senha" id="travelagency--register-form-102009-22"></span>
          </div>
          <div class="register-form__field" id="travelagency--register-form-102009-23">
            <label for="register-senha-confirm" class="register-form__label" id="travelagency--register-form-102009-24">Confirme a senha <span class="register-form__required" id="travelagency--register-form-102009-25">*</span></label>
            <input type="password" id="register-senha-confirm" name="senha_confirm" class="register-form__input" placeholder="Repita a senha" minlength="6" required="">
            <span class="register-form__error" data-error-for="senha_confirm" id="travelagency--register-form-102009-26"></span>
          </div>
          <div class="register-form__actions" id="travelagency--register-form-102009-27">
            <button type="submit" class="register-form__submit" id="travelagency--register-form-102009-28">Cadastrar</button>
          </div>
          <div class="register-form__login-link" id="travelagency--register-form-102009-29">
            Já tem uma conta? <a href="/login" class="register-form__link" id="travelagency--register-form-102009-30">Entrar</a>
          </div>
        </form>
      </div>
    `;
    }
};
organismRegisterForm = __decorate([
    customElement('travelagency--organism-register-form-102009')
], organismRegisterForm);
export { organismRegisterForm };
