/// <mls shortName="organismReservationForm" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismReservationForm = class organismReservationForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-reservation-form-102009{display:block}travelagency--organism-reservation-form-102009 .reservation-form__container{background:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 8px rgba(192,192,192,0.1);max-width:480px;margin:var(--space-32) auto var(--space-24) auto;padding:var(--space-32) var(--space-24)}travelagency--organism-reservation-form-102009 .reservation-form__title{font-family:var(--font-family-primary);font-size:var(--font-size-24);color:var(--text-primary-color);margin-bottom:var(--space-24);font-weight:var(--font-weight-bold);text-align:center}travelagency--organism-reservation-form-102009 .reservation-form__form{display:flex;flex-direction:column;gap:var(--space-16)}travelagency--organism-reservation-form-102009 .reservation-form__group{display:flex;flex-direction:column;gap:var(--space-8)}travelagency--organism-reservation-form-102009 .reservation-form__group label{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);font-weight:var(--font-weight-normal)}travelagency--organism-reservation-form-102009 .reservation-form__group input,travelagency--organism-reservation-form-102009 .reservation-form__group select,travelagency--organism-reservation-form-102009 .reservation-form__group textarea{border:1px solid var(--grey-color-dark);border-radius:4px;padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);font-family:var(--font-family-primary);background:var(--bg-secondary-color-lighter);color:var(--text-primary-color);transition:border-color var(--transition-slow)}travelagency--organism-reservation-form-102009 .reservation-form__group input:focus,travelagency--organism-reservation-form-102009 .reservation-form__group select:focus,travelagency--organism-reservation-form-102009 .reservation-form__group textarea:focus{border-color:var(--active-color);outline:none}travelagency--organism-reservation-form-102009 .reservation-form__group textarea{resize:vertical}travelagency--organism-reservation-form-102009 .reservation-form__group--dates{flex-direction:row;gap:var(--space-16)}travelagency--organism-reservation-form-102009 .reservation-form__group--dates>div{flex:1}travelagency--organism-reservation-form-102009 .reservation-form__submit{margin-top:var(--space-16);background:#fff;color:var(--bg-primary-color);font-size:var(--font-size-16);font-family:var(--font-family-primary);font-weight:var(--font-weight-bold);border:none;border-radius:4px;padding:var(--space-16);cursor:pointer;transition:background var(--transition-slow)}travelagency--organism-reservation-form-102009 .reservation-form__submit:hover{background:#fff}@media (max-width:544px){travelagency--organism-reservation-form-102009 .reservation-form__container{padding:var(--space-16) var(--space-8)}travelagency--organism-reservation-form-102009 .reservation-form__group--dates{flex-direction:column;gap:var(--space-8)}}`);
    }
    render() {
        return html `<section class="reservation-form__container" id="travelagency--reservation-form-102009-1">
        <h2 class="reservation-form__title" id="travelagency--reservation-form-102009-2">Reserve seu pacote</h2>
        <form class="reservation-form__form" autocomplete="off" id="travelagency--reservation-form-102009-3">
          <div class="reservation-form__group" id="travelagency--reservation-form-102009-4">
            <label for="reservation-name" id="travelagency--reservation-form-102009-5">Nome completo *</label>
            <input type="text" id="reservation-name" name="name" required="" placeholder="Seu nome completo">
          </div>
          <div class="reservation-form__group" id="travelagency--reservation-form-102009-6">
            <label for="reservation-email" id="travelagency--reservation-form-102009-7">E-mail *</label>
            <input type="email" id="reservation-email" name="email" required="" placeholder="seu@email.com">
          </div>
          <div class="reservation-form__group" id="travelagency--reservation-form-102009-8">
            <label for="reservation-phone" id="travelagency--reservation-form-102009-9">Telefone *</label>
            <input type="tel" id="reservation-phone" name="phone" required="" placeholder="(99) 99999-9999">
          </div>
          <div class="reservation-form__group" id="travelagency--reservation-form-102009-10">
            <label for="reservation-package" id="travelagency--reservation-form-102009-11">Pacote *</label>
            <select id="reservation-package" name="package" required="">
              <option value="" id="travelagency--reservation-form-102009-12">Selecione o pacote</option>
              <option value="rio" id="travelagency--reservation-form-102009-13">Rio de Janeiro - 5 dias</option>
              <option value="gramado" id="travelagency--reservation-form-102009-14">Gramado - 7 dias</option>
              <option value="salvador" id="travelagency--reservation-form-102009-15">Salvador - 4 dias</option>
            </select>
          </div>
          <div class="reservation-form__group reservation-form__group--dates" id="travelagency--reservation-form-102009-16">
            <div id="travelagency--reservation-form-102009-17">
              <label for="reservation-date-in" id="travelagency--reservation-form-102009-18">Data de ida *</label>
              <input type="date" id="reservation-date-in" name="date_in" required="">
            </div>
            <div id="travelagency--reservation-form-102009-19">
              <label for="reservation-date-out" id="travelagency--reservation-form-102009-20">Data de volta *</label>
              <input type="date" id="reservation-date-out" name="date_out" required="">
            </div>
          </div>
          <div class="reservation-form__group" id="travelagency--reservation-form-102009-21">
            <label for="reservation-notes" id="travelagency--reservation-form-102009-22">Observações</label>
            <textarea id="reservation-notes" name="notes" rows="3" placeholder="Alguma observação especial?"></textarea>
          </div>
          <button type="submit" class="reservation-form__submit" id="travelagency--reservation-form-102009-23">Avançar para pagamento</button>
        </form>
      </section>
    `;
    }
};
organismReservationForm = __decorate([
    customElement('travelagency--organism-reservation-form-102009')
], organismReservationForm);
export { organismReservationForm };
