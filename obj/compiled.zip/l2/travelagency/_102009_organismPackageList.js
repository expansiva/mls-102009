/// <mls shortName="organismPackageList" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPackageList = class organismPackageList extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-package-list-102009{display:block}travelagency--organism-package-list-102009 .package-list{display:flex;flex-direction:column;gap:var(--space-32);margin:0;padding:0;list-style:none}travelagency--organism-package-list-102009 .package-card{display:flex;background:var(--bg-primary-color);border-radius:var(--space-16);box-shadow:0 2px 8px rgba(192,192,192,0.1);overflow:hidden;transition:box-shadow var(--transition-normal)}travelagency--organism-package-list-102009 .package-card:hover{box-shadow:0 4px 16px rgba(192,192,192,0.18)}travelagency--organism-package-list-102009 .package-card .package-image{flex:0 0 180px;height:140px;background:var(--grey-color-light);display:flex;align-items:center;justify-content:center}travelagency--organism-package-list-102009 .package-card .package-image img{width:100%;height:100%;object-fit:cover;border-radius:var(--space-16) 0 0 var(--space-16)}travelagency--organism-package-list-102009 .package-card .package-info{flex:1 1 auto;padding:var(--space-24);display:flex;flex-direction:column;justify-content:center}travelagency--organism-package-list-102009 .package-card .package-info .package-destino{font-size:var(--font-size-24);color:var(--text-primary-color);margin:0 0 var(--space-8) 0;font-weight:var(--font-weight-bold)}travelagency--organism-package-list-102009 .package-card .package-info .package-datas{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);margin-bottom:var(--space-8)}travelagency--organism-package-list-102009 .package-card .package-info .package-preco{font-size:var(--font-size-20);color:var(--text-secondary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}travelagency--organism-package-list-102009 .package-card .package-info .package-detalhes{font-size:var(--font-size-16);color:var(--link-color);text-decoration:underline;font-weight:var(--font-weight-bold);transition:color var(--transition-normal)}travelagency--organism-package-list-102009 .package-card .package-info .package-detalhes:hover{color:var(--link-color-hover)}@media (max-width:768px){travelagency--organism-package-list-102009 organism-package-list .package-list{gap:var(--space-16)}travelagency--organism-package-list-102009 organism-package-list .package-card{flex-direction:column}travelagency--organism-package-list-102009 organism-package-list .package-card .package-image{width:100%;height:180px;border-radius:var(--space-16) var(--space-16) 0 0}travelagency--organism-package-list-102009 organism-package-list .package-card .package-image img{border-radius:var(--space-16) var(--space-16) 0 0}travelagency--organism-package-list-102009 organism-package-list .package-card .package-info{padding:var(--space-16)}}`);
    }
    render() {
        return html `<ul class="package-list" id="travelagency--package-list-102009-1">
          <li class="package-card" id="travelagency--package-list-102009-2">
            <div class="package-image" id="travelagency--package-list-102009-3">
              <img src="https://images.unsplash.com/photo-1698320856830-246e897b8e9b?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxQcmFpYSUyMGRlJTIwQ29wYWNhYmFuYSUyMFJpbyUyMGRlJTIwSmFuZWlyb3xlbnwwfHx8fDE3NTUwMzE0NjZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Praia de Copacabana, Rio de Janeiro" id="travelagency--package-list-102009-4">
            </div>
            <div class="package-info" id="travelagency--package-list-102009-5">
              <h3 class="package-destino" id="travelagency--package-list-102009-6">Rio de Janeiro</h3>
              <div class="package-datas" id="travelagency--package-list-102009-7">20/09/2025 - 27/09/2025</div>
              <div class="package-preco" id="travelagency--package-list-102009-8">R$ 2.500</div>
              <a href="#" class="package-detalhes" id="travelagency--package-list-102009-9">Ver detalhes</a>
            </div>
          </li>
          <li class="package-card" id="travelagency--package-list-102009-10">
            <div class="package-image" id="travelagency--package-list-102009-11">
              <img src="https://images.unsplash.com/photo-1600908239415-f118642d5646?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxDZW50cm8lMjBkZSUyMEdyYW1hZG8lMjBSU3xlbnwwfHx8fDE3NTUxMDczMDB8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Centro de Gramado, RS" id="travelagency--package-list-102009-12">
            </div>
            <div class="package-info" id="travelagency--package-list-102009-13">
              <h3 class="package-destino" id="travelagency--package-list-102009-14">Gramado</h3>
              <div class="package-datas" id="travelagency--package-list-102009-15">15/10/2025 - 20/10/2025</div>
              <div class="package-preco" id="travelagency--package-list-102009-16">R$ 3.200</div>
              <a href="#" class="package-detalhes" id="travelagency--package-list-102009-17">Ver detalhes</a>
            </div>
          </li>
          <li class="package-card" id="travelagency--package-list-102009-18">
            <div class="package-image" id="travelagency--package-list-102009-19">
              <img src="https://images.unsplash.com/photo-1689555204783-d84595f0be50?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxGYXJvbCUyMGRhJTIwQmFycmElMjBTYWx2YWRvcnxlbnwwfHx8fDE3NTUxMDczMDB8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Farol da Barra, Salvador" id="travelagency--package-list-102009-20">
            </div>
            <div class="package-info" id="travelagency--package-list-102009-21">
              <h3 class="package-destino" id="travelagency--package-list-102009-22">Salvador</h3>
              <div class="package-datas" id="travelagency--package-list-102009-23">05/11/2025 - 12/11/2025</div>
              <div class="package-preco" id="travelagency--package-list-102009-24">R$ 2.800</div>
              <a href="#" class="package-detalhes" id="travelagency--package-list-102009-25">Ver detalhes</a>
            </div>
          </li>
        </ul>
      `;
    }
};
organismPackageList = __decorate([
    customElement('travelagency--organism-package-list-102009')
], organismPackageList);
export { organismPackageList };
