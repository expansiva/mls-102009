/// <mls shortName="organismClientReviews" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismClientReviews = class organismClientReviews extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-client-reviews-102009{display:block}travelagency--organism-client-reviews-102009 .reviews-section h2{font-size:var(--font-size-24);font-family:var(--font-family-primary);color:var(--text-primary-color);margin-bottom:var(--space-24)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:var(--space-24)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list .review-card{background:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 8px var(--grey-color-darker);padding:var(--space-16)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list .review-card .review-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-8)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list .review-card .review-header .review-destination{font-weight:var(--font-weight-bold);color:var(--text-primary-color);font-size:var(--font-size-16)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list .review-card .review-header .review-rating{color:var(--warning-color);font-size:var(--font-size-16)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list .review-card .review-comment{color:var(--text-primary-color-lighter);font-size:var(--font-size-16);margin-bottom:var(--space-16)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list .review-card .review-actions{display:flex;gap:var(--space-16)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list .review-card .review-actions .edit-btn{background:var(--info-color);color:#fff;border:none;border-radius:4px;padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);cursor:pointer;transition:background var(--transition-normal)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list .review-card .review-actions .edit-btn:hover{background:var(--info-color-hover)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list .review-card .review-actions .delete-btn{background:var(--error-color);color:#fff;border:none;border-radius:4px;padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);cursor:pointer;transition:background var(--transition-normal)}travelagency--organism-client-reviews-102009 .reviews-section .reviews-list .review-card .review-actions .delete-btn:hover{background:var(--error-color-hover)}`);
    }
    render() {
        return html `<section class="reviews-section" id="travelagency--client-reviews-102009-1">
          <h2 id="travelagency--client-reviews-102009-2">Minhas Avaliações</h2>
          <ul class="reviews-list" id="travelagency--client-reviews-102009-3">
            <li class="review-card" id="travelagency--client-reviews-102009-4">
              <div class="review-header" id="travelagency--client-reviews-102009-5">
                <span class="review-destination" id="travelagency--client-reviews-102009-6">Rio de Janeiro - Férias de Verão</span>
                <span class="review-rating" id="travelagency--client-reviews-102009-7">⭐⭐⭐⭐⭐</span>
              </div>
              <p class="review-comment" id="travelagency--client-reviews-102009-8">Viagem incrível! Hotel confortável e passeios bem organizados.</p>
              <div class="review-actions" id="travelagency--client-reviews-102009-9">
                <button class="edit-btn" id="travelagency--client-reviews-102009-10">Editar</button>
                <button class="delete-btn" id="travelagency--client-reviews-102009-11">Excluir</button>
              </div>
            </li>
            <li class="review-card" id="travelagency--client-reviews-102009-12">
              <div class="review-header" id="travelagency--client-reviews-102009-13">
                <span class="review-destination" id="travelagency--client-reviews-102009-14">Gramado - Natal Luz</span>
                <span class="review-rating" id="travelagency--client-reviews-102009-15">⭐⭐⭐⭐</span>
              </div>
              <p class="review-comment" id="travelagency--client-reviews-102009-16">Cidade linda, mas o hotel poderia ser melhor.</p>
              <div class="review-actions" id="travelagency--client-reviews-102009-17">
                <button class="edit-btn" id="travelagency--client-reviews-102009-18">Editar</button>
                <button class="delete-btn" id="travelagency--client-reviews-102009-19">Excluir</button>
              </div>
            </li>
            <li class="review-card" id="travelagency--client-reviews-102009-20">
              <div class="review-header" id="travelagency--client-reviews-102009-21">
                <span class="review-destination" id="travelagency--client-reviews-102009-22">Bahia - Praia e Sol</span>
                <span class="review-rating" id="travelagency--client-reviews-102009-23">⭐⭐⭐⭐⭐</span>
              </div>
              <p class="review-comment" id="travelagency--client-reviews-102009-24">Tudo perfeito! Recomendo muito.</p>
              <div class="review-actions" id="travelagency--client-reviews-102009-25">
                <button class="edit-btn" id="travelagency--client-reviews-102009-26">Editar</button>
                <button class="delete-btn" id="travelagency--client-reviews-102009-27">Excluir</button>
              </div>
            </li>
          </ul>
        </section>
      `;
    }
};
organismClientReviews = __decorate([
    customElement('travelagency--organism-client-reviews-102009')
], organismClientReviews);
export { organismClientReviews };
