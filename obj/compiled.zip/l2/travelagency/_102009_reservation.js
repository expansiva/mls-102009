/// <mls shortName="reservation" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageReservation = class PageReservation extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--reservation-102009{display:block;min-height:100vh;background:var(--bg-secondary-color-lighter)}travelagency--reservation-102009 header{background:var(--bg-primary-color);box-shadow:0 1px 4px rgba(192,192,192,0.08)}travelagency--reservation-102009 main{display:flex;flex-direction:column;align-items:center;justify-content:flex-start;min-height:70vh;padding:var(--space-32) 0;gap:var(--space-24)}travelagency--reservation-102009 footer{background:var(--bg-secondary-color);margin-top:var(--space-32)}@media (max-width:544px){travelagency--reservation-102009 main{padding:var(--space-16) 0;gap:var(--space-16)}}`);
    }
    initPage() {
    }
};
PageReservation = __decorate([
    customElement('travelagency--reservation-102009')
], PageReservation);
export { PageReservation };
