/// <mls shortName="login" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageLogin = class PageLogin extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--login-102009{min-height:100vh;display:flex;flex-direction:column;background:var(--bg-primary-color-lighter)}travelagency--login-102009>header{width:100%;background:var(--bg-primary-color);box-shadow:0 2px 8px 0 rgba(192,192,192,0.06);z-index:10}travelagency--login-102009>main{flex:1 1 auto;display:flex;flex-direction:column;justify-content:center;align-items:center;background:var(--bg-primary-color-lighter);min-height:70vh}travelagency--login-102009>footer{width:100%;background:var(--bg-secondary-color-lighter);box-shadow:0 -2px 8px 0 rgba(192,192,192,0.04)}`);
    }
    initPage() {
    }
};
PageLogin = __decorate([
    customElement('travelagency--login-102009')
], PageLogin);
export { PageLogin };
