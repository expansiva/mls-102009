/// <mls shortName="adminDashboard" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageAdminDashboard = class PageAdminDashboard extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--admin-dashboard-102009{display:grid;grid-template-columns:220px 1fr;grid-template-rows:auto 1fr auto;grid-template-areas:"header header" "aside main" "footer footer";min-height:100vh;background:var(--bg-primary-color-darker)}travelagency--admin-dashboard-102009>header{grid-area:header;background:var(--bg-primary-color);box-shadow:0 2px 4px 0 rgba(211,211,211,0.08);z-index:10}travelagency--admin-dashboard-102009>aside{grid-area:aside;background:var(--bg-secondary-color-lighter);min-width:220px;z-index:5}travelagency--admin-dashboard-102009>main{grid-area:main;padding:var(--space-32);display:flex;flex-direction:column;gap:var(--space-32)}travelagency--admin-dashboard-102009>footer{grid-area:footer;background:var(--bg-secondary-color-lighter);box-shadow:0 -2px 4px 0 rgba(211,211,211,0.08)}@media (max-width:768px){travelagency--admin-dashboard-102009{grid-template-columns:1fr;grid-template-areas:"header" "aside" "main" "footer"}travelagency--admin-dashboard-102009>aside{min-width:unset;width:100vw}travelagency--admin-dashboard-102009>main{padding:var(--space-16)}}`);
    }
    initPage() {
    }
};
PageAdminDashboard = __decorate([
    customElement('travelagency--admin-dashboard-102009')
], PageAdminDashboard);
export { PageAdminDashboard };
