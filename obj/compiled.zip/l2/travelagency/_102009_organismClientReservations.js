/// <mls shortName="organismClientReservations" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismClientReservations = class organismClientReservations extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-client-reservations-102009{display:block}travelagency--organism-client-reservations-102009 .reservations-section{margin-bottom:var(--space-40)}travelagency--organism-client-reservations-102009 .reservations-section h2{font-size:var(--font-size-24);font-family:var(--font-family-primary);color:var(--text-primary-color);margin-bottom:var(--space-24)}travelagency--organism-client-reservations-102009 .reservations-section .reservations-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:var(--space-24)}travelagency--organism-client-reservations-102009 .reservations-section .reservations-list .reservation-card{display:flex;background:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 8px var(--grey-color-darker);overflow:hidden;align-items:center}travelagency--organism-client-reservations-102009 .reservations-section .reservations-list .reservation-card .reservation-image{flex:0 0 100px;height:100px}travelagency--organism-client-reservations-102009 .reservations-section .reservations-list .reservation-card .reservation-image img{width:100px;height:100px;object-fit:cover;border-radius:8px 0 0 8px}travelagency--organism-client-reservations-102009 .reservations-section .reservations-list .reservation-card .reservation-info{flex:1;padding:var(--space-16)}travelagency--organism-client-reservations-102009 .reservations-section .reservations-list .reservation-card .reservation-info h3{font-size:var(--font-size-20);margin:0 0 var(--space-8) 0;color:var(--text-primary-color)}travelagency--organism-client-reservations-102009 .reservations-section .reservations-list .reservation-card .reservation-info p{margin:0 0 var(--space-8) 0;color:var(--text-primary-color-lighter);font-size:var(--font-size-16)}travelagency--organism-client-reservations-102009 .reservations-section .reservations-list .reservation-card .reservation-info .cancel-btn{padding:var(--space-8) var(--space-16);background:var(--error-color);color:#fff;border:none;border-radius:4px;font-size:var(--font-size-16);cursor:pointer;transition:background var(--transition-normal)}travelagency--organism-client-reservations-102009 .reservations-section .reservations-list .reservation-card .reservation-info .cancel-btn:hover:not([disabled]){background:var(--error-color-hover)}travelagency--organism-client-reservations-102009 .reservations-section .reservations-list .reservation-card .reservation-info .cancel-btn[disabled]{background:var(--error-color-disabled);cursor:not-allowed;opacity:.7}`);
    }
    render() {
        return html `<section class="reservations-section" id="travelagency--client-reservations-102009-1">
          <h2 id="travelagency--client-reservations-102009-2">Minhas Reservas</h2>
          <ul class="reservations-list" id="travelagency--client-reservations-102009-3">
            <li class="reservation-card" id="travelagency--client-reservations-102009-4">
              <div class="reservation-image" id="travelagency--client-reservations-102009-5">
                <img src="https://images.unsplash.com/photo-1583161443050-262d4f5e8b35?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxSaW8lMjBkZSUyMEphbmVpcm8lMjBwcmFpYSUyMHZpYWdlbXxlbnwwfHx8fDE3NTUwMjgzNDN8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Imagem do pacote Rio de Janeiro" id="travelagency--client-reservations-102009-6">
              </div>
              <div class="reservation-info" id="travelagency--client-reservations-102009-7">
                <h3 id="travelagency--client-reservations-102009-8">Rio de Janeiro - Férias de Verão</h3>
                <p id="travelagency--client-reservations-102009-9"><strong id="travelagency--client-reservations-102009-10">Data:</strong> 10/01/2026 - 17/01/2026</p>
                <p id="travelagency--client-reservations-102009-11"><strong id="travelagency--client-reservations-102009-12">Status:</strong> Confirmada</p>
                <button class="cancel-btn" disabled="" id="travelagency--client-reservations-102009-13">Cancelar</button>
              </div>
            </li>
            <li class="reservation-card" id="travelagency--client-reservations-102009-14">
              <div class="reservation-image" id="travelagency--client-reservations-102009-15">
                <img src="https://images.unsplash.com/photo-1595424377378-a253ca4a7486?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxHcmFtYWRvJTIwTmF0YWwlMjBMdXolMjB2aWFnZW18ZW58MHx8fHwxNzU1MTA3Njk4fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Imagem do pacote Gramado" id="travelagency--client-reservations-102009-16">
              </div>
              <div class="reservation-info" id="travelagency--client-reservations-102009-17">
                <h3 id="travelagency--client-reservations-102009-18">Gramado - Natal Luz</h3>
                <p id="travelagency--client-reservations-102009-19"><strong id="travelagency--client-reservations-102009-20">Data:</strong> 15/12/2025 - 20/12/2025</p>
                <p id="travelagency--client-reservations-102009-21"><strong id="travelagency--client-reservations-102009-22">Status:</strong> Pendente</p>
                <button class="cancel-btn" id="travelagency--client-reservations-102009-23">Cancelar</button>
              </div>
            </li>
            <li class="reservation-card" id="travelagency--client-reservations-102009-24">
              <div class="reservation-image" id="travelagency--client-reservations-102009-25">
                <img src="https://images.unsplash.com/photo-1712443715993-0b1c2163f82f?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxCYWhpYSUyMHByYWlhJTIwdmlhZ2VtfGVufDB8fHx8MTc1NTEwNzcwMHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Imagem do pacote Bahia" id="travelagency--client-reservations-102009-26">
              </div>
              <div class="reservation-info" id="travelagency--client-reservations-102009-27">
                <h3 id="travelagency--client-reservations-102009-28">Bahia - Praia e Sol</h3>
                <p id="travelagency--client-reservations-102009-29"><strong id="travelagency--client-reservations-102009-30">Data:</strong> 05/03/2026 - 12/03/2026</p>
                <p id="travelagency--client-reservations-102009-31"><strong id="travelagency--client-reservations-102009-32">Status:</strong> Cancelada</p>
                <button class="cancel-btn" disabled="" id="travelagency--client-reservations-102009-33">Cancelada</button>
              </div>
            </li>
          </ul>
        </section>
      `;
    }
};
organismClientReservations = __decorate([
    customElement('travelagency--organism-client-reservations-102009')
], organismClientReservations);
export { organismClientReservations };
