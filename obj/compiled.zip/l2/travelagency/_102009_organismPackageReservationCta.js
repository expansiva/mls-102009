/// <mls shortName="organismPackageReservationCta" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPackageReservationCta = class organismPackageReservationCta extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-package-reservation-cta-102009 .package-reservation-cta__container{background:var(--bg-secondary-color-lighter);border-radius:8px;box-shadow:0 1px 4px var(--grey-color-dark);padding:var(--space-24);display:flex;flex-direction:column;align-items:center;margin-bottom:var(--space-40)}travelagency--organism-package-reservation-cta-102009 .package-reservation-cta__btn{background:var(--bg-secondary-color);color:var(--bg-primary-color);font-size:var(--font-size-20);font-weight:var(--font-weight-bold);border:none;border-radius:6px;padding:var(--space-16) var(--space-40);cursor:pointer;margin-bottom:var(--space-8);transition:background var(--transition-slow)}travelagency--organism-package-reservation-cta-102009 .package-reservation-cta__btn:hover,travelagency--organism-package-reservation-cta-102009 .package-reservation-cta__btn:focus{background:var(--bg-secondary-color-hover)}travelagency--organism-package-reservation-cta-102009 .package-reservation-cta__btn:disabled{background:var(--bg-secondary-color-disabled);cursor:not-allowed}travelagency--organism-package-reservation-cta-102009 .package-reservation-cta__note{font-size:var(--font-size-12);color:var(--text-primary-color-lighter-disabled);margin-top:var(--space-8)}@media (max-width:768px){travelagency--organism-package-reservation-cta-102009 organism-package-reservation-cta .package-reservation-cta__container{padding:var(--space-16)}travelagency--organism-package-reservation-cta-102009 organism-package-reservation-cta .package-reservation-cta__btn{font-size:var(--font-size-16);padding:var(--space-8) var(--space-24)}}`);
    }
    render() {
        return html `<div class="package-reservation-cta__container" id="travelagency--package-reservation-cta-102009-1">
        <button class="package-reservation-cta__btn" id="travelagency--package-reservation-cta-102009-2">Reservar Agora</button>
        <span class="package-reservation-cta__note" id="travelagency--package-reservation-cta-102009-3">* Disponível apenas para clientes autenticados</span>
      </div>
    `;
    }
};
organismPackageReservationCta = __decorate([
    customElement('travelagency--organism-package-reservation-cta-102009')
], organismPackageReservationCta);
export { organismPackageReservationCta };
