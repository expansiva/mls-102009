/// <mls shortName="organismAdminSidebar" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAdminSidebar = class organismAdminSidebar extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-admin-sidebar-102009{background:var(--bg-secondary-color-lighter);min-height:100vh;width:220px;display:flex;flex-direction:column}travelagency--organism-admin-sidebar-102009 .sidebar-nav{width:100%}travelagency--organism-admin-sidebar-102009 .sidebar-nav .sidebar-header{padding:var(--space-24) var(--space-16);text-align:center}travelagency--organism-admin-sidebar-102009 .sidebar-nav .sidebar-header .sidebar-logo{width:90px;height:auto}travelagency--organism-admin-sidebar-102009 .sidebar-nav .sidebar-menu{list-style:none;margin:0;padding:0}travelagency--organism-admin-sidebar-102009 .sidebar-nav .sidebar-menu .sidebar-menu-item{display:flex;align-items:center;padding:var(--space-16) var(--space-24);color:var(--text-primary-color);font-size:var(--font-size-16);cursor:pointer;border-left:4px solid transparent;transition:background var(--transition-normal),border-color var(--transition-normal)}travelagency--organism-admin-sidebar-102009 .sidebar-nav .sidebar-menu .sidebar-menu-item:hover,travelagency--organism-admin-sidebar-102009 .sidebar-nav .sidebar-menu .sidebar-menu-item.active{background:var(--bg-primary-color-hover);border-left:4px solid var(--bg-secondary-color);color:var(--bg-secondary-color)}travelagency--organism-admin-sidebar-102009 .sidebar-nav .sidebar-menu .sidebar-menu-item .sidebar-menu-icon{margin-right:var(--space-16);font-size:var(--font-size-20)}@media (max-width:768px){travelagency--organism-admin-sidebar-102009{width:100vw;min-height:unset}travelagency--organism-admin-sidebar-102009 .sidebar-nav{flex-direction:row}travelagency--organism-admin-sidebar-102009 .sidebar-nav .sidebar-menu{display:flex;flex-direction:row}travelagency--organism-admin-sidebar-102009 .sidebar-nav .sidebar-menu .sidebar-menu-item{flex:1;justify-content:center;padding:var(--space-16) 0}}`);
    }
    render() {
        return html `<nav class="sidebar-nav" id="travelagency--admin-sidebar-102009-1">
        <div class="sidebar-header" id="travelagency--admin-sidebar-102009-2">
          <img src="https://images.unsplash.com/photo-1504542982118-59308b40fe0c?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxsb2dvJTIwYWclQzMlQUFuY2lhJTIwZGUlMjB2aWFnZW5zJTIwdHJhdmVsJTIwYWdlbmN5fGVufDB8fHx8MTc1NTEwNzgzOHww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Logo Travel Agency" class="sidebar-logo" id="travelagency--admin-sidebar-102009-3">
        </div>
        <ul class="sidebar-menu" id="travelagency--admin-sidebar-102009-4">
          <li class="sidebar-menu-item active" id="travelagency--admin-sidebar-102009-5">
            <span class="sidebar-menu-icon" id="travelagency--admin-sidebar-102009-6">🏝️</span>
            <span class="sidebar-menu-label" id="travelagency--admin-sidebar-102009-7">Pacotes</span>
          </li>
          <li class="sidebar-menu-item" id="travelagency--admin-sidebar-102009-8">
            <span class="sidebar-menu-icon" id="travelagency--admin-sidebar-102009-9">📅</span>
            <span class="sidebar-menu-label" id="travelagency--admin-sidebar-102009-10">Reservas</span>
          </li>
          <li class="sidebar-menu-item" id="travelagency--admin-sidebar-102009-11">
            <span class="sidebar-menu-icon" id="travelagency--admin-sidebar-102009-12">⭐</span>
            <span class="sidebar-menu-label" id="travelagency--admin-sidebar-102009-13">Avaliações</span>
          </li>
          <li class="sidebar-menu-item" id="travelagency--admin-sidebar-102009-14">
            <span class="sidebar-menu-icon" id="travelagency--admin-sidebar-102009-15">👤</span>
            <span class="sidebar-menu-label" id="travelagency--admin-sidebar-102009-16">Administradores</span>
          </li>
        </ul>
      </nav>
    `;
    }
};
organismAdminSidebar = __decorate([
    customElement('travelagency--organism-admin-sidebar-102009')
], organismAdminSidebar);
export { organismAdminSidebar };
