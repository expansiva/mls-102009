/// <mls shortName="home" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageHome = class PageHome extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--home-102009{display:flex;flex-direction:column;min-height:100vh;background:var(--bg-primary-color)}travelagency--home-102009 header{flex-shrink:0}travelagency--home-102009 main{flex:1 0 auto;max-width:1200px;margin:0 auto;width:100%;padding:var(--space-32) var(--space-16);box-sizing:border-box}travelagency--home-102009 footer{flex-shrink:0;margin-top:auto}`);
    }
    initPage() {
    }
};
PageHome = __decorate([
    customElement('travelagency--home-102009')
], PageHome);
export { PageHome };
