/// <mls shortName="organismPackageSearch" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismPackageSearch = class organismPackageSearch extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-package-search-102009 .package-search-form{display:flex;flex-direction:column;background:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 8px 0 var(--grey-color-light);padding:var(--space-32);margin:var(--space-32) 0}@media (max-width:768px){travelagency--organism-package-search-102009 .package-search-form{padding:var(--space-16)}}travelagency--organism-package-search-102009 .search-fields{display:flex;gap:var(--space-24);margin-bottom:var(--space-24)}@media (max-width:768px){travelagency--organism-package-search-102009 .search-fields{flex-direction:column;gap:var(--space-16)}}travelagency--organism-package-search-102009 .search-field{flex:1;display:flex;flex-direction:column}travelagency--organism-package-search-102009 .search-field label{font-size:var(--font-size-16);color:var(--text-primary-color);margin-bottom:var(--space-8)}travelagency--organism-package-search-102009 .search-field input{padding:var(--space-8) var(--space-16);border:1px solid var(--grey-color-dark);border-radius:4px;font-size:var(--font-size-16);font-family:var(--font-family-primary);color:var(--text-primary-color);background:var(--bg-secondary-color-lighter);transition:border-color var(--transition-normal)}travelagency--organism-package-search-102009 .search-field input:focus{border-color:var(--link-color);outline:none}travelagency--organism-package-search-102009 .search-btn{align-self:flex-end;background:var(--link-color);color:#fff;padding:var(--space-16) var(--space-32);border:none;border-radius:6px;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-normal)}travelagency--organism-package-search-102009 .search-btn:hover,travelagency--organism-package-search-102009 .search-btn:focus{background:var(--link-color-hover)}@media (max-width:768px){travelagency--organism-package-search-102009 .search-btn{align-self:stretch}}`);
    }
    render() {
        return html `<form class="package-search-form" aria-label="Buscar pacotes de viagem" id="travelagency--package-search-102009-1">
        <div class="search-fields" id="travelagency--package-search-102009-2">
          <div class="search-field" id="travelagency--package-search-102009-3">
            <label for="destino" id="travelagency--package-search-102009-4">Destino</label>
            <input type="text" id="destino" name="destino" placeholder="Ex: Paris, Rio de Janeiro...">
          </div>
          <div class="search-field" id="travelagency--package-search-102009-5">
            <label for="data" id="travelagency--package-search-102009-6">Data</label>
            <input type="date" id="data" name="data">
          </div>
          <div class="search-field" id="travelagency--package-search-102009-7">
            <label for="preco" id="travelagency--package-search-102009-8">Preço até</label>
            <input type="number" id="preco" name="preco" placeholder="R$" min="0">
          </div>
        </div>
        <button type="submit" class="search-btn" id="travelagency--package-search-102009-9">Buscar Pacotes</button>
      </form>
    `;
    }
};
organismPackageSearch = __decorate([
    customElement('travelagency--organism-package-search-102009')
], organismPackageSearch);
export { organismPackageSearch };
