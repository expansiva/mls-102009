/// <mls shortName="organismAdminReviewManagement" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismAdminReviewManagement = class organismAdminReviewManagement extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-admin-review-management-102009 .admin-section{background:var(--bg-primary-color);border-radius:var(--space-8);margin-bottom:var(--space-32);padding:var(--space-24);box-shadow:0 2px 8px 0 rgba(211,211,211,0.1)}travelagency--organism-admin-review-management-102009 .admin-section .section-header{margin-bottom:var(--space-24)}travelagency--organism-admin-review-management-102009 .admin-section .section-header h2{font-size:var(--font-size-24);color:var(--text-primary-color);font-weight:var(--font-weight-bold)}travelagency--organism-admin-review-management-102009 .admin-section .admin-table{width:100%;border-collapse:collapse}travelagency--organism-admin-review-management-102009 .admin-section .admin-table th,travelagency--organism-admin-review-management-102009 .admin-section .admin-table td{padding:var(--space-16);text-align:left;border-bottom:1px solid var(--grey-color)}travelagency--organism-admin-review-management-102009 .admin-section .admin-table th{color:var(--text-primary-color-darker);font-weight:var(--font-weight-bold);background:var(--bg-secondary-color-lighter)}travelagency--organism-admin-review-management-102009 .admin-section .admin-table .btn{margin-right:var(--space-8)}travelagency--organism-admin-review-management-102009 .admin-section .admin-table .btn.btn-small{padding:var(--space-8) var(--space-16);font-size:var(--font-size-12)}travelagency--organism-admin-review-management-102009 .admin-section .admin-table .btn.btn-secondary{background:var(--bg-secondary-color);color:var(--text-primary-color)}travelagency--organism-admin-review-management-102009 .admin-section .admin-table .btn.btn-secondary:hover{background:var(--bg-secondary-color-hover)}travelagency--organism-admin-review-management-102009 .admin-section .admin-table .btn.btn-danger{background:var(--error-color);color:#fff}travelagency--organism-admin-review-management-102009 .admin-section .admin-table .btn.btn-danger:hover{background:var(--error-color-hover)}`);
    }
    render() {
        return html `<section class="admin-section" id="travelagency--admin-review-management-102009-1">
        <div class="section-header" id="travelagency--admin-review-management-102009-2">
          <h2 id="travelagency--admin-review-management-102009-3">Gestão de Avaliações</h2>
        </div>
        <table class="admin-table" id="travelagency--admin-review-management-102009-4">
          <thead id="travelagency--admin-review-management-102009-5">
            <tr id="travelagency--admin-review-management-102009-6">
              <th id="travelagency--admin-review-management-102009-7">Cliente</th>
              <th id="travelagency--admin-review-management-102009-8">Pacote</th>
              <th id="travelagency--admin-review-management-102009-9">Nota</th>
              <th id="travelagency--admin-review-management-102009-10">Comentário</th>
              <th id="travelagency--admin-review-management-102009-11">Ações</th>
            </tr>
          </thead>
          <tbody id="travelagency--admin-review-management-102009-12">
            <tr id="travelagency--admin-review-management-102009-13">
              <td id="travelagency--admin-review-management-102009-14">Lucas Silva</td>
              <td id="travelagency--admin-review-management-102009-15">Rio de Janeiro</td>
              <td id="travelagency--admin-review-management-102009-16">5 ⭐</td>
              <td id="travelagency--admin-review-management-102009-17">Viagem incrível, recomendo!</td>
              <td id="travelagency--admin-review-management-102009-18">
                <button class="btn btn-small btn-secondary" id="travelagency--admin-review-management-102009-19">Editar</button>
                <button class="btn btn-small btn-danger" id="travelagency--admin-review-management-102009-20">Excluir</button>
              </td>
            </tr>
            <tr id="travelagency--admin-review-management-102009-21">
              <td id="travelagency--admin-review-management-102009-22">Maria Souza</td>
              <td id="travelagency--admin-review-management-102009-23">Salvador</td>
              <td id="travelagency--admin-review-management-102009-24">4 ⭐</td>
              <td id="travelagency--admin-review-management-102009-25">Ótimo atendimento.</td>
              <td id="travelagency--admin-review-management-102009-26">
                <button class="btn btn-small btn-secondary" id="travelagency--admin-review-management-102009-27">Editar</button>
                <button class="btn btn-small btn-danger" id="travelagency--admin-review-management-102009-28">Excluir</button>
              </td>
            </tr>
          </tbody>
        </table>
      </section>
    `;
    }
};
organismAdminReviewManagement = __decorate([
    customElement('travelagency--organism-admin-review-management-102009')
], organismAdminReviewManagement);
export { organismAdminReviewManagement };
