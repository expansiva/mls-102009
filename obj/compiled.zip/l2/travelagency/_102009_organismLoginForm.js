/// <mls shortName="organismLoginForm" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismLoginForm = class organismLoginForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-login-form-102009{display:flex;justify-content:center;align-items:center;min-height:70vh;background:var(--bg-primary-color-lighter);width:100%}travelagency--organism-login-form-102009 .login-form__container{background:var(--bg-primary-color);border-radius:12px;box-shadow:0 2px 16px 0 rgba(192,192,192,0.1);padding:var(--space-48) var(--space-40);max-width:380px;width:100%;margin:var(--space-32) auto;display:flex;flex-direction:column;gap:var(--space-24)}travelagency--organism-login-form-102009 .login-form__header{display:flex;flex-direction:column;align-items:center;gap:var(--space-8);margin-bottom:var(--space-16)}travelagency--organism-login-form-102009 .login-form__logo{width:56px;height:56px;object-fit:contain;margin-bottom:var(--space-8)}travelagency--organism-login-form-102009 .login-form__title{font-family:var(--font-family-primary);font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin:0}travelagency--organism-login-form-102009 .login-form__subtitle{font-size:var(--font-size-16);color:var(--text-primary-color-lighter);margin:0;text-align:center}travelagency--organism-login-form-102009 .login-form__form{display:flex;flex-direction:column;gap:var(--space-16)}travelagency--organism-login-form-102009 .login-form__field{display:flex;flex-direction:column;gap:var(--space-8)}travelagency--organism-login-form-102009 .login-form__field label{font-size:var(--font-size-16);color:var(--text-primary-color);font-weight:var(--font-weight-normal)}travelagency--organism-login-form-102009 .login-form__field input{padding:var(--space-8) var(--space-16);border:1px solid var(--grey-color-dark);border-radius:6px;font-size:var(--font-size-16);font-family:var(--font-family-primary);color:var(--text-primary-color);background:var(--bg-secondary-color-lighter);transition:border-color var(--transition-normal)}travelagency--organism-login-form-102009 .login-form__field input:focus{border-color:var(--bg-secondary-color);outline:none}travelagency--organism-login-form-102009 .login-form__actions{display:flex;flex-direction:column;align-items:stretch;margin-top:var(--space-8)}travelagency--organism-login-form-102009 .login-form__actions .login-form__submit{background:var(--bg-secondary-color);color:var(--bg-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);border:none;border-radius:6px;padding:var(--space-8) 0;cursor:pointer;transition:background var(--transition-normal)}travelagency--organism-login-form-102009 .login-form__actions .login-form__submit:hover{background:var(--bg-secondary-color-hover)}travelagency--organism-login-form-102009 .login-form__actions .login-form__submit:active{background:var(--bg-secondary-color-focus)}travelagency--organism-login-form-102009 .login-form__actions .login-form__submit:disabled{background:var(--bg-secondary-color-disabled);cursor:not-allowed}travelagency--organism-login-form-102009 .login-form__links{display:flex;justify-content:center;align-items:center;gap:var(--space-8);margin-top:var(--space-8)}travelagency--organism-login-form-102009 .login-form__links a{color:var(--link-color);font-size:var(--font-size-16);text-decoration:none;transition:color var(--transition-normal)}travelagency--organism-login-form-102009 .login-form__links a:hover{color:var(--link-color-hover)}travelagency--organism-login-form-102009 .login-form__links .login-form__divider{color:var(--grey-color-darker);font-size:var(--font-size-16)}travelagency--organism-login-form-102009 .login-form__footer{margin-top:var(--space-16);text-align:center}travelagency--organism-login-form-102009 .login-form__footer .login-form__info{color:var(--text-primary-color-lighter);font-size:var(--font-size-12);margin:0}@media (max-width:544px){travelagency--organism-login-form-102009 .login-form__container{padding:var(--space-24) var(--space-8);max-width:100vw}}`);
    }
    render() {
        return html `<div class="login-form__container" id="travelagency--login-form-102009-1">
        <div class="login-form__header" id="travelagency--login-form-102009-2">
          <img class="login-form__logo" src="https://images.unsplash.com/photo-1626417359455-2377907b1141?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHx0cmF2ZWwlMjBhZ2VuY3klMjBsb2dvJTIwaWNvbnxlbnwwfHx8fDE3NTUxMDc1Njd8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Logo Travel Agency" id="travelagency--login-form-102009-3">
          <h1 class="login-form__title" id="travelagency--login-form-102009-4">Entrar na sua conta</h1>
          <p class="login-form__subtitle" id="travelagency--login-form-102009-5">Acesse sua conta de cliente ou administrador</p>
        </div>
        <form class="login-form__form" autocomplete="off" id="travelagency--login-form-102009-6">
          <div class="login-form__field" id="travelagency--login-form-102009-7">
            <label for="login-email" id="travelagency--login-form-102009-8">E-mail</label>
            <input type="email" id="login-email" name="email" placeholder="seu@email.com" required="" autocomplete="username">
          </div>
          <div class="login-form__field" id="travelagency--login-form-102009-9">
            <label for="login-password" id="travelagency--login-form-102009-10">Senha</label>
            <input type="password" id="login-password" name="password" placeholder="Sua senha" required="" autocomplete="current-password">
          </div>
          <div class="login-form__actions" id="travelagency--login-form-102009-11">
            <button type="submit" class="login-form__submit" id="travelagency--login-form-102009-12">Entrar</button>
          </div>
          <div class="login-form__links" id="travelagency--login-form-102009-13">
            <a href="#" class="login-form__forgot" id="travelagency--login-form-102009-14">Esqueci minha senha</a>
            <span class="login-form__divider" id="travelagency--login-form-102009-15">|</span>
            <a href="#" class="login-form__register" id="travelagency--login-form-102009-16">Criar conta</a>
          </div>
        </form>
        <div class="login-form__footer" id="travelagency--login-form-102009-17">
          <p class="login-form__info" id="travelagency--login-form-102009-18">Acesso restrito a clientes e administradores cadastrados.</p>
        </div>
      </div>
    `;
    }
};
organismLoginForm = __decorate([
    customElement('travelagency--organism-login-form-102009')
], organismLoginForm);
export { organismLoginForm };
