/// <mls shortName="organismHeroBanner" project="102009" folder="travelagency" enhancement="_100554_enhancementLit" groupName="travelagency" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let organismHeroBanner = class organismHeroBanner extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`travelagency--organism-hero-banner-102009 .hero-banner{display:flex;align-items:center;justify-content:space-between;background:var(--bg-secondary-color-lighter);padding:var(--space-48) var(--space-32);border-radius:12px;margin:var(--space-32) 0}@media (max-width:768px){travelagency--organism-hero-banner-102009 .hero-banner{flex-direction:column;padding:var(--space-24) var(--space-8);text-align:center}}travelagency--organism-hero-banner-102009 .hero-content{flex:1;max-width:520px}@media (max-width:768px){travelagency--organism-hero-banner-102009 .hero-content{max-width:100%}}travelagency--organism-hero-banner-102009 .hero-title{font-size:var(--font-size-40);font-family:var(--font-family-primary);color:var(--text-primary-color);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16);line-height:var(--line-height-large)}travelagency--organism-hero-banner-102009 .hero-title .highlight{color:var(--link-color)}travelagency--organism-hero-banner-102009 .hero-subtitle{font-size:var(--font-size-20);color:var(--text-primary-color-lighter);margin-bottom:var(--space-24);line-height:var(--line-height-medium)}travelagency--organism-hero-banner-102009 .hero-cta{display:inline-block;background:var(--link-color);color:#fff;padding:var(--space-16) var(--space-32);border-radius:6px;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);text-decoration:none;transition:background var(--transition-normal)}travelagency--organism-hero-banner-102009 .hero-cta:hover,travelagency--organism-hero-banner-102009 .hero-cta:focus{background:var(--link-color-hover)}travelagency--organism-hero-banner-102009 .hero-image{flex:1;display:flex;justify-content:flex-end}@media (max-width:768px){travelagency--organism-hero-banner-102009 .hero-image{justify-content:center;margin-top:var(--space-24)}}travelagency--organism-hero-banner-102009 .hero-image img{max-width:380px;width:100%;border-radius:10px;box-shadow:0 4px 24px 0 var(--grey-color-dark)}`);
    }
    render() {
        return html `<div class="hero-banner" id="travelagency--hero-banner-102009-1">
        <div class="hero-content" id="travelagency--hero-banner-102009-2">
          <h1 class="hero-title" id="travelagency--hero-banner-102009-3">Descubra o mundo com a <span class="highlight" id="travelagency--hero-banner-102009-4">Travel Agency</span></h1>
          <p class="hero-subtitle" id="travelagency--hero-banner-102009-5">Encontre os melhores pacotes de viagem, reserve online e viva experiências inesquecíveis.</p>
          <a href="#pacotes" class="hero-cta" id="travelagency--hero-banner-102009-6">Explorar Pacotes</a>
        </div>
        <div class="hero-image" id="travelagency--hero-banner-102009-7">
          <img src="https://images.unsplash.com/photo-1576485290814-1c72aa4bbb8e?crop=entropy&amp;cs=srgb&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHx0cmF2ZWwlMjBsYW5kc2NhcGUlMjBiYW5uZXJ8ZW58MHx8fHwxNzU1MTA3MjA4fDA&amp;ixlib=rb-4.1.0&amp;q=85" alt="Paisagem de viagem inspiradora" id="travelagency--hero-banner-102009-8">
        </div>
      </div>
    `;
    }
};
organismHeroBanner = __decorate([
    customElement('travelagency--organism-hero-banner-102009')
], organismHeroBanner);
export { organismHeroBanner };
