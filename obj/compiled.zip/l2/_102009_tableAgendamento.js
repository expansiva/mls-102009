/// <mls shortName="tableAgendamento" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
export const modelPrisma = `
model Agendamento {
  id Int @id @default(autoincrement())
  data DateTime
  hora String
  servico String 
  clienteId Int 
  status String
}
`;
