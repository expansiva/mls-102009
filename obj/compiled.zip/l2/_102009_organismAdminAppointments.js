/// <mls shortName="organismAdminAppointments" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAdminAppointments = class _102009_organismAdminAppointments extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-admin-appointments-102009 .admin-section{background-color:var(--color-background);border-radius:var(--border-radius-md);padding:var(--spacing-lg);margin-bottom:var(--spacing-lg);box-shadow:var(--shadow-sm)}organism-admin-appointments-102009 .admin-section .section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-lg)}organism-admin-appointments-102009 .admin-section .section-header h2{color:var(--color-text-normal);font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);margin:0}organism-admin-appointments-102009 .admin-section .section-header .filter-controls{display:flex;gap:var(--spacing-sm)}organism-admin-appointments-102009 .admin-section .section-header .filter-controls .filter-select,organism-admin-appointments-102009 .admin-section .section-header .filter-controls .date-filter{padding:var(--spacing-xs) var(--spacing-sm);border:1px solid var(--color-border);border-radius:var(--border-radius-xs);font-size:var(--font-size-sm)}organism-admin-appointments-102009 .admin-section .appointments-list{display:flex;flex-direction:column;gap:var(--spacing-md)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card{display:grid;grid-template-columns:120px 1fr auto auto;gap:var(--spacing-md);padding:var(--spacing-md);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);align-items:center;transition:var(--transition-base)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card:hover{box-shadow:var(--shadow-md)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card.confirmed{border-left:4px solid var(--color-success)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card.pending{border-left:4px solid var(--color-warning)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-time{display:flex;flex-direction:column;align-items:center}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-time .date{font-weight:var(--font-weight-bold);color:var(--color-text-normal);font-size:var(--font-size-sm)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-time .time{color:var(--color-primary);font-weight:var(--font-weight-bold);font-size:var(--font-size-lg)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-details h4{margin:0 0 var(--spacing-xs) 0;color:var(--color-text-normal);font-size:var(--font-size-md)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-details .pet-info{color:var(--color-text-secondary);font-size:var(--font-size-sm);margin:var(--spacing-xs) 0}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-details .contact{color:var(--color-text-secondary);font-size:var(--font-size-sm);margin:var(--spacing-xs) 0 0 0}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-status .status{padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);font-size:var(--font-size-xs);font-weight:var(--font-weight-bold)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-status .status.confirmed{background-color:var(--color-success);color:white}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-status .status.pending{background-color:var(--color-warning);color:white}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-actions{display:flex;gap:var(--spacing-xs)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-actions button{padding:var(--spacing-xs) var(--spacing-sm);border:none;border-radius:var(--border-radius-xs);cursor:pointer;font-size:var(--font-size-xs);transition:var(--transition-base)}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-actions .btn-edit{background-color:var(--color-secondary);color:white}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-actions .btn-edit:hover{opacity:.9}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-actions .btn-confirm{background-color:var(--color-success);color:white}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-actions .btn-confirm:hover{opacity:.9}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-actions .btn-cancel{background-color:var(--color-error);color:white}organism-admin-appointments-102009 .admin-section .appointments-list .appointment-card .appointment-actions .btn-cancel:hover{opacity:.9}`);
    }
    render() {
        return html `
    <section class="admin-section" id="admin-appointments-1">
  <div class="section-header" id="admin-appointments-2">
    <h2 id="admin-appointments-3">Agendamentos</h2>
    <div class="filter-controls" id="admin-appointments-4">
      <select class="filter-select" id="admin-appointments-5">
        <option id="admin-appointments-6">Todos os status</option>
        <option id="admin-appointments-7">Confirmado</option>
        <option id="admin-appointments-8">Pendente</option>
        <option id="admin-appointments-9">Cancelado</option>
      </select>
      <input type="date" class="date-filter" id="admin-appointments-10" />
    </div>
  </div>

  <div class="appointments-list" id="admin-appointments-11">
    <div class="appointment-card confirmed" id="admin-appointments-12">
      <div class="appointment-time" id="admin-appointments-13">
        <span class="date" id="admin-appointments-14">24/07/2025</span>
        <span class="time" id="admin-appointments-15">09:00</span>
      </div>
      <div class="appointment-details" id="admin-appointments-16">
        <h4 id="admin-appointments-17">Maria Silva</h4>
        <p class="pet-info" id="admin-appointments-18">Rex (Golden Retriever) - Banho e Tosa</p>
        <p class="contact" id="admin-appointments-19">📞 (11) 99999-9999</p>
      </div>
      <div class="appointment-status" id="admin-appointments-20">
        <span class="status confirmed" id="admin-appointments-21">Confirmado</span>
      </div>
      <div class="appointment-actions" id="admin-appointments-22">
        <button class="btn-edit" id="admin-appointments-23">Editar</button>
        <button class="btn-cancel" id="admin-appointments-24">Cancelar</button>
      </div>
    </div>

    <div class="appointment-card pending" id="admin-appointments-25">
      <div class="appointment-time" id="admin-appointments-26">
        <span class="date" id="admin-appointments-27">24/07/2025</span>
        <span class="time" id="admin-appointments-28">14:30</span>
      </div>
      <div class="appointment-details" id="admin-appointments-29">
        <h4 id="admin-appointments-30">João Santos</h4>
        <p class="pet-info" id="admin-appointments-31">Mimi (Gato Persa) - Consulta Veterinária</p>
        <p class="contact" id="admin-appointments-32">📞 (11) 88888-8888</p>
      </div>
      <div class="appointment-status" id="admin-appointments-33">
        <span class="status pending" id="admin-appointments-34">Pendente</span>
      </div>
      <div class="appointment-actions" id="admin-appointments-35">
        <button class="btn-confirm" id="admin-appointments-36">Confirmar</button>
        <button class="btn-cancel" id="admin-appointments-37">Cancelar</button>
      </div>
    </div>
  </div>
</section>

    `;
    }
};
_102009_organismAdminAppointments = __decorate([
    customElement('organism-admin-appointments-102009')
], _102009_organismAdminAppointments);
export { _102009_organismAdminAppointments };
