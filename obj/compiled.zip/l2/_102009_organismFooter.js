/// <mls shortName="organismFooter" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
let _102009_organismFooter = class _102009_organismFooter extends IcaOrganismWireframeBase {
    constructor() {
        super(...arguments);
        this.generalDescription = 'Rodapé do site, visível em todas as páginas.';
        this.goal = 'Exibir informações de contato e links úteis.';
    }
};
_102009_organismFooter = __decorate([
    customElement('organism-footer-102009')
], _102009_organismFooter);
export { _102009_organismFooter };
