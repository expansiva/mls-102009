/// <mls shortName="organismCheckoutForm" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismCheckoutForm = class _102009_organismCheckoutForm extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-checkout-form-102009 .checkout-form-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-lg);box-shadow:var(--shadow-sm)}organism-checkout-form-102009 .checkout-form-container h2{color:var(--color-primary);font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-lg);text-align:center}organism-checkout-form-102009 .checkout-form-container .form-section{margin-bottom:var(--spacing-lg)}organism-checkout-form-102009 .checkout-form-container .form-section h3{color:var(--color-text-normal);font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-md);padding-bottom:var(--spacing-xs);border-bottom:2px solid var(--color-primary)}organism-checkout-form-102009 .checkout-form-container .form-row{display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-md);margin-bottom:var(--spacing-md)}@media (max-width:480px){organism-checkout-form-102009 .checkout-form-container .form-row{grid-template-columns:1fr}}organism-checkout-form-102009 .checkout-form-container .form-group{display:flex;flex-direction:column}organism-checkout-form-102009 .checkout-form-container .form-group label{color:var(--color-text-normal);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-xs);font-size:var(--font-size-sm)}organism-checkout-form-102009 .checkout-form-container .form-group input{padding:var(--spacing-sm);border:2px solid var(--color-border);border-radius:var(--border-radius-sm);font-size:var(--font-size-md);transition:var(--transition-base)}organism-checkout-form-102009 .checkout-form-container .form-group input:focus{outline:none;border-color:var(--color-primary);box-shadow:0 0 0 3px rgba(28,145,205,0.1)}organism-checkout-form-102009 .checkout-form-container .form-group input:required:invalid{border-color:var(--color-error)}`);
    }
    render() {
        return html `
  <div class="checkout-form-container" id="checkout-form-1">
  <h2 id="checkout-form-2">Dados para Entrega</h2>
  <form class="checkout-form" id="checkout-form-3">
    <div class="form-section" id="checkout-form-4">
      <h3 id="checkout-form-5">Informações Pessoais</h3>
      <div class="form-row" id="checkout-form-6">
        <div class="form-group" id="checkout-form-7">
          <label for="fullName" id="checkout-form-8">Nome Completo *</label>
          <input type="text" id="fullName" name="fullName" required="" />
        </div>
        <div class="form-group" id="checkout-form-9">
          <label for="email" id="checkout-form-10">E-mail *</label>
          <input type="email" id="email" name="email" required="" />
        </div>
      </div>
      <div class="form-row" id="checkout-form-11">
        <div class="form-group" id="checkout-form-12">
          <label for="phone" id="checkout-form-13">Telefone *</label>
          <input type="tel" id="phone" name="phone" required="" />
        </div>
        <div class="form-group" id="checkout-form-14">
          <label for="cpf" id="checkout-form-15">CPF *</label>
          <input type="text" id="cpf" name="cpf" required="" />
        </div>
      </div>
    </div>

    <div class="form-section" id="checkout-form-16">
      <h3 id="checkout-form-17">Endereço de Entrega</h3>
      <div class="form-row" id="checkout-form-18">
        <div class="form-group" id="checkout-form-19">
          <label for="cep" id="checkout-form-20">CEP *</label>
          <input type="text" id="cep" name="cep" required="" />
        </div>
        <div class="form-group" id="checkout-form-21">
          <label for="street" id="checkout-form-22">Rua *</label>
          <input type="text" id="street" name="street" required="" />
        </div>
      </div>
      <div class="form-row" id="checkout-form-23">
        <div class="form-group" id="checkout-form-24">
          <label for="number" id="checkout-form-25">Número *</label>
          <input type="text" id="number" name="number" required="" />
        </div>
        <div class="form-group" id="checkout-form-26">
          <label for="complement" id="checkout-form-27">Complemento</label>
          <input type="text" id="complement" name="complement" />
        </div>
      </div>
      <div class="form-row" id="checkout-form-28">
        <div class="form-group" id="checkout-form-29">
          <label for="neighborhood" id="checkout-form-30">Bairro *</label>
          <input type="text" id="neighborhood" name="neighborhood" required="" />
        </div>
        <div class="form-group" id="checkout-form-31">
          <label for="city" id="checkout-form-32">Cidade *</label>
          <input type="text" id="city" name="city" required="" />
        </div>
      </div>
    </div>
  </form>
</div>

    `;
    }
};
_102009_organismCheckoutForm = __decorate([
    customElement('organism-checkout-form-102009')
], _102009_organismCheckoutForm);
export { _102009_organismCheckoutForm };
