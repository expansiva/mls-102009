/// <mls shortName="organismProductList" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismProductList = class _102009_organismProductList extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-product-list-102009 .products-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-lg)}organism-product-list-102009 .products-header h2{margin:0;font-size:var(--font-size-xxl);font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-product-list-102009 .products-header .products-count{color:var(--color-text-secondary);font-size:var(--font-size-sm)}organism-product-list-102009 .products-grid{display:grid;grid-template-columns:repeat(auto-fill, minmax(280px, 1fr));gap:var(--spacing-lg);margin-bottom:var(--spacing-xl)}@media (max-width:768px){organism-product-list-102009 .products-grid{grid-template-columns:repeat(auto-fill, minmax(250px, 1fr));gap:var(--spacing-md)}}organism-product-list-102009 .product-card{background:var(--color-surface);border-radius:var(--border-radius-md);overflow:hidden;box-shadow:var(--shadow-sm);transition:var(--transition-base)}organism-product-list-102009 .product-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-lg)}organism-product-list-102009 .product-card .product-image{position:relative;height:200px;overflow:hidden}organism-product-list-102009 .product-card .product-image img{width:100%;height:100%;object-fit:cover;transition:var(--transition-base)}organism-product-list-102009 .product-card .product-image .product-badge{position:absolute;top:var(--spacing-sm);right:var(--spacing-sm);background:var(--color-secondary);color:var(--color-text-normal);padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-sm);font-size:var(--font-size-xs);font-weight:var(--font-weight-bold)}organism-product-list-102009 .product-card .product-info{padding:var(--spacing-md)}organism-product-list-102009 .product-card .product-info .product-name{margin:0 0 var(--spacing-xs) 0;font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-text-normal)}organism-product-list-102009 .product-card .product-info .product-description{margin:0 0 var(--spacing-md) 0;color:var(--color-text-secondary);font-size:var(--font-size-sm);line-height:var(--line-height-md)}organism-product-list-102009 .product-card .product-info .product-price{display:flex;align-items:center;gap:var(--spacing-sm);margin-bottom:var(--spacing-md)}organism-product-list-102009 .product-card .product-info .product-price .price-current{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-product-list-102009 .product-card .product-info .product-price .price-original{font-size:var(--font-size-sm);color:var(--color-text-disabled);text-decoration:line-through}organism-product-list-102009 .product-card .product-info .add-to-cart{width:100%;padding:var(--spacing-sm);background:var(--color-primary);color:var(--color-background);border:none;border-radius:var(--border-radius-sm);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-fast)}organism-product-list-102009 .product-card .product-info .add-to-cart:hover{background:var(--color-link-hover);transform:translateY(-1px)}organism-product-list-102009 .pagination{display:flex;justify-content:center;align-items:center;gap:var(--spacing-md)}organism-product-list-102009 .pagination .pagination-btn{padding:var(--spacing-sm) var(--spacing-md);background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);color:var(--color-text-normal);cursor:pointer;transition:var(--transition-fast)}organism-product-list-102009 .pagination .pagination-btn:hover:not(:disabled){background:var(--color-primary);color:var(--color-background);border-color:var(--color-primary)}organism-product-list-102009 .pagination .pagination-btn:disabled{opacity:.5;cursor:not-allowed}organism-product-list-102009 .pagination .pagination-info{color:var(--color-text-secondary);font-size:var(--font-size-sm)}`);
    }
    render() {
        return html `
        <div class="products-header">
          <h2>Nossos Produtos</h2>
          <div class="products-count">24 produtos encontrados</div>
        </div>
        
        <div class="products-grid">
          <div class="product-card">
            <div class="product-image">
              <img src="https://images.unsplash.com/photo-1611443522715-3220344f1a37?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwZG9nJTIwZm9vZCUyMGJhZ3xlbnwwfHx8fDE3NTMyOTE4ODh8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Ração Premium para Cães">
              <div class="product-badge">Mais Vendido</div>
            </div>
            <div class="product-info">
              <h3 class="product-name">Ração Premium Cães Adultos</h3>
              <p class="product-description">Ração super premium para cães adultos de todas as raças</p>
              <div class="product-price">
                <span class="price-current">R$ 89,90</span>
                <span class="price-original">R$ 99,90</span>
              </div>
              <button class="add-to-cart">Adicionar ao Carrinho</button>
            </div>
          </div>
          
          <div class="product-card">
            <div class="product-image">
              <img src="https://images.unsplash.com/photo-1594064142712-e84e63f95a55?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjByb3BlJTIwdG95fGVufDB8fHx8MTc1MzM2NTQ5NXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Brinquedo de Corda">
            </div>
            <div class="product-info">
              <h3 class="product-name">Brinquedo de Corda</h3>
              <p class="product-description">Brinquedo resistente para cães de todos os tamanhos</p>
              <div class="product-price">
                <span class="price-current">R$ 24,90</span>
              </div>
              <button class="add-to-cart">Adicionar ao Carrinho</button>
            </div>
          </div>
          
          <div class="product-card">
            <div class="product-image">
              <img src="https://images.unsplash.com/photo-1592028604480-6e7938872f57?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxsZWF0aGVyJTIwZG9nJTIwY29sbGFyfGVufDB8fHx8MTc1MzM2NTQ5Nnww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Coleira de Couro">
            </div>
            <div class="product-info">
              <h3 class="product-name">Coleira de Couro Premium</h3>
              <p class="product-description">Coleira resistente e confortável em couro legítimo</p>
              <div class="product-price">
                <span class="price-current">R$ 45,90</span>
              </div>
              <button class="add-to-cart">Adicionar ao Carrinho</button>
            </div>
          </div>
          
          <div class="product-card">
            <div class="product-image">
              <img src="https://images.unsplash.com/photo-1608571899793-a1c0c27a7555?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBzaGFtcG9vJTIwYm90dGxlfGVufDB8fHx8MTc1MzMwMDk1MXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Shampoo para Pets">
            </div>
            <div class="product-info">
              <h3 class="product-name">Shampoo Hipoalergênico</h3>
              <p class="product-description">Shampoo suave para peles sensíveis</p>
              <div class="product-price">
                <span class="price-current">R$ 32,90</span>
              </div>
              <button class="add-to-cart">Adicionar ao Carrinho</button>
            </div>
          </div>
          
          <div class="product-card">
            <div class="product-image">
              <img src="https://images.unsplash.com/photo-1661844956374-0df9ad6423b2?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwY2F0JTIwZm9vZCUyMGJhZ3xlbnwwfHx8fDE3NTMzNjU0OTZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Ração para Gatos">
            </div>
            <div class="product-info">
              <h3 class="product-name">Ração Premium Gatos</h3>
              <p class="product-description">Ração balanceada para gatos adultos</p>
              <div class="product-price">
                <span class="price-current">R$ 75,90</span>
              </div>
              <button class="add-to-cart">Adicionar ao Carrinho</button>
            </div>
          </div>
          
          <div class="product-card">
            <div class="product-image">
              <img src="https://images.unsplash.com/photo-1637942641210-6b035968584d?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxydWJiZXIlMjBiYWxsJTIwZG9nJTIwdG95fGVufDB8fHx8MTc1MzM2NTQ5N3ww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Bola de Borracha">
            </div>
            <div class="product-info">
              <h3 class="product-name">Bola de Borracha</h3>
              <p class="product-description">Bola resistente para brincadeiras</p>
              <div class="product-price">
                <span class="price-current">R$ 18,90</span>
              </div>
              <button class="add-to-cart">Adicionar ao Carrinho</button>
            </div>
          </div>
        </div>
        
        <div class="pagination">
          <button class="pagination-btn" disabled="">Anterior</button>
          <span class="pagination-info">Página 1 de 4</span>
          <button class="pagination-btn">Próxima</button>
        </div>
      `;
    }
};
_102009_organismProductList = __decorate([
    customElement('organism-product-list-102009')
], _102009_organismProductList);
export { _102009_organismProductList };
