/// <mls shortName="organismFooterInfo" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismFooterInfo = class _102009_organismFooterInfo extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-footer-info-102009 .site-footer{background-color:var(--color-text-normal);color:white;padding:var(--spacing-xxl) 0 var(--spacing-lg)}organism-footer-info-102009 .footer-content{display:grid;grid-template-columns:repeat(auto-fit, minmax(250px, 1fr));gap:var(--spacing-xl);margin-bottom:var(--spacing-xl)}organism-footer-info-102009 .footer-section .footer-title{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-secondary);margin-bottom:var(--spacing-md)}organism-footer-info-102009 .footer-section .footer-subtitle{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-md);color:white}organism-footer-info-102009 .footer-section .footer-description{color:rgba(255,255,255,0.8);line-height:var(--line-height-lg);margin-bottom:var(--spacing-md)}organism-footer-info-102009 .social-links{display:flex;gap:var(--spacing-sm)}organism-footer-info-102009 .social-links .social-link{display:inline-block;padding:var(--spacing-xs);border-radius:var(--border-radius-xs);transition:var(--transition-base)}organism-footer-info-102009 .social-links .social-link:hover{background-color:var(--color-primary)}organism-footer-info-102009 .social-links .social-link img{width:24px;height:24px}organism-footer-info-102009 .footer-links{list-style:none;padding:0;margin:0}organism-footer-info-102009 .footer-links li{margin-bottom:var(--spacing-xs)}organism-footer-info-102009 .footer-links li a{color:rgba(255,255,255,0.8);text-decoration:none;transition:var(--transition-base)}organism-footer-info-102009 .footer-links li a:hover{color:var(--color-secondary)}organism-footer-info-102009 .contact-details{color:rgba(255,255,255,0.8);line-height:var(--line-height-lg)}organism-footer-info-102009 .contact-details p{margin-bottom:var(--spacing-sm)}organism-footer-info-102009 .contact-details strong{color:white}organism-footer-info-102009 .footer-bottom{text-align:center;padding-top:var(--spacing-lg);border-top:1px solid rgba(255,255,255,0.2);color:rgba(255,255,255,0.6)}`);
    }
    render() {
        return html `
<footer class="site-footer" id="footer-info-1">
  <div class="container" id="footer-info-2">
    <div class="footer-content" id="footer-info-3">
      <div class="footer-section" id="footer-info-4">
        <h3 class="footer-title" id="footer-info-5">PetShop</h3>
        <p class="footer-description" id="footer-info-6">Cuidando do seu pet com amor e profissionalismo há mais de 10 anos.</p>
        <div class="social-links" id="footer-info-7">
          <a href="#" class="social-link" id="footer-info-8">
            <img src="https://images.unsplash.com/photo-1688678991612-c1e7c9d85c71?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxmYWNlYm9vayUyMHNvY2lhbCUyMG1lZGlhJTIwaWNvbnxlbnwwfHx8fDE3NTMyOTE4OTJ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Facebook" id="footer-info-9">
          </a>
          <a href="#" class="social-link" id="footer-info-10">
            <img src="https://images.unsplash.com/photo-1688678991318-b6949e7d26ab?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxpbnN0YWdyYW0lMjBzb2NpYWwlMjBtZWRpYSUyMGljb258ZW58MHx8fHwxNzUzMjkxODkzfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Instagram" id="footer-info-11">
          </a>
          <a href="#" class="social-link" id="footer-info-12">
            <img src="https://images.unsplash.com/photo-1644035525230-61eae56969da?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHx3aGF0c2FwcCUyMG1lc3NhZ2luZyUyMGljb258ZW58MHx8fHwxNzUzMjkxODkzfDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="WhatsApp" id="footer-info-13">
          </a>
        </div>
      </div>
      <div class="footer-section" id="footer-info-14">
        <h4 class="footer-subtitle" id="footer-info-15">Serviços</h4>
        <ul class="footer-links" id="footer-info-16">
          <li id="footer-info-17"><a href="#" id="footer-info-18">Banho e Tosa</a></li>
          <li id="footer-info-19"><a href="#" id="footer-info-20">Consulta Veterinária</a></li>
          <li id="footer-info-21"><a href="#" id="footer-info-22">Vacinação</a></li>
          <li id="footer-info-23"><a href="#" id="footer-info-24">Cirurgias</a></li>
        </ul>
      </div>
      <div class="footer-section" id="footer-info-25">
        <h4 class="footer-subtitle" id="footer-info-26">Produtos</h4>
        <ul class="footer-links" id="footer-info-27">
          <li id="footer-info-28"><a href="#" id="footer-info-29">Ração</a></li>
          <li id="footer-info-30"><a href="#" id="footer-info-31">Brinquedos</a></li>
          <li id="footer-info-32"><a href="#" id="footer-info-33">Acessórios</a></li>
          <li id="footer-info-34"><a href="#" id="footer-info-35">Higiene</a></li>
        </ul>
      </div>
      <div class="footer-section" id="footer-info-36">
        <h4 class="footer-subtitle" id="footer-info-37">Contato</h4>
        <div class="contact-details" id="footer-info-38">
          <p id="footer-info-39"><strong>Telefone:</strong> (11) 9999-9999</p>
          <p id="footer-info-40"><strong>Email:</strong> contato@petshop.com</p>
          <p id="footer-info-41"><strong>Endereço:</strong> Rua dos Pets, 123<br id="footer-info-42">São Paulo, SP - CEP 01234-567</p>
        </div>
      </div>
    </div>
    <div class="footer-bottom" id="footer-info-43">
      <p id="footer-info-44">© 2024 PetShop. Todos os direitos reservados.</p>
    </div>
  </div>
</footer>

    `;
    }
};
_102009_organismFooterInfo = __decorate([
    customElement('organism-footer-info-102009')
], _102009_organismFooterInfo);
export { _102009_organismFooterInfo };
