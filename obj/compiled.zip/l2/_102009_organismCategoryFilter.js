/// <mls shortName="organismCategoryFilter" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismCategoryFilter = class _102009_organismCategoryFilter extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-category-filter-102009 .category-filter{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-md);box-shadow:var(--shadow-sm)}organism-category-filter-102009 .category-filter h3{margin:0 0 var(--spacing-md) 0;font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-category-filter-102009 .category-filter .filter-group{display:flex;flex-direction:column;gap:var(--spacing-sm);margin-bottom:var(--spacing-md)}organism-category-filter-102009 .category-filter .filter-item{display:flex;align-items:center;cursor:pointer;padding:var(--spacing-xs);border-radius:var(--border-radius-xs);transition:var(--transition-fast)}organism-category-filter-102009 .category-filter .filter-item:hover{background-color:var(--color-overlay)}organism-category-filter-102009 .category-filter .filter-item input[type="checkbox"]{display:none}organism-category-filter-102009 .category-filter .filter-item .checkmark{width:20px;height:20px;border:2px solid var(--color-border);border-radius:var(--border-radius-xs);margin-right:var(--spacing-sm);position:relative;transition:var(--transition-fast)}organism-category-filter-102009 .category-filter .filter-item .checkmark::after{content:'';position:absolute;left:6px;top:2px;width:6px;height:10px;border:solid var(--color-background);border-width:0 2px 2px 0;transform:rotate(45deg);opacity:0;transition:var(--transition-fast)}organism-category-filter-102009 .category-filter .filter-item input[type="checkbox"]:checked+.checkmark{background-color:var(--color-primary);border-color:var(--color-primary)}organism-category-filter-102009 .category-filter .filter-item input[type="checkbox"]:checked+.checkmark::after{opacity:1}organism-category-filter-102009 .category-filter .clear-filters{width:100%;padding:var(--spacing-sm);background:transparent;border:1px solid var(--color-border);border-radius:var(--border-radius-sm);color:var(--color-text-secondary);cursor:pointer;transition:var(--transition-fast)}organism-category-filter-102009 .category-filter .clear-filters:hover{border-color:var(--color-primary);color:var(--color-primary)}`);
    }
    render() {
        return html `
<div class="category-filter" id="category-filter-1">
  <h3 id="category-filter-2">Categorias</h3>
  <div class="filter-group" id="category-filter-3">
    <label class="filter-item" id="category-filter-4">
      <input type="checkbox" name="category" value="racao" checked="" id="category-filter-5">
      <span class="checkmark" id="category-filter-6"></span>
      Ração
    </label>
    <label class="filter-item" id="category-filter-7">
      <input type="checkbox" name="category" value="brinquedos" id="category-filter-8">
      <span class="checkmark" id="category-filter-9"></span>
      Brinquedos
    </label>
    <label class="filter-item" id="category-filter-10">
      <input type="checkbox" name="category" value="acessorios" id="category-filter-11">
      <span class="checkmark" id="category-filter-12"></span>
      Acessórios
    </label>
    <label class="filter-item" id="category-filter-13">
      <input type="checkbox" name="category" value="higiene" id="category-filter-14">
      <span class="checkmark" id="category-filter-15"></span>
      Produtos de Higiene
    </label>
  </div>
  <button class="clear-filters" id="category-filter-16">Limpar Filtros</button>
</div>

      `;
    }
};
_102009_organismCategoryFilter = __decorate([
    customElement('organism-category-filter-102009')
], _102009_organismCategoryFilter);
export { _102009_organismCategoryFilter };
