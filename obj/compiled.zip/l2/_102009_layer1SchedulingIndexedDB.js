import { STORE_NAME_SCHEDULING, openDB } from "./_102009_layer1IndexedDb";
class Scheduling {
    //-----------METHODS----------- 
    async upd(param) {
        return await this.saveSchedulingRecord(param);
    }
    async add(param) {
        return await this.saveSchedulingRecord(param);
    }
    async del(id) {
        return await this.deleteSchedulingRecord(id);
    }
    async list() {
        return await this.getAllSchedulingRecord();
    }
    async getById(id) {
        return await this.getSchedulingRecord(id);
    }
    async recordCount() {
        return await this.getRecordCount();
    }
    async listByClient(clientId) {
        return await this.getRecordsByClient(clientId);
    }
    //-----------IMPLEMENTS------------
    async saveSchedulingRecord(data) {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME_SCHEDULING, "readwrite");
        const store = tx.objectStore(STORE_NAME_SCHEDULING);
        data.version = Date.now().toString();
        return new Promise((resolve, reject) => {
            let request;
            if (!data.id) {
                request = store.add(data);
            }
            else {
                request = store.put(data);
            }
            request.onsuccess = (event) => {
                const newId = event.target.result;
                if (!data.id) {
                    data.id = newId;
                }
            };
            tx.oncomplete = () => resolve(data);
            tx.onerror = () => reject(tx.error);
        });
    }
    async getRecordCount() {
        const db = await openDB();
        const transaction = db.transaction(STORE_NAME_SCHEDULING, 'readonly');
        const store = transaction.objectStore(STORE_NAME_SCHEDULING);
        const request = store.count();
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result || 0);
            request.onerror = () => reject(request.error);
        });
    }
    async getSchedulingRecord(id) {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME_SCHEDULING, "readonly");
        const request = tx.objectStore(STORE_NAME_SCHEDULING).get(id);
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => reject(request.error);
        });
    }
    async getAllSchedulingRecord() {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME_SCHEDULING, "readonly");
        const request = tx.objectStore(STORE_NAME_SCHEDULING).getAll();
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    async deleteSchedulingRecord(id) {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME_SCHEDULING, "readwrite");
        tx.objectStore(STORE_NAME_SCHEDULING).delete(id);
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }
    async getRecordsByClient(clientId) {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME_SCHEDULING, "readonly");
        const index = tx.objectStore(STORE_NAME_SCHEDULING).index("clientMdmId");
        const request = index.getAll(clientId);
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error);
        });
    }
}
export const schedulingIndexedDB = new Scheduling();
