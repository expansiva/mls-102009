/// <mls shortName="organismProductDetails" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismProductDetails = class _102009_organismProductDetails extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-product-details-102009 .product-container{max-width:1200px;margin:0 auto;padding:0 var(--spacing-md);display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-xl);align-items:start}@media (max-width:768px){organism-product-details-102009 .product-container{grid-template-columns:1fr;gap:var(--spacing-lg)}}organism-product-details-102009 .product-images .main-image{margin-bottom:var(--spacing-md)}organism-product-details-102009 .product-images .main-image .main-product-image{width:100%;height:400px;object-fit:cover;border-radius:var(--border-radius-md);box-shadow:var(--shadow-md)}organism-product-details-102009 .product-images .thumbnail-images{display:flex;gap:var(--spacing-sm)}organism-product-details-102009 .product-images .thumbnail-images .thumbnail{width:80px;height:80px;object-fit:cover;border-radius:var(--border-radius-sm);cursor:pointer;border:2px solid transparent;transition:var(--transition-fast)}organism-product-details-102009 .product-images .thumbnail-images .thumbnail:hover{border-color:var(--color-primary)}organism-product-details-102009 .product-info .product-header{margin-bottom:var(--spacing-lg)}organism-product-details-102009 .product-info .product-header .product-title{font-size:var(--font-size-xxl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-sm);line-height:var(--line-height-sm)}organism-product-details-102009 .product-info .product-header .product-rating{display:flex;align-items:center;gap:var(--spacing-sm)}organism-product-details-102009 .product-info .product-header .product-rating .stars .star{color:#ddd;font-size:var(--font-size-lg)}organism-product-details-102009 .product-info .product-header .product-rating .stars .star.filled{color:var(--color-secondary)}organism-product-details-102009 .product-info .product-header .product-rating .rating-text{color:var(--color-text-secondary);font-size:var(--font-size-sm)}organism-product-details-102009 .product-info .product-pricing{display:flex;align-items:center;gap:var(--spacing-sm);margin-bottom:var(--spacing-md)}organism-product-details-102009 .product-info .product-pricing .current-price{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-product-details-102009 .product-info .product-pricing .original-price{font-size:var(--font-size-md);color:var(--color-text-secondary);text-decoration:line-through}organism-product-details-102009 .product-info .product-pricing .discount-badge{background-color:var(--color-accent);color:white;padding:var(--spacing-xxs) var(--spacing-xs);border-radius:var(--border-radius-xs);font-size:var(--font-size-xs);font-weight:var(--font-weight-bold)}organism-product-details-102009 .product-info .product-availability{display:flex;align-items:center;gap:var(--spacing-sm);margin-bottom:var(--spacing-lg)}organism-product-details-102009 .product-info .product-availability .stock-status{font-weight:var(--font-weight-bold)}organism-product-details-102009 .product-info .product-availability .stock-status.available{color:var(--color-success)}organism-product-details-102009 .product-info .product-availability .stock-quantity{color:var(--color-text-secondary);font-size:var(--font-size-sm)}organism-product-details-102009 .product-info .product-description{margin-bottom:var(--spacing-lg)}organism-product-details-102009 .product-info .product-description h3{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-sm);color:var(--color-text-normal)}organism-product-details-102009 .product-info .product-description p{color:var(--color-text-secondary);line-height:var(--line-height-md);margin-bottom:var(--spacing-md)}organism-product-details-102009 .product-info .product-description .product-features{list-style:none;padding:0}organism-product-details-102009 .product-info .product-description .product-features li{padding:var(--spacing-xxs) 0;color:var(--color-text-secondary);position:relative;padding-left:var(--spacing-md)}organism-product-details-102009 .product-info .product-description .product-features li:before{content:'✓';color:var(--color-success);font-weight:var(--font-weight-bold);position:absolute;left:0}organism-product-details-102009 .product-info .product-specifications h3{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-sm);color:var(--color-text-normal)}organism-product-details-102009 .product-info .product-specifications .spec-grid{display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-sm)}@media (max-width:480px){organism-product-details-102009 .product-info .product-specifications .spec-grid{grid-template-columns:1fr}}organism-product-details-102009 .product-info .product-specifications .spec-item{display:flex;justify-content:space-between;padding:var(--spacing-xs);background-color:var(--color-surface);border-radius:var(--border-radius-xs)}organism-product-details-102009 .product-info .product-specifications .spec-item .spec-label{font-weight:var(--font-weight-bold);color:var(--color-text-normal)}organism-product-details-102009 .product-info .product-specifications .spec-item .spec-value{color:var(--color-text-secondary)}`);
    }
    render() {
        return html `
      <div class="product-container">
        <div class="product-images">
          <div class="main-image">
            <img src="https://images.unsplash.com/photo-1684882726821-2999db517441?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwZG9nJTIwZm9vZCUyMGJhZyUyMGtpYmJsZSUyMG51dHJpdGlvbnxlbnwwfHx8fDE3NTMzNjU1NzZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Imagem principal do produto" class="main-product-image">
          </div>
          <div class="thumbnail-images">
            <img src="https://images.unsplash.com/photo-1647699926980-b7d360761521?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBmb29kJTIwa2liYmxlJTIwY2xvc2UlMjB1cCUyMHRleHR1cmV8ZW58MHx8fHwxNzUzMzY1NTc3fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Miniatura do produto 1" class="thumbnail">
            <img src="https://images.unsplash.com/photo-1672323471046-21e40fab1ccd?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBlYXRpbmclMjBwcmVtaXVtJTIwZm9vZCUyMGJvd2x8ZW58MHx8fHwxNzUzMjkyMTc5fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Miniatura do produto 2" class="thumbnail">
            <img src="https://images.unsplash.com/photo-1684882726821-2999db517441?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBmb29kJTIwaW5ncmVkaWVudHMlMjBuYXR1cmFsJTIwY2hpY2tlbnxlbnwwfHx8fDE3NTMzNjU1Nzh8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Miniatura do produto 3" class="thumbnail">
          </div>
        </div>
        <div class="product-info">
          <div class="product-header">
            <h1 class="product-title">Ração Premium para Cães Adultos</h1>
            <div class="product-rating">
              <div class="stars">
                <span class="star filled">★</span>
                <span class="star filled">★</span>
                <span class="star filled">★</span>
                <span class="star filled">★</span>
                <span class="star">★</span>
              </div>
              <span class="rating-text">(4.2) 127 avaliações</span>
            </div>
          </div>
          <div class="product-pricing">
            <span class="current-price">R$ 89,90</span>
            <span class="original-price">R$ 109,90</span>
            <span class="discount-badge">18% OFF</span>
          </div>
          <div class="product-availability">
            <span class="stock-status available">✓ Em estoque</span>
            <span class="stock-quantity">12 unidades disponíveis</span>
          </div>
          <div class="product-description">
            <h3>Descrição do Produto</h3>
            <p>Ração super premium desenvolvida especialmente para cães adultos de todas as raças. Formulada com ingredientes naturais e proteínas de alta qualidade para garantir uma nutrição completa e balanceada.</p>
            <ul class="product-features">
              <li>Rico em proteínas de frango e cordeiro</li>
              <li>Sem corantes artificiais</li>
              <li>Fortalece o sistema imunológico</li>
              <li>Melhora a digestão</li>
              <li>Pelagem mais brilhante</li>
            </ul>
          </div>
          <div class="product-specifications">
            <h3>Especificações</h3>
            <div class="spec-grid">
              <div class="spec-item">
                <span class="spec-label">Peso:</span>
                <span class="spec-value">15kg</span>
              </div>
              <div class="spec-item">
                <span class="spec-label">Idade:</span>
                <span class="spec-value">Cães adultos (1-7 anos)</span>
              </div>
              <div class="spec-item">
                <span class="spec-label">Porte:</span>
                <span class="spec-value">Todos os portes</span>
              </div>
              <div class="spec-item">
                <span class="spec-label">Sabor:</span>
                <span class="spec-value">Frango e Cordeiro</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    }
};
_102009_organismProductDetails = __decorate([
    customElement('organism-product-details-102009')
], _102009_organismProductDetails);
export { _102009_organismProductDetails };
