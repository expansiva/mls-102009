/// <mls shortName="organismProductDetails" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismProductDetails = class _102009_organismProductDetails extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-product-details-102009 .product-container{max-width:1200px;margin:0 auto;padding:0 var(--spacing-md);display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-xl);align-items:start}@media (max-width:768px){organism-product-details-102009 .product-container{grid-template-columns:1fr;gap:var(--spacing-lg)}}organism-product-details-102009 .product-images .main-image{margin-bottom:var(--spacing-md)}organism-product-details-102009 .product-images .main-image .main-product-image{width:100%;height:400px;object-fit:cover;border-radius:var(--border-radius-md);box-shadow:var(--shadow-md)}organism-product-details-102009 .product-images .thumbnail-images{display:flex;gap:var(--spacing-sm)}organism-product-details-102009 .product-images .thumbnail-images .thumbnail{width:80px;height:80px;object-fit:cover;border-radius:var(--border-radius-sm);cursor:pointer;border:2px solid transparent;transition:var(--transition-fast)}organism-product-details-102009 .product-images .thumbnail-images .thumbnail:hover{border-color:var(--color-primary)}organism-product-details-102009 .product-info .product-header{margin-bottom:var(--spacing-lg)}organism-product-details-102009 .product-info .product-header .product-title{font-size:var(--font-size-xxl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-sm);line-height:var(--line-height-sm)}organism-product-details-102009 .product-info .product-header .product-rating{display:flex;align-items:center;gap:var(--spacing-sm)}organism-product-details-102009 .product-info .product-header .product-rating .stars .star{color:#ddd;font-size:var(--font-size-lg)}organism-product-details-102009 .product-info .product-header .product-rating .stars .star.filled{color:var(--color-secondary)}organism-product-details-102009 .product-info .product-header .product-rating .rating-text{color:var(--color-text-secondary);font-size:var(--font-size-sm)}organism-product-details-102009 .product-info .product-pricing{display:flex;align-items:center;gap:var(--spacing-sm);margin-bottom:var(--spacing-md)}organism-product-details-102009 .product-info .product-pricing .current-price{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-product-details-102009 .product-info .product-pricing .original-price{font-size:var(--font-size-md);color:var(--color-text-secondary);text-decoration:line-through}organism-product-details-102009 .product-info .product-pricing .discount-badge{background-color:var(--color-accent);color:white;padding:var(--spacing-xxs) var(--spacing-xs);border-radius:var(--border-radius-xs);font-size:var(--font-size-xs);font-weight:var(--font-weight-bold)}organism-product-details-102009 .product-info .product-availability{display:flex;align-items:center;gap:var(--spacing-sm);margin-bottom:var(--spacing-lg)}organism-product-details-102009 .product-info .product-availability .stock-status{font-weight:var(--font-weight-bold)}organism-product-details-102009 .product-info .product-availability .stock-status.available{color:var(--color-success)}organism-product-details-102009 .product-info .product-availability .stock-quantity{color:var(--color-text-secondary);font-size:var(--font-size-sm)}organism-product-details-102009 .product-info .product-description{margin-bottom:var(--spacing-lg)}organism-product-details-102009 .product-info .product-description h3{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-sm);color:var(--color-text-normal)}organism-product-details-102009 .product-info .product-description p{color:var(--color-text-secondary);line-height:var(--line-height-md);margin-bottom:var(--spacing-md)}organism-product-details-102009 .product-info .product-description .product-features{list-style:none;padding:0}organism-product-details-102009 .product-info .product-description .product-features li{padding:var(--spacing-xxs) 0;color:var(--color-text-secondary);position:relative;padding-left:var(--spacing-md)}organism-product-details-102009 .product-info .product-description .product-features li:before{content:'✓';color:var(--color-success);font-weight:var(--font-weight-bold);position:absolute;left:0}organism-product-details-102009 .product-info .product-specifications h3{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-sm);color:var(--color-text-normal)}organism-product-details-102009 .product-info .product-specifications .spec-grid{display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-sm)}@media (max-width:480px){organism-product-details-102009 .product-info .product-specifications .spec-grid{grid-template-columns:1fr}}organism-product-details-102009 .product-info .product-specifications .spec-item{display:flex;justify-content:space-between;padding:var(--spacing-xs);background-color:var(--color-surface);border-radius:var(--border-radius-xs)}organism-product-details-102009 .product-info .product-specifications .spec-item .spec-label{font-weight:var(--font-weight-bold);color:var(--color-text-normal)}organism-product-details-102009 .product-info .product-specifications .spec-item .spec-value{color:var(--color-text-secondary)}`);
    }
    render() {
        return html `
  <div class="product-container" id="product-details-1">
  <div class="product-images" id="product-details-2">
    <div class="main-image" id="product-details-3">
      <img src="https://images.unsplash.com/photo-1684882726821-2999db517441?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwZG9nJTIwZm9vZCUyMGJhZyUyMGtpYmJsZSUyMG51dHJpdGlvbnxlbnwwfHx8fDE3NTMzNjU1NzZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Imagem principal do produto" class="main-product-image" id="product-details-4">
    </div>
    <div class="thumbnail-images" id="product-details-5">
      <img src="https://images.unsplash.com/photo-1647699926980-b7d360761521?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBmb29kJTIwa2liYmxlJTIwY2xvc2UlMjB1cCUyMHRleHR1cmV8ZW58MHx8fHwxNzUzMzY1NTc3fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Miniatura do produto 1" class="thumbnail" id="product-details-6">
      <img src="https://images.unsplash.com/photo-1672323471046-21e40fab1ccd?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBlYXRpbmclMjBwcmVtaXVtJTIwZm9vZCUyMGJvd2x8ZW58MHx8fHwxNzUzMjkyMTc5fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Miniatura do produto 2" class="thumbnail" id="product-details-7">
      <img src="https://images.unsplash.com/photo-1684882726821-2999db517441?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBmb29kJTIwaW5ncmVkaWVudHMlMjBuYXR1cmFsJTIwY2hpY2tlbnxlbnwwfHx8fDE3NTMzNjU1Nzh8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=200" alt="Miniatura do produto 3" class="thumbnail" id="product-details-8">
    </div>
  </div>
  <div class="product-info" id="product-details-9">
    <div class="product-header" id="product-details-10">
      <h1 class="product-title" id="product-details-11">Ração Premium para Cães Adultos</h1>
      <div class="product-rating" id="product-details-12">
        <div class="stars" id="product-details-13">
          <span class="star filled" id="product-details-14">★</span>
          <span class="star filled" id="product-details-15">★</span>
          <span class="star filled" id="product-details-16">★</span>
          <span class="star filled" id="product-details-17">★</span>
          <span class="star" id="product-details-18">★</span>
        </div>
        <span class="rating-text" id="product-details-19">(4.2) 127 avaliações</span>
      </div>
    </div>
    <div class="product-pricing" id="product-details-20">
      <span class="current-price" id="product-details-21">R$ 89,90</span>
      <span class="original-price" id="product-details-22">R$ 109,90</span>
      <span class="discount-badge" id="product-details-23">18% OFF</span>
    </div>
    <div class="product-availability" id="product-details-24">
      <span class="stock-status available" id="product-details-25">✓ Em estoque</span>
      <span class="stock-quantity" id="product-details-26">12 unidades disponíveis</span>
    </div>
    <div class="product-description" id="product-details-27">
      <h3 id="product-details-28">Descrição do Produto</h3>
      <p id="product-details-29">Ração super premium desenvolvida especialmente para cães adultos de todas as raças. Formulada com ingredientes naturais e proteínas de alta qualidade para garantir uma nutrição completa e balanceada.</p>
      <ul class="product-features" id="product-details-30">
        <li id="product-details-31">Rico em proteínas de frango e cordeiro</li>
        <li id="product-details-32">Sem corantes artificiais</li>
        <li id="product-details-33">Fortalece o sistema imunológico</li>
        <li id="product-details-34">Melhora a digestão</li>
        <li id="product-details-35">Pelagem mais brilhante</li>
      </ul>
    </div>
    <div class="product-specifications" id="product-details-36">
      <h3 id="product-details-37">Especificações</h3>
      <div class="spec-grid" id="product-details-38">
        <div class="spec-item" id="product-details-39">
          <span class="spec-label" id="product-details-40">Peso:</span>
          <span class="spec-value" id="product-details-41">15kg</span>
        </div>
        <div class="spec-item" id="product-details-42">
          <span class="spec-label" id="product-details-43">Idade:</span>
          <span class="spec-value" id="product-details-44">Cães adultos (1-7 anos)</span>
        </div>
        <div class="spec-item" id="product-details-45">
          <span class="spec-label" id="product-details-46">Porte:</span>
          <span class="spec-value" id="product-details-47">Todos os portes</span>
        </div>
        <div class="spec-item" id="product-details-48">
          <span class="spec-label" id="product-details-49">Sabor:</span>
          <span class="spec-value" id="product-details-50">Frango e Cordeiro</span>
        </div>
      </div>
    </div>
  </div>
</div>

    `;
    }
};
_102009_organismProductDetails = __decorate([
    customElement('organism-product-details-102009')
], _102009_organismProductDetails);
export { _102009_organismProductDetails };
