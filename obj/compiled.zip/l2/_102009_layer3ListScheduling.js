/// <mls shortName="layer3ListScheduling" project="102009" enhancement="_blank" />
export async function listScheduling(ctx) {
    return await ctx.io.scheduling.list();
}
