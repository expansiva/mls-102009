/// <mls shortName="organismCartList" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismCartList = class _102009_organismCartList extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-cart-list-102009 .cart-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-lg);box-shadow:var(--shadow-sm)}organism-cart-list-102009 .cart-title{font-size:var(--font-size-xxl);font-weight:var(--font-weight-bold);color:var(--color-primary);margin-bottom:var(--spacing-lg);border-bottom:2px solid var(--color-border);padding-bottom:var(--spacing-sm)}organism-cart-list-102009 .cart-items{display:flex;flex-direction:column;gap:var(--spacing-md)}organism-cart-list-102009 .cart-item{display:grid;grid-template-columns:80px 1fr auto auto;gap:var(--spacing-md);align-items:center;padding:var(--spacing-md);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);background:var(--color-background);transition:var(--transition-base)}organism-cart-list-102009 .cart-item:hover{box-shadow:var(--shadow-md);border-color:var(--color-primary)}@media (max-width:768px){organism-cart-list-102009 .cart-item{grid-template-columns:1fr;text-align:center;gap:var(--spacing-sm)}}organism-cart-list-102009 .item-image{width:80px;height:80px;object-fit:cover;border-radius:var(--border-radius-sm);border:1px solid var(--color-border)}organism-cart-list-102009 .item-details .item-name{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin-bottom:var(--spacing-xs)}organism-cart-list-102009 .item-details .item-description{font-size:var(--font-size-sm);color:var(--color-text-secondary);margin-bottom:var(--spacing-xs)}organism-cart-list-102009 .item-details .item-price{font-size:var(--font-size-md);color:var(--color-primary);font-weight:var(--font-weight-bold)}organism-cart-list-102009 .item-controls{display:flex;flex-direction:column;gap:var(--spacing-sm);align-items:center}organism-cart-list-102009 .item-controls .quantity-control{display:flex;align-items:center;border:1px solid var(--color-border);border-radius:var(--border-radius-sm);overflow:hidden}organism-cart-list-102009 .item-controls .quantity-control .qty-btn{background:var(--color-surface);border:none;padding:var(--spacing-xs) var(--spacing-sm);cursor:pointer;font-size:var(--font-size-md);color:var(--color-primary);transition:var(--transition-fast)}organism-cart-list-102009 .item-controls .quantity-control .qty-btn:hover{background:var(--color-primary);color:var(--color-background)}organism-cart-list-102009 .item-controls .quantity-control .qty-input{border:none;width:50px;text-align:center;padding:var(--spacing-xs);font-size:var(--font-size-sm)}organism-cart-list-102009 .item-controls .quantity-control .qty-input:focus{outline:none;background:var(--color-overlay)}organism-cart-list-102009 .item-controls .remove-btn{background:none;border:1px solid var(--color-error);color:var(--color-error);padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-sm);cursor:pointer;font-size:var(--font-size-sm);transition:var(--transition-fast)}organism-cart-list-102009 .item-controls .remove-btn:hover{background:var(--color-error);color:var(--color-background)}organism-cart-list-102009 .item-total{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-primary)}organism-cart-list-102009 .empty-cart{text-align:center;padding:var(--spacing-xxl)}organism-cart-list-102009 .empty-cart .empty-cart-image{width:200px;height:200px;object-fit:contain;margin-bottom:var(--spacing-lg);opacity:.6}organism-cart-list-102009 .empty-cart h2{font-size:var(--font-size-xl);color:var(--color-text-secondary);margin-bottom:var(--spacing-sm)}organism-cart-list-102009 .empty-cart p{color:var(--color-text-secondary);margin-bottom:var(--spacing-lg)}organism-cart-list-102009 .empty-cart .continue-shopping-btn{background:var(--color-primary);color:var(--color-background);padding:var(--spacing-sm) var(--spacing-lg);border-radius:var(--border-radius-sm);text-decoration:none;font-weight:var(--font-weight-bold);transition:var(--transition-base)}organism-cart-list-102009 .empty-cart .continue-shopping-btn:hover{background:var(--color-accent);transform:translateY(-2px)}`);
    }
    render() {
        return html `
      <div class="cart-container">
        <h1 class="cart-title">Meu Carrinho</h1>
        <div class="cart-items">
          <div class="cart-item">
            <img src="https://images.unsplash.com/photo-1708746333832-9a8cde4a0cfa?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwZG9nJTIwZm9vZCUyMGJhZyUyMGtpYmJsZXxlbnwwfHx8fDE3NTMyOTIxMjB8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Ração Premium para Cães" class="item-image">
            <div class="item-details">
              <h3 class="item-name">Ração Premium para Cães Adultos 15kg</h3>
              <p class="item-description">Ração completa e balanceada para cães adultos</p>
              <div class="item-price">R$ 89,90</div>
            </div>
            <div class="item-controls">
              <div class="quantity-control">
                <button class="qty-btn minus">-</button>
                <input type="number" value="2" min="1" class="qty-input">
                <button class="qty-btn plus">+</button>
              </div>
              <button class="remove-btn">Remover</button>
            </div>
            <div class="item-total">R$ 179,80</div>
          </div>
          
          <div class="cart-item">
            <img src="https://images.unsplash.com/photo-1652524791225-ea5e6de0ea71?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxpbnRlcmFjdGl2ZSUyMGNhdCUyMHRveSUyMGZlYXRoZXJzfGVufDB8fHx8MTc1MzI5MjIzNXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Brinquedo para Gatos" class="item-image">
            <div class="item-details">
              <h3 class="item-name">Brinquedo Interativo para Gatos</h3>
              <p class="item-description">Brinquedo estimulante com penas e guizo</p>
              <div class="item-price">R$ 24,90</div>
            </div>
            <div class="item-controls">
              <div class="quantity-control">
                <button class="qty-btn minus">-</button>
                <input type="number" value="1" min="1" class="qty-input">
                <button class="qty-btn plus">+</button>
              </div>
              <button class="remove-btn">Remover</button>
            </div>
            <div class="item-total">R$ 24,90</div>
          </div>
          
          <div class="cart-item">
            <img src="https://images.unsplash.com/photo-1587291086390-69a3af40cf0b?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBzaGFtcG9vJTIwYm90dGxlJTIwbmV1dHJhbHxlbnwwfHx8fDE3NTMzNjU2NjF8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Shampoo para Pets" class="item-image">
            <div class="item-details">
              <h3 class="item-name">Shampoo Neutro para Pets 500ml</h3>
              <p class="item-description">Shampoo suave para todos os tipos de pelo</p>
              <div class="item-price">R$ 32,50</div>
            </div>
            <div class="item-controls">
              <div class="quantity-control">
                <button class="qty-btn minus">-</button>
                <input type="number" value="1" min="1" class="qty-input">
                <button class="qty-btn plus">+</button>
              </div>
              <button class="remove-btn">Remover</button>
            </div>
            <div class="item-total">R$ 32,50</div>
          </div>
        </div>
        
        <div class="empty-cart" style="display: none;">
          <img src="https://images.unsplash.com/photo-1634406688363-02ff7644d950?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxlbXB0eSUyMHNob3BwaW5nJTIwY2FydCUyMGlsbHVzdHJhdGlvbnxlbnwwfHx8fDE3NTMzNjU2NjJ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Carrinho vazio" class="empty-cart-image">
          <h2>Seu carrinho está vazio</h2>
          <p>Adicione produtos incríveis para seu pet!</p>
          <a href="/loja" class="continue-shopping-btn">Continuar Comprando</a>
        </div>
      </div>
    `;
    }
};
_102009_organismCartList = __decorate([
    customElement('organism-cart-list-102009')
], _102009_organismCartList);
export { _102009_organismCartList };
