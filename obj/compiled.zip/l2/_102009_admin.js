/// <mls shortName="admin" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let _102009_admin = class _102009_admin extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`admin-102009{display:grid;grid-template-areas:"header header" "sidebar main" "footer footer";grid-template-columns:280px 1fr;grid-template-rows:auto 1fr auto;min-height:100vh;background-color:var(--color-surface);font-family:var(--font-family-primary)}admin-102009 header{grid-area:header;background-color:var(--color-background);border-bottom:1px solid var(--color-border);box-shadow:var(--shadow-sm)}admin-102009 aside{grid-area:sidebar;background-color:var(--color-background);border-right:1px solid var(--color-border)}admin-102009 main{grid-area:main;padding:var(--spacing-lg);overflow-y:auto}admin-102009 footer{grid-area:footer}@media (max-width:768px){admin-102009{grid-template-areas:"header" "main" "footer";grid-template-columns:1fr}admin-102009 aside{display:none}}`);
    }
    initPage() {
    }
};
_102009_admin = __decorate([
    customElement('admin-102009')
], _102009_admin);
export { _102009_admin };
