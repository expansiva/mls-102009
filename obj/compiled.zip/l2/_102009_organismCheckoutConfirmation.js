/// <mls shortName="organismCheckoutConfirmation" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismCheckoutConfirmation = class _102009_organismCheckoutConfirmation extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-checkout-confirmation-102009{grid-column:1 / -1}organism-checkout-confirmation-102009 .checkout-confirmation-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-lg);box-shadow:var(--shadow-sm);text-align:center}organism-checkout-confirmation-102009 .checkout-confirmation-container .confirmation-actions{display:flex;gap:var(--spacing-md);justify-content:center;margin-bottom:var(--spacing-lg)}@media (max-width:480px){organism-checkout-confirmation-102009 .checkout-confirmation-container .confirmation-actions{flex-direction:column}}organism-checkout-confirmation-102009 .checkout-confirmation-container .confirmation-actions .btn-secondary{padding:var(--spacing-md) var(--spacing-lg);background:var(--color-background);color:var(--color-text-normal);border:2px solid var(--color-border);border-radius:var(--border-radius-sm);font-size:var(--font-size-md);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-base)}organism-checkout-confirmation-102009 .checkout-confirmation-container .confirmation-actions .btn-secondary:hover{border-color:var(--color-primary);color:var(--color-primary)}organism-checkout-confirmation-102009 .checkout-confirmation-container .confirmation-actions .btn-primary{padding:var(--spacing-md) var(--spacing-xl);background:var(--color-primary);color:white;border:none;border-radius:var(--border-radius-sm);font-size:var(--font-size-md);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-base)}organism-checkout-confirmation-102009 .checkout-confirmation-container .confirmation-actions .btn-primary:hover{background:var(--color-link-visited);transform:translateY(-2px);box-shadow:var(--shadow-md)}organism-checkout-confirmation-102009 .checkout-confirmation-container .confirmation-actions .btn-primary:disabled{background:var(--color-text-disabled);cursor:not-allowed;transform:none;box-shadow:none}organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance{margin-bottom:var(--spacing-lg)}organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance .checkbox-label{display:flex;align-items:center;justify-content:center;gap:var(--spacing-sm);cursor:pointer;font-size:var(--font-size-sm);color:var(--color-text-secondary)}organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance .checkbox-label input[type="checkbox"]{display:none}organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance .checkbox-label input[type="checkbox"]:checked+.checkmark{background:var(--color-primary);border-color:var(--color-primary)}organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance .checkbox-label input[type="checkbox"]:checked+.checkmark::after{display:block}organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance .checkbox-label .checkmark{width:20px;height:20px;border:2px solid var(--color-border);border-radius:var(--border-radius-xs);position:relative;transition:var(--transition-base)}organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance .checkbox-label .checkmark::after{content:'';position:absolute;display:none;left:6px;top:2px;width:6px;height:10px;border:solid white;border-width:0 2px 2px 0;transform:rotate(45deg)}organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance .checkbox-label .terms-link,organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance .checkbox-label .privacy-link{color:var(--color-link-normal);text-decoration:none}organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance .checkbox-label .terms-link:hover,organism-checkout-confirmation-102009 .checkout-confirmation-container .terms-acceptance .checkbox-label .privacy-link:hover{color:var(--color-link-hover);text-decoration:underline}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message{text-align:center}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message .success-icon{width:80px;height:80px;margin:0 auto var(--spacing-lg)}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message .success-icon img{width:100%;height:100%;object-fit:contain}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message h2{color:var(--color-success);font-size:var(--font-size-xxl);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-md)}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message p{color:var(--color-text-normal);font-size:var(--font-size-lg);margin-bottom:var(--spacing-md)}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message p strong{color:var(--color-primary)}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message .next-steps{background:var(--color-background);padding:var(--spacing-lg);border-radius:var(--border-radius-sm);margin:var(--spacing-lg) 0;text-align:left}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message .next-steps h3{color:var(--color-text-normal);font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);margin-bottom:var(--spacing-md)}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message .next-steps ul{color:var(--color-text-secondary);padding-left:var(--spacing-lg)}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message .next-steps ul li{margin-bottom:var(--spacing-xs);line-height:var(--line-height-md)}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message .btn-primary{padding:var(--spacing-md) var(--spacing-xl);background:var(--color-primary);color:white;border:none;border-radius:var(--border-radius-sm);font-size:var(--font-size-md);font-weight:var(--font-weight-bold);cursor:pointer;transition:var(--transition-base);margin-top:var(--spacing-lg)}organism-checkout-confirmation-102009 .checkout-confirmation-container .success-message .btn-primary:hover{background:var(--color-link-visited);transform:translateY(-2px);box-shadow:var(--shadow-md)}`);
    }
    render() {
        return html `
    <div class="checkout-confirmation-container" id="checkout-confirmation-1">
  <div class="confirmation-actions" id="checkout-confirmation-2">
    <button type="button" class="btn-secondary" onclick="history.back()" id="checkout-confirmation-3">Voltar ao Carrinho</button>
    <button type="submit" class="btn-primary" id="checkout-confirmation-4">Finalizar Compra</button>
  </div>
  
  <div class="terms-acceptance" id="checkout-confirmation-5">
    <label class="checkbox-label" id="checkout-confirmation-6">
      <input type="checkbox" id="checkout-confirmation-7" required="">
      <span class="checkmark" id="checkout-confirmation-8"></span>
      Aceito os <a href="#" class="terms-link" id="checkout-confirmation-9">termos e condições</a> e a <a href="#" class="privacy-link" id="checkout-confirmation-10">política de privacidade</a>
    </label>
  </div>
  
  <div class="success-message" id="checkout-confirmation-11" style="display: none;">
    <div class="success-icon" id="checkout-confirmation-12">
      <img src="https://images.unsplash.com/photo-1662057168153-c0d62a4025f7?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxncmVlbiUyMGNoZWNrbWFyayUyMHN1Y2Nlc3MlMjBpY29uJTIwY29uZmlybWF0aW9ufGVufDB8fHx8MTc1MzM2NTc1OXww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=400" alt="Sucesso" id="checkout-confirmation-13">
    </div>
    <h2 id="checkout-confirmation-14">Pedido Realizado com Sucesso!</h2>
    <p id="checkout-confirmation-15">Número do pedido: <strong id="checkout-confirmation-16">#PET2024001</strong></p>
    <p id="checkout-confirmation-17">Você receberá um e-mail de confirmação em breve.</p>
    <div class="next-steps" id="checkout-confirmation-18">
      <h3 id="checkout-confirmation-19">Próximos Passos:</h3>
      <ul id="checkout-confirmation-20">
        <li id="checkout-confirmation-21">Acompanhe seu pedido através do e-mail enviado</li>
        <li id="checkout-confirmation-22">O prazo de entrega é de 3-5 dias úteis</li>
        <li id="checkout-confirmation-23">Em caso de dúvidas, entre em contato conosco</li>
      </ul>
    </div>
    <button type="button" class="btn-primary" onclick="window.location.href='/'" id="checkout-confirmation-24">Continuar Comprando</button>
  </div>
</div>

    `;
    }
};
_102009_organismCheckoutConfirmation = __decorate([
    customElement('organism-checkout-confirmation-102009')
], _102009_organismCheckoutConfirmation);
export { _102009_organismCheckoutConfirmation };
