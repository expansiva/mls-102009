/// <mls shortName="organismAdminServices" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismAdminServices = class _102009_organismAdminServices extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-admin-services-102009 .admin-section{background-color:var(--color-background);border-radius:var(--border-radius-md);padding:var(--spacing-lg);margin-bottom:var(--spacing-lg);box-shadow:var(--shadow-sm)}organism-admin-services-102009 .admin-section .section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-lg)}organism-admin-services-102009 .admin-section .section-header h2{color:var(--color-text-normal);font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);margin:0}organism-admin-services-102009 .admin-section .section-header .add-service-btn{background-color:var(--color-primary);color:white;border:none;padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--border-radius-sm);cursor:pointer;font-weight:var(--font-weight-bold);transition:var(--transition-base)}organism-admin-services-102009 .admin-section .section-header .add-service-btn:hover{background-color:var(--color-link-hover)}organism-admin-services-102009 .admin-section .services-grid{display:grid;grid-template-columns:repeat(auto-fill, minmax(300px, 1fr));gap:var(--spacing-md)}organism-admin-services-102009 .admin-section .services-grid .service-card{border:1px solid var(--color-border);border-radius:var(--border-radius-sm);overflow:hidden;transition:var(--transition-base)}organism-admin-services-102009 .admin-section .services-grid .service-card:hover{box-shadow:var(--shadow-md)}organism-admin-services-102009 .admin-section .services-grid .service-card .service-image{width:100%;height:200px;object-fit:cover}organism-admin-services-102009 .admin-section .services-grid .service-card .service-info{padding:var(--spacing-md)}organism-admin-services-102009 .admin-section .services-grid .service-card .service-info h3{margin:0 0 var(--spacing-xs) 0;color:var(--color-text-normal);font-size:var(--font-size-lg)}organism-admin-services-102009 .admin-section .services-grid .service-card .service-info .service-price{color:var(--color-primary);font-weight:var(--font-weight-bold);font-size:var(--font-size-lg);margin:var(--spacing-xs) 0}organism-admin-services-102009 .admin-section .services-grid .service-card .service-info .service-duration{color:var(--color-text-secondary);font-size:var(--font-size-sm);margin:var(--spacing-xs) 0 var(--spacing-md) 0}organism-admin-services-102009 .admin-section .services-grid .service-card .service-info .service-actions{display:flex;gap:var(--spacing-xs)}organism-admin-services-102009 .admin-section .services-grid .service-card .service-info .service-actions .btn-edit{background-color:var(--color-secondary);color:white;border:none;padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);cursor:pointer;font-size:var(--font-size-sm);transition:var(--transition-base)}organism-admin-services-102009 .admin-section .services-grid .service-card .service-info .service-actions .btn-edit:hover{opacity:.9}organism-admin-services-102009 .admin-section .services-grid .service-card .service-info .service-actions .btn-delete{background-color:var(--color-error);color:white;border:none;padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);cursor:pointer;font-size:var(--font-size-sm);transition:var(--transition-base)}organism-admin-services-102009 .admin-section .services-grid .service-card .service-info .service-actions .btn-delete:hover{opacity:.9}`);
    }
    render() {
        return html `
      <section class="admin-section">
        <div class="section-header">
          <h2>Gerenciar Serviços</h2>
          <button class="btn-primary add-service-btn">+ Adicionar Serviço</button>
        </div>
        
        <div class="services-grid">
          <div class="service-card">
            <img src="https://images.unsplash.com/photo-1647002380358-fc70ed2f04e0?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBiYXRoJTIwZ3Jvb21pbmclMjBzZXJ2aWNlJTIwcGV0c2hvcHxlbnwwfHx8fDE3NTMzNjU5OTF8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Banho" class="service-image">
            <div class="service-info">
              <h3>Banho</h3>
              <p class="service-price">R$ 35,00</p>
              <p class="service-duration">45 min</p>
              <div class="service-actions">
                <button class="btn-edit">Editar</button>
                <button class="btn-delete">Excluir</button>
              </div>
            </div>
          </div>
          
          <div class="service-card">
            <img src="https://images.unsplash.com/photo-1644675443401-ea4c14bad0e6?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBncm9vbWluZyUyMGhhaXJjdXQlMjBzZXJ2aWNlJTIwcHJvZmVzc2lvbmFsfGVufDB8fHx8MTc1MzM2NTk5Mnww&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Tosa" class="service-image">
            <div class="service-info">
              <h3>Tosa</h3>
              <p class="service-price">R$ 50,00</p>
              <p class="service-duration">60 min</p>
              <div class="service-actions">
                <button class="btn-edit">Editar</button>
                <button class="btn-delete">Excluir</button>
              </div>
            </div>
          </div>
          
          <div class="service-card">
            <img src="https://images.unsplash.com/photo-1733783489145-f3d3ee7a9ccf?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJpYW4lMjBjb25zdWx0YXRpb24lMjBkb2clMjBjYXQlMjBleGFtaW5hdGlvbnxlbnwwfHx8fDE3NTMzNjU5OTJ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Consulta Veterinária" class="service-image">
            <div class="service-info">
              <h3>Consulta Veterinária</h3>
              <p class="service-price">R$ 80,00</p>
              <p class="service-duration">30 min</p>
              <div class="service-actions">
                <button class="btn-edit">Editar</button>
                <button class="btn-delete">Excluir</button>
              </div>
            </div>
          </div>
        </div>
      </section>
    `;
    }
};
_102009_organismAdminServices = __decorate([
    customElement('organism-admin-services-102009')
], _102009_organismAdminServices);
export { _102009_organismAdminServices };
