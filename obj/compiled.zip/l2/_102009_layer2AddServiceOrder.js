/// <mls shortName="layer2AddServiceOrder" project="102009" enhancement="_blank" />
import * as layer3 from "./_102009_layer3AddServiceOrder";
export async function addServiceOrder(ctx, data) {
    const ret = {
        statusCode: 200,
        ok: true,
        data: undefined,
        error: undefined
    };
    try {
        if (!data)
            throw new Error('[layer2AddServiceOrder]:Into the data');
        ret.data = await layer3.addServiceOrder(ctx, data);
        return ret;
    }
    catch (e) {
        ret.statusCode = 400;
        ret.ok = false;
        ret.error = e.message;
        return ret;
    }
}
