/// <mls shortName="checkout" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let _102009_checkout = class _102009_checkout extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`checkout-102009{min-height:100vh;display:flex;flex-direction:column;background-color:var(--color-background);font-family:var(--font-family-primary)}checkout-102009 header{position:sticky;top:0;z-index:100;background-color:var(--color-background);box-shadow:var(--shadow-sm)}checkout-102009 main{flex:1;max-width:1200px;margin:0 auto;padding:var(--spacing-lg) var(--spacing-md);display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-xl)}@media (max-width:768px){checkout-102009 main{grid-template-columns:1fr;padding:var(--spacing-md) var(--spacing-sm);gap:var(--spacing-lg)}}checkout-102009 footer{margin-top:var(--spacing-xl)}`);
    }
    initPage() {
    }
};
_102009_checkout = __decorate([
    customElement('checkout-102009')
], _102009_checkout);
export { _102009_checkout };
