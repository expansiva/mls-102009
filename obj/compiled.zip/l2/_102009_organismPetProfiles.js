/// <mls shortName="organismPetProfiles" project="102009" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaOrganismBase } from './_100554_icaOrganismBase';
let _102009_organismPetProfiles = class _102009_organismPetProfiles extends IcaOrganismBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`organism-pet-profiles-102009 .pet-profiles-container{background:var(--color-surface);border-radius:var(--border-radius-md);padding:var(--spacing-xl);margin-bottom:var(--spacing-xl);box-shadow:var(--shadow-sm)}organism-pet-profiles-102009 .pet-profiles-container .section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--spacing-lg)}organism-pet-profiles-102009 .pet-profiles-container .section-header h2{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin:0}organism-pet-profiles-102009 .pet-profiles-container .section-header .add-pet-btn{background:var(--color-secondary);color:white;border:none;padding:var(--spacing-sm) var(--spacing-lg);border-radius:var(--border-radius-sm);cursor:pointer;font-weight:var(--font-weight-bold);transition:var(--transition-base)}organism-pet-profiles-102009 .pet-profiles-container .section-header .add-pet-btn:hover{background:var(--color-accent)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid{display:grid;grid-template-columns:repeat(auto-fill, minmax(300px, 1fr));gap:var(--spacing-lg)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card{background:white;border-radius:var(--border-radius-md);padding:var(--spacing-lg);box-shadow:var(--shadow-sm);transition:var(--transition-base)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card:hover{box-shadow:var(--shadow-md);transform:translateY(-2px)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-image{text-align:center;margin-bottom:var(--spacing-md)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-image img{width:80px;height:80px;border-radius:50%;object-fit:cover;border:3px solid var(--color-primary)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-info{text-align:center;margin-bottom:var(--spacing-md)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-info h3{font-size:var(--font-size-lg);font-weight:var(--font-weight-bold);color:var(--color-text-normal);margin:0 0 var(--spacing-xs) 0}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-info .pet-breed{color:var(--color-text-secondary);font-size:var(--font-size-md);margin:0 0 var(--spacing-xs) 0}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-info .pet-age{color:var(--color-primary);font-weight:var(--font-weight-bold);margin:0 0 var(--spacing-sm) 0}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-info .pet-details{display:flex;justify-content:center;gap:var(--spacing-sm)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-info .pet-details .detail-item{background:var(--color-overlay);color:var(--color-primary);padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--border-radius-xs);font-size:var(--font-size-xs);font-weight:var(--font-weight-bold)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-actions{display:flex;justify-content:center;gap:var(--spacing-sm)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-actions .btn-icon{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--border-radius-sm);padding:var(--spacing-sm);cursor:pointer;transition:var(--transition-base)}organism-pet-profiles-102009 .pet-profiles-container .pets-grid .pet-card .pet-actions .btn-icon:hover{background:var(--color-primary);color:white;border-color:var(--color-primary)}`);
    }
    render() {
        return html `
      <div class="pet-profiles-container">
        <div class="section-header">
          <h2>Meus Pets</h2>
          <button class="btn-primary add-pet-btn">+ Adicionar Pet</button>
        </div>
        
        <div class="pets-grid">
          <div class="pet-card">
            <div class="pet-image">
              <img src="https://images.unsplash.com/photo-1734966213753-1b361564bab4?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxnb2xkZW4lMjByZXRyaWV2ZXIlMjBkb2clMjBwb3J0cmFpdHxlbnwwfHx8fDE3NTMyOTI0MTZ8MA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Foto do pet">
            </div>
            <div class="pet-info">
              <h3>Rex</h3>
              <p class="pet-breed">Golden Retriever</p>
              <p class="pet-age">3 anos</p>
              <div class="pet-details">
                <span class="detail-item">Macho</span>
                <span class="detail-item">25kg</span>
              </div>
            </div>
            <div class="pet-actions">
              <button class="btn-icon edit-btn" title="Editar">✏️</button>
              <button class="btn-icon history-btn" title="Histórico médico">📋</button>
            </div>
          </div>
          
          <div class="pet-card">
            <div class="pet-image">
              <img src="https://images.unsplash.com/photo-1735618603118-89e26b0dcf6e?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXJzaWFuJTIwY2F0JTIwcG9ydHJhaXR8ZW58MHx8fHwxNzUzMjkyNDE2fDA&amp;ixlib=rb-4.1.0&amp;q=80&amp;w=1080" alt="Foto do pet">
            </div>
            <div class="pet-info">
              <h3>Luna</h3>
              <p class="pet-breed">Persa</p>
              <p class="pet-age">2 anos</p>
              <div class="pet-details">
                <span class="detail-item">Fêmea</span>
                <span class="detail-item">4kg</span>
              </div>
            </div>
            <div class="pet-actions">
              <button class="btn-icon edit-btn" title="Editar">✏️</button>
              <button class="btn-icon history-btn" title="Histórico médico">📋</button>
            </div>
          </div>
        </div>
      </div>
    `;
    }
};
_102009_organismPetProfiles = __decorate([
    customElement('organism-pet-profiles-102009')
], _102009_organismPetProfiles);
export { _102009_organismPetProfiles };
