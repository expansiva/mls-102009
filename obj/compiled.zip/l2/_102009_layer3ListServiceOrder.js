/// <mls shortName="layer3ListServiceOrder" project="102009" enhancement="_blank" />
export async function listServiceOrder(ctx) {
    return await ctx.io.serviceOrder.list();
}
