/// <mls fileReference="_102009_/l1/petshop/layer_2_controllers/catalogHandlers.ts" enhancement="_blank" />
import { AppError, ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { getPetshopTopProducts, listPetshopCatalog, loadPetshopHome, seedPetshopMockData, updatePetshopProduct, } from '/_102009_/l1/petshop/layer_3_usecases/catalogUsecases.js';
function parseLimit(value) {
    if (value === undefined) {
        return 3;
    }
    const parsed = Number(value);
    if (!Number.isInteger(parsed) || parsed <= 0) {
        throw new AppError('VALIDATION_ERROR', 'limit must be a positive integer', 400);
    }
    return parsed;
}
export const petshopListCatalogHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listPetshopCatalog(ctx, {
        category: typeof params.category === 'string' ? params.category : undefined,
        query: typeof params.query === 'string' ? params.query : undefined,
    }));
};
export const petshopGetTopProductsHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getPetshopTopProducts(ctx, parseLimit(params.limit)));
};
export const petshopSeedMockDataHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await seedPetshopMockData(ctx, params.force === true));
};
export const petshopHomeLoadHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await loadPetshopHome(ctx, {
        category: typeof params.category === 'string' ? params.category : undefined,
        query: typeof params.query === 'string' ? params.query : undefined,
        topLimit: params.topLimit === undefined ? undefined : parseLimit(params.topLimit),
        forceSeed: params.forceSeed === true,
    }));
};
export const petshopUpdateProductHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await updatePetshopProduct(ctx, {
        productId: typeof params.productId === 'string' ? params.productId : '',
        author: typeof params.author === 'string' ? params.author : undefined,
        name: typeof params.name === 'string' ? params.name : undefined,
        category: typeof params.category === 'string' ? params.category : undefined,
        priceInCents: params.priceInCents === undefined
            ? undefined
            : Number.isInteger(Number(params.priceInCents))
                ? Number(params.priceInCents)
                : undefined,
        highlightScore: params.highlightScore === undefined
            ? undefined
            : Number.isInteger(Number(params.highlightScore))
                ? Number(params.highlightScore)
                : undefined,
        stockStatus: params.stockStatus === 'in_stock' || params.stockStatus === 'low_stock' || params.stockStatus === 'out_of_stock'
            ? params.stockStatus
            : undefined,
        description: typeof params.description === 'string' ? params.description : undefined,
    }));
};
