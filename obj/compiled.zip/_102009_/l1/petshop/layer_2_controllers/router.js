import { petshopGetTopProductsHandler, petshopHomeLoadHandler, petshopListCatalogHandler, petshopSeedMockDataHandler, petshopUpdateProductHandler, } from '/_102009_/l1/petshop/layer_2_controllers/catalogHandlers.js';
export function createPetshopRouter() {
    return new Map([
        ['petshop.home.load', petshopHomeLoadHandler],
        ['petshop.listCatalog', petshopListCatalogHandler],
        ['petshop.getTopProducts', petshopGetTopProductsHandler],
        ['petshop.seedMockData', petshopSeedMockDataHandler],
        ['petshop.updateProduct', petshopUpdateProductHandler],
    ]);
}
