import { getPetshopMockProducts } from '/_102009_/l1/petshop/mock/adminMock.js';
import { AppError, ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
export async function getPetshopProductRepository(ctx) {
    return ctx.data.moduleData.getTable('petshopProduct');
}
export function resetPetshopCatalogForTests() { }
export async function seedPetshopMockData(ctx, force = false) {
    const repository = await getPetshopProductRepository(ctx);
    const mockProducts = getPetshopMockProducts();
    const nowIso = ctx.clock.nowIso();
    const existingRows = await repository.findMany();
    if (existingRows.length > 0 && !force) {
        return {
            insertedCount: 0,
            totalCount: existingRows.length,
            seededAt: nowIso,
        };
    }
    if (force) {
        for (const row of existingRows) {
            await repository.delete({
                where: { productId: row.productId },
            });
        }
    }
    for (const product of mockProducts) {
        await repository.upsert({
            record: {
                ...product,
                updatedAt: nowIso,
            },
        });
    }
    return {
        insertedCount: mockProducts.length,
        totalCount: mockProducts.length,
        seededAt: nowIso,
    };
}
export async function listPetshopCatalog(ctx, input) {
    const repository = await getPetshopProductRepository(ctx);
    const rows = await repository.findMany({
        orderBy: {
            field: 'name',
            direction: 'asc',
        },
    });
    const category = input?.category?.trim().toLowerCase();
    const query = input?.query?.trim().toLowerCase();
    return rows.filter((product) => {
        if (category && product.category.toLowerCase() !== category) {
            return false;
        }
        if (!query) {
            return true;
        }
        return [
            product.name,
            product.category,
            product.description,
        ].some((value) => value.toLowerCase().includes(query));
    });
}
export async function getPetshopTopProducts(ctx, limit = 3) {
    const repository = await getPetshopProductRepository(ctx);
    const rows = await repository.findMany();
    return [...rows]
        .sort((left, right) => right.highlightScore - left.highlightScore)
        .slice(0, Math.max(1, Math.min(limit, 12)));
}
export async function loadPetshopHome(ctx, input) {
    const seed = await seedPetshopMockData(ctx, input?.forceSeed === true);
    const [catalog, topProducts] = await Promise.all([
        listPetshopCatalog(ctx, {
            category: input?.category,
            query: input?.query,
        }),
        getPetshopTopProducts(ctx, input?.topLimit ?? 3),
    ]);
    return {
        seed,
        catalog,
        topProducts,
    };
}
function parseLimit(value) {
    if (value === undefined) {
        return 3;
    }
    const parsed = Number(value);
    if (!Number.isInteger(parsed) || parsed <= 0) {
        throw new AppError('VALIDATION_ERROR', 'limit must be a positive integer', 400);
    }
    return parsed;
}
export const petshopListCatalogHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await listPetshopCatalog(ctx, {
        category: typeof params.category === 'string' ? params.category : undefined,
        query: typeof params.query === 'string' ? params.query : undefined,
    }));
};
export const petshopGetTopProductsHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await getPetshopTopProducts(ctx, parseLimit(params.limit)));
};
export const petshopSeedMockDataHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await seedPetshopMockData(ctx, params.force === true));
};
export const petshopHomeLoadHandler = async ({ request, ctx }) => {
    const params = (request.params ?? {});
    return ok(await loadPetshopHome(ctx, {
        category: typeof params.category === 'string' ? params.category : undefined,
        query: typeof params.query === 'string' ? params.query : undefined,
        topLimit: params.topLimit === undefined ? undefined : parseLimit(params.topLimit),
        forceSeed: params.forceSeed === true,
    }));
};
