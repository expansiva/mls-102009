export function createPetshopRouter() {
    return new Map([]);
}
/* example with handlers:


import {
  petshopGetTopProductsHandler,
  petshopHomeLoadHandler,
  petshopListCatalogHandler,
  petshopSeedMockDataHandler,
  petshopUpdateProductHandler,
} from '/_102030_/l1/petshop/layer_2_controllers/catalogHandlers.js';

export function createPetshopRouter(): Map<string, BffHandler> {
  return new Map<string, BffHandler>([
    ['petshop.home.load', petshopHomeLoadHandler],
    ['petshop.listCatalog', petshopListCatalogHandler],
    ['petshop.getTopProducts', petshopGetTopProductsHandler],
    ['petshop.seedMockData', petshopSeedMockDataHandler],
    ['petshop.updateProduct', petshopUpdateProductHandler],
  ]);
}


*/ 
