// ── TempStateAction ───────────────────────────────────────────────
export var TempStateAction;
(function (TempStateAction) {
    TempStateAction["SHOW_PASSWORD"] = "showPassword";
    TempStateAction["REMEMBER_ME"] = "rememberMe";
    TempStateAction["LAST_TRIED_EMAIL"] = "lastTriedEmail";
})(TempStateAction || (TempStateAction = {}));
// ── NavigationFieldsAction ────────────────────────────────────────
export var NavigationFieldsAction;
(function (NavigationFieldsAction) {
    NavigationFieldsAction["GO_TO_FORGOT_PASSWORD"] = "goToForgotPassword";
    NavigationFieldsAction["GO_TO_REGISTER"] = "goToRegister";
})(NavigationFieldsAction || (NavigationFieldsAction = {}));
// ── EmitsAction ───────────────────────────────────────────────────
export var EmitsAction;
(function (EmitsAction) {
    EmitsAction["SUBMIT_LOGIN"] = "submitLogin";
})(EmitsAction || (EmitsAction = {}));
// ── action state enums ────────────────────────────────────────────
export var Loading;
(function (Loading) {
    Loading["IDLE"] = "idle";
    Loading["LOADING"] = "loading";
})(Loading || (Loading = {}));
export var Error;
(function (Error) {
    Error["NONE"] = "none";
    Error["INVALID_CREDENTIALS"] = "invalid_credentials";
    Error["NETWORK_ERROR"] = "network_error";
})(Error || (Error = {}));
// ── mocks ─────────────────────────────────────────────────────────
export const Mock_user = [
    {
        email: 'alice@example.com',
        password: 'Alice@2024!',
    },
    {
        email: 'bob@pizzaria.com',
        password: 'B0bSecure#',
    },
    {
        email: 'carol@pizza.io',
        password: 'C@rolPass99',
    },
];
