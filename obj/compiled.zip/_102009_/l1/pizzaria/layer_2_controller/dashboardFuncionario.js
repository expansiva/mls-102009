// ── TempStateAction ───────────────────────────────────────────────
export var TempStateAction;
(function (TempStateAction) {
    TempStateAction["AUTO_REFRESH"] = "autoRefresh";
    TempStateAction["FILTRO_STATUS"] = "filtroStatus";
})(TempStateAction || (TempStateAction = {}));
// ── NavigationFieldsAction ────────────────────────────────────────
export var NavigationFieldsAction;
(function (NavigationFieldsAction) {
    NavigationFieldsAction["LOGOUT"] = "logout";
    NavigationFieldsAction["VER_DETALHES_PEDIDO"] = "verDetalhesPedido";
})(NavigationFieldsAction || (NavigationFieldsAction = {}));
// ── EmitsAction ───────────────────────────────────────────────────
export var EmitsAction;
(function (EmitsAction) {
    EmitsAction["LOGOUT"] = "logout";
    EmitsAction["PEDIDO_SELECIONADO"] = "pedidoSelecionado";
})(EmitsAction || (EmitsAction = {}));
// ── action state enums ────────────────────────────────────────────
export var Loading;
(function (Loading) {
    Loading["IDLE"] = "idle";
    Loading["LOADING"] = "loading";
    Loading["SUCCESS"] = "success";
    Loading["ERROR"] = "error";
})(Loading || (Loading = {}));
// ── mocks ─────────────────────────────────────────────────────────
export const Mock_staff = [
    {
        name: 'Alice Oliveira',
        role: 'Atendente',
        avatarUrl: 'https://example.com/avatar/alice.png',
    },
    {
        name: 'Bruno Silva',
        role: 'Pizzaiolo',
        // avatarUrl omitted
    },
    {
        name: 'Carla Souza',
        role: 'Gerente',
        avatarUrl: 'https://example.com/avatar/carla.png',
    },
];
export const Mock_pedido = [
    {
        id: 'pedido_001',
        clienteNome: 'João Lima',
        status: 'em produção',
        horaPedido: '2024-03-15T18:30:00Z',
        itens: [
            { produtoNome: 'Pizza Calabresa', quantidade: '2' },
            { produtoNome: 'Refrigerante', quantidade: '1' },
        ],
    },
    {
        id: 'pedido_002',
        // clienteNome omitted
        status: 'pronto',
        horaPedido: '2024-03-15T18:45:00Z',
        itens: [
            { produtoNome: 'Pizza Marguerita', quantidade: '1' },
        ],
    },
    {
        id: 'pedido_003',
        clienteNome: 'Maria Fernanda',
        status: 'atrasado',
        horaPedido: '2024-03-15T19:00:00Z',
        itens: [
            { produtoNome: 'Pizza Portuguesa', quantidade: '3' },
        ],
    },
];
export const Mock_itemPedido = [
    {
        produtoNome: 'Pizza Calabresa',
        quantidade: '2',
    },
    {
        produtoNome: 'Pizza Marguerita',
        quantidade: '1',
    },
    {
        produtoNome: 'Pizza Portuguesa',
        quantidade: '3',
    },
];
export const Mock_dashboardResumo = [
    {
        totalPedidosHoje: '25',
        emProducao: '8',
        prontos: '12',
        atrasados: '5',
    },
    {
        totalPedidosHoje: '30',
        emProducao: '10',
        prontos: '15',
        atrasados: '5',
    },
    {
        totalPedidosHoje: '18',
        emProducao: '5',
        prontos: '10',
        atrasados: '3',
    },
];
