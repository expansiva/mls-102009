import { pizzariaGetTopItemsHandler, pizzariaHomeLoadHandler, pizzariaListMenuHandler, pizzariaSeedMockDataHandler, pizzariaUpdateItemHandler, } from '/_102009_/l1/pizzaria/layer_2_controllers/catalogHandlers.js';
export function createPizzariaRouter() {
    return new Map([
        ['pizzaria.home.load', pizzariaHomeLoadHandler],
        ['pizzaria.listMenu', pizzariaListMenuHandler],
        ['pizzaria.getTopItems', pizzariaGetTopItemsHandler],
        ['pizzaria.seedMockData', pizzariaSeedMockDataHandler],
        ['pizzaria.updateItem', pizzariaUpdateItemHandler],
    ]);
}
