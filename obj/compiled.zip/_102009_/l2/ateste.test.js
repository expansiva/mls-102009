/// <mls shortName="ateste" project="102009" enhancement="_blank" folder="" />
export const integrations = [];
export const tests = [];
