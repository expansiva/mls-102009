"use strict";
/// <mls shortName="ateste" project="102009" enhancement="_blank" />
console.info('a');
