export const moduleGenome = {
    page11: {
        device: 'desktop',
        layout: 'standard',
    },
    page21: {
        device: 'mobile',
        layout: 'standard',
    },
};
export const moduleStates = {
    currentSection: 'ui.pizzaria.currentSection',
    selectedCategory: 'ui.pizzaria.selectedCategory',
    searchQuery: 'ui.pizzaria.searchQuery',
    editorAuthor: 'ui.pizzaria.editorAuthor',
};
export const moduleShellPreferences = {
    layout: {
        asideMode: {
            desktop: 'inline',
            mobile: 'fullscreen',
        },
    },
};
export const moduleFrontendDefinition = {
    pageTitle: 'pizzaria',
    device: 'desktop',
    navigation: [
        {
            id: 'catalog',
            label: 'Cardapio',
            href: '/pizzaria',
            description: 'Storefront menu view',
        },
        {
            id: 'edit-items',
            label: 'Edit items',
            href: '/pizzaria/edit-items',
            description: 'Simulate menu item changes with author',
        },
    ],
    routes: [
        {
            path: '/pizzaria',
            aliases: ['/pizzaria/index.html', '/pizzaria/cardapio'],
            entrypoint: '/_102009_/l2/pizzaria/web/routes/catalog.js',
            tag: 'pizzaria-web-desktop-home-page',
            title: 'Cardapio',
        },
        {
            path: '/pizzaria/edit-items',
            entrypoint: '/_102009_/l2/pizzaria/web/routes/edit-items.js',
            tag: 'pizzaria-web-desktop-home-page',
            title: 'Edit items',
        },
    ],
};
