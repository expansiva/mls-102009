import { execBff } from '/_102029_/l2/bffClient.js';
export async function loadPizzariaHome(params = {}, options) {
    return execBff('pizzaria.home.load', params, options);
}
