import { execBff } from '/_102029_/l2/bffClient.js';
export async function updatePizzariaItem(params, options) {
    return execBff('pizzaria.updateItem', params, options);
}
