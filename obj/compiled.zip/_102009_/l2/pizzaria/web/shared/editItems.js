/// <mls fileReference="_102009_/l2/pizzaria/web/shared/editItems.ts" enhancement="_blank" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_en = {
    brand: 'Pizzaria',
    pageTitle: 'Edit items',
    pageSubtitle: 'Simulate item changes and send an explicit author to the audit trail.',
    preparingItems: 'Preparing items...',
    loadingItems: 'Loading items...',
    couldNotLoadItems: 'Could not load items.',
    itemsLoaded: 'items loaded',
    authorLabel: 'Author',
    authorHint: 'This value is sent to the audit trail as the simulated user.',
    sectionTitle: 'Edit items',
    fieldName: 'Name',
    fieldCategory: 'Category',
    fieldPriceInCents: 'Price in cents',
    fieldHighlightScore: 'Highlight score',
    fieldStockStatus: 'Stock status',
    fieldDescription: 'Description',
    lastUpdate: 'Last update:',
    save: 'Save',
    saving: 'Saving',
    updated: 'Updated',
    by: 'by',
    couldNotUpdate: 'Could not update item.',
    couldNotSave: 'Could not save item',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
export class PizzariaEditItemsBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.editorAuthor = 'joao.pizzaria';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadItems(undefined, {
            mode: pendingLoad ? 'blocking' : 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
    }
    async loadItems(category, options) {
        this.status = this.msg.loadingItems;
        const response = await execBff('pizzaria.listMenu', {
            category,
        }, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoadItems,
                });
            }
            this.status = this.msg.couldNotLoadItems;
            this.items = [];
            return;
        }
        this.items = response.data ?? [];
        this.status = `${this.items.length} ${this.msg.itemsLoaded}`;
    }
    async saveItem(params, signal) {
        this.status = `${this.msg.saving} ${params.menuItemId}...`;
        const response = await execBff('pizzaria.updateItem', params, {
            mode: 'blocking',
            signal,
        });
        if (!response.ok || !response.data) {
            throw (response.error ?? {
                code: 'UNEXPECTED_ERROR',
                message: this.msg.couldNotUpdate,
            });
        }
        this.status = `${this.msg.updated} ${response.data.name} ${this.msg.by} ${this.editorAuthor.trim() || 'system'}.`;
        await this.loadItems(undefined, { mode: 'blocking', signal });
    }
    handleEditorSubmit(event) {
        event.preventDefault();
        const form = event.currentTarget;
        const formData = new FormData(form);
        const menuItemId = String(formData.get('menuItemId') ?? '');
        const payload = {
            menuItemId,
            author: this.editorAuthor.trim(),
            name: String(formData.get('name') ?? ''),
            category: String(formData.get('category') ?? ''),
            priceInCents: Number(formData.get('priceInCents') ?? 0),
            highlightScore: Number(formData.get('highlightScore') ?? 0),
            stockStatus: String(formData.get('stockStatus') ?? 'in_stock'),
            description: String(formData.get('description') ?? ''),
        };
        void runBlockingUiAction(async (signal) => { await this.saveItem(payload, signal); }, {
            busyLabel: `${this.msg.saving} ${menuItemId}...`,
            errorTitle: this.msg.couldNotSave,
            retry: () => this.saveItem(payload),
        });
    }
}
PizzariaEditItemsBase.properties = {
    items: { state: true },
    status: { state: true },
    editorAuthor: { state: true },
};
