/// <mls fileReference="_102009_/l2/pizzaria/web/shared/cardapio.ts" enhancement="_blank" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Pizzaria',
    pageTitle: 'Cardapio',
    pageSubtitle: 'Navegue pelos itens do menu e destaques.',
    preparingMenu: 'Preparando cardapio...',
    loadingMenu: 'Carregando cardapio...',
    filteringBy: 'Filtrando por',
    filteringMenu: 'Filtrando cardapio...',
    updatingMenu: 'Atualizando cardapio...',
    couldNotLoad: 'Nao foi possivel carregar os dados da pizzaria.',
    couldNotUpdate: 'Nao foi possivel atualizar o cardapio',
    itemsAvailable: 'itens disponiveis',
    reload: 'Recarregar',
    catPizzas: 'Pizzas',
    catBebidas: 'Bebidas',
    catSobremesas: 'Sobremesas',
    catBordas: 'Bordas',
    topItems: 'Itens em destaque',
    sectionTitle: 'Cardapio',
    score: 'score',
};
const message_en = {
    brand: 'Pizzaria',
    pageTitle: 'Menu',
    pageSubtitle: 'Browse menu items and featured highlights.',
    preparingMenu: 'Preparing menu...',
    loadingMenu: 'Loading menu...',
    filteringBy: 'Filtering by',
    filteringMenu: 'Filtering menu...',
    updatingMenu: 'Updating menu...',
    couldNotLoad: 'Could not load pizzaria data.',
    couldNotUpdate: 'Could not update menu',
    itemsAvailable: 'items available',
    reload: 'Reload',
    catPizzas: 'Pizzas',
    catBebidas: 'Bebidas',
    catSobremesas: 'Sobremesas',
    catBordas: 'Bordas',
    topItems: 'Top items',
    sectionTitle: 'Menu',
    score: 'score',
};
const messages = {
    en: message_en,
    pt: message_pt,
};
/// **collab_i18n_end**
export function formatPrice(priceInCents) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL',
    }).format(priceInCents / 100);
}
export class PizzariaCardapioBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadHome(undefined, {
            mode: pendingLoad ? 'blocking' : 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
    }
    async loadHome(category, options) {
        this.status = category ? `${this.msg.filteringBy} ${category}...` : this.msg.loadingMenu;
        const response = await execBff('pizzaria.home.load', {
            category,
            topLimit: 3,
            forceSeed: false,
        }, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoad,
                });
            }
            this.status = this.msg.couldNotLoad;
            this.items = [];
            this.topItems = [];
            return;
        }
        this.items = response.data.menu ?? [];
        this.topItems = response.data.topItems ?? [];
        this.status = `${this.items.length} ${this.msg.itemsAvailable}`;
    }
    reloadMenu(category) {
        const label = category ? this.msg.filteringMenu : this.msg.updatingMenu;
        void runBlockingUiAction((signal) => this.loadHome(category, { mode: 'blocking', signal }), {
            busyLabel: label,
            errorTitle: this.msg.couldNotUpdate,
            retry: () => this.loadHome(category, { mode: 'blocking' }),
        });
    }
}
PizzariaCardapioBase.properties = {
    items: { state: true },
    topItems: { state: true },
    status: { state: true },
};
