/// <mls fileReference="_102009_/l2/pizzaria/web/shared/login.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement } from 'lit';
import { state } from 'lit/decorators.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad } from '/_102029_/l2/interactionRuntime.js';
import { TempStateAction, NavigationFieldsAction, EmitsAction, Loading, Error, Mock_user, } from '/_102009_/l1/pizzaria/layer_2_controller/login.js';
export class LoginShared extends LitElement {
    constructor() {
        // ── @property() fields ──────────────────────────────
        // No route/input params specified in spec
        super(...arguments);
        // ── @state() fields ─────────────────────────────────
        this.action = null;
        this.loading = false;
        this.error = null;
        // Entity fields
        this.user_email = '';
        this.user_password = '';
        // Temp states
        this.showPassword = false;
        this.rememberMe = false;
        this.lastTriedEmail = '';
        this.errorMessage = '';
        // Action states
        this.loginLoading = Loading.IDLE;
        this.loginError = Error.NONE;
        // Computed fields
        this.isSubmitEnabled = false;
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        bindExpectedNavigationLoad(pendingLoad, Promise.resolve());
    }
    // ── updated() — covers every action value ───────────
    updated(changed) {
        if (changed.has('action')) {
            // EmitsAction
            if (this.action === EmitsAction.SUBMIT_LOGIN)
                this._submitLogin();
            // NavigationFieldsAction
            if (this.action === NavigationFieldsAction.GO_TO_FORGOT_PASSWORD)
                this.navigateToForgotPassword();
            if (this.action === NavigationFieldsAction.GO_TO_REGISTER)
                this.navigateToRegister();
            // TempStateAction
            if (this.action === TempStateAction.SHOW_PASSWORD)
                this._toggleShowPassword();
            if (this.action === TempStateAction.REMEMBER_ME)
                this._toggleRememberMe();
            if (this.action === TempStateAction.LAST_TRIED_EMAIL)
                this._setLastTriedEmail();
        }
    }
    // ── EmitsAction handlers ────────────────────────────
    async _submitLogin() {
        this.action = null;
        this.loading = true;
        this.error = null;
        this.loginLoading = Loading.LOADING;
        try {
            /*
            // Remove comment to execute
            const result = await execBff<user>(
              'user.submitLogin',
              { email: this.user_email, password: this.user_password },
            );
            if (result.error) {
              this.error = result.error.message;
              this.errorMessage = result.error.message;
              this.loginLoading = Loading.IDLE;
              this.loginError = Error.INVALID_CREDENTIALS;
              this.loading = false;
              return;
            }
            const res = result.data;
            if (!res) {
              this.loading = false;
              return;
            }
            */
            const res = Mock_user[0];
            this.user_email = res.email;
            this.user_password = res.password;
            this.lastTriedEmail = res.email;
            this._computeIsSubmitEnabled();
            this.loginLoading = Loading.IDLE;
            this.loginError = Error.NONE;
            this.loading = false;
        }
        catch (e) {
            this.loading = false;
            this.loginLoading = Loading.IDLE;
            this.loginError = Error.NETWORK_ERROR;
            this.error = e.message;
            this.errorMessage = e.message;
        }
    }
    // ── TempStateAction handlers ────────────────────────
    _toggleShowPassword() {
        this.action = null;
        this.showPassword = !this.showPassword;
    }
    _toggleRememberMe() {
        this.action = null;
        this.rememberMe = !this.rememberMe;
    }
    _setLastTriedEmail() {
        this.action = null;
        this.lastTriedEmail = this.user_email;
    }
    // ── NavigationFieldsAction handlers ─────────────────
    navigateToForgotPassword() {
        this.action = null;
        // Example: update router state or call navigation service
    }
    navigateToRegister() {
        this.action = null;
        // Example: update router state or call navigation service
    }
    // ── EmitsAction public surface ──────────────────────
    emitSubmitLogin() {
        this.action = null;
        // Payload available as state; extending component reads it
    }
    // ── Computed fields ─────────────────────────────────
    _computeIsSubmitEnabled() {
        this.isSubmitEnabled =
            this.user_email.includes('@') &&
                this.user_password.length >= 8 &&
                !this.loading;
    }
}
__decorate([
    state()
], LoginShared.prototype, "action", void 0);
__decorate([
    state()
], LoginShared.prototype, "loading", void 0);
__decorate([
    state()
], LoginShared.prototype, "error", void 0);
__decorate([
    state()
], LoginShared.prototype, "user_email", void 0);
__decorate([
    state()
], LoginShared.prototype, "user_password", void 0);
__decorate([
    state()
], LoginShared.prototype, "showPassword", void 0);
__decorate([
    state()
], LoginShared.prototype, "rememberMe", void 0);
__decorate([
    state()
], LoginShared.prototype, "lastTriedEmail", void 0);
__decorate([
    state()
], LoginShared.prototype, "errorMessage", void 0);
__decorate([
    state()
], LoginShared.prototype, "loginLoading", void 0);
__decorate([
    state()
], LoginShared.prototype, "loginError", void 0);
__decorate([
    state()
], LoginShared.prototype, "isSubmitEnabled", void 0);
