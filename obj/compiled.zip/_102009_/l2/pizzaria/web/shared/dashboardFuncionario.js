/// <mls fileReference="_102009_/l2/pizzaria/web/shared/dashboardFuncionario.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
import { state } from 'lit/decorators.js';
import { TempStateAction, NavigationFieldsAction, EmitsAction, Loading, Mock_staff, Mock_pedido, Mock_dashboardResumo, } from '_102009_/l1/pizzaria/layer_2_controller/dashboardFuncionario.js';
export class DashboardFuncionarioShared extends CollabLitElement {
    constructor() {
        // --- @property() fields (none: no route/input params) ---
        super(...arguments);
        // --- @state() fields ---
        this.action = null;
        this.loading = false;
        this.error = null;
        // staff fields (header)
        this.staff_name = '';
        this.staff_role = '';
        this.staff_avatarUrl = '';
        // pedidos (main - pedidos abertos)
        this.pedidos = [];
        // dashboardResumo (main - resumo produção)
        this.dashboardResumo_totalPedidosHoje = 0;
        this.dashboardResumo_emProducao = 0;
        this.dashboardResumo_prontos = 0;
        this.dashboardResumo_atrasados = 0;
        // --- Computed fields ---
        this.pedidosAtrasadosCount = 0;
        // --- Temp states ---
        this.autoRefresh = true;
        this.filtroStatus = 'todos';
        // --- Action states ---
        this.pedidosAbertosLoading = Loading.IDLE;
        this.resumoProducaoLoading = Loading.IDLE;
    }
    firstUpdated() {
        this.loadCurrentUser();
        this.loadPedidosAbertos();
        this.loadResumoProducao();
    }
    // --- updated() covers every Action value ---
    updated(changed) {
        if (changed.has('action')) {
            // EmitsAction
            if (this.action === EmitsAction.LOGOUT)
                this._emitLogout();
            if (this.action === EmitsAction.PEDIDO_SELECIONADO)
                this._emitPedidoSelecionado();
            // NavigationFieldsAction
            if (this.action === NavigationFieldsAction.LOGOUT)
                this.navigateToLogout();
            if (this.action === NavigationFieldsAction.VER_DETALHES_PEDIDO)
                this.navigateToVerDetalhesPedido();
            // TempStateAction
            if (this.action === TempStateAction.FILTRO_STATUS)
                this._toggleFiltroStatus();
            if (this.action === TempStateAction.AUTO_REFRESH)
                this._toggleAutoRefresh();
        }
    }
    // --- EmitsAction handlers ---
    async _emitLogout() {
        this.action = null;
        this.loading = true;
        this.error = null;
        try {
            /*
            const result = await execBff<staff>(
              'auth.logout',
              {},
            );
            if (result.error) {
              this.error = result.error.message;
              this.loading = false;
              return;
            }
            */
            // No payload to distribute for logout
            this.loading = false;
        }
        catch (e) {
            this.loading = false;
            this.error = e.message;
        }
    }
    async _emitPedidoSelecionado() {
        this.action = null;
        // This would be handled by the extending component, which knows the selected pedidoId
    }
    // --- NavigationFieldsAction handlers ---
    navigateToLogout() {
        this.action = null;
        // e.g. router push to logout or update state
    }
    navigateToVerDetalhesPedido() {
        this.action = null;
        // e.g. router push to pedidoDetalhe with id
    }
    // --- TempStateAction handlers ---
    _toggleFiltroStatus() {
        this.action = null;
        // Example: toggle between status filters (the actual logic may depend on UI)
        this.filtroStatus = this.filtroStatus === 'todos' ? 'em_producao' : 'todos';
    }
    _toggleAutoRefresh() {
        this.action = null;
        this.autoRefresh = !this.autoRefresh;
    }
    // --- Public emit methods (for extending component) ---
    emitLogout() {
        this.action = null;
    }
    emitPedidoSelecionado() {
        this.action = null;
    }
    // --- BFF action methods for data loading ---
    async loadCurrentUser() {
        this.loading = true;
        this.error = null;
        try {
            /*
            const result = await execBff<staff>(
              'auth.getCurrentUser',
              {},
            );
            if (result.error) {
              this.error = result.error.message;
              this.loading = false;
              return;
            }
            const res = result.data;
            if (!res) {
              this.loading = false;
              return;
            }
            */
            const res = Mock_staff[0];
            this.staff_name = res.name;
            this.staff_role = res.role;
            this.staff_avatarUrl = res.avatarUrl || '';
            this.loading = false;
        }
        catch (e) {
            this.loading = false;
            this.error = e.message;
        }
    }
    async loadPedidosAbertos() {
        this.pedidosAbertosLoading = Loading.LOADING;
        this.loading = true;
        this.error = null;
        try {
            /*
            const result = await execBff<pedido[]>(
              'pedidos.listAbertos',
              {},
            );
            if (result.error) {
              this.error = result.error.message;
              this.pedidosAbertosLoading = Loading.error;
              this.loading = false;
              return;
            }
            const res = result.data;
            if (!res) {
              this.pedidosAbertosLoading = Loading.error;
              this.loading = false;
              return;
            }
            */
            const res = Mock_pedido;
            this.pedidos = res;
            this._computePedidosAtrasadosCount();
            this.pedidosAbertosLoading = Loading.SUCCESS;
            this.loading = false;
        }
        catch (e) {
            this.loading = false;
            this.pedidosAbertosLoading = Loading.ERROR;
            this.error = e.message;
        }
    }
    async loadResumoProducao() {
        this.resumoProducaoLoading = Loading.LOADING;
        this.loading = true;
        this.error = null;
        try {
            /*
            const result = await execBff<dashboardResumo>(
              'dashboard.getResumoProducao',
              {},
            );
            if (result.error) {
              this.error = result.error.message;
              this.resumoProducaoLoading = Loading.error;
              this.loading = false;
              return;
            }
            const res = result.data;
            if (!res) {
              this.resumoProducaoLoading = Loading.error;
              this.loading = false;
              return;
            }
            */
            const res = Mock_dashboardResumo[0];
            this.dashboardResumo_totalPedidosHoje = +res.totalPedidosHoje || 0;
            this.dashboardResumo_emProducao = +res.emProducao || 0;
            this.dashboardResumo_prontos = +res.prontos;
            this.dashboardResumo_atrasados = +res.atrasados;
            this.resumoProducaoLoading = Loading.SUCCESS;
            this.loading = false;
        }
        catch (e) {
            this.loading = false;
            this.resumoProducaoLoading = Loading.ERROR;
            this.error = e.message;
        }
    }
    // --- Computed field methods ---
    _computePedidosAtrasadosCount() {
        this.pedidosAtrasadosCount = this.pedidos.filter(p => p.status === 'atrasado').length;
    }
}
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "action", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "loading", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "error", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "staff_name", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "staff_role", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "staff_avatarUrl", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "pedidos", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "dashboardResumo_totalPedidosHoje", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "dashboardResumo_emProducao", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "dashboardResumo_prontos", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "dashboardResumo_atrasados", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "pedidosAtrasadosCount", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "autoRefresh", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "filtroStatus", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "pedidosAbertosLoading", void 0);
__decorate([
    state()
], DashboardFuncionarioShared.prototype, "resumoProducaoLoading", void 0);
