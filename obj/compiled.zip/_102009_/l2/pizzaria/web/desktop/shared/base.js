/// <mls fileReference="_102009_/l2/pizzaria/web/desktop/shared/base.ts" enhancement="_blank" />
import { LitElement } from 'lit';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
export function formatPrice(priceInCents) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL',
    }).format(priceInCents / 100);
}
export class PizzariaDesktopBase extends LitElement {
    constructor() {
        super(...arguments);
        this.editorAuthor = 'joao.pizzaria';
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadHome(undefined, {
            mode: pendingLoad ? 'blocking' : 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
    }
    async loadHome(category, options) {
        this.status = category ? `Filtering by ${category}...` : 'Loading menu...';
        const response = await execBff('pizzaria.home.load', {
            category,
            topLimit: 3,
            forceSeed: false,
        }, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: 'Could not load pizzaria data.',
                });
            }
            this.status = 'Could not load pizzaria data.';
            this.items = [];
            this.topItems = [];
            return;
        }
        this.items = response.data.menu ?? [];
        this.topItems = response.data.topItems ?? [];
        this.status = `${this.items.length} items available`;
    }
    reloadMenu(category) {
        const label = category ? 'Filtrando cardapio...' : 'Atualizando cardapio...';
        void runBlockingUiAction((signal) => this.loadHome(category, { mode: 'blocking', signal }), {
            busyLabel: label,
            errorTitle: 'Nao foi possivel atualizar o cardapio',
            retry: () => this.loadHome(category, { mode: 'blocking' }),
        });
    }
    async saveItem(params, signal) {
        this.status = `Saving ${params.menuItemId}...`;
        const response = await execBff('pizzaria.updateItem', params, {
            mode: 'blocking',
            signal,
        });
        if (!response.ok || !response.data) {
            throw (response.error ?? {
                code: 'UNEXPECTED_ERROR',
                message: 'Could not update item.',
            });
        }
        this.status = `Updated ${response.data.name} by ${this.editorAuthor.trim() || 'system'}.`;
        await this.loadHome(undefined, { mode: 'blocking', signal });
    }
    handleEditorSubmit(event) {
        event.preventDefault();
        const form = event.currentTarget;
        const formData = new FormData(form);
        const menuItemId = String(formData.get('menuItemId') ?? '');
        const payload = {
            menuItemId,
            author: this.editorAuthor.trim(),
            name: String(formData.get('name') ?? ''),
            category: String(formData.get('category') ?? ''),
            priceInCents: Number(formData.get('priceInCents') ?? 0),
            highlightScore: Number(formData.get('highlightScore') ?? 0),
            stockStatus: String(formData.get('stockStatus') ?? 'in_stock'),
            description: String(formData.get('description') ?? ''),
        };
        void runBlockingUiAction(async (signal) => { await this.saveItem(payload, signal); }, {
            busyLabel: `Salvando ${menuItemId}...`,
            errorTitle: 'Nao foi possivel salvar o item',
            retry: () => this.saveItem(payload),
        });
    }
}
PizzariaDesktopBase.properties = {
    items: { state: true },
    topItems: { state: true },
    status: { state: true },
    editorAuthor: { state: true },
};
