/// <mls shortName="module" project="102009" enhancement="_blank" folder="petshop" />
export const integrations = [];
export const tests = [];
