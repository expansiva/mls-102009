import { execBff } from '/_102029_/l2/bffClient.js';
export async function loadPetshopHome(params = {}, options) {
    return execBff('petshop.home.load', params, options);
}
