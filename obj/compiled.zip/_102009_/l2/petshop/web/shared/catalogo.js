/// <mls fileReference="_102009_/l2/petshop/web/shared/catalogo.ts" enhancement="_blank" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_en = {
    brand: 'Petshop',
    pageTitle: 'Catalog',
    pageSubtitle: 'Browse products and featured highlights.',
    preparingCatalog: 'Preparing catalog...',
    loadingCatalog: 'Loading catalog...',
    filteringBy: 'Filtering by',
    filteringCatalog: 'Filtering catalog...',
    updatingCatalog: 'Updating catalog...',
    couldNotLoad: 'Could not load petshop data.',
    couldNotUpdate: 'Could not update catalog',
    productsAvailable: 'products available',
    reload: 'Reload',
    catBanho: 'Banho',
    catAlimentacao: 'Alimentacao',
    catHigiene: 'Higiene',
    topProducts: 'Top products',
    sectionTitle: 'Catalog',
    score: 'score',
};
const messages = { en: message_en };
/// **collab_i18n_end**
export function formatPrice(priceInCents) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL',
    }).format(priceInCents / 100);
}
export class PetshopCatalogoBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadHome(undefined, {
            mode: pendingLoad ? 'blocking' : 'silent',
            signal: pendingLoad?.signal,
        });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
    }
    async loadHome(category, options) {
        this.status = category ? `${this.msg.filteringBy} ${category}...` : this.msg.loadingCatalog;
        const response = await execBff('petshop.home.load', {
            category,
            topLimit: 3,
            forceSeed: false,
        }, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoad,
                });
            }
            this.status = this.msg.couldNotLoad;
            this.items = [];
            this.topItems = [];
            return;
        }
        this.items = response.data.catalog ?? [];
        this.topItems = response.data.topProducts ?? [];
        this.status = `${this.items.length} ${this.msg.productsAvailable}`;
    }
    reloadCatalog(category) {
        const label = category ? this.msg.filteringCatalog : this.msg.updatingCatalog;
        void runBlockingUiAction((signal) => this.loadHome(category, { mode: 'blocking', signal }), {
            busyLabel: label,
            errorTitle: this.msg.couldNotUpdate,
            retry: () => this.loadHome(category, { mode: 'blocking' }),
        });
    }
}
PetshopCatalogoBase.properties = {
    items: { state: true },
    topItems: { state: true },
    status: { state: true },
};
