declare module "_102009_/l1/pizzaria/layer_2_controller/dashboardFuncionario" {
    /**
    * @screen dashboardFuncionario
    * @page dashboardFuncionario
    * @actor staff
    * @purpose Painel principal para funcionários acompanharem pedidos, status de produção, e métricas rápidas da pizzaria.
    */
    export interface staff {
        name: string;
        role: string;
        avatarUrl?: string;
    }
    export interface pedido {
        id: string;
        clienteNome?: string;
        status: string;
        horaPedido: string;
        itens: itemPedido[];
    }
    export interface itemPedido {
        produtoNome: string;
        quantidade: string;
    }
    export interface dashboardResumo {
        totalPedidosHoje: string;
        emProducao: string;
        prontos: string;
        atrasados: string;
    }
    export enum TempStateAction {
        AUTO_REFRESH = "autoRefresh",
        FILTRO_STATUS = "filtroStatus"
    }
    export enum NavigationFieldsAction {
        LOGOUT = "logout",
        VER_DETALHES_PEDIDO = "verDetalhesPedido"
    }
    export enum EmitsAction {
        LOGOUT = "logout",
        PEDIDO_SELECIONADO = "pedidoSelecionado"
    }
    export enum Loading {
        IDLE = "idle",
        LOADING = "loading",
        SUCCESS = "success",
        ERROR = "error"
    }
    export const Mock_staff: staff[];
    export const Mock_pedido: pedido[];
    export const Mock_itemPedido: itemPedido[];
    export const Mock_dashboardResumo: dashboardResumo[];
}
declare module "_102009_/l1/pizzaria/layer_2_controller/login" {
    /**
    * @screen login
    * @page login
    * @actor customer
    * @purpose Authenticate user and establish session for secure access to the pizzaria app.
    */
    export interface user {
        email: string;
        password: string;
    }
    export enum TempStateAction {
        SHOW_PASSWORD = "showPassword",
        REMEMBER_ME = "rememberMe",
        LAST_TRIED_EMAIL = "lastTriedEmail"
    }
    export enum NavigationFieldsAction {
        GO_TO_FORGOT_PASSWORD = "goToForgotPassword",
        GO_TO_REGISTER = "goToRegister"
    }
    export enum EmitsAction {
        SUBMIT_LOGIN = "submitLogin"
    }
    export enum Loading {
        IDLE = "idle",
        LOADING = "loading"
    }
    export enum Error {
        NONE = "none",
        INVALID_CREDENTIALS = "invalid_credentials",
        NETWORK_ERROR = "network_error"
    }
    export const Mock_user: user[];
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102009_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102009_/l2/project" {
    export const modules: {
        name: string;
        path: string;
        auth: string;
        icon: string;
    }[];
}
declare module "_102009_/l2/pizzaria/dashboardFuncionario.defs" {
    export const definition: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: ({
                sectionName: string;
                mode: string;
                organisms: {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        fields: {
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                        }[];
                        params: any[];
                    };
                    tempStates: any[];
                    computedFields: any[];
                    navigationFields: {
                        fieldId: string;
                        target: string;
                        params: any[];
                        priority: string;
                        navigationType: string;
                    }[];
                    emits: {
                        event: string;
                        payload: string;
                    }[];
                }[];
            } | {
                sectionName: string;
                mode: string;
                organisms: ({
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        itemFields: ({
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                            isNested?: undefined;
                            nestedCollection?: undefined;
                        } | {
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                            isNested: boolean;
                            nestedCollection: {
                                stateKeySuffix: string;
                                itemFields: {
                                    entityField: string;
                                    entity: string;
                                    priority: string;
                                    usage: string;
                                }[];
                            };
                        })[];
                        params: any[];
                        editable: boolean;
                        fields?: undefined;
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: {
                        fieldId: string;
                        target: string;
                        params: string[];
                        priority: string;
                        navigationType: string;
                    }[];
                    emits: {
                        event: string;
                        payload: string;
                    }[];
                } | {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        stateKey: string;
                        sourceRoutine: string;
                        fields: {
                            entityField: string;
                            entity: string;
                            priority: string;
                            usage: string;
                        }[];
                        params: any[];
                        itemFields?: undefined;
                        editable?: undefined;
                    };
                    tempStates: any[];
                    computedFields: any[];
                    navigationFields: any[];
                    emits: any[];
                })[];
            })[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
                initialValue: string;
            }[];
        }[];
    };
    export const contractSpec = "\n##Pages spec\n```JSON\n    [[(_102009_/l2/pizzaria/dashboardFuncionario.defs.ts).definition]]\n```\n";
    export const sharedSpec = "\n##Pages spec\n```JSON\n{\n  \"interfacePath\":\"_102009_/l1/pizzaria/layer_2_controller/dashboardFuncionario.js\",\n  \"definition\": [[(_102009_/l2/pizzaria/dashboardFuncionario.defs.ts).definition]]\n}    \n```\n\n##Base Interfaces, Enuns ...\n```\n    [[(_102009_/l1/pizzaria/layer_2_controller/dashboardFuncionario.ts)]]\n```\n";
    export const desktopLayout: {
        className: string;
        tagName: string;
        extends: string;
        sharedPath: string;
        styling: string;
        imports: {
            type: string;
            import: string;
            path: string;
        }[];
        render: {
            conditions: {
                if: string;
                return: string;
            }[];
            blocks: {
                default: {
                    element: string;
                    class: string;
                    children: ({
                        element: string;
                        class: string;
                        children: {
                            element: string;
                            class: string;
                            children: ({
                                element: string;
                                class: string;
                                bind: string;
                                condition: string;
                                children?: undefined;
                                i18n?: undefined;
                                event?: undefined;
                            } | {
                                element: string;
                                class: string;
                                children: {
                                    element: string;
                                    class: string;
                                    bind: string;
                                    i18n: string;
                                }[];
                                bind?: undefined;
                                condition?: undefined;
                                i18n?: undefined;
                                event?: undefined;
                            } | {
                                element: string;
                                class: string;
                                i18n: string;
                                event: {
                                    on: string;
                                    type: string;
                                    method: string;
                                };
                                bind?: undefined;
                                condition?: undefined;
                                children?: undefined;
                            })[];
                        }[];
                    } | {
                        element: string;
                        class: string;
                        children: ({
                            element: string;
                            class: string;
                            children: ({
                                element: string;
                                class: string;
                                i18n: string;
                                children?: undefined;
                            } | {
                                element: string;
                                class: string;
                                i18n: string;
                                children: {
                                    element: string;
                                    class: string;
                                    bind: string;
                                    event: {
                                        on: string;
                                        type: string;
                                        state: string;
                                        cast: string;
                                    };
                                    children: {
                                        element: string;
                                        i18n: string;
                                        bind: string;
                                        children: any[];
                                        value: string;
                                    }[];
                                }[];
                            } | {
                                element: string;
                                class: string;
                                children: {
                                    element: string;
                                    class: string;
                                    i18n: string;
                                    children: {
                                        element: string;
                                        class: string;
                                        type: string;
                                        bind: string;
                                        event: {
                                            on: string;
                                            type: string;
                                            state: string;
                                            cast: string;
                                        };
                                    }[];
                                }[];
                                i18n?: undefined;
                            })[];
                            repeat?: undefined;
                        } | {
                            element: string;
                            class: string;
                            repeat: {
                                source: string;
                                item: string;
                                key: string;
                            };
                            children: {
                                element: string;
                                class: string;
                                condition: string;
                                children: ({
                                    element: string;
                                    class: string;
                                    children: {
                                        element: string;
                                        class: string;
                                        bind: string;
                                        i18n: string;
                                    }[];
                                    bind?: undefined;
                                    i18n?: undefined;
                                    event?: undefined;
                                } | {
                                    element: string;
                                    class: string;
                                    bind: string;
                                    i18n: string;
                                    children?: undefined;
                                    event?: undefined;
                                } | {
                                    element: string;
                                    class: string;
                                    children: {
                                        element: string;
                                        class: string;
                                        repeat: {
                                            source: string;
                                            item: string;
                                            key: string;
                                        };
                                        children: {
                                            element: string;
                                            class: string;
                                            children: {
                                                element: string;
                                                class: string;
                                                bind: string;
                                                i18n: string;
                                            }[];
                                        }[];
                                    }[];
                                    bind?: undefined;
                                    i18n?: undefined;
                                    event?: undefined;
                                } | {
                                    element: string;
                                    class: string;
                                    i18n: string;
                                    event: {
                                        on: string;
                                        type: string;
                                        method: string;
                                    };
                                    children?: undefined;
                                    bind?: undefined;
                                })[];
                            }[];
                        } | {
                            element: string;
                            class: string;
                            children: {
                                element: string;
                                class: string;
                                bind: string;
                                i18n: string;
                            }[];
                            repeat?: undefined;
                        })[];
                    } | {
                        element: string;
                        class: string;
                        children: ({
                            element: string;
                            class: string;
                            i18n: string;
                            children?: undefined;
                        } | {
                            element: string;
                            class: string;
                            children: {
                                element: string;
                                class: string;
                                children: ({
                                    element: string;
                                    class: string;
                                    i18n: string;
                                    bind?: undefined;
                                } | {
                                    element: string;
                                    class: string;
                                    bind: string;
                                    i18n?: undefined;
                                })[];
                            }[];
                            i18n?: undefined;
                        })[];
                    })[];
                };
                loading: {
                    element: string;
                    class: string;
                    children: {
                        element: string;
                        class: string;
                        i18n: string;
                    }[];
                };
                error: {
                    element: string;
                    class: string;
                    children: ({
                        element: string;
                        class: string;
                        i18n: string;
                        event?: undefined;
                    } | {
                        element: string;
                        class: string;
                        i18n: string;
                        event: {
                            on: string;
                            type: string;
                            state: string;
                            value: string;
                        };
                    })[];
                };
            };
        };
        i18n: {
            default: string;
            languages: string[];
            keys: string[];
        };
    };
    export const desktopLayoutSpec = "\n## Page layout\n```JSON\n{ \n  \"interfacePath\":\"_102009_/l1/pizzaria/layer_2_controller/dashboardFuncionario.js\",\n  \"definition\": [[(_102009_/l2/pizzaria/dashboardFuncionario.defs.ts).desktopLayout]]  \n}\n```\n\n##Base class\n```\n  [[(_102009_/l2/pizzaria/web/shared/dashboardFuncionario.ts)]]\n```\n";
    export const materializeIndex: {
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
    }[];
}
declare module "_102009_/l2/pizzaria/login.defs" {
    export const definition: {
        pages: {
            screenId: string;
            pageName: string;
            actor: string;
            purpose: string;
            sections: {
                sectionName: string;
                mode: string;
                organisms: {
                    organismName: string;
                    purpose: string;
                    rulesApplied: string[];
                    dataShape: {
                        shape: string;
                        entityFields: {
                            entity: string;
                            entityField: string;
                            stateKey: string;
                            priority: string;
                            usage: string;
                            priorityReason: string;
                        }[];
                    };
                    tempStates: {
                        stateKey: string;
                        type: string;
                        description: string;
                        priority: string;
                        initialValue: string;
                    }[];
                    computedFields: {
                        fieldId: string;
                        derivedFrom: string[];
                        description: string;
                        priority: string;
                    }[];
                    navigationFields: {
                        fieldId: string;
                        target: string;
                        params: any[];
                        priority: string;
                        navigationType: string;
                    }[];
                    emits: {
                        event: string;
                        payload: string;
                        writesState: string;
                    }[];
                }[];
            }[];
            actionStates: {
                stateKey: string;
                description: string;
                values: string[];
            }[];
            tempStates: {
                stateKey: string;
                type: string;
                description: string;
                priority: string;
            }[];
        }[];
    };
    export const contractSpec = "\n##Pages spec\n```JSON\n    [[(_102009_/l2/pizzaria/login.defs.ts).definition]]\n```\n";
    export const sharedSpec = "\n##Pages spec\n```JSON\n{\n  \"interfacePath\":\"_102009_/l1/pizzaria/layer_2_controller/login.js\",\n  \"definition\": [[(_102009_/l2/pizzaria/login.defs.ts).definition]]\n}    \n```\n\n##Base Interfaces, Enuns ...\n```\n    [[(_102009_/l1/pizzaria/layer_2_controller/login.ts)]]\n```\n";
    export const desktopLayout: {
        className: string;
        tagName: string;
        extends: string;
        sharedPath: string;
        styling: string;
        imports: {
            type: string;
            import: string;
            path: string;
        }[];
        render: {
            conditions: {
                if: string;
                return: string;
            }[];
            blocks: {
                default: {
                    element: string;
                    class: string;
                    children: {
                        element: string;
                        class: string;
                        children: {
                            element: string;
                            class: string;
                            event: {
                                on: string;
                                type: string;
                                state: string;
                                value: string;
                                prevent: boolean;
                            };
                            children: ({
                                element: string;
                                class: string;
                                i18n: string;
                                children: {
                                    element: string;
                                    type: string;
                                    class: string;
                                    bind: string;
                                    autocomplete: string;
                                    required: boolean;
                                    event: {
                                        on: string;
                                        type: string;
                                        state: string;
                                        cast: string;
                                    };
                                }[];
                            } | {
                                element: string;
                                class: string;
                                i18n: string;
                                children: ({
                                    element: string;
                                    type: {
                                        condition: string;
                                        then: string;
                                        else: string;
                                    };
                                    class: string;
                                    bind: string;
                                    autocomplete: string;
                                    required: boolean;
                                    event: {
                                        on: string;
                                        type: string;
                                        state: string;
                                        cast: string;
                                        value?: undefined;
                                    };
                                    i18n?: undefined;
                                } | {
                                    element: string;
                                    type: string;
                                    class: string;
                                    i18n: string;
                                    event: {
                                        on: string;
                                        type: string;
                                        state: string;
                                        value: string;
                                        cast?: undefined;
                                    };
                                    bind?: undefined;
                                    autocomplete?: undefined;
                                    required?: undefined;
                                })[];
                            } | {
                                element: string;
                                class: string;
                                i18n: string;
                                children: {
                                    element: string;
                                    type: string;
                                    class: string;
                                    bind: string;
                                    event: {
                                        on: string;
                                        type: string;
                                        state: string;
                                        cast: string;
                                    };
                                }[];
                            } | {
                                element: string;
                                class: string;
                                children: {
                                    element: string;
                                    type: string;
                                    class: string;
                                    i18n: string;
                                    disabled: {
                                        condition: string;
                                    };
                                }[];
                                i18n?: undefined;
                            } | {
                                element: string;
                                class: string;
                                children: {
                                    element: string;
                                    type: string;
                                    class: string;
                                    i18n: string;
                                    event: {
                                        on: string;
                                        type: string;
                                        method: string;
                                    };
                                }[];
                                i18n?: undefined;
                            })[];
                        }[];
                    }[];
                };
                loading: {
                    element: string;
                    class: string;
                    children: {
                        element: string;
                        class: string;
                        i18n: string;
                    }[];
                };
                error: {
                    element: string;
                    class: string;
                    children: ({
                        element: string;
                        class: string;
                        i18n: string;
                        type?: undefined;
                        event?: undefined;
                    } | {
                        element: string;
                        type: string;
                        class: string;
                        i18n: string;
                        event: {
                            on: string;
                            type: string;
                            state: string;
                            value: string;
                        };
                    })[];
                };
            };
        };
        i18n: {
            default: string;
            languages: string[];
            keys: string[];
        };
    };
    export const desktopLayoutSpec = "\n## Page layout\n```JSON\n{ \n  \"interfacePath\":\"_102009_/l1/pizzaria/layer_2_controller/login.js\",\n  \"definition\": [[(_102009_/l2/pizzaria/login.defs.ts).desktopLayout]]  \n}\n```\n\n##Base class\n```\n  [[(_102009_/l2/pizzaria/web/shared/login.ts)]]\n```\n";
    export const materializeIndex: {
        id: string;
        specVar: string;
        outputPath: string;
        skillPath: string;
        agent: string;
        dependsOn: string[];
        specUpdatedAt: string;
    }[];
}
declare module "_102009_/l2/pizzaria/module.defs" {
    export const ontology: {
        meta: {
            userLanguage: string;
            moduleName: string;
            userPromptOriginal: string;
            userPromptFinal: string;
        };
        ontology: {
            entities: {
                Pedido: {
                    description: string;
                    fields: {
                        numeroPedido: {
                            type: string;
                        };
                        clienteNome: {
                            type: string;
                        };
                        clienteTelefone: {
                            type: string;
                        };
                        enderecoEntrega: {
                            type: string;
                        };
                        dataHora: {
                            type: string;
                            constraints: string;
                        };
                        status: {
                            type: string;
                            values: string[];
                            constraints: string;
                        };
                        valorTotal: {
                            type: string;
                        };
                        formaPagamento: {
                            type: string;
                        };
                        itens: {
                            type: string;
                            constraints: string;
                        };
                    };
                    rules: string[];
                };
                Pizza: {
                    description: string;
                    fields: {
                        sabores: {
                            type: string;
                            constraints: string;
                        };
                        tamanho: {
                            type: string;
                        };
                        quantidade: {
                            type: string;
                        };
                        bordaRecheada: {
                            type: string;
                        };
                        adicionais: {
                            type: string;
                            constraints: string;
                        };
                    };
                };
                Usuario: {
                    description: string;
                    fields: {
                        papel: {
                            type: string;
                            values: string[];
                        };
                    };
                };
                Cliente: {
                    description: string;
                    fields: {
                        nome: {
                            type: string;
                        };
                        telefone: {
                            type: string;
                        };
                        enderecos: {
                            type: string;
                            constraints: string;
                        };
                        historicoPedidos: {
                            type: string;
                            constraints: string;
                        };
                    };
                };
                CupomDesconto: {
                    description: string;
                    fields: {
                        codigo: {
                            type: string;
                        };
                        descricao: {
                            type: string;
                        };
                        valorDesconto: {
                            type: string;
                            constraints: string;
                        };
                        tipoDesconto: {
                            type: string;
                            values: string[];
                        };
                        validoAte: {
                            type: string;
                            constraints: string;
                        };
                    };
                };
                ComboPromocional: {
                    description: string;
                    fields: {
                        nome: {
                            type: string;
                        };
                        descricao: {
                            type: string;
                        };
                        itensCombo: {
                            type: string;
                            constraints: string;
                        };
                        precoCombo: {
                            type: string;
                        };
                    };
                };
            };
        };
        rules: {
            ruleCadastroPedido: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleListagemPedido: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            rulePublicoAlvo: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleIdioma: {
                kind: string;
                description: string;
                acceptanceCriteria: string[];
            };
            rulePrioridadeFuncionalidades: {
                kind: string;
                description: string;
                acceptanceCriteria: string[];
            };
            rulePizzaMultiSabor: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleCadastroCliente: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleCupomDesconto: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleComboPromocional: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleRastreamentoPedido: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleRelatorioVendas: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
            ruleAtualizacaoRapidaStatusPedido: {
                kind: string;
                description: string;
                scope: string[];
                acceptanceCriteria: string[];
            };
        };
        capabilities: {
            cadastroPedido: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            listagemPedido: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            cadastroCliente: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            aplicarCupomDesconto: {
                description: string;
                usesRules: string[];
                isOptional: boolean;
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            selecionarComboPromocional: {
                description: string;
                usesRules: string[];
                isOptional: boolean;
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            rastreamentoPedido: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
            relatorioVendas: {
                description: string;
                usesRules: string[];
                actions: {
                    actionId: string;
                    description: string;
                }[];
            };
        };
    };
}
declare module "_102027_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102027_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/contracts/bootstrap" {
    export type AuraShellMode = 'spa' | 'pwa';
    export type AuraDeviceKind = 'desktop' | 'mobile';
    export type AuraAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface AuraRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface AuraLayoutConfig {
        regions: {
            desktop: AuraRegionVisibility;
            mobile: AuraRegionVisibility;
        };
        asideMode: {
            desktop: AuraAsideMode;
            mobile: AuraAsideMode;
        };
    }
    export interface AuraRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export type AuraRouteMatchMode = 'exact' | 'prefix';
    export interface AuraRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: AuraRouteMatchMode;
    }
    export interface AuraModuleFrontendDefinition {
        pageTitle?: string;
        device?: AuraDeviceKind;
        navigation?: AuraNavigationItem[];
        routes: AuraRouteDefinition[];
        headerRenderer?: AuraRegionRendererConfig;
        asideRenderer?: AuraRegionRendererConfig;
    }
    export interface AuraNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface AuraModuleShellPreferences {
        layout?: Partial<AuraLayoutConfig>;
    }
    export interface AuraBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: AuraShellMode;
        device: AuraDeviceKind;
        routes: AuraRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: AuraNavigationItem[];
        moduleLinks?: AuraNavigationItem[];
        layout: AuraLayoutConfig;
    }
    export type AuraInteractionMode = 'blocking' | 'silent';
    export type AuraBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface AuraNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface AuraBlockingErrorState {
        title: string;
        error: AuraNormalizedError;
        canRetry: boolean;
    }
    export interface AuraInteractionState {
        busy: boolean;
        busyPhase: AuraBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: AuraBlockingErrorState;
    }
    global {
        interface Window {
            collabAuraShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
            };
        }
        interface Window {
            collabBoot?: AuraBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabAuraInteractionState?: AuraInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/bffClient" {
    import type { AuraInteractionMode, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    export interface BffClientOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: AuraNormalizedError | null;
    }
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102009_/l2/pizzaria/web/shared/dashboardFuncionario" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    import type { pedido } from "_102009_/l1/pizzaria/layer_2_controller/dashboardFuncionario";
    import { TempStateAction, NavigationFieldsAction, EmitsAction, Loading } from "_102009_/l1/pizzaria/layer_2_controller/dashboardFuncionario";
    export class DashboardFuncionarioShared extends CollabLitElement {
        action: TempStateAction | NavigationFieldsAction | EmitsAction | null;
        loading: boolean;
        error: string | null;
        staff_name: string;
        staff_role: string;
        staff_avatarUrl: string;
        pedidos: pedido[];
        dashboardResumo_totalPedidosHoje: number;
        dashboardResumo_emProducao: number;
        dashboardResumo_prontos: number;
        dashboardResumo_atrasados: number;
        pedidosAtrasadosCount: number;
        autoRefresh: boolean;
        filtroStatus: string;
        pedidosAbertosLoading: Loading;
        resumoProducaoLoading: Loading;
        firstUpdated(): void;
        updated(changed: Map<string, unknown>): void;
        private _emitLogout;
        private _emitPedidoSelecionado;
        navigateToLogout(): void;
        navigateToVerDetalhesPedido(): void;
        private _toggleFiltroStatus;
        private _toggleAutoRefresh;
        emitLogout(): void;
        emitPedidoSelecionado(): void;
        loadCurrentUser(): Promise<void>;
        loadPedidosAbertos(): Promise<void>;
        loadResumoProducao(): Promise<void>;
        private _computePedidosAtrasadosCount;
    }
}
declare module "_102009_/l2/pizzaria/web/desktop/dashboardFuncionario" {
    import { DashboardFuncionarioShared } from "_102009_/l2/pizzaria/web/shared/dashboardFuncionario";
    export class DashboardFuncionarioPage extends DashboardFuncionarioShared {
        private msg;
        render(): any;
    }
}
declare module "_102009_/l2/pizzaria/web/shared/login" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    import { TempStateAction, NavigationFieldsAction, EmitsAction, Loading, Error } from "_102009_/l1/pizzaria/layer_2_controller/login";
    export class LoginShared extends CollabLitElement {
        action: TempStateAction | NavigationFieldsAction | EmitsAction | null;
        loading: boolean;
        error: string | null;
        user_email: string;
        user_password: string;
        showPassword: boolean;
        rememberMe: boolean;
        lastTriedEmail: string;
        errorMessage: string;
        loginLoading: Loading;
        loginError: Error;
        isSubmitEnabled: boolean;
        updated(changed: Map<string, unknown>): void;
        private _submitLogin;
        private _toggleShowPassword;
        private _toggleRememberMe;
        private _setLastTriedEmail;
        navigateToForgotPassword(): void;
        navigateToRegister(): void;
        emitSubmitLogin(): void;
        private _computeIsSubmitEnabled;
    }
}
declare module "_102009_/l2/pizzaria/web/desktop/login" {
    import { LoginShared } from "_102009_/l2/pizzaria/web/shared/login";
    export class LoginPage extends LoginShared {
        private msg;
        render(): any;
    }
}
