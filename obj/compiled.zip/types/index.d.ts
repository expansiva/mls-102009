declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102009_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102009_/l2/project" {
    export const modules: {
        name: string;
        path: string;
        auth: string;
        icon: string;
    }[];
}
declare module "_102009_/l2/petshop/module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: {
            pageName: string;
            title: string;
            auth: string;
            icon: string;
        }[];
    };
    export const payload3: {
        finalModuleDetails: {
            userLanguage: string;
            executionRegions: string;
            userPrompt: string;
            moduleGoal: string;
            moduleName: string;
            requirements: string[];
            userRequestsEnhancements: {
                description: string;
                priority: string;
            }[];
        };
        pages: {
            pageSequential: number;
            pageName: string;
            pageGoal: string;
            pageRequirements: string[];
        }[];
        plugins: {
            pluginSequential: number;
            pluginName: string;
            pluginType: string;
            pluginGoal: string;
            pluginRequirements: string[];
        }[];
        pagesWireframe: {
            pageSequential: number;
            pageName: string;
            pageHtml: string[];
        }[];
        organism: ({
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                    }[];
                }[];
                constraints: string[];
            };
        } | {
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                    }[];
                }[];
                constraints?: undefined;
            };
        })[];
        visualIdentity: {
            logoDescription: string;
            fontFamily: string;
            iconStyle: string;
            illustrationStyle: string;
            colorPalette: {
                primary: string;
                secondary: string;
                text: string;
                background: string;
                border: string;
                error: string;
                warning: string;
                success: string;
            };
        };
        tokens: {
            description: string;
            themeName: string;
            color: {
                "text-primary-color-lighter": string;
                "text-primary-color-lighter-hover": string;
                "text-primary-color-lighter-focus": string;
                "text-primary-color-lighter-disabled": string;
                "text-primary-color": string;
                "text-primary-color-hover": string;
                "text-primary-color-focus": string;
                "text-primary-color-disabled": string;
                "text-primary-color-darker": string;
                "text-primary-color-darker-hover": string;
                "text-primary-color-darker-focus": string;
                "text-primary-color-darker-disabled": string;
                "text-secondary-color-lighter": string;
                "text-secondary-color-lighter-hover": string;
                "text-secondary-color-lighter-focus": string;
                "text-secondary-color-lighter-disabled": string;
                "text-secondary-color": string;
                "text-secondary-color-hover": string;
                "text-secondary-color-focus": string;
                "text-secondary-color-disabled": string;
                "text-secondary-color-darker": string;
                "text-secondary-color-darker-hover": string;
                "text-secondary-color-darker-focus": string;
                "text-secondary-color-darker-disabled": string;
                "bg-primary-color-lighter": string;
                "bg-primary-color-lighter-hover": string;
                "bg-primary-color-lighter-focus": string;
                "bg-primary-color-lighter-disabled": string;
                "bg-primary-color": string;
                "bg-primary-color-hover": string;
                "bg-primary-color-focus": string;
                "bg-primary-color-disabled": string;
                "bg-primary-color-darker": string;
                "bg-primary-color-darker-hover": string;
                "bg-primary-color-darker-focus": string;
                "bg-primary-color-darker-disabled": string;
                "bg-secondary-color-lighter": string;
                "bg-secondary-color-lighter-hover": string;
                "bg-secondary-color-lighter-focus": string;
                "bg-secondary-color-lighter-disabled": string;
                "bg-secondary-color": string;
                "bg-secondary-color-hover": string;
                "bg-secondary-color-focus": string;
                "bg-secondary-color-disabled": string;
                "bg-secondary-color-darker": string;
                "bg-secondary-color-darker-hover": string;
                "bg-secondary-color-darker-focus": string;
                "bg-secondary-color-darker-disabled": string;
                "grey-color-lighter": string;
                "grey-color-light": string;
                "grey-color": string;
                "grey-color-dark": string;
                "grey-color-darker": string;
                "error-color": string;
                "error-color-hover": string;
                "error-color-focus": string;
                "error-color-disabled": string;
                "success-color": string;
                "success-color-hover": string;
                "success-color-focus": string;
                "success-color-disabled": string;
                "warning-color": string;
                "warning-color-hover": string;
                "warning-color-focus": string;
                "warning-color-disabled": string;
                "info-color": string;
                "info-color-hover": string;
                "info-color-focus": string;
                "info-color-disabled": string;
                "active-color": string;
                "active-color-hover": string;
                "active-color-focus": string;
                "active-color-disabled": string;
                "link-color": string;
                "link-color-hover": string;
                "link-color-focus": string;
                "link-color-disabled": string;
                "_dark-text-primary-color-lighter": string;
                "_dark-text-primary-color-lighter-hover": string;
                "_dark-text-primary-color-lighter-focus": string;
                "_dark-text-primary-color-lighter-disabled": string;
                "_dark-text-primary-color": string;
                "_dark-text-primary-color-hover": string;
                "_dark-text-primary-color-focus": string;
                "_dark-text-primary-color-disabled": string;
                "_dark-text-primary-color-darker": string;
                "_dark-text-primary-color-darker-hover": string;
                "_dark-text-primary-color-darker-focus": string;
                "_dark-text-primary-color-darker-disabled": string;
                "_dark-text-secondary-color-lighter": string;
                "_dark-text-secondary-color-lighter-hover": string;
                "_dark-text-secondary-color-lighter-focus": string;
                "_dark-text-secondary-color-lighter-disabled": string;
                "_dark-text-secondary-color": string;
                "_dark-text-secondary-color-hover": string;
                "_dark-text-secondary-color-focus": string;
                "_dark-text-secondary-color-disabled": string;
                "_dark-text-secondary-color-darker": string;
                "_dark-text-secondary-color-darker-hover": string;
                "_dark-text-secondary-color-darker-focus": string;
                "_dark-text-secondary-color-darker-disabled": string;
                "_dark-bg-primary-color-lighter": string;
                "_dark-bg-primary-color-lighter-hover": string;
                "_dark-bg-primary-color-lighter-focus": string;
                "_dark-bg-primary-color-lighter-disabled": string;
                "_dark-bg-primary-color": string;
                "_dark-bg-primary-color-hover": string;
                "_dark-bg-primary-color-focus": string;
                "_dark-bg-primary-color-disabled": string;
                "_dark-bg-primary-color-darker": string;
                "_dark-bg-primary-color-darker-hover": string;
                "_dark-bg-primary-color-darker-focus": string;
                "_dark-bg-primary-color-darker-disabled": string;
                "_dark-bg-secondary-color-lighter": string;
                "_dark-bg-secondary-color-lighter-hover": string;
                "_dark-bg-secondary-color-lighter-focus": string;
                "_dark-bg-secondary-color-lighter-disabled": string;
                "_dark-bg-secondary-color": string;
                "_dark-bg-secondary-color-hover": string;
                "_dark-bg-secondary-color-focus": string;
                "_dark-bg-secondary-color-disabled": string;
                "_dark-bg-secondary-color-darker": string;
                "_dark-bg-secondary-color-darker-hover": string;
                "_dark-bg-secondary-color-darker-focus": string;
                "_dark-bg-secondary-color-darker-disabled": string;
                "_dark-grey-color-lighter": string;
                "_dark-grey-color-light": string;
                "_dark-grey-color": string;
                "_dark-grey-color-dark": string;
                "_dark-grey-color-darker": string;
                "_dark-error-color": string;
                "_dark-error-color-hover": string;
                "_dark-error-color-focus": string;
                "_dark-error-color-disabled": string;
                "_dark-success-color": string;
                "_dark-success-color-hover": string;
                "_dark-success-color-focus": string;
                "_dark-success-color-disabled": string;
                "_dark-warning-color": string;
                "_dark-warning-color-hover": string;
                "_dark-warning-color-focus": string;
                "_dark-warning-color-disabled": string;
                "_dark-info-color": string;
                "_dark-info-color-hover": string;
                "_dark-info-color-focus": string;
                "_dark-info-color-disabled": string;
                "_dark-active-color": string;
                "_dark-active-color-hover": string;
                "_dark-active-color-focus": string;
                "_dark-active-color-disabled": string;
                "_dark-link-color": string;
                "_dark-link-color-hover": string;
                "_dark-link-color-focus": string;
                "_dark-link-color-disabled": string;
            };
            global: {
                "breakpoint-small": string;
                "breakpoint-medium": string;
                "breakpoint-large": string;
                "transition-slow": string;
                "transition-normal": string;
                "transition-fast": string;
                "space-base-unit": string;
                "space-8": string;
                "space-16": string;
                "space-24": string;
                "space-32": string;
                "space-40": string;
                "space-48": string;
                "space-64": string;
            };
            typography: {
                "font-base-unit": string;
                "font-family-primary": string;
                "font-family-secondary": string;
                "font-size-12": string;
                "font-size-16": string;
                "font-size-20": string;
                "font-size-24": string;
                "font-size-40": string;
                "font-size-48": string;
                "font-size-64": string;
                "line-height-base-unit": string;
                "line-height-small": string;
                "line-height-medium": string;
                "line-height-large": string;
                "font-weight-lighter": string;
                "font-weight-light": string;
                "font-weight-normal": string;
                "font-weight-bold": string;
                "font-weight-bolder": string;
            };
        };
    };
}
