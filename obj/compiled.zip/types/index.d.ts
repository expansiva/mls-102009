declare module "_102009_admin.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_admin" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_admin extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_agendamento.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_agendamento" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_agendamento extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_catalogo.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_catalogo" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_catalogo extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_contato.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_contato" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_contato extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102009_home.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_home" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_home extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_login.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_login" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_login extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_organismBanner.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismBanner" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismBanner extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismBuscaProdutos.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismBuscaProdutos" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismBuscaProdutos extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismChamadaAgendamento.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismChamadaAgendamento" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismChamadaAgendamento extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismConfirmacaoPagamento.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismConfirmacaoPagamento" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismConfirmacaoPagamento extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismDestaquesProdutos.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismDestaquesProdutos" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismDestaquesProdutos extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismFiltroCategorias.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismFiltroCategorias" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismFiltroCategorias extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismFooter.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismFooter" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismFooter extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismFormAgendamento.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismFormAgendamento" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismFormAgendamento extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismFormContato.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismFormContato" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismFormContato extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismFormLogin.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismFormLogin" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismFormLogin extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismFormPagamento.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismFormPagamento" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismFormPagamento extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismGerenciarAgendamentos.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismGerenciarAgendamentos" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismGerenciarAgendamentos extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismGerenciarProdutos.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismGerenciarProdutos" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismGerenciarProdutos extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismGerenciarUsuarios.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismGerenciarUsuarios" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismGerenciarUsuarios extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismHistoricoAgendamentos.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismHistoricoAgendamentos" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismHistoricoAgendamentos extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismInfoContato.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismInfoContato" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismInfoContato extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismListaProdutos.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismListaProdutos" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismListaProdutos extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismLoginSocial.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismLoginSocial" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismLoginSocial extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismMenuAdmin.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismMenuAdmin" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismMenuAdmin extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismNav.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismNav" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismNav extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismNavAdmin.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismNavAdmin" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismNavAdmin extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismRecuperarSenha.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismRecuperarSenha" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismRecuperarSenha extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismRedesSociais.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismRedesSociais" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismRedesSociais extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismResumoPedido.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismResumoPedido" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismResumoPedido extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_organismServicosDestaque.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismServicosDestaque" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismServicosDestaque extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
declare module "_102009_pagamento.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_pagamento" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_pagamento extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_tableAgendamento.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Agendamento {
        id: number;
        data: string;
        hora: string;
        servico: string;
        clienteId: number;
        status: string;
        details: AgendamentoDetails;
    }
    export interface AgendamentoDetails {
        observacoes?: string;
        canceladoPor?: string;
        reagendadoParaId?: number;
    }
}
declare module "_102009_tableAgendamento" {
    export interface Agendamento {
        id: number;
        data: string;
        hora: string;
        servico: string;
        clienteId: number;
        status: string;
        details: AgendamentoDetails;
    }
    export interface AgendamentoDetails {
        observacoes?: string;
        canceladoPor?: string;
        reagendadoParaId?: number;
    }
    export const modelPrisma = "\nmodel Agendamento {\n  id Int @id @default(autoincrement())\n  data DateTime\n  hora String\n  servico String \n  clienteId Int \n  status String\n}\n";
}
declare module "_102009_tableCategoria.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Categoria {
        id: number;
        nome: string;
        details: CategoriaDetails;
    }
    export interface CategoriaDetails {
        descricao?: string;
        produtosIds?: number[];
    }
}
declare module "_102009_tableCategoria" {
    export interface Categoria {
        id: number;
        nome: string;
        details: CategoriaDetails;
    }
    export interface CategoriaDetails {
        descricao?: string;
        produtosIds?: number[];
    }
    export const modelPrisma = "\nmodel Categoria {\n  id Int @id @default(autoincrement())\n  nome String\n}\n";
}
declare module "_102009_tableContato.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Contato {
        id: number;
        nome: string;
        email: string;
        mensagem: string;
        dataEnvio: string;
        details: ContatoDetails;
    }
    export interface ContatoDetails {
        respondido?: boolean;
        resposta?: string;
    }
}
declare module "_102009_tableContato" {
    export interface Contato {
        id: number;
        nome: string;
        email: string;
        mensagem: string;
        dataEnvio: string;
        details: ContatoDetails;
    }
    export interface ContatoDetails {
        respondido?: boolean;
        resposta?: string;
    }
    export const modelPrisma = "\nmodel Contato {\n  id Int @id @default(autoincrement())\n  nome String \n  email String \n  mensagem String \n  dataEnvio DateTime\n}\n";
}
declare module "_102009_tableItempedido.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface ItemPedido {
        id: number;
        pedidoId: number;
        produtoId: number;
        quantidade: number;
        precoUnitario: number;
        details: ItemPedidoDetails;
    }
    export interface ItemPedidoDetails {
        observacoes?: string;
    }
}
declare module "_102009_tableItempedido" {
    export interface ItemPedido {
        id: number;
        pedidoId: number;
        produtoId: number;
        quantidade: number;
        precoUnitario: number;
        details: ItemPedidoDetails;
    }
    export interface ItemPedidoDetails {
        observacoes?: string;
    }
    export const modelPrisma = "\nmodel ItemPedido {\n  id Int @id @default(autoincrement())\n  pedidoId Int \n  produtoId Int \n  quantidade Int \n  precoUnitario Float\n}\n";
}
declare module "_102009_tablePagamento.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Pagamento {
        id: number;
        pedidoId: number;
        metodo: string;
        dados: any;
        status?: string;
        details: PagamentoDetails;
    }
    export interface PagamentoDetails {
        comprovanteUrl?: string;
        gatewayRetorno?: any;
    }
}
declare module "_102009_tablePagamento" {
    export interface Pagamento {
        id: number;
        pedidoId: number;
        metodo: string;
        dados: any;
        status?: string;
        details: PagamentoDetails;
    }
    export interface PagamentoDetails {
        comprovanteUrl?: string;
        gatewayRetorno?: any;
    }
    export const modelPrisma = "\nmodel Pagamento {\n  id Int @id @default(autoincrement())\n  pedidoId Int \n  metodo String \n  dados Json \n  status String?\n}\n";
}
declare module "_102009_tablePedido.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Pedido {
        id: number;
        usuarioId: number;
        valorTotal: number;
        status?: string;
        dataCriacao: string;
        details: PedidoDetails;
    }
    export interface PedidoDetails {
        itensPedidoIds?: number[];
        pagamentoId?: number;
    }
}
declare module "_102009_tablePedido" {
    export interface Pedido {
        id: number;
        usuarioId: number;
        valorTotal: number;
        status?: string;
        dataCriacao: string;
        details: PedidoDetails;
    }
    export interface PedidoDetails {
        itensPedidoIds?: number[];
        pagamentoId?: number;
    }
    export const modelPrisma = "\nmodel Pedido {\n  id Int @id @default(autoincrement())\n  usuarioId Int \n  valorTotal Float \n  status String? \n  dataCriacao DateTime\n}\n";
}
declare module "_102009_tableProduto.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Produto {
        id: number;
        nome: string;
        descricao?: string;
        preco: number;
        estoque: number;
        categoriaId: number;
        imagem?: string;
        destaque?: boolean;
        details: ProdutoDetails;
    }
    export interface ProdutoDetails {
        tags?: string[];
        comentariosIds?: number[];
    }
}
declare module "_102009_tableProduto" {
    export interface Produto {
        id: number;
        nome: string;
        descricao?: string;
        preco: number;
        estoque: number;
        categoriaId: number;
        imagem?: string;
        destaque?: boolean;
        details: ProdutoDetails;
    }
    export interface ProdutoDetails {
        tags?: string[];
        comentariosIds?: number[];
    }
    export const modelPrisma = "\nmodel Produto {\n  id Int @id @default(autoincrement())\n  nome String \n  descricao String? \n  preco Float \n  estoque Int \n  categoriaId Int \n  imagem String? \n  destaque Boolean?\n}\n";
}
declare module "_102009_tableUsuario.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Usuario {
        id: number;
        nome: string;
        email: string;
        senha?: string;
        tipo: string;
        status?: string;
        facebookId?: string;
        instagramId?: string;
        details: UsuarioDetails;
    }
    export interface UsuarioDetails {
        historicoAgendamentos?: number[];
        historicoPedidos?: number[];
        endereco?: string;
        telefone?: string;
    }
}
declare module "_102009_tableUsuario" {
    export interface Usuario {
        id: number;
        nome: string;
        email: string;
        senha?: string;
        tipo: string;
        status?: string;
        facebookId?: string;
        instagramId?: string;
        details: UsuarioDetails;
    }
    export interface UsuarioDetails {
        historicoAgendamentos?: number[];
        historicoPedidos?: number[];
        endereco?: string;
        telefone?: string;
    }
    export const modelPrisma = "\nmodel Usuario {\n  id Int @id @default(autoincrement())\n  nome String email String senha String? tipo String status String? facebookId String? instagramId String?\n}\n";
}
