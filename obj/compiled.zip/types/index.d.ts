declare module "_102009_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102009_tableAgendamento.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Agendamento {
        id: number;
        data: string;
        hora: string;
        servico: string;
        clienteId: number;
        status: string;
        details: AgendamentoDetails;
    }
    export interface AgendamentoDetails {
        observacoes?: string;
        canceladoPor?: string;
        reagendadoParaId?: number;
    }
}
declare module "_102009_tableAgendamento" {
    export interface Agendamento {
        id: number;
        data: string;
        hora: string;
        servico: string;
        clienteId: number;
        status: string;
        details: AgendamentoDetails;
    }
    export interface AgendamentoDetails {
        observacoes?: string;
        canceladoPor?: string;
        reagendadoParaId?: number;
    }
    export const modelPrisma = "\nmodel Agendamento {\n  id Int @id @default(autoincrement())\n  data DateTime\n  hora String\n  servico String \n  clienteId Int \n  status String\n}\n";
}
declare module "_102009_tableCategoria.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Categoria {
        id: number;
        nome: string;
        details: CategoriaDetails;
    }
    export interface CategoriaDetails {
        descricao?: string;
        produtosIds?: number[];
    }
}
declare module "_102009_tableCategoria" {
    export interface Categoria {
        id: number;
        nome: string;
        details: CategoriaDetails;
    }
    export interface CategoriaDetails {
        descricao?: string;
        produtosIds?: number[];
    }
    export const modelPrisma = "\nmodel Categoria {\n  id Int @id @default(autoincrement())\n  nome String\n}\n";
}
declare module "_102009_tableContato.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Contato {
        id: number;
        nome: string;
        email: string;
        mensagem: string;
        dataEnvio: string;
        details: ContatoDetails;
    }
    export interface ContatoDetails {
        respondido?: boolean;
        resposta?: string;
    }
}
declare module "_102009_tableContato" {
    export interface Contato {
        id: number;
        nome: string;
        email: string;
        mensagem: string;
        dataEnvio: string;
        details: ContatoDetails;
    }
    export interface ContatoDetails {
        respondido?: boolean;
        resposta?: string;
    }
    export const modelPrisma = "\nmodel Contato {\n  id Int @id @default(autoincrement())\n  nome String \n  email String \n  mensagem String \n  dataEnvio DateTime\n}\n";
}
declare module "_102009_tableItempedido.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface ItemPedido {
        id: number;
        pedidoId: number;
        produtoId: number;
        quantidade: number;
        precoUnitario: number;
        details: ItemPedidoDetails;
    }
    export interface ItemPedidoDetails {
        observacoes?: string;
    }
}
declare module "_102009_tableItempedido" {
    export interface ItemPedido {
        id: number;
        pedidoId: number;
        produtoId: number;
        quantidade: number;
        precoUnitario: number;
        details: ItemPedidoDetails;
    }
    export interface ItemPedidoDetails {
        observacoes?: string;
    }
    export const modelPrisma = "\nmodel ItemPedido {\n  id Int @id @default(autoincrement())\n  pedidoId Int \n  produtoId Int \n  quantidade Int \n  precoUnitario Float\n}\n";
}
declare module "_102009_tablePagamento.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Pagamento {
        id: number;
        pedidoId: number;
        metodo: string;
        dados: any;
        status?: string;
        details: PagamentoDetails;
    }
    export interface PagamentoDetails {
        comprovanteUrl?: string;
        gatewayRetorno?: any;
    }
}
declare module "_102009_tablePagamento" {
    export interface Pagamento {
        id: number;
        pedidoId: number;
        metodo: string;
        dados: any;
        status?: string;
        details: PagamentoDetails;
    }
    export interface PagamentoDetails {
        comprovanteUrl?: string;
        gatewayRetorno?: any;
    }
    export const modelPrisma = "\nmodel Pagamento {\n  id Int @id @default(autoincrement())\n  pedidoId Int \n  metodo String \n  dados Json \n  status String?\n}\n";
}
declare module "_102009_tablePedido.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Pedido {
        id: number;
        usuarioId: number;
        valorTotal: number;
        status?: string;
        dataCriacao: string;
        details: PedidoDetails;
    }
    export interface PedidoDetails {
        itensPedidoIds?: number[];
        pagamentoId?: number;
    }
}
declare module "_102009_tablePedido" {
    export interface Pedido {
        id: number;
        usuarioId: number;
        valorTotal: number;
        status?: string;
        dataCriacao: string;
        details: PedidoDetails;
    }
    export interface PedidoDetails {
        itensPedidoIds?: number[];
        pagamentoId?: number;
    }
    export const modelPrisma = "\nmodel Pedido {\n  id Int @id @default(autoincrement())\n  usuarioId Int \n  valorTotal Float \n  status String? \n  dataCriacao DateTime\n}\n";
}
declare module "_102009_tableProduto.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Produto {
        id: number;
        nome: string;
        descricao?: string;
        preco: number;
        estoque: number;
        categoriaId: number;
        imagem?: string;
        destaque?: boolean;
        details: ProdutoDetails;
    }
    export interface ProdutoDetails {
        tags?: string[];
        comentariosIds?: number[];
    }
}
declare module "_102009_tableProduto" {
    export interface Produto {
        id: number;
        nome: string;
        descricao?: string;
        preco: number;
        estoque: number;
        categoriaId: number;
        imagem?: string;
        destaque?: boolean;
        details: ProdutoDetails;
    }
    export interface ProdutoDetails {
        tags?: string[];
        comentariosIds?: number[];
    }
    export const modelPrisma = "\nmodel Produto {\n  id Int @id @default(autoincrement())\n  nome String \n  descricao String? \n  preco Float \n  estoque Int \n  categoriaId Int \n  imagem String? \n  destaque Boolean?\n}\n";
}
declare module "_102009_tableUsuario.defs" {
    export const defs: mls.l4.BaseDefs;
    export interface Usuario {
        id: number;
        nome: string;
        email: string;
        senha?: string;
        tipo: string;
        status?: string;
        facebookId?: string;
        instagramId?: string;
        details: UsuarioDetails;
    }
    export interface UsuarioDetails {
        historicoAgendamentos?: number[];
        historicoPedidos?: number[];
        endereco?: string;
        telefone?: string;
    }
}
declare module "_102009_tableUsuario" {
    export interface Usuario {
        id: number;
        nome: string;
        email: string;
        senha?: string;
        tipo: string;
        status?: string;
        facebookId?: string;
        instagramId?: string;
        details: UsuarioDetails;
    }
    export interface UsuarioDetails {
        historicoAgendamentos?: number[];
        historicoPedidos?: number[];
        endereco?: string;
        telefone?: string;
    }
    export const modelPrisma = "\nmodel Usuario {\n  id Int @id @default(autoincrement())\n  nome String email String senha String? tipo String status String? facebookId String? instagramId String?\n}\n";
}
