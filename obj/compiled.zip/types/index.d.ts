declare module "_102009_admin.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_admin" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_admin extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_agendamento.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_agendamento" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_agendamento extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_carrinho.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_carrinho" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_carrinho extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_checkout.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_checkout" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_checkout extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102009_home.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_home" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_home extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_loja.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_loja" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_loja extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_organismAddToCart.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismAddToCart" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismAddToCart extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismAdminAppointments.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismAdminAppointments" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismAdminAppointments extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismAdminCustomers.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismAdminCustomers" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismAdminCustomers extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismAdminNav.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismAdminNav" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismAdminNav extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismAdminProducts.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismAdminProducts" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismAdminProducts extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismAdminServices.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismAdminServices" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismAdminServices extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismAdminSidebar.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismAdminSidebar" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismAdminSidebar extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismAppointmentConfirmation.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismAppointmentConfirmation" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismAppointmentConfirmation extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismAppointmentForm.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismAppointmentForm" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismAppointmentForm extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismAppointmentsHistory.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismAppointmentsHistory" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismAppointmentsHistory extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismBanner.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismBanner" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismBanner extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismBusinessHours.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismBusinessHours" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismBusinessHours extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismCartActions.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismCartActions" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismCartActions extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismCartList.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismCartList" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismCartList extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismCartSummary.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismCartSummary" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismCartSummary extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismCategoryFilter.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismCategoryFilter" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismCategoryFilter extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismCheckoutConfirmation.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismCheckoutConfirmation" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismCheckoutConfirmation extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismCheckoutForm.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismCheckoutForm" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismCheckoutForm extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismFooterInfo.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismFooterInfo" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismFooterInfo extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismNav.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismNav" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismNav extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismOrderSummary.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismOrderSummary" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismOrderSummary extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismOrdersHistory.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismOrdersHistory" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismOrdersHistory extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismPaymentMethods.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismPaymentMethods" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismPaymentMethods extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismPetProfiles.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismPetProfiles" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismPetProfiles extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismPetSelector.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismPetSelector" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismPetSelector extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismProductDetails.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismProductDetails" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismProductDetails extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismProductList.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismProductList" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismProductList extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismProductSearch.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismProductSearch" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismProductSearch extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismProductsHighlight.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismProductsHighlight" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismProductsHighlight extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismQuickAccess.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismQuickAccess" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismQuickAccess extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismServiceDetails.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismServiceDetails" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismServiceDetails extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismServicesHighlight.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismServicesHighlight" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismServicesHighlight extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismServicesList.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismServicesList" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismServicesList extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismTestimonials.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismTestimonials" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismTestimonials extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_organismUserProfile.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_organismUserProfile" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class _102009_organismUserProfile extends IcaOrganismBase {
        render(): any;
    }
}
declare module "_102009_perfil.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_perfil" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_perfil extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_produto.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_produto" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_produto extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102009_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_project" {
    export const payload3: {
        finalModuleDetails: {
            userLanguage: string;
            executionRegions: string;
            userPrompt: string;
            moduleGoal: string;
            moduleName: string;
            requirements: string[];
            userRequestsEnhancements: {
                description: string;
                priority: string;
            }[];
        };
        pages: {
            pageSequential: number;
            pageName: string;
            pageGoal: string;
            pageRequirements: string[];
        }[];
        plugins: {
            pluginSequential: number;
            pluginName: string;
            pluginType: string;
            pluginGoal: string;
            pluginRequirements: string[];
        }[];
        pagesWireframe: {
            pageSequential: number;
            pageName: string;
            pageHtml: string[];
        }[];
        organism: ({
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                    }[];
                }[];
                constraints: string[];
            };
        } | {
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                    }[];
                }[];
                constraints?: undefined;
            };
        })[];
        visualIdentity: {
            logoDescription: string;
            fontFamily: string;
            iconStyle: string;
            illustrationStyle: string;
            colorPalette: {
                primary: string;
                secondary: string;
                text: string;
                background: string;
                border: string;
                error: string;
                warning: string;
                success: string;
            };
        };
        tokens: {
            description: string;
            themeName: string;
            color: {
                "color-primary": string;
                "color-secondary": string;
                "color-accent": string;
                "color-background": string;
                "color-surface": string;
                "color-text-normal": string;
                "color-text-secondary": string;
                "color-text-disabled": string;
                "color-border": string;
                "color-link-normal": string;
                "color-link-hover": string;
                "color-link-visited": string;
                "color-overlay": string;
                "color-error": string;
                "color-warning": string;
                "color-success": string;
                "_dark-color-primary": string;
                "_dark-color-secondary": string;
                "_dark-color-accent": string;
                "_dark-color-background": string;
                "_dark-color-surface": string;
                "_dark-color-text-normal": string;
                "_dark-color-text-secondary": string;
                "_dark-color-text-disabled": string;
                "_dark-color-border": string;
                "_dark-color-link-normal": string;
                "_dark-color-link-hover": string;
                "_dark-color-link-visited": string;
                "_dark-color-overlay": string;
                "_dark-color-error": string;
                "_dark-color-warning": string;
                "_dark-color-success": string;
            };
            global: {
                "spacing-xxs": string;
                "spacing-xs": string;
                "spacing-sm": string;
                "spacing-md": string;
                "spacing-lg": string;
                "spacing-xl": string;
                "spacing-xxl": string;
                "border-radius-xs": string;
                "border-radius-sm": string;
                "border-radius-md": string;
                "border-radius-lg": string;
                "shadow-sm": string;
                "shadow-md": string;
                "shadow-lg": string;
                "transition-base": string;
                "transition-fast": string;
                "transition-slow": string;
                "z-index-modal": string;
                "z-index-tooltip": string;
                "z-index-dropdown": string;
            };
            typography: {
                "font-family-primary": string;
                "font-family-secondary": string;
                "font-size-xs": string;
                "font-size-sm": string;
                "font-size-md": string;
                "font-size-lg": string;
                "font-size-xl": string;
                "font-size-xxl": string;
                "font-weight-light": string;
                "font-weight-normal": string;
                "font-weight-bold": string;
                "line-height-xs": string;
                "line-height-sm": string;
                "line-height-md": string;
                "line-height-lg": string;
            };
        };
    };
}
declare module "_102009_servicos.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "_102009_servicos" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class _102009_servicos extends CollabPageElement {
        initPage(): void;
    }
}
