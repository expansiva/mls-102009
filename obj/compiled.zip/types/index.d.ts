declare module "_102009_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102009_organismServicosDestaque" {
    import { IcaOrganismWireframeBase } from './_100554_icaOrganismWireframeBase';
    export class _102009_organismServicosDestaque extends IcaOrganismWireframeBase {
        generalDescription: string | undefined;
        goal: string | undefined;
    }
}
