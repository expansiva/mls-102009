declare module "_102009_designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102009_layer1Context.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer4Scheduling" {
    export interface SchedulingData {
        id?: number;
        data: SchedulingRecord;
        version?: string;
    }
    export enum SchedulingStatus {
        'PENDING' = "PENDING",
        'CONFIRMED' = "CONFIRMED",
        'COMPLETED' = "COMPLETED",
        'CANCELED' = "CANCELED"
    }
    export interface SchedulingRecord {
        clientMdmId: number;
        petMdmId: number;
        serviceMdmId: number;
        startDateTime: string;
        endDateTime?: string;
        status: SchedulingStatus;
        serviceOrderId: number | null;
        jsonBin: {
            tutor: {
                name: string;
                phone: string;
            };
            pet: {
                name: string;
                species: string;
                breed: string;
                allergies: string[];
            };
            service: {
                name: string;
                serviceCode?: string;
            };
            employee?: {
                name: string;
                description: string;
            };
            notes?: string;
        };
    }
}
declare module "_102009_layer4ResReqBase" {
    export interface RequestBase {
        action: ActionTypes;
        params?: Record<string, any>;
        version: string;
        inDeveloped: boolean;
    }
    export interface ResponseBase {
        statusCode: number;
        ok: boolean;
        data?: any;
        error?: string;
    }
    export type ActionTypes = 'SchedulingAdd' | 'SchedulingUpd' | 'SchedulingDel' | 'SchedulingList' | 'SchedulingGetById' | 'SchedulingGetByClient' | 'ServiceOrderAdd' | 'ServiceOrderUpd' | 'ServiceOrderDel' | 'ServiceOrderList' | 'ServiceOrderGetById';
}
declare module "_102009_layer4SchedulingBase" {
    import { SchedulingData } from "_102009_layer4Scheduling";
    import { RequestBase } from "_102009_layer4ResReqBase";
    export interface SchedulingBase {
        upd: (param: SchedulingData) => Promise<SchedulingData | null>;
        add: (param: SchedulingData) => Promise<SchedulingData | null>;
        del: (id: number) => Promise<boolean>;
        list: () => Promise<SchedulingData[]>;
        getById: (id: number) => Promise<SchedulingData | null>;
        listByClient: (clientId: number) => Promise<SchedulingData[]>;
    }
    export interface RequestSchedulingAdd extends RequestBase {
        action: 'SchedulingAdd';
        params: SchedulingData;
    }
    export interface RequestSchedulingUpd extends RequestBase {
        action: 'SchedulingUpd';
        params: SchedulingData;
    }
    export interface RequestSchedulingDel extends RequestBase {
        action: 'SchedulingDel';
        params: {
            id: number;
        };
    }
    export interface RequestSchedulingList extends RequestBase {
        action: 'SchedulingList';
    }
    export interface RequestSchedulingGetById extends RequestBase {
        action: 'SchedulingGetById';
        params: {
            id: number;
        };
    }
    export interface RequestSchedulingGetByClient extends RequestBase {
        action: 'SchedulingGetByClient';
        params: {
            clientId: number;
        };
    }
}
declare module "_102009_layer1IndexedDb" {
    export const DB_NAME = "PetshopDB";
    export const VERSION = 4;
    export const STORE_NAME_SCHEDULING = "scheduling_data";
    export const STORE_NAME_SERVICEORDER = "service_order_data";
    export function openDB(): Promise<IDBDatabase>;
}
declare module "_102009_layer1SchedulingDB" {
    import { SchedulingBase } from "_102009_layer4SchedulingBase";
    import { SchedulingData } from "_102009_layer4Scheduling";
    class Scheduling implements SchedulingBase {
        upd(param: SchedulingData): Promise<SchedulingData | null>;
        add(param: SchedulingData): Promise<SchedulingData | null>;
        del(id: number): Promise<boolean>;
        list(): Promise<SchedulingData[]>;
        getById(id: number): Promise<SchedulingData | null>;
        recordCount(): Promise<number>;
        listByClient(clientId: number): Promise<SchedulingData[]>;
        private saveSchedulingData;
        private getRecordCount;
        private getSchedulingData;
        private getAllSchedulingData;
        private deleteSchedulingData;
        private getRecordsByClient;
    }
    export const scheduling: Scheduling;
}
declare module "_102009_layer4ServiceOrder" {
    export interface ServiceOrderData {
        id?: number;
        data: ServiceOrderRecord;
        version?: string;
    }
    export enum ServiceOrderStatus {
        'WAITING' = "WAITING",
        'IN_PROGRESS' = "IN_PROGRESS",
        'READY_FOR_COLLECTION' = "READY_FOR_COLLECTION",
        'BILLED' = "BILLED",
        'CANCELED' = "CANCELED"
    }
    interface ServiceOrderRecord {
        schedulingId: number;
        clientMdmId: number;
        petMdmId: number;
        employeeMdmId: number;
        serviceMdmId: number;
        executionDateTime: string;
        status: ServiceOrderStatus;
        totalAmount: number;
        jsonBin: ServiceOrderJsonBin;
    }
    interface ServiceOrderJsonBin {
        client: {
            name: string;
            phone: string;
        };
        pet: {
            name: string;
            breed: string;
        };
        employee: {
            name: string;
        };
        serviceProvided: ServiceProvided;
        notes: string;
        isExternalAuthorization: boolean;
        history: ServiceOrderHistoryEntry[];
    }
    interface ServiceOrderHistoryEntry {
        date: string;
        description: string;
        login: string;
    }
    interface ServiceProvided {
        name: string;
        priceCharged: number;
    }
}
declare module "_102009_layer4ServiceOrderBase" {
    import { ServiceOrderData } from "_102009_layer4ServiceOrder";
    import { RequestBase } from "_102009_layer4ResReqBase";
    export interface ServiceOrderBase {
        upd: (param: ServiceOrderData) => Promise<ServiceOrderData | null>;
        add: (param: ServiceOrderData) => Promise<ServiceOrderData | null>;
        del: (id: number) => Promise<boolean>;
        list: () => Promise<ServiceOrderData[]>;
        getById: (id: number) => Promise<ServiceOrderData | null>;
    }
    export interface RequestServiceOrderAdd extends RequestBase {
        action: 'ServiceOrderAdd';
        params: ServiceOrderData;
    }
    export interface RequestServiceOrderUpd extends RequestBase {
        action: 'ServiceOrderUpd';
        params: ServiceOrderData;
    }
    export interface RequestServiceOrderDel extends RequestBase {
        action: 'ServiceOrderDel';
        params: {
            id: number;
        };
    }
    export interface RequestServiceOrderList extends RequestBase {
        action: 'ServiceOrderList';
    }
    export interface RequestServiceOrderGetById extends RequestBase {
        action: 'ServiceOrderGetById';
        params: {
            id: number;
        };
    }
}
declare module "_102009_layer1ServiceOrderDB" {
    import { ServiceOrderBase } from "_102009_layer4ServiceOrderBase";
    import { ServiceOrderData } from "_102009_layer4ServiceOrder";
    class ServiceOrder implements ServiceOrderBase {
        upd(param: ServiceOrderData): Promise<ServiceOrderData | null>;
        add(param: ServiceOrderData): Promise<ServiceOrderData | null>;
        del(id: number): Promise<boolean>;
        list(): Promise<ServiceOrderData[]>;
        getById(id: number): Promise<ServiceOrderData | null>;
        private saveServiceOrderData;
        private getServiceOrderData;
        private getAllServiceOrderData;
        private deleteServiceOrderData;
    }
    export const serviceOrder: ServiceOrder;
}
declare module "_102009_layer1Context" {
    import { SchedulingBase } from "_102009_layer4SchedulingBase";
    import { ServiceOrderBase } from "_102009_layer4ServiceOrderBase";
    import { RequestBase } from "_102009_layer4ResReqBase";
    export function createContext(param: RequestBase): Ctx;
    export interface Ctx {
        io: {
            scheduling: SchedulingBase;
            serviceOrder: ServiceOrderBase;
        };
    }
}
declare module "_102009_layer1Exec.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3AddScheduling" {
    import { SchedulingData } from "_102009_layer4Scheduling";
    import { Ctx } from "_102009_layer1Context";
    export function addScheduling(ctx: Ctx, data: SchedulingData): Promise<SchedulingData | null>;
}
declare module "_102009_layer2AddScheduling" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function addScheduling(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer3UpdScheduling" {
    import { SchedulingData } from "_102009_layer4Scheduling";
    import { Ctx } from "_102009_layer1Context";
    export function updScheduling(ctx: Ctx, data: SchedulingData): Promise<SchedulingData | null>;
}
declare module "_102009_layer2UpdScheduling" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function updScheduling(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer3DelScheduling" {
    import { Ctx } from "_102009_layer1Context";
    export function delScheduling(ctx: Ctx, id: number): Promise<boolean>;
}
declare module "_102009_layer2DelScheduling" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function delScheduling(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer3ListScheduling" {
    import { SchedulingData } from "_102009_layer4Scheduling";
    import { Ctx } from "_102009_layer1Context";
    export function listScheduling(ctx: Ctx): Promise<SchedulingData[]>;
}
declare module "_102009_layer2ListScheduling" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function listScheduling(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer3GetByIdScheduling" {
    import { SchedulingData } from "_102009_layer4Scheduling";
    import { Ctx } from "_102009_layer1Context";
    export function getByIdScheduling(ctx: Ctx, id: number): Promise<SchedulingData | null>;
}
declare module "_102009_layer2GetByIdScheduling" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function getByIdScheduling(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer3GetByClientScheduling" {
    import { SchedulingData } from "_102009_layer4Scheduling";
    import { Ctx } from "_102009_layer1Context";
    export function getByClientScheduling(ctx: Ctx, clientId: number): Promise<SchedulingData[] | null>;
}
declare module "_102009_layer2GetByClientScheduling" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function getByClientScheduling(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer3AddServiceOrder" {
    import { ServiceOrderData } from "_102009_layer4ServiceOrder";
    import { Ctx } from "_102009_layer1Context";
    export function addServiceOrder(ctx: Ctx, data: ServiceOrderData): Promise<ServiceOrderData | null>;
}
declare module "_102009_layer2AddServiceOrder" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function addServiceOrder(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer3UpdServiceOrder" {
    import { ServiceOrderData } from "_102009_layer4ServiceOrder";
    import { Ctx } from "_102009_layer1Context";
    export function updServiceOrder(ctx: Ctx, data: ServiceOrderData): Promise<ServiceOrderData | null>;
}
declare module "_102009_layer2UpdServiceOrder" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function updServiceOrder(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer3DelServiceOrder" {
    import { Ctx } from "_102009_layer1Context";
    export function delServiceOrder(ctx: Ctx, id: number): Promise<boolean>;
}
declare module "_102009_layer2DelServiceOrder" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function delServiceOrder(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer3ListServiceOrder" {
    import { ServiceOrderData } from "_102009_layer4ServiceOrder";
    import { Ctx } from "_102009_layer1Context";
    export function listServiceOrder(ctx: Ctx): Promise<ServiceOrderData[]>;
}
declare module "_102009_layer2ListServiceOrder" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function listServiceOrder(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer3GetByIdServiceOrder" {
    import { ServiceOrderData } from "_102009_layer4ServiceOrder";
    import { Ctx } from "_102009_layer1Context";
    export function getByIdServiceOrder(ctx: Ctx, id: number): Promise<ServiceOrderData | null>;
}
declare module "_102009_layer2GetByIdServiceOrder" {
    import { Ctx } from "_102009_layer1Context";
    import { ResponseBase } from "_102009_layer4ResReqBase";
    export function getByIdServiceOrder(ctx: Ctx, data: Record<string, any> | undefined): Promise<ResponseBase>;
}
declare module "_102009_layer1Exec" {
    import { RequestBase, ResponseBase } from "_102009_layer4ResReqBase";
    export function petshopExec(param: RequestBase): Promise<ResponseBase>;
}
declare module "_102009_layer1IndexedDb.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer1SchedulingDB.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer1ServiceOrderDB.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2AddScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2AddServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2DelScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2DelServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2GetByClientScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2GetByIdScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2GetByIdServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2ListScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2ListServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2UpdScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer2UpdServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3AddScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3AddServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3DelScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3DelServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3GetByClientScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3GetByIdScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3GetByIdServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3ListScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3ListServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3UpdScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer3UpdServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer4ResReqBase.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer4Scheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer4SchedulingBase.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer4ServiceOrder.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_layer4ServiceOrderBase.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_project" {
    export const modules: {
        name: string;
    }[];
}
declare module "crm/_102009_organismAttachmentsAdd.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_adminPanel.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_adminPanel.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_adminPanel" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PageAdminPanel extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_module.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
    };
    export const payload3: {
        finalModuleDetails: {
            userLanguage: string;
            executionRegions: string;
            userPrompt: string;
            moduleGoal: string;
            moduleName: string;
            requirements: string[];
            userRequestsEnhancements: {
                description: string;
                priority: string;
            }[];
        };
        pages: {
            pageSequential: number;
            pageName: string;
            pageGoal: string;
            pageRequirements: string[];
        }[];
        plugins: {
            pluginSequential: number;
            pluginName: string;
            pluginType: string;
            pluginGoal: string;
            pluginRequirements: string[];
        }[];
        pagesWireframe: {
            pageSequential: number;
            pageName: string;
            pageHtml: string[];
        }[];
        organism: ({
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                    }[];
                }[];
                constraints: string[];
            };
        } | {
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                    }[];
                }[];
                constraints?: undefined;
            };
        })[];
        visualIdentity: {
            logoDescription: string;
            fontFamily: string;
            iconStyle: string;
            illustrationStyle: string;
            colorPalette: {
                primary: string;
                secondary: string;
                text: string;
                background: string;
                border: string;
                error: string;
                warning: string;
                success: string;
            };
        };
        tokens: {
            description: string;
            themeName: string;
            color: {
                "text-primary-color-lighter": string;
                "text-primary-color-lighter-hover": string;
                "text-primary-color-lighter-focus": string;
                "text-primary-color-lighter-disabled": string;
                "text-primary-color": string;
                "text-primary-color-hover": string;
                "text-primary-color-focus": string;
                "text-primary-color-disabled": string;
                "text-primary-color-darker": string;
                "text-primary-color-darker-hover": string;
                "text-primary-color-darker-focus": string;
                "text-primary-color-darker-disabled": string;
                "text-secondary-color-lighter": string;
                "text-secondary-color-lighter-hover": string;
                "text-secondary-color-lighter-focus": string;
                "text-secondary-color-lighter-disabled": string;
                "text-secondary-color": string;
                "text-secondary-color-hover": string;
                "text-secondary-color-focus": string;
                "text-secondary-color-disabled": string;
                "text-secondary-color-darker": string;
                "text-secondary-color-darker-hover": string;
                "text-secondary-color-darker-focus": string;
                "text-secondary-color-darker-disabled": string;
                "bg-primary-color-lighter": string;
                "bg-primary-color-lighter-hover": string;
                "bg-primary-color-lighter-focus": string;
                "bg-primary-color-lighter-disabled": string;
                "bg-primary-color": string;
                "bg-primary-color-hover": string;
                "bg-primary-color-focus": string;
                "bg-primary-color-disabled": string;
                "bg-primary-color-darker": string;
                "bg-primary-color-darker-hover": string;
                "bg-primary-color-darker-focus": string;
                "bg-primary-color-darker-disabled": string;
                "bg-secondary-color-lighter": string;
                "bg-secondary-color-lighter-hover": string;
                "bg-secondary-color-lighter-focus": string;
                "bg-secondary-color-lighter-disabled": string;
                "bg-secondary-color": string;
                "bg-secondary-color-hover": string;
                "bg-secondary-color-focus": string;
                "bg-secondary-color-disabled": string;
                "bg-secondary-color-darker": string;
                "bg-secondary-color-darker-hover": string;
                "bg-secondary-color-darker-focus": string;
                "bg-secondary-color-darker-disabled": string;
                "grey-color-lighter": string;
                "grey-color-light": string;
                "grey-color": string;
                "grey-color-dark": string;
                "grey-color-darker": string;
                "error-color": string;
                "error-color-hover": string;
                "error-color-focus": string;
                "error-color-disabled": string;
                "success-color": string;
                "success-color-hover": string;
                "success-color-focus": string;
                "success-color-disabled": string;
                "warning-color": string;
                "warning-color-hover": string;
                "warning-color-focus": string;
                "warning-color-disabled": string;
                "info-color": string;
                "info-color-hover": string;
                "info-color-focus": string;
                "info-color-disabled": string;
                "active-color": string;
                "active-color-hover": string;
                "active-color-focus": string;
                "active-color-disabled": string;
                "link-color": string;
                "link-color-hover": string;
                "link-color-focus": string;
                "link-color-disabled": string;
                "_dark-text-primary-color-lighter": string;
                "_dark-text-primary-color-lighter-hover": string;
                "_dark-text-primary-color-lighter-focus": string;
                "_dark-text-primary-color-lighter-disabled": string;
                "_dark-text-primary-color": string;
                "_dark-text-primary-color-hover": string;
                "_dark-text-primary-color-focus": string;
                "_dark-text-primary-color-disabled": string;
                "_dark-text-primary-color-darker": string;
                "_dark-text-primary-color-darker-hover": string;
                "_dark-text-primary-color-darker-focus": string;
                "_dark-text-primary-color-darker-disabled": string;
                "_dark-text-secondary-color-lighter": string;
                "_dark-text-secondary-color-lighter-hover": string;
                "_dark-text-secondary-color-lighter-focus": string;
                "_dark-text-secondary-color-lighter-disabled": string;
                "_dark-text-secondary-color": string;
                "_dark-text-secondary-color-hover": string;
                "_dark-text-secondary-color-focus": string;
                "_dark-text-secondary-color-disabled": string;
                "_dark-text-secondary-color-darker": string;
                "_dark-text-secondary-color-darker-hover": string;
                "_dark-text-secondary-color-darker-focus": string;
                "_dark-text-secondary-color-darker-disabled": string;
                "_dark-bg-primary-color-lighter": string;
                "_dark-bg-primary-color-lighter-hover": string;
                "_dark-bg-primary-color-lighter-focus": string;
                "_dark-bg-primary-color-lighter-disabled": string;
                "_dark-bg-primary-color": string;
                "_dark-bg-primary-color-hover": string;
                "_dark-bg-primary-color-focus": string;
                "_dark-bg-primary-color-disabled": string;
                "_dark-bg-primary-color-darker": string;
                "_dark-bg-primary-color-darker-hover": string;
                "_dark-bg-primary-color-darker-focus": string;
                "_dark-bg-primary-color-darker-disabled": string;
                "_dark-bg-secondary-color-lighter": string;
                "_dark-bg-secondary-color-lighter-hover": string;
                "_dark-bg-secondary-color-lighter-focus": string;
                "_dark-bg-secondary-color-lighter-disabled": string;
                "_dark-bg-secondary-color": string;
                "_dark-bg-secondary-color-hover": string;
                "_dark-bg-secondary-color-focus": string;
                "_dark-bg-secondary-color-disabled": string;
                "_dark-bg-secondary-color-darker": string;
                "_dark-bg-secondary-color-darker-hover": string;
                "_dark-bg-secondary-color-darker-focus": string;
                "_dark-bg-secondary-color-darker-disabled": string;
                "_dark-grey-color-lighter": string;
                "_dark-grey-color-light": string;
                "_dark-grey-color": string;
                "_dark-grey-color-dark": string;
                "_dark-grey-color-darker": string;
                "_dark-error-color": string;
                "_dark-error-color-hover": string;
                "_dark-error-color-focus": string;
                "_dark-error-color-disabled": string;
                "_dark-success-color": string;
                "_dark-success-color-hover": string;
                "_dark-success-color-focus": string;
                "_dark-success-color-disabled": string;
                "_dark-warning-color": string;
                "_dark-warning-color-hover": string;
                "_dark-warning-color-focus": string;
                "_dark-warning-color-disabled": string;
                "_dark-info-color": string;
                "_dark-info-color-hover": string;
                "_dark-info-color-focus": string;
                "_dark-info-color-disabled": string;
                "_dark-active-color": string;
                "_dark-active-color-hover": string;
                "_dark-active-color-focus": string;
                "_dark-active-color-disabled": string;
                "_dark-link-color": string;
                "_dark-link-color-hover": string;
                "_dark-link-color-focus": string;
                "_dark-link-color-disabled": string;
            };
            global: {
                "breakpoint-small": string;
                "breakpoint-medium": string;
                "breakpoint-large": string;
                "transition-slow": string;
                "transition-normal": string;
                "transition-fast": string;
                "space-base-unit": string;
                "space-8": string;
                "space-16": string;
                "space-24": string;
                "space-32": string;
                "space-40": string;
                "space-48": string;
                "space-64": string;
            };
            typography: {
                "font-base-unit": string;
                "font-family-primary": string;
                "font-family-secondary": string;
                "font-size-12": string;
                "font-size-16": string;
                "font-size-20": string;
                "font-size-24": string;
                "font-size-40": string;
                "font-size-48": string;
                "font-size-64": string;
                "line-height-base-unit": string;
                "line-height-small": string;
                "line-height-medium": string;
                "line-height-large": string;
                "font-weight-lighter": string;
                "font-weight-light": string;
                "font-weight-normal": string;
                "font-weight-bold": string;
                "font-weight-bolder": string;
            };
        };
    };
}
declare module "petshop/_102009_organismAboutPetshop.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAboutPetshop.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAboutPetshop" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAboutPetshop extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminAddProduct.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminAddProduct" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAddProduct extends IcaOrganismBase {
        loading: boolean;
        nameProduct?: string;
        descriptionShort?: string;
        labelError?: string;
        labelOk?: string;
        action?: string;
        link?: HTMLAnchorElement;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(_key: string, _value: any): void;
        render(): any;
        private handleClickBack;
        private delay;
        private clearErrors;
        private handleClickSave;
    }
}
declare module "petshop/_102009_organismAdminAddService.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminAddService" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAddService extends IcaOrganismBase {
        loading: boolean;
        nameService?: string;
        descriptionShort?: string;
        serviceCode?: string;
        labelError?: string;
        labelOk?: string;
        action?: string;
        link?: HTMLAnchorElement;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(_key: string, _value: any): void;
        render(): any;
        private handleClickBack;
        private delay;
        private clearErrors;
        private handleClickSave;
    }
}
declare module "petshop/_102009_organismAdminBookings.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminBookings.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminBookings" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class OrganismAdminBookings extends IcaOrganismBase {
        mode: 'only-list' | 'with-filter';
        filterMode: 'today' | 'week' | '';
        private search;
        private statusFilter;
        private filterService;
        private filterDateStart;
        private filterDateEnd;
        private schedulings;
        private filtered;
        private currentPage;
        labelError?: string;
        labelOk?: string;
        linkToEdit?: HTMLAnchorElement;
        private pageSize;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private handleEdit;
        private handleSearch;
        private handleStatusFilter;
        private handleDateStartFilter;
        private handleDateEndFilter;
        private handleServiceFilter;
        private applyFilters;
        private get paginated();
        private nextPage;
        private prevPage;
        render(): any;
        private getStatusCls;
        private getStatusLabel;
        private getUniqueServices;
    }
}
declare module "petshop/_102009_organismAdminContent.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminContent.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminContent" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAdminContent extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminDashboard.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminDashboard.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminDashboard" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAdminDashboard extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminNav.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminNav.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminNav" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class OrganismAdminNav extends IcaOrganismBase {
        selected: IMenuItens;
        avatarUrl?: string;
        userName?: string;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private onMenuClick;
    }
    type IMenuItens = 'dashboard' | 'scheduling' | 'product' | 'service';
}
declare module "petshop/_102009_organismAdminOrderEdit.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminOrderEdit.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminOrderEdit" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { ServiceOrderData } from './_102009_layer4ServiceOrder';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismAdminOrderEdit extends IcaOrganismBase {
        loading: boolean;
        orderData?: ServiceOrderData;
        employees: MdmData[];
        service?: MdmData;
        labelError?: string;
        labelOk?: string;
        action?: string;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onChangeStatus;
        private onChangeBilling;
        private onChangeEmployer;
        private getService;
        private getEmployers;
    }
}
declare module "petshop/_102009_organismAdminProductEdit.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminProductEdit.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminProductEdit" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismAdminProductEdit extends IcaOrganismBase {
        loading: boolean;
        mdmData?: MdmData;
        nameProduct?: string;
        descriptionShort?: string;
        sku?: string;
        barcode?: string;
        category?: string;
        subcategory?: string;
        unitOfMeasure?: string;
        petSuitability?: string[];
        productDetails?: string;
        labelError?: string;
        labelOk?: string;
        action?: string;
        link?: HTMLAnchorElement;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private handleInputChange;
        private clearErrors;
        private handleClickSave;
    }
}
declare module "petshop/_102009_organismAdminProductList.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminProductList.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminProductList" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismAdminProductList extends IcaOrganismBase {
        mdmProducts?: MdmData[];
        filterText: string;
        sortColumn: string;
        sortDirection: 'asc' | 'desc';
        currentPage: number;
        itemsPerPage: number;
        linkToEdit?: HTMLAnchorElement;
        firstUpdated(): Promise<void>;
        get filteredProducts(): MdmData[];
        get sortedProducts(): MdmData[];
        get totalPages(): number;
        get paginatedProducts(): MdmData[];
        get visiblePages(): any[];
        handleSort(column: string): void;
        handleEdit(e: MouseEvent, product: MdmData): void;
        handlePrevPage(): void;
        handleNextPage(): void;
        handlePageClick(page: number): void;
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminProducts.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminProducts.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminProducts" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAdminProducts extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminScheduling.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminScheduling" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismAdminScheduling extends IcaOrganismBase {
        loading: boolean;
        labelError?: string;
        labelOk?: string;
        searchText?: string;
        userSelected?: MdmData;
        petSelected?: MdmData;
        serviceSelected?: MdmData;
        date?: string;
        action?: string;
        users: MdmData[];
        pets: MdmData[];
        services: MdmData[];
        currentStep: 'user-selection' | 'scheduling';
        link?: HTMLAnchorElement;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(_key: string, _value: any): void;
        render(): any;
        private renderSelectUser;
        private renderAddScheduling;
        private handleContinue;
        private handleBack;
        private getMyPets;
        private getServices;
        private handleSave;
        private handleSearch;
    }
}
declare module "petshop/_102009_organismAdminServiceEdit.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminServiceEdit.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminServiceEdit" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismAdminServiceEdit extends IcaOrganismBase {
        loading: boolean;
        mdmData?: MdmData;
        nameService?: string;
        descriptionShort?: string;
        serviceCode?: string;
        category?: string;
        priceRegular?: string;
        priceSubscription?: string;
        durationMinutes?: string;
        speciesSuitability?: string[];
        sizeSuitability?: string[];
        requiredResources?: string[];
        employeeCommission?: string;
        labelError?: string;
        labelOk?: string;
        action?: string;
        link?: HTMLAnchorElement;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private handleInputChange;
        private handleSelectMultipleChange;
        private clearErrors;
        private handleClickSave;
    }
}
declare module "petshop/_102009_organismAdminServicesList.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminServicesList.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminServicesList" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismAdminServicesList extends IcaOrganismBase {
        mdmServices?: MdmData[];
        filterText: string;
        sortColumn: string;
        sortDirection: 'asc' | 'desc';
        currentPage: number;
        itemsPerPage: number;
        linkToEdit?: HTMLAnchorElement;
        firstUpdated(): Promise<void>;
        get filteredServices(): MdmData[];
        get sortedServices(): MdmData[];
        get totalPages(): number;
        get paginatedServices(): MdmData[];
        get visiblePages(): any[];
        handleSort(column: string): void;
        handleEdit(e: MouseEvent, service: MdmData): void;
        handlePrevPage(): void;
        handleNextPage(): void;
        handlePageClick(page: number): void;
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminSidebar.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminSidebar.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminSidebar" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAdminSidebar extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismBookingForm.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismBookingForm.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismBookingForm" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismBookingForm extends IcaOrganismBase {
        meusagendamentos: HTMLElement | undefined;
        mdmData: MdmData | undefined;
        myPets: MdmData[];
        services: MdmData[];
        error: string;
        loading: boolean;
        petIndex: number;
        serviceIndex: number;
        data: string;
        horario: string;
        firstUpdated(): void;
        render(): any;
        private init;
        private loadInfos;
        private getMyPets;
        private getServices;
        private handleClickSave;
    }
}
declare module "petshop/_102009_organismBookingInfo.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismBookingInfo.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismBookingInfo" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismBookingInfo extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismCartSummary.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismCartSummary.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismCartSummary" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismCartSummary extends IcaOrganismBase {
        carProducts: MdmData[];
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(_key: string, _value: any): void;
        render(): any;
        renderItem(prod: MdmData, index: number): any;
        private handleClickDel;
    }
}
declare module "petshop/_102009_organismContactDetails.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismContactDetails.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismContactDetails" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismContactDetails extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismContactForm.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismContactForm.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismContactForm" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismContactForm extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismEditScheduling.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismEditScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismEditScheduling" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { SchedulingData } from './_102009_layer4Scheduling';
    import { ServiceOrderData } from './_102009_layer4ServiceOrder';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismEditScheduling extends IcaOrganismBase {
        loadingCancel: boolean;
        loadingConfirm: boolean;
        schedulingData?: SchedulingData;
        employees: MdmData[];
        employerSelected?: MdmData;
        service?: MdmData;
        orderData?: ServiceOrderData;
        labelError?: string;
        labelOk?: string;
        action?: string;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderOrderService;
        private getService;
        private getOrderData;
        private getEmployers;
        private handleClickCancel;
        private handleClickGenerateOS;
        private updateScheduling;
    }
}
declare module "petshop/_102009_organismFeaturedProducts.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismFeaturedProducts.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismFeaturedProducts" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismFeaturedProducts extends IcaOrganismBase {
        mdmProducts: MdmData[];
        firstUpdated(): Promise<void>;
        render(): any;
        renderItem(prod: MdmData, index: number): any;
        private init;
        private loadProd;
    }
}
declare module "petshop/_102009_organismFeaturedServices.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismFeaturedServices.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismFeaturedServices" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismFeaturedServices extends IcaOrganismBase {
        mdmServices: MdmData[];
        firstUpdated(): Promise<void>;
        render(): any;
        renderItem(serv: MdmData, index: number): any;
        private init;
        private loadServ;
    }
}
declare module "petshop/_102009_organismFooterInfo.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismFooterInfo.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismFooterInfo" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismFooterInfo extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismHeroBanner.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismHeroBanner.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismHeroBanner" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismHeroBanner extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismMenuPerfil.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismMenuPerfil.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismMenuPerfil" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismMenuPerfil extends IcaOrganismBase {
        active: string;
        render(): any;
    }
}
declare module "petshop/_102009_organismNav.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismNav.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismNav" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismNav extends IcaOrganismBase {
        mdmData: MdmData | undefined;
        name: string;
        img?: string;
        firstUpdated(): void;
        render(): any;
        private init;
    }
}
declare module "petshop/_102009_organismProductFilters.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismProductFilters.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismProductFilters" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismProductFilters extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismProductList.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismProductList.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismProductList" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismProductList extends IcaOrganismBase {
        mdmProducts: MdmData[];
        carProducts: MdmData[];
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(_key: string, _value: any): void;
        firstUpdated(): Promise<void>;
        render(): any;
        renderItem(prod: MdmData, index: number): any;
        private loadProd;
        private handleClickAdd;
    }
}
declare module "petshop/_102009_organismSimulateLogin.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismSimulateLogin.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismSimulateLogin" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismSimulateLogin extends IcaOrganismBase {
        users: MdmData[];
        enterprise: MdmData[];
        firstUpdated(): void;
        render(): any;
        private init;
        private handleSimulateClick;
        private importIndexedDB;
        private clearIndexedDB;
    }
}
declare module "petshop/_102009_organismViewIdentifyPf.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismViewIdentifyPf.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismViewIdentifyPf" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismViewIdentifyPf extends IcaOrganismBase {
        mdm: MdmData | undefined;
        loading: boolean;
        error?: string;
        img?: string;
        name?: string;
        cpf?: string;
        email?: string;
        telefone?: string;
        rua?: string;
        bairro?: string;
        estado?: string;
        cidade?: string;
        numero?: string;
        firstUpdated(): void;
        render(): any;
        private init;
        private setInitialValues;
        private handleClickSave;
    }
}
declare module "petshop/_102009_organismViewMyAppointments.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismViewMyAppointments.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismViewMyAppointments" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { SchedulingData } from './_102009_layer4Scheduling';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismViewMyAppointments extends IcaOrganismBase {
        scenary: string;
        mdmData: MdmData | undefined;
        scheduling: SchedulingData[];
        error: string;
        indexDetail: number;
        filterData: string;
        firstUpdated(): void;
        render(): any;
        renderList(): any;
        renderItem(sch: SchedulingData, index: number): any;
        renderEdit(): any;
        private init;
        private loadInfos;
        private getScheduling;
        private changeScneray;
        private getDataHorario;
        private handleClickCancel;
    }
}
declare module "petshop/_102009_organismViewMyPets.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismViewMyPets.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismViewMyPets" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    import { MdmData } from "./_102019_layer4Mdm";
    export class organismViewMyPets extends IcaOrganismBase {
        private editIndex;
        mdmData: MdmData | undefined;
        scenary: string;
        error: string;
        loading: boolean;
        myPets: MdmData[];
        filterTp: string;
        filterTxt: string;
        namePet?: string;
        species?: string;
        breed?: string;
        private specie;
        firstUpdated(): void;
        render(): any;
        renderList(): any;
        renderItem(pet: MdmData, idx: number): any;
        renderEdit(): any;
        private init;
        private changeScneray;
        private edit;
        private handleClickSave;
        private updateReg;
        private addRelationship;
        private updateMyStates;
        private getMyPets;
    }
}
declare module "petshop/_102009_pageAdminAddProduct.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAdminAddProduct" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageAdminAddProduct102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageAdminAddService.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAdminAddService" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageAdminAddService102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageAdminDashboard.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAdminDashboard" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageAdminDashboard102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageAdminEditProduct.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAdminEditProduct" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageAdminEditProduct102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageAdminEditScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAdminEditScheduling" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageAdminEditScheduling102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageAdminEditService.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAdminEditService" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageAdminEditService102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageAdminProduct.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAdminProduct" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageAdminProduct102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageAdminScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAdminScheduling" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageAdminScheduling102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageAdminSchedulingAdd.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAdminSchedulingAdd" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageAdminSchedulingAdd102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageAdminService.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAdminService" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageAdminService102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageAppointments.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_pageAppointments.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageAppointments" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PageAppointments extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageContact.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_pageContact.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageContact" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PageContact extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageHome.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_pageHome.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageHome" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PageHome extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageLogin.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageLogin" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageLogin102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pagePerfil.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_pagePerfil.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pagePerfil" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PagePerfil extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pagePerfilAppointments.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pagePerfilAppointments" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class pagePerfilAppointments extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pagePerfilPets.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pagePerfilPets" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class pagePerfilPets extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_pageProduct.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_pageProduct.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageProduct" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PageProduct extends CollabPageElement {
        initPage(): void;
    }
}
