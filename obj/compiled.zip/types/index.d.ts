declare module "_102009_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_/l2/designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102009_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_/l2/project" {
    export const modules: {
        name: string;
        path: string;
        auth: string;
        icon: string;
    }[];
}
declare module "_102009_/l2/crm/organismAttachmentsAdd.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_/l2/petshop/module.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_/l2/petshop/module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: {
            pageName: string;
            title: string;
            auth: string;
            icon: string;
        }[];
    };
    export const payload3: {
        finalModuleDetails: {
            userLanguage: string;
            executionRegions: string;
            userPrompt: string;
            moduleGoal: string;
            moduleName: string;
            requirements: string[];
            userRequestsEnhancements: {
                description: string;
                priority: string;
            }[];
        };
        pages: {
            pageSequential: number;
            pageName: string;
            pageGoal: string;
            pageRequirements: string[];
        }[];
        plugins: {
            pluginSequential: number;
            pluginName: string;
            pluginType: string;
            pluginGoal: string;
            pluginRequirements: string[];
        }[];
        pagesWireframe: {
            pageSequential: number;
            pageName: string;
            pageHtml: string[];
        }[];
        organism: ({
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                    }[];
                }[];
                constraints: string[];
            };
        } | {
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                    }[];
                }[];
                constraints?: undefined;
            };
        })[];
        visualIdentity: {
            logoDescription: string;
            fontFamily: string;
            iconStyle: string;
            illustrationStyle: string;
            colorPalette: {
                primary: string;
                secondary: string;
                text: string;
                background: string;
                border: string;
                error: string;
                warning: string;
                success: string;
            };
        };
        tokens: {
            description: string;
            themeName: string;
            color: {
                "text-primary-color-lighter": string;
                "text-primary-color-lighter-hover": string;
                "text-primary-color-lighter-focus": string;
                "text-primary-color-lighter-disabled": string;
                "text-primary-color": string;
                "text-primary-color-hover": string;
                "text-primary-color-focus": string;
                "text-primary-color-disabled": string;
                "text-primary-color-darker": string;
                "text-primary-color-darker-hover": string;
                "text-primary-color-darker-focus": string;
                "text-primary-color-darker-disabled": string;
                "text-secondary-color-lighter": string;
                "text-secondary-color-lighter-hover": string;
                "text-secondary-color-lighter-focus": string;
                "text-secondary-color-lighter-disabled": string;
                "text-secondary-color": string;
                "text-secondary-color-hover": string;
                "text-secondary-color-focus": string;
                "text-secondary-color-disabled": string;
                "text-secondary-color-darker": string;
                "text-secondary-color-darker-hover": string;
                "text-secondary-color-darker-focus": string;
                "text-secondary-color-darker-disabled": string;
                "bg-primary-color-lighter": string;
                "bg-primary-color-lighter-hover": string;
                "bg-primary-color-lighter-focus": string;
                "bg-primary-color-lighter-disabled": string;
                "bg-primary-color": string;
                "bg-primary-color-hover": string;
                "bg-primary-color-focus": string;
                "bg-primary-color-disabled": string;
                "bg-primary-color-darker": string;
                "bg-primary-color-darker-hover": string;
                "bg-primary-color-darker-focus": string;
                "bg-primary-color-darker-disabled": string;
                "bg-secondary-color-lighter": string;
                "bg-secondary-color-lighter-hover": string;
                "bg-secondary-color-lighter-focus": string;
                "bg-secondary-color-lighter-disabled": string;
                "bg-secondary-color": string;
                "bg-secondary-color-hover": string;
                "bg-secondary-color-focus": string;
                "bg-secondary-color-disabled": string;
                "bg-secondary-color-darker": string;
                "bg-secondary-color-darker-hover": string;
                "bg-secondary-color-darker-focus": string;
                "bg-secondary-color-darker-disabled": string;
                "grey-color-lighter": string;
                "grey-color-light": string;
                "grey-color": string;
                "grey-color-dark": string;
                "grey-color-darker": string;
                "error-color": string;
                "error-color-hover": string;
                "error-color-focus": string;
                "error-color-disabled": string;
                "success-color": string;
                "success-color-hover": string;
                "success-color-focus": string;
                "success-color-disabled": string;
                "warning-color": string;
                "warning-color-hover": string;
                "warning-color-focus": string;
                "warning-color-disabled": string;
                "info-color": string;
                "info-color-hover": string;
                "info-color-focus": string;
                "info-color-disabled": string;
                "active-color": string;
                "active-color-hover": string;
                "active-color-focus": string;
                "active-color-disabled": string;
                "link-color": string;
                "link-color-hover": string;
                "link-color-focus": string;
                "link-color-disabled": string;
                "_dark-text-primary-color-lighter": string;
                "_dark-text-primary-color-lighter-hover": string;
                "_dark-text-primary-color-lighter-focus": string;
                "_dark-text-primary-color-lighter-disabled": string;
                "_dark-text-primary-color": string;
                "_dark-text-primary-color-hover": string;
                "_dark-text-primary-color-focus": string;
                "_dark-text-primary-color-disabled": string;
                "_dark-text-primary-color-darker": string;
                "_dark-text-primary-color-darker-hover": string;
                "_dark-text-primary-color-darker-focus": string;
                "_dark-text-primary-color-darker-disabled": string;
                "_dark-text-secondary-color-lighter": string;
                "_dark-text-secondary-color-lighter-hover": string;
                "_dark-text-secondary-color-lighter-focus": string;
                "_dark-text-secondary-color-lighter-disabled": string;
                "_dark-text-secondary-color": string;
                "_dark-text-secondary-color-hover": string;
                "_dark-text-secondary-color-focus": string;
                "_dark-text-secondary-color-disabled": string;
                "_dark-text-secondary-color-darker": string;
                "_dark-text-secondary-color-darker-hover": string;
                "_dark-text-secondary-color-darker-focus": string;
                "_dark-text-secondary-color-darker-disabled": string;
                "_dark-bg-primary-color-lighter": string;
                "_dark-bg-primary-color-lighter-hover": string;
                "_dark-bg-primary-color-lighter-focus": string;
                "_dark-bg-primary-color-lighter-disabled": string;
                "_dark-bg-primary-color": string;
                "_dark-bg-primary-color-hover": string;
                "_dark-bg-primary-color-focus": string;
                "_dark-bg-primary-color-disabled": string;
                "_dark-bg-primary-color-darker": string;
                "_dark-bg-primary-color-darker-hover": string;
                "_dark-bg-primary-color-darker-focus": string;
                "_dark-bg-primary-color-darker-disabled": string;
                "_dark-bg-secondary-color-lighter": string;
                "_dark-bg-secondary-color-lighter-hover": string;
                "_dark-bg-secondary-color-lighter-focus": string;
                "_dark-bg-secondary-color-lighter-disabled": string;
                "_dark-bg-secondary-color": string;
                "_dark-bg-secondary-color-hover": string;
                "_dark-bg-secondary-color-focus": string;
                "_dark-bg-secondary-color-disabled": string;
                "_dark-bg-secondary-color-darker": string;
                "_dark-bg-secondary-color-darker-hover": string;
                "_dark-bg-secondary-color-darker-focus": string;
                "_dark-bg-secondary-color-darker-disabled": string;
                "_dark-grey-color-lighter": string;
                "_dark-grey-color-light": string;
                "_dark-grey-color": string;
                "_dark-grey-color-dark": string;
                "_dark-grey-color-darker": string;
                "_dark-error-color": string;
                "_dark-error-color-hover": string;
                "_dark-error-color-focus": string;
                "_dark-error-color-disabled": string;
                "_dark-success-color": string;
                "_dark-success-color-hover": string;
                "_dark-success-color-focus": string;
                "_dark-success-color-disabled": string;
                "_dark-warning-color": string;
                "_dark-warning-color-hover": string;
                "_dark-warning-color-focus": string;
                "_dark-warning-color-disabled": string;
                "_dark-info-color": string;
                "_dark-info-color-hover": string;
                "_dark-info-color-focus": string;
                "_dark-info-color-disabled": string;
                "_dark-active-color": string;
                "_dark-active-color-hover": string;
                "_dark-active-color-focus": string;
                "_dark-active-color-disabled": string;
                "_dark-link-color": string;
                "_dark-link-color-hover": string;
                "_dark-link-color-focus": string;
                "_dark-link-color-disabled": string;
            };
            global: {
                "breakpoint-small": string;
                "breakpoint-medium": string;
                "breakpoint-large": string;
                "transition-slow": string;
                "transition-normal": string;
                "transition-fast": string;
                "space-base-unit": string;
                "space-8": string;
                "space-16": string;
                "space-24": string;
                "space-32": string;
                "space-40": string;
                "space-48": string;
                "space-64": string;
            };
            typography: {
                "font-base-unit": string;
                "font-family-primary": string;
                "font-family-secondary": string;
                "font-size-12": string;
                "font-size-16": string;
                "font-size-20": string;
                "font-size-24": string;
                "font-size-40": string;
                "font-size-48": string;
                "font-size-64": string;
                "line-height-base-unit": string;
                "line-height-small": string;
                "line-height-medium": string;
                "line-height-large": string;
                "font-weight-lighter": string;
                "font-weight-light": string;
                "font-weight-normal": string;
                "font-weight-bold": string;
                "font-weight-bolder": string;
            };
        };
    };
}
declare module "_102009_/l2/petshop/organismAdminAddService.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_/l2/petshop/organismAdminAddService" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAddService extends IcaOrganismBase {
        loading: boolean;
        nameService?: string;
        descriptionShort?: string;
        serviceCode?: string;
        labelError?: string;
        labelOk?: string;
        action?: string;
        link?: HTMLAnchorElement;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(_key: string, _value: any): void;
        render(): any;
        private handleClickBack;
        private delay;
        private clearErrors;
        private handleClickSave;
    }
}
