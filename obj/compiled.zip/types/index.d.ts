declare module "_102009_designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102009_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102009_project" {
    export const modules: {
        name: string;
    }[];
}
declare module "crm/_102009_organismAttachmentsAdd.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_adminPanel.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_adminPanel.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_adminPanel" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PageAdminPanel extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_agendamento.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_agendamento.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_agendamento" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PageAgendamento extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_contato.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_contato.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_contato" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PageContato extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_home.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_home.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_home" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PageHome extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_module.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
    };
    export const payload3: {
        finalModuleDetails: {
            userLanguage: string;
            executionRegions: string;
            userPrompt: string;
            moduleGoal: string;
            moduleName: string;
            requirements: string[];
            userRequestsEnhancements: {
                description: string;
                priority: string;
            }[];
        };
        pages: {
            pageSequential: number;
            pageName: string;
            pageGoal: string;
            pageRequirements: string[];
        }[];
        plugins: {
            pluginSequential: number;
            pluginName: string;
            pluginType: string;
            pluginGoal: string;
            pluginRequirements: string[];
        }[];
        pagesWireframe: {
            pageSequential: number;
            pageName: string;
            pageHtml: string[];
        }[];
        organism: ({
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                    }[];
                }[];
                constraints: string[];
            };
        } | {
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                    }[];
                }[];
                constraints?: undefined;
            };
        })[];
        visualIdentity: {
            logoDescription: string;
            fontFamily: string;
            iconStyle: string;
            illustrationStyle: string;
            colorPalette: {
                primary: string;
                secondary: string;
                text: string;
                background: string;
                border: string;
                error: string;
                warning: string;
                success: string;
            };
        };
        tokens: {
            description: string;
            themeName: string;
            color: {
                "text-primary-color-lighter": string;
                "text-primary-color-lighter-hover": string;
                "text-primary-color-lighter-focus": string;
                "text-primary-color-lighter-disabled": string;
                "text-primary-color": string;
                "text-primary-color-hover": string;
                "text-primary-color-focus": string;
                "text-primary-color-disabled": string;
                "text-primary-color-darker": string;
                "text-primary-color-darker-hover": string;
                "text-primary-color-darker-focus": string;
                "text-primary-color-darker-disabled": string;
                "text-secondary-color-lighter": string;
                "text-secondary-color-lighter-hover": string;
                "text-secondary-color-lighter-focus": string;
                "text-secondary-color-lighter-disabled": string;
                "text-secondary-color": string;
                "text-secondary-color-hover": string;
                "text-secondary-color-focus": string;
                "text-secondary-color-disabled": string;
                "text-secondary-color-darker": string;
                "text-secondary-color-darker-hover": string;
                "text-secondary-color-darker-focus": string;
                "text-secondary-color-darker-disabled": string;
                "bg-primary-color-lighter": string;
                "bg-primary-color-lighter-hover": string;
                "bg-primary-color-lighter-focus": string;
                "bg-primary-color-lighter-disabled": string;
                "bg-primary-color": string;
                "bg-primary-color-hover": string;
                "bg-primary-color-focus": string;
                "bg-primary-color-disabled": string;
                "bg-primary-color-darker": string;
                "bg-primary-color-darker-hover": string;
                "bg-primary-color-darker-focus": string;
                "bg-primary-color-darker-disabled": string;
                "bg-secondary-color-lighter": string;
                "bg-secondary-color-lighter-hover": string;
                "bg-secondary-color-lighter-focus": string;
                "bg-secondary-color-lighter-disabled": string;
                "bg-secondary-color": string;
                "bg-secondary-color-hover": string;
                "bg-secondary-color-focus": string;
                "bg-secondary-color-disabled": string;
                "bg-secondary-color-darker": string;
                "bg-secondary-color-darker-hover": string;
                "bg-secondary-color-darker-focus": string;
                "bg-secondary-color-darker-disabled": string;
                "grey-color-lighter": string;
                "grey-color-light": string;
                "grey-color": string;
                "grey-color-dark": string;
                "grey-color-darker": string;
                "error-color": string;
                "error-color-hover": string;
                "error-color-focus": string;
                "error-color-disabled": string;
                "success-color": string;
                "success-color-hover": string;
                "success-color-focus": string;
                "success-color-disabled": string;
                "warning-color": string;
                "warning-color-hover": string;
                "warning-color-focus": string;
                "warning-color-disabled": string;
                "info-color": string;
                "info-color-hover": string;
                "info-color-focus": string;
                "info-color-disabled": string;
                "active-color": string;
                "active-color-hover": string;
                "active-color-focus": string;
                "active-color-disabled": string;
                "link-color": string;
                "link-color-hover": string;
                "link-color-focus": string;
                "link-color-disabled": string;
                "_dark-text-primary-color-lighter": string;
                "_dark-text-primary-color-lighter-hover": string;
                "_dark-text-primary-color-lighter-focus": string;
                "_dark-text-primary-color-lighter-disabled": string;
                "_dark-text-primary-color": string;
                "_dark-text-primary-color-hover": string;
                "_dark-text-primary-color-focus": string;
                "_dark-text-primary-color-disabled": string;
                "_dark-text-primary-color-darker": string;
                "_dark-text-primary-color-darker-hover": string;
                "_dark-text-primary-color-darker-focus": string;
                "_dark-text-primary-color-darker-disabled": string;
                "_dark-text-secondary-color-lighter": string;
                "_dark-text-secondary-color-lighter-hover": string;
                "_dark-text-secondary-color-lighter-focus": string;
                "_dark-text-secondary-color-lighter-disabled": string;
                "_dark-text-secondary-color": string;
                "_dark-text-secondary-color-hover": string;
                "_dark-text-secondary-color-focus": string;
                "_dark-text-secondary-color-disabled": string;
                "_dark-text-secondary-color-darker": string;
                "_dark-text-secondary-color-darker-hover": string;
                "_dark-text-secondary-color-darker-focus": string;
                "_dark-text-secondary-color-darker-disabled": string;
                "_dark-bg-primary-color-lighter": string;
                "_dark-bg-primary-color-lighter-hover": string;
                "_dark-bg-primary-color-lighter-focus": string;
                "_dark-bg-primary-color-lighter-disabled": string;
                "_dark-bg-primary-color": string;
                "_dark-bg-primary-color-hover": string;
                "_dark-bg-primary-color-focus": string;
                "_dark-bg-primary-color-disabled": string;
                "_dark-bg-primary-color-darker": string;
                "_dark-bg-primary-color-darker-hover": string;
                "_dark-bg-primary-color-darker-focus": string;
                "_dark-bg-primary-color-darker-disabled": string;
                "_dark-bg-secondary-color-lighter": string;
                "_dark-bg-secondary-color-lighter-hover": string;
                "_dark-bg-secondary-color-lighter-focus": string;
                "_dark-bg-secondary-color-lighter-disabled": string;
                "_dark-bg-secondary-color": string;
                "_dark-bg-secondary-color-hover": string;
                "_dark-bg-secondary-color-focus": string;
                "_dark-bg-secondary-color-disabled": string;
                "_dark-bg-secondary-color-darker": string;
                "_dark-bg-secondary-color-darker-hover": string;
                "_dark-bg-secondary-color-darker-focus": string;
                "_dark-bg-secondary-color-darker-disabled": string;
                "_dark-grey-color-lighter": string;
                "_dark-grey-color-light": string;
                "_dark-grey-color": string;
                "_dark-grey-color-dark": string;
                "_dark-grey-color-darker": string;
                "_dark-error-color": string;
                "_dark-error-color-hover": string;
                "_dark-error-color-focus": string;
                "_dark-error-color-disabled": string;
                "_dark-success-color": string;
                "_dark-success-color-hover": string;
                "_dark-success-color-focus": string;
                "_dark-success-color-disabled": string;
                "_dark-warning-color": string;
                "_dark-warning-color-hover": string;
                "_dark-warning-color-focus": string;
                "_dark-warning-color-disabled": string;
                "_dark-info-color": string;
                "_dark-info-color-hover": string;
                "_dark-info-color-focus": string;
                "_dark-info-color-disabled": string;
                "_dark-active-color": string;
                "_dark-active-color-hover": string;
                "_dark-active-color-focus": string;
                "_dark-active-color-disabled": string;
                "_dark-link-color": string;
                "_dark-link-color-hover": string;
                "_dark-link-color-focus": string;
                "_dark-link-color-disabled": string;
            };
            global: {
                "breakpoint-small": string;
                "breakpoint-medium": string;
                "breakpoint-large": string;
                "transition-slow": string;
                "transition-normal": string;
                "transition-fast": string;
                "space-base-unit": string;
                "space-8": string;
                "space-16": string;
                "space-24": string;
                "space-32": string;
                "space-40": string;
                "space-48": string;
                "space-64": string;
            };
            typography: {
                "font-base-unit": string;
                "font-family-primary": string;
                "font-family-secondary": string;
                "font-size-12": string;
                "font-size-16": string;
                "font-size-20": string;
                "font-size-24": string;
                "font-size-40": string;
                "font-size-48": string;
                "font-size-64": string;
                "line-height-base-unit": string;
                "line-height-small": string;
                "line-height-medium": string;
                "line-height-large": string;
                "font-weight-lighter": string;
                "font-weight-light": string;
                "font-weight-normal": string;
                "font-weight-bold": string;
                "font-weight-bolder": string;
            };
        };
    };
}
declare module "petshop/_102009_organismAboutPetshop.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAboutPetshop.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAboutPetshop" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAboutPetshop extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminBookings.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminBookings.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminBookings" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAdminBookings extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminContent.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminContent.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminContent" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAdminContent extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminDashboard.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminDashboard.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminDashboard" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAdminDashboard extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminNav.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminNav.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminNav" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAdminNav extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminProducts.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminProducts.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminProducts" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAdminProducts extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismAdminSidebar.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismAdminSidebar.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismAdminSidebar" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismAdminSidebar extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismBookingForm.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismBookingForm.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismBookingForm" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismBookingForm extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismBookingInfo.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismBookingInfo.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismBookingInfo" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismBookingInfo extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismCartSummary.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismCartSummary.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismCartSummary" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismCartSummary extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismContactDetails.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismContactDetails.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismContactDetails" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismContactDetails extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismContactForm.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismContactForm.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismContactForm" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismContactForm extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismFeaturedProducts.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismFeaturedProducts.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismFeaturedProducts" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismFeaturedProducts extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismFeaturedServices.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismFeaturedServices.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismFeaturedServices" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismFeaturedServices extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismFooterInfo.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismFooterInfo.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismFooterInfo" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismFooterInfo extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismHeroBanner.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismHeroBanner.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismHeroBanner" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismHeroBanner extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismNav.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismNav.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismNav" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismNav extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismProductFilters.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismProductFilters.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismProductFilters" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismProductFilters extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismProductList.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismProductList.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismProductList" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismProductList extends IcaOrganismBase {
        render(): any;
    }
}
declare module "petshop/_102009_organismSimulateLogin.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_organismSimulateLogin.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_organismSimulateLogin" {
    import { IcaOrganismBase } from './_100554_icaOrganismBase';
    export class organismSimulateLogin extends IcaOrganismBase {
        private handleSimulateClick;
        render(): any;
    }
}
declare module "petshop/_102009_pageLogin.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_pageLogin" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class PageLogin102009 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102009_produtos.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102009_produtos.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102009_produtos" {
    import { CollabPageElement } from './_100554_collabPageElement';
    export class PageProdutos extends CollabPageElement {
        initPage(): void;
    }
}
